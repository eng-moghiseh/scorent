"use client";

import { AppShell } from "@/components/scorent/app-shell";

export default function Page() {
  return <AppShell />;
}
