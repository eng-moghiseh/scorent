"use client";

/* ————— کاور رویه‌ای بازی‌ها (Procedural Cover Art) —————
 * به‌جای تصاویر خارجیِ ناپایدار، هر بازی یک ترکیب‌بندی SVG اختصاصی دارد که
 * از پالت و موتیف خودش ساخته می‌شود: خروجی همیشه در دسترس، سبک و هماهنگ است.
 * عنوان بازی با املای اصلی (لاتین) روی کاور می‌نشیند.
 */

import { motion } from "framer-motion";
import type { CoverMotif, Game } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useGameText, useT } from "@/lib/i18n";

function MotifArt({ motif, colors, seed }: { motif: CoverMotif; colors: [string, string, string]; seed: number }) {
  const [, , accent] = colors;
  const key = `${motif}-${seed}`;
  switch (motif) {
    case "peaks":
      return (
        <g key={key}>
          <circle cx="200" cy="170" r="58" fill={accent} opacity="0.85" />
          <path d="M-20 430 L120 250 L210 380 L300 240 L420 430 Z" fill="#000" opacity="0.35" />
          <path d="M-20 430 L100 300 L200 430 Z" fill="#000" opacity="0.45" />
          <path d="M120 250 L150 288 L90 288 Z" fill={accent} opacity="0.6" />
          <path d="M300 240 L330 278 L270 278 Z" fill={accent} opacity="0.4" />
        </g>
      );
    case "orb":
      return (
        <g key={key}>
          <circle cx="200" cy="190" r="86" fill={accent} opacity="0.9" />
          <circle cx="200" cy="190" r="120" fill="none" stroke={accent} strokeWidth="2" opacity="0.5" />
          <ellipse cx="200" cy="190" rx="150" ry="46" fill="none" stroke="#fff" strokeWidth="1.4" opacity="0.35" transform="rotate(-18 200 190)" />
          <circle cx="296" cy="132" r="14" fill="#fff" opacity="0.7" />
        </g>
      );
    case "grid":
      return (
        <g key={key} opacity="0.9">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <path key={i} d={`M${-40 + i * 90} 440 L${60 + i * 60} 120`} stroke={accent} strokeWidth={i === 2 ? 3 : 1.2} opacity={0.16 + i * 0.08} fill="none" />
          ))}
          {[0, 1, 2, 3, 4].map((i) => (
            <path key={`h${i}`} d={`M0 ${200 + i * 62} Q200 ${168 + i * 62} 400 ${200 + i * 62}`} stroke="#fff" strokeWidth="1" opacity="0.14" fill="none" />
          ))}
          <rect x="164" y="150" width="72" height="108" rx="10" fill={accent} opacity="0.85" />
        </g>
      );
    case "waves":
      return (
        <g key={key}>
          {[0, 1, 2, 3, 4].map((i) => (
            <path
              key={i}
              d={`M-20 ${180 + i * 62} C 100 ${120 + i * 62}, 300 ${240 + i * 62}, 420 ${170 + i * 62}`}
              stroke={i === 2 ? accent : "#fff"}
              strokeWidth={i === 2 ? 4 : 1.4}
              opacity={i === 2 ? 0.85 : 0.16}
              fill="none"
            />
          ))}
          <circle cx="316" cy="120" r="40" fill={accent} opacity="0.85" />
        </g>
      );
    case "slashes":
      return (
        <g key={key}>
          <path d="M40 460 L250 60" stroke={accent} strokeWidth="10" strokeLinecap="round" opacity="0.9" />
          <path d="M120 470 L330 70" stroke="#fff" strokeWidth="4" strokeLinecap="round" opacity="0.3" />
          <path d="M200 470 L380 110" stroke={accent} strokeWidth="2" strokeLinecap="round" opacity="0.4" />
          <circle cx="268" cy="104" r="9" fill="#fff" opacity="0.8" />
        </g>
      );
    case "spiral":
      return (
        <g key={key} fill="none" strokeLinecap="round">
          {[96, 74, 52, 30].map((r, i) => (
            <path
              key={r}
              d={`M ${200 + r} 190 A ${r} ${r} 0 ${i % 2} 1 ${200 - r} 190`}
              stroke={i % 2 ? "#fff" : accent}
              strokeWidth={5 - i}
              opacity={0.85 - i * 0.14}
            />
          ))}
          <circle cx="200" cy="190" r="12" fill={accent} />
        </g>
      );
    case "shards":
      return (
        <g key={key}>
          {[
            [150, 140, 66, 20],
            [250, 200, 44, -14],
            [110, 260, 36, 30],
            [280, 300, 58, 10],
            [200, 210, 80, -8],
          ].map(([x, y, s, rot], i) => (
            <path
              key={i}
              d={`M${x} ${y - s / 2} L${x + s / 2.6} ${y + s / 2} L${x - s / 2.6} ${y + s / 2} Z`}
              fill={i % 2 ? accent : "#fff"}
              opacity={i === 4 ? 0.9 : 0.24 + i * 0.08}
              transform={`rotate(${rot} ${x} ${y})`}
            />
          ))}
        </g>
      );
    case "ring":
      return (
        <g key={key}>
          <circle cx="200" cy="190" r="96" fill="none" stroke={accent} strokeWidth="14" opacity="0.9" />
          <circle cx="200" cy="190" r="96" fill="none" stroke="#fff" strokeWidth="2" opacity="0.3" strokeDasharray="6 10" />
          <circle cx="292" cy="150" r="12" fill={accent} />
          <circle cx="126" cy="252" r="7" fill="#fff" opacity="0.65" />
        </g>
      );
    case "pips":
      return (
        <g key={key} fill={accent}>
          {Array.from({ length: 24 }).map((_, i) => {
            const x = 60 + (i % 6) * 56;
            const y = 110 + Math.floor(i / 6) * 56;
            const r = [7, 4, 9, 3, 6, 5][i % 6];
            return <circle key={i} cx={x} cy={y} r={r} opacity={0.25 + ((i * 7) % 10) * 0.075} />;
          })}
        </g>
      );
    case "arch":
      return (
        <g key={key} fill="none" strokeLinecap="round">
          {[110, 84, 58, 32].map((r, i) => (
            <path key={r} d={`M ${200 - r} 330 A ${r} ${r} 0 0 1 ${200 + r} 330`} stroke={i === 1 ? accent : "#fff"} strokeWidth={6 - i} opacity={0.7 - i * 0.1} />
          ))}
          <circle cx="200" cy="298" r="10" fill={accent} />
          <path d="M60 440 L340 440" stroke="#fff" strokeWidth="1.4" opacity="0.2" />
        </g>
      );
  }
}

function hashSeed(id: string): number {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) % 9973;
  return h;
}

export function GameCover({
  game,
  className,
  showTitle = true,
  priority = false,
}: {
  game: Game;
  className?: string;
  showTitle?: boolean;
  priority?: boolean;
}) {
  const seed = hashSeed(game.id);
  const t = useT();
  const gt = useGameText(game);
  const [c1, c2, accent] = game.palette;
  const titleSize = game.title.length > 16 ? 30 : game.title.length > 10 ? 36 : 44;

  return (
    <motion.div
      initial={priority ? false : { opacity: 0, scale: 1.03 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
      className={cn("relative overflow-hidden bg-card", className)}
      dir="ltr"
      role="img"
      aria-label={t("shared.coverAria", { game: game.title })}
    >
      <svg viewBox="0 0 400 560" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 size-full">
        <defs>
          <linearGradient id={`bg-${game.id}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={c1} />
            <stop offset="62%" stopColor={c2} />
            <stop offset="100%" stopColor={c1} />
          </linearGradient>
          <radialGradient id={`glow-${game.id}`} cx="0.5" cy="0.32" r="0.75">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.16" />
            <stop offset="60%" stopColor="#ffffff" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="400" height="560" fill={`url(#bg-${game.id})`} />
        <g transform="translate(0,40)">{/* مرکز هنری */}
          <MotifArt motif={game.motif} colors={game.palette} seed={seed} />
        </g>
        <rect width="400" height="560" fill={`url(#glow-${game.id})`} />
        {/* وینیت پایین برای خوانایی عنوان */}
        <rect y="380" width="400" height="180" fill="url(#vg)" />
        <defs>
          <linearGradient id="vg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#000" stopOpacity="0" />
            <stop offset="100%" stopColor="#000" stopOpacity="0.66" />
          </linearGradient>
        </defs>
      </svg>

      {showTitle ? (
        <div className="absolute inset-x-0 bottom-0 p-4">
          <p
            className="font-extrabold leading-tight text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.7)]"
            style={{ fontSize: titleSize * 0.62, letterSpacing: "-0.02em" }}
          >
            {game.title}
          </p>
          <p className="mt-1 line-clamp-1 text-[0.72rem] font-medium text-white/70" dir="rtl" style={{ textAlign: "right" }}>
            {gt.tagline}
          </p>
        </div>
      ) : null}

      {/* خط برند پایین کاور */}
      <div className="absolute inset-x-0 bottom-0 h-0.5 opacity-70" style={{ background: `linear-gradient(90deg, ${accent}, transparent)` }} />
    </motion.div>
  );
}
