"use client";

/* ————— جعبه‌ابزار UI سراسری: جهت پویا، توستر، اعمال زبان/تم —————
 * - زبان و تم ذخیره‌شده را پس از اولین رندر اعمال می‌کند (سازگار با SSR).
 * - DirectionProvider و Toaster بر اساس زبان فعال جهت می‌گیرند.
 * - عنوان سند (document.title) هم با زبان عوض می‌شود.
 */

import { useEffect } from "react";
import { Toaster } from "sonner";
import { DirectionProvider as RadixDirectionProvider } from "@radix-ui/react-direction";
import { makeT, useLang, useTheme, useUi, useUiDir } from "@/lib/i18n";

export function UiEffects({ children }: { children: React.ReactNode }) {
  const dir = useUiDir();
  const locale = useLang();
  const theme = useTheme();

  /* خواندن تنظیمات ذخیره‌شده پس از اولین رندر (بدون شکست hydration) */
  useEffect(() => {
    useUi.getState().load();
  }, []);

  /* عنوان سند بر اساس زبان */
  useEffect(() => {
    document.title = makeT(locale)("meta.title");
  }, [locale]);

  /* meta theme-color هم با تم هم‌گام شود */
  useEffect(() => {
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", theme === "light" ? "#f5f6f9" : "#111318");
  }, [theme]);

  return (
    <RadixDirectionProvider dir={dir}>
      {children}
      <Toaster
        position={dir === "rtl" ? "bottom-right" : "bottom-left"}
        dir={dir}
        toastOptions={{
          style: {
            background: "var(--popover)",
            border: "1px solid var(--border)",
            color: "var(--popover-foreground)",
          },
        }}
      />
    </RadixDirectionProvider>
  );
}
