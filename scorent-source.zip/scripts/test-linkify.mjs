// Quick logic check of the lookbehind regex behavior
function escapeRegExp(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
const cases = [
  ["Hades", "Hades"],
  ["Cyberpunk 2077", "Cyberpunk 2077"],
  ["The Witcher 3", "The Witcher 3"],
  ["INSIDE", "INSIDE"],
];
for (const [title, id] of cases) {
  const re = new RegExp(`(?<!\\[)\\b${escapeRegExp(title)}\\b(?!\\]\\()`, "g");
  const bare = `این هم ${title} عالی است`;
  const linked = `[${title}](#/game/x) قبلا لینک است`;
  const boldLinked = `**[${title}](#/game/x)**`;
  console.log(title, "| bare:", JSON.stringify(bare.replace(re, `[${title}](#/game/g)`)));
  console.log(title, "| linked unchanged:", !linked.replace(re, "X").includes("X"));
  console.log(title, "| bold-linked unchanged:", !boldLinked.replace(re, "X").includes("X"));
}
