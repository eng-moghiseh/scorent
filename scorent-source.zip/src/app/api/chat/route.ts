/* ————— API گفتگوی دستیار Scorent — POST /api/chat —————
 *
 * معماری:
 *  1. اعتبارسنجی سخت‌گیرانه ورودی (zod) + محدودیت نرخ (in-memory per-IP)
 *  2. استخراج نیت: موتور قطعی (regex روی کاتالوگ) + یک فراخوانی کوچک مدل
 *     برای نیت‌های محاوره‌ای؛ سپس ادغام امن دو منبع
 *  3. اجرای ابزارهای کاتالوگ روی داده واقعی → بلوک CATALOG_DATA
 *  4. پاسخ نهایی به‌صورت استریم SSE به کلاینت (delta/done/error)
 *
 * امنیت: کلید SDK فقط سمت سرور؛ محدودیت طول پیام و تاریخچه؛ timeout؛
 * هیچ عملیات خرید/اجاره/ذخیره‌ای از این مسیر انجام نمی‌شود.
 */

import { NextRequest } from "next/server";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";
import { z } from "zod";
import ZAI from "z-ai-web-dev-sdk";
import { extractIntentDeterministic, mergeIntents, type CatalogIntent } from "@/lib/ai/intent";
import { ASSISTANT_VERSION, SYSTEM_PERSONA, buildCatalogContext, clampHistory, languageHint } from "@/lib/ai/prompt";

export const runtime = "nodejs";
export const maxDuration = 120;

/* ————— اعتبارسنجی ورودی ————— */

const MessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().min(1).max(4000),
});

const BodySchema = z.object({
  history: z.array(MessageSchema).max(24).default([]),
  message: z.string().min(1).max(2000),
  /** زبان UI سایت — فقط برای پیام‌های بدون حروف استفاده می‌شود */
  uiLang: z.enum(["fa", "en"]).default("fa"),
});

/* ————— محدودیت نرخ مشترک و پایدار — ۲۰ درخواست در دقیقه برای هر IP ————— */
/* از همان لایه‌ی rate-limit دیتابیس‌محور استفاده می‌کند (شریک بین نمونه‌های serverless) */

/* ————— برنامه‌ریز مدل: استخراج نیت JSON از پیام محاوره‌ای ————— */

const PLANNER_PROMPT = `تو یک استخراج‌کننده نیت هستی. پیام کاربر (فارسی یا انگلیسی) را به JSON تبدیل کن. فقط JSON خالص بده، بدون توضیح.

ژانرهای مجاز genres: "نقش‌آفرینی", "اکشن", "ماجرایی", "استراتژیک", "شبیه‌سازی", "معمایی پازل", "تیراندازی", "سکوبازی", "روگ‌لایت", "مسابقه‌ای", "ورزشی"
سبک‌های مجاز playstyle: "داستان‌محور", "رقابتی", "آرام و دلنشین", "چالشی", "اکتشافی", "تاکتیکی"
حالت‌های مجاز mode: "تک‌نفره", "همکاری محلی", "همکاری آنلاین", "رقابتی آنلاین"

Schema:
{
 "titles": [عناوین بازی‌های صریحاً نام‌برده — انگلیسی یا شناسه],
 "genres": [ژانرهای مجاز که کاربر خواسته],
 "playstyle": یکی از سبک‌های مجاز یا null,
 "mode": یکی از حالت‌های مجاز یا null,
 "budgetToman": عدد تومان یا null,
 "intent": "buy" | "rent" | "either",
 "wantsRecommendation": bool,
 "wantsComparison": bool,
 "wantsDeals": bool,
 "wantsRental": bool
}

مثال: «یه بازی آروم برای آخر هفته زیر ۵۰۰ تومان» → {"titles":[],"genres":[],"playstyle":"آرام و دلنشین","mode":null,"budgetToman":500000,"intent":"either","wantsRecommendation":true,"wantsComparison":false,"wantsDeals":false,"wantsRental":false}`;

async function planWithModel(
  message: string
): Promise<Partial<CatalogIntent> | null> {
  const TIMEOUT_MS = 7000;
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
  }, TIMEOUT_MS);
  try {
    const zai = await ZAI.create();
    if (timedOut) return null;
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "assistant", content: PLANNER_PROMPT },
        { role: "user", content: message.slice(0, 1200) },
      ],
      thinking: { type: "disabled" },
      temperature: 0,
      max_tokens: 300,
    });
    const raw = completion?.choices?.[0]?.message?.content;
    if (typeof raw !== "string") return null;
    const jsonText = raw.slice(raw.indexOf("{"), raw.lastIndexOf("}") + 1);
    const parsed = JSON.parse(jsonText) as Record<string, unknown>;
    return {
      mentionedTitles: Array.isArray(parsed.titles) ? (parsed.titles as unknown[]).filter((t): t is string => typeof t === "string") : undefined,
      genres: Array.isArray(parsed.genres) ? (parsed.genres as unknown[]).filter((t): t is string => typeof t === "string") : undefined,
      playstyle: typeof parsed.playstyle === "string" ? parsed.playstyle : undefined,
      mode: typeof parsed.mode === "string" ? parsed.mode : undefined,
      budgetToman: typeof parsed.budgetToman === "number" ? parsed.budgetToman : undefined,
      intent: parsed.intent === "buy" || parsed.intent === "rent" || parsed.intent === "either" ? parsed.intent : undefined,
      wantsRecommendation: parsed.wantsRecommendation === true,
      wantsComparison: parsed.wantsComparison === true,
      wantsDeals: parsed.wantsDeals === true,
      wantsRental: parsed.wantsRental === true,
    } satisfies Partial<CatalogIntent>;
  } catch {
    return null; // fallback قطعی پوشش می‌دهد
  } finally {
    clearTimeout(timer);
  }
}

/* ————— SSE helpers ————— */

function sse(obj: Record<string, unknown>): Uint8Array {
  return new TextEncoder().encode(`data: ${JSON.stringify(obj)}\n\n`);
}

/* ————— Route ————— */

export async function POST(req: NextRequest) {
  /* محدودیت نرخ */
  const ip = clientIp(req);
  if (!(await rateLimit(`chat:${ip}`, 20, 60_000))) {
    return Response.json(
      { error: "درخواست‌ها زیاد است؛ لطفاً یک دقیقه صبر کن و دوباره امتحان کن." },
      { status: 429 }
    );
  }

  /* اعتبارسنجی */
  let body: z.infer<typeof BodySchema>;
  try {
    const json = await req.json();
    const parsed = BodySchema.safeParse(json);
    if (!parsed.success) {
      return Response.json(
        { error: "پیام نامعتبر است (حداکثر ۲۰۰۰ کاراکتر)." },
        { status: 400 }
      );
    }
    body = parsed.data;
  } catch {
    return Response.json({ error: "بدنه درخواست قابل خواندن نیست." }, { status: 400 });
  }

  const userMessage = body.message.trim();
  if (!userMessage) {
    return Response.json({ error: "پیام خالی است." }, { status: 400 });
  }

  /* ۱) نیت: قطعی + مدل (ادغام امن) */
  const deterministic = extractIntentDeterministic(userMessage);
  let intent: CatalogIntent = deterministic;
  try {
    const modelPlan = await planWithModel(userMessage);
    intent = mergeIntents(deterministic, modelPlan);
  } catch {
    intent = deterministic; // بدون برنامه‌ریز هم پاسخ داده‌محور می‌ماند
  }

  /* ۲) کانتکست واقعی کاتالوگ */
  const context = buildCatalogContext(intent, userMessage);

  /* ۳) پیام‌های نهایی مدل */
  const history = clampHistory(body.history);
  const messages: Array<{ role: "user" | "assistant"; content: string }> = [
    ...history,
    { role: "user", content: `${userMessage}\n\n---\n${context}` },
  ];

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const abort = new AbortController();
      const timeout = setTimeout(() => abort.abort("timeout"), 90_000);
      let closed = false;
      const safeEnqueue = (chunk: Uint8Array) => {
        if (!closed) {
          try {
            controller.enqueue(chunk);
          } catch {
            closed = true;
          }
        }
      };

      req.signal.addEventListener("abort", () => {
        abort.abort();
      });

      try {
        const zai = await ZAI.create();
        const completion = await zai.chat.completions.create({
          messages: [
            { role: "assistant", content: `${SYSTEM_PERSONA}\n\n${languageHint(userMessage, body.uiLang)}` },
            ...messages,
          ],
          stream: true,
          thinking: { type: "disabled" },
          temperature: 0.7,
          max_tokens: 1600,
        });

        const decoder = new TextDecoder();
        let buffer = "";
        for await (const chunk of completion as AsyncIterable<Uint8Array>) {
          if (abort.signal.aborted) break;
          buffer += decoder.decode(chunk, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith("data:")) continue;
            const payload = trimmed.slice(5).trim();
            if (payload === "[DONE]") continue;
            try {
              const json = JSON.parse(payload) as {
                choices?: Array<{ delta?: { content?: string } }>;
              };
              const delta = json.choices?.[0]?.delta?.content;
              if (delta) safeEnqueue(sse({ t: "delta", v: delta }));
            } catch {
              /* قطعه ناقص SSE — نادیده گرفته می‌شود */
            }
          }
        }
        safeEnqueue(sse({ t: "done", meta: { version: ASSISTANT_VERSION } }));
      } catch (err) {
        const msg =
          abort.signal.aborted || req.signal.aborted
            ? "پاسدادی متوقف شد."
            : `اتصال به مدل برقرار نشد. چند لحظه بعد دوباره امتحان کن.${process.env.NODE_ENV !== "production" && err instanceof Error ? ` [${err.message}]` : ""}`;
        safeEnqueue(sse({ t: "error", v: msg }));
      } finally {
        clearTimeout(timeout);
        safeEnqueue(new TextEncoder().encode("data: [DONE]\n\n"));
        if (!closed) {
          closed = true;
          try {
            controller.close();
          } catch {
            /* از قبل بسته شده */
          }
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
