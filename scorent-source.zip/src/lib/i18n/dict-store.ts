/* ————— fragment: dict-store — فروشگاه بازی‌ها (دوزبانه) —————
 * هر کلید: [فارسی، English] — پارامترها با الگوی {name} جایگزین می‌شوند.
 * برچسب ژانر/حالت‌ها واژگان لایه داده‌اند و با tx() ترجمه می‌شوند (در EN_MAP).
 */

export const STR: Record<string, [string, string]> = {
  /* ————— سربرگ ————— */
  "store.heading": ["فروشگاه بازی‌ها", "Game Store"],
  "store.desc": [
    "{n} بازی با جستجو، فیلتر و مرتب‌سازی — همه قیمت‌ها داده نمونه دمو هستند.",
    "{n} games with search, filters and sorting — all prices are demo sample data.",
  ],

  /* ————— جستجو ————— */
  "store.searchPlaceholder": ["جستجوی عنوان بازی…", "Search game titles…"],
  "store.searchAria": ["جستجوی بازی", "Search games"],

  /* ————— فیلترها و مرتب‌سازی ————— */
  "store.genreAria": ["فیلتر ژانر", "Filter by genre"],
  "store.genreLabel": ["ژانر:", "Genre:"],
  "store.genreAll": ["همه ژانرها", "All genres"],
  "store.modeAria": ["فیلتر حالت بازی", "Filter by game mode"],
  "store.modeLabel": ["حالت:", "Mode:"],
  "store.modeAll": ["همه حالت‌ها", "All modes"],
  "store.sortAria": ["مرتب‌سازی", "Sort by"],
  "store.sortPopular": ["محبوب‌ترین", "Most popular"],
  "store.sortRating": ["بالاترین امتیاز", "Highest rated"],
  "store.sortPriceAsc": ["ارزان‌ترین", "Cheapest"],
  "store.sortPriceDesc": ["گران‌ترین", "Most expensive"],
  "store.sortDiscount": ["بیشترین تخفیف", "Biggest discount"],
  "store.maxPrice": ["حداکثر قیمت", "Max price"],
  "store.noCap": ["بدون سقف", "No cap"],
  "store.minRating": ["حداقل امتیاز منتقدان (نمونه)", "Minimum critic score (sample)"],
  "store.minRatingAria": ["حداقل امتیاز", "Minimum rating"],
  "store.ratingAll": ["همه", "All"],
  "store.clearFilters": ["پاک‌کردن فیلترها", "Clear filters"],
  "store.clearAllFilters": ["پاک‌کردن همه فیلترها", "Clear all filters"],

  /* ————— نتیجه ————— */
  "store.count": ["{n} بازی پیدا شد", "{n} games found"],
  "store.countFor": ["برای «{q}»", "for “{q}”"],
  "store.filtersShared": [
    "فیلترها در نشانی صفحه هم ذخیره می‌شوند — لینک را می‌توانی به اشتراک بگذاری",
    "Filters are saved in the page URL too — you can share the link",
  ],

  /* ————— حالت خالی ————— */
  "store.emptyTitle": ["چیزی با این فیلترها پیدا نشد", "Nothing matched these filters"],
  "store.emptyDesc": [
    "ترکیب فیلترها را کمی بازتر کن یا جستجو را تغییر بده. مثلاً سقف قیمت را بالاتر ببر یا ژانر را آزاد بگذار.",
    "Loosen the filter combination a little or change your search — for example, raise the price cap or leave the genre open.",
  ],

  /* ————— پیشنهاد پرسش‌نامه AI ————— */
  "store.aiPromptPre": ["دنبال پیشنهاد شخصی‌تر هستی؟", "Want more personalized picks?"],
  "store.aiQuizLink": ["پرسش‌نامه Scorent AI", "Scorent AI questionnaire"],
  "store.aiPromptPost": ["را امتحان کن.", "— give it a try."],
};
