/* ————— Rental time logic (pure) —————
 * قانون تمدید (سند شده و همیشه یکسان اعمال می‌شود):
 *  - اجاره فعال: تمدید از انتهای مهلت فعلی (expiresAt) اضافه می‌شود.
 *  - اجاره منقضی‌شده: تمدید از لحظه فعلی شروع به شمارش می‌کند.
 * زمان منقضی‌شدن همیشه از timestamp محاسبه می‌شود (هرگز رشته ثابت نیست).
 */

export const DAY_MS = 86_400_000;

export interface RentalTimeLike {
  startedAt: number;
  expiresAt: number;
  status: "active" | "completed";
}

export function isExpired(r: RentalTimeLike, now: number): boolean {
  return r.expiresAt <= now;
}

export function remainingMs(r: RentalTimeLike, now: number): number {
  return Math.max(0, r.expiresAt - now);
}

/**
 * انقضای جدید پس از تمدید به مدت days.
 * - فعال: expiresAt + days (تمدید پشت‌سرهم)
 * - منقضی: now + days (شروع دوره تازه)
 */
export function renewalExpiry(r: RentalTimeLike, now: number, days: number): number {
  const add = Math.max(1, Math.floor(days)) * DAY_MS;
  if (isExpired(r, now)) return now + add;
  return r.expiresAt + add;
}

/** مهلت مجاز بین دو تمدید برای جلوگیری از تمدید تکراری ناخواسته (۵ ثانیه) */
export const RENEW_COOLDOWN_MS = 5_000;
