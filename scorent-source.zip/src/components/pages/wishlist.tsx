"use client";

/* ————— علاقه‌مندی‌ها — بدون تکرار، با حذف ————— */

import { Heart, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { GameCard } from "@/components/scorent/commerce";
import { EmptyState } from "@/components/scorent/shared";
import { Link as RouteLink } from "@/components/scorent/router";
import { gamesOf } from "@/lib/data/community";
import { useFmt, useT } from "@/lib/i18n";
import { useHydrated, useScorent } from "@/lib/store";

export function WishlistPage() {
  const hydrated = useHydrated();
  const wishlist = useScorent((s) => s.wishlist);
  const toggleWishlist = useScorent((s) => s.toggleWishlist);
  const t = useT();
  const f = useFmt();
  const games = gamesOf(wishlist);

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16">
        <div className="skeleton-shimmer h-40 rounded-3xl" />
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      <header className="mb-8">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-[#ff6b8a]/12 px-3.5 py-1.5 text-xs font-bold text-[#ff8fa8]">
          <Heart className="size-3.5" />
          {t("wishlist.badge")}
        </div>
        <h1 className="text-3xl font-black">{t("wishlist.title")}</h1>
        <p className="mt-2 text-sm leading-7 text-muted-foreground">
          {wishlist.length === 0
            ? t("wishlist.descEmpty")
            : t("wishlist.descCount", { n: f.num(games.length) })}
        </p>
      </header>

      {games.length === 0 ? (
        <EmptyState
          icon={Heart}
          title={t("wishlist.emptyTitle")}
          description={t("wishlist.emptyDesc")}
          action={
            <RouteLink to="/store">
              <Button className="gap-2">
                <ShoppingBag className="size-4" />
                {t("wishlist.goStore")}
              </Button>
            </RouteLink>
          }
        />
      ) : (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {games.map((g, i) => (
            <div key={g.id} className="relative">
              <GameCard game={g} index={i} />
              <button
                type="button"
                onClick={() => {
                  toggleWishlist(g.id);
                  toast.info(t("wishlist.removedToast", { game: g.title }));
                }}
                className="absolute inset-x-4 bottom-[4.4rem] z-10 rounded-xl border border-[#ff6b8a]/30 bg-background/80 py-2 text-xs font-bold text-[#ff8fa8] backdrop-blur transition-colors hover:bg-[#ff6b8a]/10"
              >
                {t("wishlist.removeBtn")}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
