/* /api/support/tickets — ایجاد تیکت (مهمان هم می‌تواند) و فهرست تیکت‌های من */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, cleanName, cleanText, isEmail, json, normalizePhone, readJson, sameOrigin, unauthorized } from "@/lib/server/http";
import { requireUser, isGuardError } from "@/lib/server/guard";
import { userFromRequest } from "@/lib/server/session";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";
import { sendAndLog, emailHtml, escapeHtml } from "@/lib/server/notify";

export const CATEGORIES = ["ACCOUNT", "BILLING", "GAME", "BUG", "SUGGESTION", "OTHER"] as const;

interface CreateBody {
  name?: string;
  contact?: string;
  subject?: string;
  message?: string;
  category?: string;
}

export async function GET(req: NextRequest) {
  const guard = await requireUser(req);
  if (isGuardError(guard)) return guard;
  const tickets = await db.supportTicket.findMany({
    where: { userId: guard.user.id },
    orderBy: { updatedAt: "desc" },
    include: { messages: { orderBy: { createdAt: "asc" } } },
  });
  return json({ ok: true, tickets });
}

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  if (!(await rateLimit(`ticket:${clientIp(req)}`, 5, 10 * 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);

  const user = await userFromRequest(req);
  const body = await readJson<CreateBody>(req);
  if (!body) return badRequest("BAD_JSON");

  const subject = cleanText(body.subject, 4, 120);
  const message = cleanText(body.message, 10, 3000);
  if (!subject || !message) return json({ ok: false, error: "INVALID_INPUT" }, 400);
  const category = (CATEGORIES as readonly string[]).includes(body.category ?? "") ? body.category! : "OTHER";

  // مخاطب: برای کاربر متصل از حساب؛ برای مهمان الزامی
  let contact = user?.email ?? user?.phone ?? null;
  let guestName: string | null = null;
  if (!user) {
    guestName = cleanName(body.name) ?? null;
    const c = typeof body.contact === "string" ? body.contact.trim() : "";
    if (isEmail(c)) contact = c.toLowerCase();
    else contact = normalizePhone(c);
    if (!contact || !guestName) return json({ ok: false, error: "GUEST_CONTACT_REQUIRED" }, 400);
  }

  const ticket = await db.supportTicket.create({
    data: {
      userId: user?.id ?? null,
      guestName,
      contact: contact!,
      subject,
      category,
      messages: {
        create: { authorId: user?.id ?? null, authorName: user?.name ?? guestName!, authorRole: "USER", body: message },
      },
    },
    include: { messages: true },
  });

  // اطلاع‌رسانی تأیید دریافت (ایمیل اگر ایمیل باشد، وگرنه پیامک)
  const fa = user ? user.lang !== "en" : true;
  const tid = ticket.id.slice(-8).toUpperCase();
  if (contact!.includes("@")) {
    await sendAndLog({
      userId: user?.id ?? null,
      channel: "EMAIL",
      recipient: contact!,
      subject: fa ? `تیکت شما ثبت شد — Scorent #${tid}` : `Ticket received — Scorent #${tid}`,
      body: fa ? `تیکت «${subject}» با شناسه #${tid} ثبت شد و در اولین فرصت بررسی می‌شود.` : `Your ticket “${subject}” (#${tid}) was received and will be reviewed shortly.`,
      html: emailHtml(fa ? "fa" : "en", fa ? "تیکت پشتیبانی ثبت شد" : "Support ticket received", `<p>${fa ? "شناسه پیگیری:" : "Tracking ID:"} <b>#${tid}</b></p><p>${escapeHtml(subject)}</p>`),
      kind: "SYSTEM",
      meta: { ticketId: ticket.id },
    });
  } else {
    await sendAndLog({
      userId: user?.id ?? null,
      channel: "SMS",
      recipient: contact!,
      body: fa ? `Scorent — تیکت #${tid} ثبت شد؛ به‌زودی پاسخ می‌دهیم.` : `Scorent — ticket #${tid} received; we'll reply soon.`,
      kind: "SYSTEM",
      meta: { ticketId: ticket.id },
    });
  }

  return json({ ok: true, ticket, trackingId: tid });
}
