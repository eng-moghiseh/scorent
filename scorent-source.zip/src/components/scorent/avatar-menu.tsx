"use client";

/* ————— منوی حساب کاربری در ناوبری — مهمان و واردشده ————— */

import { LogIn, LogOut, Settings, ShieldCheck, LifeBuoy, Trophy, UserRound } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { AvatarBubble } from "./navbar";
import { Link, useRoute } from "./router";
import { displayName, useHydrated, useLevelInfo, useScorent } from "@/lib/store";
import { isStaff, useAuth } from "@/lib/auth";
import { useFmt, useT, useTx, useUiDir } from "@/lib/i18n";
import { cn } from "@/lib/utils";

function VerificationDot({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span
      title={label}
      className={cn(
        "inline-flex size-4 items-center justify-center rounded-full text-[0.55rem] font-black",
        ok ? "bg-rent/20 text-rent" : "bg-secondary text-muted-foreground"
      )}
    >
      {ok ? "✓" : "—"}
    </span>
  );
}

export function AvatarFallbackMenu() {
  const profile = useScorent((s) => s.profile);
  const level = useLevelInfo();
  const hydrated = useHydrated();
  const route = useRoute();
  const user = useAuth((s) => s.user);
  const logout = useAuth((s) => s.logout);
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();

  if (!user) {
    return (
      <Link
        to={route.path === "/auth" ? "/" : "/auth?next=" + encodeURIComponent(route.path)}
        ariaLabel={t("account.signIn")}
        className="flex h-10 items-center gap-1.5 rounded-full bg-ai px-3.5 text-xs font-extrabold text-white transition-colors hover:bg-ai/90"
      >
        <LogIn className="size-4" />
        <span className="hidden sm:inline">{t("account.signIn")}</span>
      </Link>
    );
  }

  return (
    <DropdownMenu dir={dir}>
      <DropdownMenuTrigger
        aria-label={t("account.menuAria")}
        className="rounded-full outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <AvatarBubble size={36} />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64 bg-popover">
        <DropdownMenuLabel>
          <div className="flex items-center gap-3">
            <AvatarBubble size={40} />
            <div className="min-w-0">
              <p className="truncate text-sm font-bold">{user.name}</p>
              <p dir="ltr" className="truncate text-start text-xs text-muted-foreground tnum">
                {user.email ?? user.phone ?? "Scorent"}
              </p>
              <div className="mt-1 flex flex-wrap items-center gap-1.5">
                <span className={cn("rounded-full px-2 py-0.5 text-[0.6rem] font-extrabold", user.role === "USER" ? "bg-secondary text-muted-foreground" : "bg-ai/15 text-ai")}>
                  {t(`account.role.${user.role}`)}
                </span>
                <VerificationDot ok={Boolean(user.emailVerified)} label={t(user.emailVerified ? "account.verified" : "account.unverified")} />
                <VerificationDot ok={Boolean(user.phoneVerified)} label={t(user.phoneVerified ? "account.verified" : "account.unverified")} />
              </div>
            </div>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link to="/profile" className="cursor-pointer">
            <UserRound className="size-4" /> {t("account.myProfile")}
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/rewards" className="cursor-pointer">
            <Trophy className="size-4" /> {t("nav.rewards")}
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/support" className="cursor-pointer">
            <LifeBuoy className="size-4" /> {t("account.support")}
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/settings" className="cursor-pointer">
            <Settings className="size-4" /> {t("nav.settings")}
          </Link>
        </DropdownMenuItem>
        {isStaff(user.role) ? (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/admin" className="cursor-pointer text-ai">
                <ShieldCheck className="size-4" /> {t("account.adminPanel")}
              </Link>
            </DropdownMenuItem>
          </>
        ) : null}
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onClick={() => void logout()}
          className="cursor-pointer text-destructive focus:text-destructive"
        >
          <LogOut className="size-4" /> {t("account.signOut")}
        </DropdownMenuItem>
        {hydrated && (
          <p className="px-2 pb-1.5 pt-0.5 text-[0.62rem] text-muted-foreground">
            {t("account.level", { n: f.num(level.level), title: tx(level.title) })}
          </p>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
