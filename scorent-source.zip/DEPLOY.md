# استقرار Scorent روی هاست 🦂

Scorent یک اپلیکیشن **Next.js 16 (Node.js)** است با دو حالت دیتابیس:
- **Netlify / serverless → PostgreSQL مدیریت‌شده** (الزامی — فایل SQLite روی توابع serverless پایدار نمی‌ماند)
- **سرور سنتی (VPS) → SQLite** (پیش‌فرض پروژه)

> ⚠ اگر سایت را قبلاً به‌صورت استاتیک روی Netlify آپلود کرده‌ای، همه‌ی مسیرهای `/api/*` (ورود، ثبت‌نام، پنل ادمین، AI) کار نمی‌کنند؛ این راهنما هر دو مسیر درست را می‌دهد.

---

## گزینه‌ی الف — استقرار روی Netlify با PostgreSQL (پیشنهادی برای دامنه‌ی فعلی)

### ۱) ساخت دیتابیس PostgreSQL
یک سرویس provider-independent بساز (هرکدام پلن رایگان دارد):
- [Neon](https://neon.tech) → Copy connection string
- [Supabase](https://supabase.com) → Project Settings → Database → Connection string (URI)
- [Railway](https://railway.app) → PostgreSQL → Variables → `DATABASE_URL`

رشته‌ی اتصال چیزی شبیه این است:
```
postgresql://USER:PASSWORD@HOST/DBNAME?sslmode=require
```

### ۲) اتصال ریپو به Netlify
- zip سورس را به یک ریپوی Git (GitHub/GitLab) push کن.
- Netlify → «Add new site» → «Import an existing project» → ریپو را انتخاب کن.
- `netlify.toml` داخل پروژه همه‌چیز را تنظیم می‌کند (Build command: `npm run build:netlify`، پلاگین رسمی `@netlify/plugin-nextjs`).
- در **Site configuration → Environment variables** این‌ها را تنظیم کن:

| متغیر | مقدار | الزامی؟ |
| --- | --- | --- |
| `DATABASE_URL` | رشته‌ی PostgreSQL مرحله‌ی ۱ | ✅ |
| `AUTH_SECRET` | خروجی `openssl rand -hex 32` | ✅ |
| `ADMIN_EMAIL` | ایمیل ادمین خودت | ✅ (فقط اولین استقرار) |
| `ADMIN_PASSWORD` | یک رمز قوی و منحصربه‌فرد (رمزهای عمومی/پیش‌فرض رد می‌شوند) | ✅ |
| `DEMO_MODE` | `false` (در production کد تأیید هرگز در پاسخ API نمی‌آید) | اختیاری |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | از Google Cloud Console | اختیاری |
| `SMTP_HOST/PORT/USER/PASS/SECURE/FROM` | سرویس ایمیل واقعی | اختیاری |
| `SMS_PROVIDER=kavenegar` + `SMS_API_KEY` (+`SMS_FROM`) یا `SMS_WEBHOOK_URL` | سرویس پیامک واقعی | اختیاری |

- Deploy را بزن. اسکریپت `check-env` پیش از build، پیکربندی را اعتبارسنجی می‌کند و خطای واضح می‌دهد اگر چیزی کم باشد.

### ۳) ساخت جداول دیتابیس (یک‌بار)
روی سیستم خودت، با همان `DATABASE_URL`:

```bash
npm install
npm run db:push:pg          # یا: npm run db:migrate:pg (migration آماده در prisma/migrations/0_init)
```

> فایل migration استاندارد Postgres در `prisma/migrations/0_init/migration.sql` موجود است؛ در session بعدی از `prisma migrate deploy` استفاده کن — هیچ دستور مخرب داده‌ای لازم نیست.

### ۴) ورود واقعی گوگل
- Google Cloud Console → Credentials → OAuth Client ID → Web application
- **Authorized redirect URI:** `https://scorent1.netlify.app/api/auth/google/callback`
- `GOOGLE_CLIENT_ID` و `GOOGLE_CLIENT_SECRET` را در Netlify env ست کن و redeploy.

### ۵) نکته‌های Netlify
- توابع serverless بی‌حالت‌اند؛ همه‌ی stateها (نشست‌ها، OTP، rate limit، حسابرسی) در PostgreSQL مشترک‌اند.
- کوکی نشست در production با `SameSite=None; Secure; Partitioned` ست می‌شود — در iframe هم کار می‌کند.
- هدرهای امنیتی (CSP، X-Frame-Options و…) فقط در production فعال‌اند؛ اگر جایی سایت باید داخل iframe باز شود `FRAME_GUARD=false`.

---

## گزینه‌ی ب — سرور سنتی (VPS) با SQLite

```bash
npm install
npx prisma generate
npx prisma db push          # فقط برای دیتابیس تازه؛ db/custom.db همراه سورس آماده است
npm run build
NODE_ENV=production PORT=3000 node .next/standalone/server.js
```

با pm2 پایدارش کن:

```bash
npm i -g pm2
pm2 start ".next/standalone/server.js" --name scorent --env NODE_ENV=production
pm2 save && pm2 startup
```

دامنه را با nginx/Caddy به پورت ۳۰۰۰ reverse-proxy کن. اگر دیتابیس آماده‌ی zip را نگه می‌داری، ورود ادمین اولیه: `admin@scorent.ir / Scorent@2026!` — **بلافاصله از پروفایل → کارت حساب رمز را عوض کن.**

---

## چک‌لیست امنیت پیش از انتشار عمومی

- [ ] `AUTH_SECRET` تصادفی و ≥۳۲ کاراکتر
- [ ] `ADMIN_PASSWORD` منحصربه‌فرد (بدون رمزهای عمومی)
- [ ] HTTPS فعال (کوکی‌ها در production با `Secure` ست می‌شوند)
- [ ] `DEMO_MODE` در production غیرفعال (کد تأیید در پاسخ API نمی‌آید)
- [ ] Redirect URI گوگل دقیقاً دامنه‌ی نهایی است
- [ ] پوشه‌ی `db/` و فایل `.env` از web root بیرون‌اند

## عیب‌یابی سریع

| نشانه | علت احتمالی |
| --- | --- |
| `AUTH_SECRET_MISSING` در لاگ توابع | `AUTH_SECRET` در Netlify env تنظیم نشده |
| `the URL must start with the protocol file:` | باندل با کلاینت SQLite ساخته شده ولی URL به Postgres اشاره دارد → `npm run build:netlify` را کامل اجرا کن |
| APIها ۵۰۰ ولی صفحه باز می‌شود | استقرار استاتیک (بدون ران‌تایم Next) → از مسیر «اتصال ریپو» استفاده کن |
| ورود گوگل «پروتکل امنیتی» | جریان داخل iframe اجرا شده → دکمه‌ی گوگل به‌صورت خودکار تب جدید باز می‌کند؛ Redirect URI را هم چک کن |
| صفحات API خطای ۵۰۰ | `npx prisma generate` اجرا نشده یا `DATABASE_URL` نامعتبر است |
