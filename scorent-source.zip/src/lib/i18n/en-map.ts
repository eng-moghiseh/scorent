/* ————— EN_MAP — ترجمه‌ی رشته‌های ثابت لایه داده در زمان رندر —————
 * داده‌های مرکزی (ژانرها، دستاوردها، دلایل خطا، داده‌های نمونه...) به فارسی
 * ذخیره می‌شوند؛ در حالت انگلیسی، UI از طریق tx() معادل انگلیسی را نشان می‌دهد.
 * کلیدها باید «دقیقاً» با رشته‌های موجود در لایه داده مطابقت داشته باشند.
 */

export const EN_MAP: Record<string, string> = {
  /* ————— واژگان دامنه (Genre) ————— */
  "نقش‌آفرینی": "RPG",
  "اکشن": "Action",
  "ماجرایی": "Adventure",
  "استراتژیک": "Strategy",
  "شبیه‌سازی": "Simulation",
  "معمایی پازل": "Puzzle",
  "تیراندازی": "Shooter",
  "سکوبازی": "Platformer",
  "روگ‌لایت": "Roguelite",
  "مسابقه‌ای": "Racing",
  "ورزشی": "Sports",

  /* ————— سبک بازی (Playstyle) ————— */
  "داستان‌محور": "Story-driven",
  "رقابتی": "Competitive",
  "آرام و دلنشین": "Cozy",
  "چالشی": "Challenging",
  "اکتشافی": "Explorative",
  "تاکتیکی": "Tactical",

  /* ————— ساختار ————— */
  "دنیای آزاد": "Open world",
  "نیمه‌آزاد": "Semi-open",
  "خطی": "Linear",

  /* ————— حالت بازی ————— */
  "تک‌نفره": "Single-player",
  "همکاری محلی": "Local co-op",
  "همکاری آنلاین": "Online co-op",
  "رقابتی آنلاین": "Online PvP",

  /* ————— طول جلسه ————— */
  "کوتاه": "Short",
  "متوسط": "Medium",
  "بلند": "Long",

  /* ————— نیت خرید ————— */
  "خرید": "Purchase",
  "اجاره ۳ روزه": "3-day rental",
  "ارزان‌ترین گزینه (خرید یا اجاره)": "Cheapest option (buy or rent)",

  /* ————— دستاوردها: عنوان ————— */
  "هویت گیمری": "Gamer Identity",
  "اولین خرید": "First Purchase",
  "کلکسیونر": "Collector",
  "مستأجر تازه‌کار": "Rookie Renter",
  "هفت‌روزه‌نشین": "Week-long Tenant",
  "نظر تیزبین": "Sharp Reviewer",
  "منتقد جامعه": "Community Critic",
  "لیست آرزوها": "Wishlister",
  "همسفر هوشمند": "AI Companion",
  "کارآفرین": "Entrepreneur",
  "بازیکن": "Player",
  "شکارچی": "Hunter",

  /* ————— دستاوردها: توضیح ————— */
  "نام کاربری و آواتارت را در پروفایل کامل کن": "Complete your username and avatar in the profile",
  "اولین خرید نمایشی خود را انجام بده": "Make your first demo purchase",
  "۳ بازی را در کتابخانه‌ات داشته باش": "Own 3 games in your library",
  "اولین اجاره‌ات را شروع کن": "Start your first rental",
  "یک اجاره ۷ روزه را کامل کن": "Complete a 7-day rental",
  "اولین نظر معتبر خود را ثبت کن": "Post your first valid review",
  "۳ نظر معتبر روی بازی‌های مختلف بنویس": "Write 3 valid reviews on different games",
  "۵ بازی را به علاقه‌مندی‌ها اضافه کن": "Add 5 games to your wishlist",
  "پرسش‌نامه Scorent AI را کامل کن": "Complete the Scorent AI questionnaire",
  "اولین آگهی اجاره‌ات را در Scorent Share بساز": "Create your first listing on Scorent Share",
  "به سطح ۵ برس": "Reach level 5",
  "به سطح ۱۰ برس": "Reach level 10",

  /* ————— چالش‌های هفتگی ————— */
  "کشف‌گر هفته": "Weekly Explorer",
  "منتقد هفته": "Weekly Critic",
  "مستأجر هفته": "Weekly Renter",
  "۳ بازی را این هفته به علاقه‌مندی‌ها اضافه کن": "Add 3 games to your wishlist this week",
  "۱ نظر معتبر این هفته بنویس": "Write 1 valid review this week",
  "یک اجاره این هفته شروع کن": "Start one rental this week",

  /* ————— برچسب‌های XP (awardXp) ————— */
  "تکمیل پروفایل": "Profile completed",
  "خرید نمایشی": "Demo purchase",
  "ثبت نظر معتبر": "Valid review posted",
  "تکمیل دوره اجاره": "Rental period completed",
  "رأی مفید به نظر": "Helpful vote",
  "پرسش‌نامه Scorent AI": "Scorent AI questionnaire",

  /* ————— دلایل خطا (store reasons) ————— */
  "بازی پیدا نشد": "Game not found",
  "این بازی قبلاً خریداری شده است": "You already own this game",
  "اجاره این عنوان در دسترس نیست": "Rental is not available for this title",
  "بازه اجاره نامعتبر است": "Invalid rental period",
  "قیمت اجاره نامعتبر است": "Invalid rental price",
  "اجاره پیدا نشد": "Rental not found",
  "بازه نامعتبر است": "Invalid period",
  "تازگی تمدید شده؛ چند لحظه صبر کن": "Just renewed — please wait a moment",
  "آگهی پیدا نشد": "Listing not found",
  "فقط آگهی‌های خودت قابل ویرایش است": "You can only edit your own listings",
  "این آگهی دیگر در دسترس نیست": "This listing is no longer available",
  "امتیاز باید بین ۱ تا ۵ باشد": "Rating must be between 1 and 5",
  "متن نظر باید حداقل ۱۰ نویسه باشد": "Review must be at least 10 characters",
  "متن نظر بیش از حد طولانی است": "Review is too long (max 600 characters)",
  "قبلاً به این نظر رأی دادی": "You already voted on this review",
  "ساختار فایل پشتیبانی نمی‌شود": "Unsupported file structure",
  "فایل JSON معتبر نیست": "Invalid JSON file",
  "خطا در خرید": "Purchase failed",
  "خطا در اجاره": "Rental failed",

  /* ————— نام‌های سطح ————— */
  "تازه‌کار": "Rookie",
  "نخبه": "Elite",
  "استاد": "Master",
  "افسانه": "Legend",

  /* ————— داده نمونه: آگهی‌های اجاره همتا‌به‌همتا ————— */
  "دو هفته تمامش کردم؛ دنیای عظیمی دارد. برای کسی که می‌خواهد امتحانش کند، اجاره ۷ روزه عالی است.":
    "Took me two full weeks; a massive world. A 7-day rental is perfect if you want to try it.",
  "داستانش را تمام کرده‌ام، دیسک سالم است. برای آخر هفته‌ی داستانی عالی است.":
    "Finished the story, disc in mint condition. Great for a story weekend.",
  "برای شروع روگ‌لایت بهترین انتخاب است. هر جلسه ۳۰ دقیقه؛ ریسک کم، لذت زیاد.":
    "The best entry into roguelites. 30-minute runs; low risk, high reward.",
  "با گروه ۳ نفره شروع کردیم؛ اجاره‌اش می‌ارزد تا ببینید با سلیقه گروهتان جور است یا نه.":
    "Started with a party of 3; worth renting first to see if it clicks with your group.",
  "برای یک شب رانندگی با دوستان. کنترلر و فرمول هر دو اوکی است.":
    "Perfect for a game night with friends. Both controller and wheel setups work.",
  "یک هفته مزرعه‌داری؛ اگر آرامش می‌خواهید همین است. آموزش نصب هم می‌دهم.":
    "One week of farming; pure tranquility. I can help with setup too.",

  /* ————— داده نمونه: نظرات جامعه ————— */
  "برای کشف کردن ساخته شده؛ هر غار و برجی یک راز دارد. اگر با شکست کنار می‌آیی، یکی از بهترین تجربه‌های عمرت خواهد بود.":
    "Built for exploration; every cave and tower hides a secret. If you can embrace failure, it will be one of the best experiences of your life.",
  "چالش واقعی است ولی منصفانه. پیشنهاد من: اول با اجاره امتحانش کن تا مطمئن شوی سبکش دوست‌داشتنی‌ات است.":
    "Genuinely hard but fair. My advice: rent it first to make sure the style clicks with you.",
  "با این قیمت چه چیزی ساختند؟! آرت، موسیقی و نقشه‌کشی همه بی‌نقص‌اند. به هرکسی پیشنهاد می‌کنم.":
    "How did they build this at this price?! Art, music and map design are flawless. Recommended to everyone.",
  "بعد از یک روز سخت درسی، فقط مزرعه‌ام را مرتب می‌کنم و حال دلم خوب می‌شود. بهترین بازی آرام.":
    "After a hard school day, I just tidy my farm and feel better. The ultimate cozy game.",
  "با خواهرم تمامش کردیم؛ هر مرحله کلی خنده و سورپرایز داشت. برای دونفره واقعاً بی‌رقیب است.":
    "My sister and I finished it; every level was packed with laughs and surprises. Unrivaled as a two-player game.",
  "۱۴ سال گذشت و هنوز بهترین نویسندگی پازل را دارد. کمپین همکاری‌اش هم عالی است.":
    "14 years later it still has the best puzzle writing ever. The co-op campaign is superb too.",
  "این بازی به تو اعتماد می‌کند و رازهایش را خودت کشف می‌کنی. کاش می‌توانستم دوباره برای اولین بار بازی‌اش کنم.":
    "This game trusts you and lets you uncover its secrets yourself. I wish I could play it again for the first time.",
  "بعد از آپدیت‌ها واقعاً درخشید. داستان Phantom Liberty هم فوق‌العاده است؛ با تخفیف فعلی ارزشش را دارد.":
    "Truly shined after the updates. The Phantom Liberty story is fantastic too; worth it at the current discount.",

  /* ————— فعالیت‌های نمونه صفحه اصلی ————— */
  "Elden Ring را اجاره کرد و ۲۰ ساعت تجربه‌اش کرد": "rented Elden Ring and played it for 20 hours",
  "به Hollow Knight امتیاز کامل داد": "gave Hollow Knight a perfect score",
  "Stardew Valley را به علاقه‌مندی‌ها اضافه کرد": "added Stardew Valley to their wishlist",
  "Slay the Spire را با تخفیف خرید": "bought Slay the Spire on sale",
  "آگهی اجاره Cyberpunk 2077 ساخت": "created a rental listing for Cyberpunk 2077",

  /* ————— یادداشت‌های سراسری ————— */
  "قیمت‌ها، امتیازها، تخفیف‌ها و موجودی در این پروتوتایپ «داده نمونه دمو» هستند و اطلاعات رسمی فروشگاه‌ها محسوب نمی‌شوند.":
    "Prices, ratings, discounts and availability in this prototype are “demo sample data” and do not represent official store information.",
  "نظرات و فعالیت‌های نمونه بخشی از داده نمایشی دمو هستند؛ نظرات خودت به‌صورت محلی ذخیره می‌شوند.":
    "Sample reviews and activity are part of the demo data; your own reviews are stored locally.",
  "گیمر مهمان": "Guest Gamer",
};
