"use client";

import { ScorpionMark, ScorentMark } from "./logo";
import { Link } from "./router";
import { DEMO_DATA_NOTE } from "@/lib/data/games";
import { useT, useTx } from "@/lib/i18n";

const COLUMNS: { titleKey: string; links: { to: string; labelKey: string }[] }[] = [
  {
    titleKey: "footer.modules",
    links: [
      { to: "/store", labelKey: "footer.storeLink" },
      { to: "/ai-chat", labelKey: "nav.aiChatFull" },
      { to: "/ai", labelKey: "nav.ai" },
      { to: "/rent", labelKey: "nav.rent" },
      { to: "/share", labelKey: "footer.shareLink" },
    ],
  },
  {
    titleKey: "footer.explore",
    links: [
      { to: "/discovery", labelKey: "footer.discoveryLink" },
      { to: "/deals", labelKey: "footer.dealsLink" },
      { to: "/trial", labelKey: "footer.trialLink" },
      { to: "/rewards", labelKey: "nav.rewards" },
    ],
  },
  {
    titleKey: "footer.account",
    links: [
      { to: "/profile", labelKey: "nav.profile" },
      { to: "/rentals", labelKey: "nav.rentals" },
      { to: "/wishlist", labelKey: "nav.wishlist" },
      { to: "/settings", labelKey: "footer.settingsLink" },
    ],
  },
];

export function Footer() {
  const t = useT();
  const tx = useTx();
  return (
    <footer className="relative mt-auto bg-surface pb-28 lg:pb-32">
      <div className="hairline-brand" aria-hidden />
      <div className="mx-auto w-full max-w-7xl px-4 py-12 md:px-6">
        <div className="grid gap-10 md:grid-cols-[1.3fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <ScorpionMark size={40} />
              <div>
                <p className="text-lg font-extrabold" dir="ltr" style={{ textAlign: "start" }}>
                  Scorent
                </p>
                <p className="text-xs font-bold text-deal">«{t("brand.slogan")}»</p>
              </div>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-7 text-muted-foreground">{t("footer.about")}</p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-rent/25 bg-rent/8 px-3 py-1.5 text-[0.7rem] font-bold text-rent">
              {t("brand.rentSlogan")}
            </div>
          </div>

          {COLUMNS.map((col) => (
            <nav key={col.titleKey} aria-label={t(col.titleKey)}>
              <h3 className="mb-3 text-sm font-extrabold">{t(col.titleKey)}</h3>
              <ul className="space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.to}>
                    <Link to={l.to} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                      {t(l.labelKey)}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        <div className="mt-10 space-y-3 border-t border-border pt-6 text-xs leading-6 text-muted-foreground">
          <p>{t("footer.disclaimer")}</p>
          <p>{tx(DEMO_DATA_NOTE)}</p>
          <p className="flex flex-wrap items-center justify-between gap-2">
            <span className="flex items-center gap-2">
              <ScorentMark size={16} />
              {t("footer.credit")}
            </span>
            <span dir="ltr" className="tnum">
              © 2026 Scorent Demo
            </span>
          </p>
        </div>
      </div>
    </footer>
  );
}
