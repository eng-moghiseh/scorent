"use client";

/* ————— اجاره‌های من: فعال‌ها با شمارش زنده + تاریخچه + تمدید ————— */

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { CalendarClock, Hourglass, KeyRound, Plus, TimerReset } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { GameCover } from "@/components/scorent/game-cover";
import { EmptyState, SectionHeader } from "@/components/scorent/shared";
import { Link as RouteLink } from "@/components/scorent/router";
import { getGame } from "@/lib/data/games";
import { useFmt, useT, useTx, useUiDir } from "@/lib/i18n";
import { rentalPrice } from "@/lib/pricing";
import { RENEW_COOLDOWN_MS, remainingMs } from "@/lib/rental-time";
import { useHydrated, useScorent, type ScorentState } from "@/lib/store";
import type { Rental } from "@/lib/types";
import { cn } from "@/lib/utils";

/** منبع زمان مشترک با به‌روزرسانی دوره‌ای — فقط برای نمایش شمارش */
function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState<number>(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

function RenewDialog({ rental, disabled }: { rental: Rental; disabled?: boolean }) {
  const [days, setDays] = useState<1 | 3 | 7>(3);
  const [open, setOpen] = useState(false);
  const renewRental = useScorent((s) => s.renewRental);
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();
  const game = getGame(rental.gameId);
  const active = rental.expiresAt > Date.now();

  const options: (1 | 3 | 7)[] = [1, 3, 7];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" className="gap-1.5 border-rent/40 text-rent hover:bg-rent/10" disabled={disabled}>
          <Plus className="size-3.5" />
          {t("rentals.renew")}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-sm" dir={dir}>
        <DialogHeader>
          <DialogTitle>{t("rentals.renewTitle", { game: game?.title ?? "" })}</DialogTitle>
          <DialogDescription>
            {active
              ? t("rentals.renewActiveDesc")
              : t("rentals.renewExpiredDesc")}
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-3 gap-2">
          {options.map((d) => (
            <button
              key={d}
              type="button"
              role="radio"
              aria-checked={days === d}
              onClick={() => setDays(d)}
              className={cn(
                "rounded-xl border p-3 text-center transition-all",
                days === d ? "border-rent bg-rent/12 text-rent" : "border-border hover:border-rent/40"
              )}
            >
              <span className="block text-sm font-extrabold">{t("rentals.dayCount", { n: f.num(d) })}</span>
              <span className="mt-1 block text-[0.65rem] text-muted-foreground tnum">
                {f.toman(game?.rental ? rentalPrice(game.rental, d) ?? 0 : 0, false)}
              </span>
            </button>
          ))}
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>
            {t("rentals.cancel")}
          </Button>
          <Button
            className="bg-rent text-[#062b18] hover:bg-rent/90"
            onClick={() => {
              const res = renewRental(rental.id, days);
              if (res.ok) {
                toast.success(t("rentals.renewOk", { n: f.num(days) }));
                setOpen(false);
              } else {
                toast.error(tx(res.reason ?? t("rentals.renewErr")));
              }
            }}
          >
            {t("rentals.confirmRenew")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ActiveRentalRow({ rental, now }: { rental: Rental; now: number }) {
  const t = useT();
  const f = useFmt();
  const game = getGame(rental.gameId);
  if (!game) return null;
  const remain = remainingMs(rental, now);
  const critical = remain < 3_600_000;
  const recentlyRenewed = rental.lastRenewedAt && now - rental.lastRenewedAt < RENEW_COOLDOWN_MS;

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-wrap items-center gap-4 rounded-2xl border border-rent/25 bg-card p-4"
    >
      <RouteLink to={`/game/${game.id}`} className="shrink-0 overflow-hidden rounded-xl">
        <GameCover game={game} showTitle={false} className="h-20 w-15" />
      </RouteLink>

      <div className="min-w-40 flex-1">
        <p className="font-black" dir="ltr" style={{ textAlign: "start" }}>
          {game.title}
        </p>
        <p className="mt-1 text-xs text-muted-foreground tnum">
          {t("rentals.dates", { start: f.dateTime(rental.startedAt), end: f.dateTime(rental.expiresAt) })}
        </p>
        <p className="mt-0.5 text-[0.68rem] text-muted-foreground">
          {t("rentals.sourceLine", {
            source: rental.source === "share" ? t("rentals.srcShare") : t("rentals.srcStore"),
            n: f.num(rental.days),
          })}
        </p>
      </div>

      <div className={cn("rounded-xl px-4 py-2.5 text-center", critical ? "bg-destructive/12" : "bg-rent/10")}>
        <p className={cn("text-xs", critical ? "text-destructive" : "text-rent")}>{t("rentals.remainingLabel")}</p>
        <p className={cn("mt-0.5 font-black tnum", critical ? "text-destructive" : "text-rent")}>{f.remaining(remain)}</p>
      </div>

      <div className="flex items-center gap-2">
        <RenewDialog rental={rental} disabled={Boolean(recentlyRenewed)} />
      </div>
    </motion.div>
  );
}

export function RentalsPage() {
  const hydrated = useHydrated();
  const rentals = useScorent((s: ScorentState) => s.rentals);
  const now = useNow(1000);
  const t = useT();
  const f = useFmt();

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-16">
        <div className="skeleton-shimmer h-40 rounded-3xl" />
      </div>
    );
  }

  const active = rentals.filter((r) => r.status === "active" && r.expiresAt > now);
  const completed = rentals.filter((r) => r.status === "completed");
  const totalSpent = rentals.reduce((a, r) => a + r.price, 0);

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-10 md:px-6">
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-rent/12 px-3.5 py-1.5 text-xs font-bold text-rent">
            <KeyRound className="size-3.5" />
            {t("rentals.myRentals")}
          </div>
          <h1 className="text-3xl font-black">{t("rentals.pageTitle")}</h1>
          <p className="mt-2 text-sm leading-7 text-muted-foreground">{t("rentals.pageDesc")}</p>
        </div>
        <div className="flex gap-3 text-center">
          <div className="rounded-2xl border border-border bg-card px-5 py-3">
            <p className="text-2xl font-black text-rent tnum">{f.num(active.length)}</p>
            <p className="text-[0.65rem] text-muted-foreground">{t("rentals.statusActive")}</p>
          </div>
          <div className="rounded-2xl border border-border bg-card px-5 py-3">
            <p className="text-2xl font-black text-deal tnum">{f.toman(totalSpent, false)}</p>
            <p className="text-[0.65rem] text-muted-foreground">{t("rentals.totalSpent")}</p>
          </div>
        </div>
      </header>

      <section className="mb-10" aria-label={t("rentals.activeTitle")}>
        <SectionHeader kicker={t("rentals.kickerOngoing")} title={t("rentals.activeTitle")} icon={Hourglass} tone="rent" />
        {active.length === 0 ? (
          <EmptyState
            icon={KeyRound}
            title={t("rentals.emptyTitle")}
            description={t("rentals.emptyDesc")}
            action={
              <RouteLink to="/rent">
                <Button className="gap-2 bg-rent text-[#062b18] hover:bg-rent/90">
                  <KeyRound className="size-4" />
                  {t("rentals.goCatalog")}
                </Button>
              </RouteLink>
            }
          />
        ) : (
          <div className="space-y-3">
            {active.map((r) => (
              <ActiveRentalRow key={r.id} rental={r} now={now} />
            ))}
          </div>
        )}
      </section>

      <section aria-label={t("rentals.historyAria")}>
        <SectionHeader kicker={t("rentals.kickerArchive")} title={t("rentals.historyTitle")} icon={CalendarClock} />
        {completed.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card/40 p-8 text-center text-sm text-muted-foreground">
            {t("rentals.historyEmpty", { xp: f.num(40) })}
          </div>
        ) : (
          <div className="space-y-2.5">
            {completed.map((r) => {
              const game = getGame(r.gameId);
              if (!game) return null;
              return (
                <div key={r.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card/70 p-3.5">
                  <GameCover game={game} showTitle={false} className="h-14 w-11 rounded-lg" />
                  <div className="min-w-32 flex-1">
                    <p className="text-sm font-bold" dir="ltr" style={{ textAlign: "start" }}>
                      {game.title}
                    </p>
                    <p className="text-[0.68rem] text-muted-foreground tnum">
                      {t("rentals.completedRow", { n: f.num(r.days), price: f.toman(r.price) })}
                      {r.completedAt ? ` — ${t("rentals.endedAt", { when: f.dateTime(r.completedAt) })}` : ""}
                    </p>
                  </div>
                  <span className="rounded-full bg-secondary px-3 py-1 text-[0.65rem] font-bold text-muted-foreground">
                    {t("rentals.statusCompleted")}
                  </span>
                  <RenewDialog rental={r} />
                </div>
              );
            })}
          </div>
        )}
      </section>

      <p className="mt-8 flex items-start gap-2 rounded-2xl border border-border bg-card/60 p-4 text-xs leading-6 text-muted-foreground">
        <TimerReset className="mt-0.5 size-4 shrink-0 text-rent" />
        {t("rentals.renewalRule")}
      </p>
    </div>
  );
}
