"use client";

import { DirectionProvider as RadixDirectionProvider } from "@radix-ui/react-direction";

export function DirectionProvider({ dir, children }: { dir: "rtl" | "ltr"; children: React.ReactNode }) {
  return <RadixDirectionProvider dir={dir}>{children}</RadixDirectionProvider>;
}
