/* ————— کمکی‌های HTTP برای API روت‌ها: پاسخ JSON، بررسی Origin (ضد CSRF)، پارسر بدنه ————— */

import { NextResponse } from "next/server";

export function json(data: unknown, init?: number | ResponseInit) {
  const res = NextResponse.json(data, typeof init === "number" ? { status: init } : init);
  res.headers.set("Cache-Control", "no-store");
  return res;
}

export function badRequest(message: string, extra?: Record<string, unknown>) {
  return json({ ok: false, error: message, ...extra }, 400);
}

export function unauthorized(message = "UNAUTHORIZED") {
  return json({ ok: false, error: message }, 401);
}

export function forbidden(message = "FORBIDDEN") {
  return json({ ok: false, error: message }, 403);
}

export function notFound(message = "NOT_FOUND") {
  return json({ ok: false, error: message }, 404);
}

/** بررسی Origin برای متدهای تغییردهنده — با کوکی SameSite لایه‌ی دوم ضد CSRF */
export function sameOrigin(req: Request): boolean {
  const method = req.method;
  if (method === "GET" || method === "HEAD") return true;

  // مرورگرها Sec-Fetch-Site را می‌فرستند — درخواست cross-site واقعی را رد کن
  const fetchSite = req.headers.get("sec-fetch-site");
  if (fetchSite && fetchSite !== "same-origin" && fetchSite !== "same-site" && fetchSite !== "none") {
    return false;
  }

  const origin = req.headers.get("origin");
  if (!origin) return true; // کلاینت‌های non-browser (کوکی SameSite هم هست)
  try {
    const host = req.headers.get("host");
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

const MAX_JSON_BYTES = 256 * 1024;

export async function readJson<T = Record<string, unknown>>(req: Request): Promise<T | null> {
  try {
    // سقف حجم بدنه — جلوگیری از مصرف منابع با payload های بزرگ
    const len = Number(req.headers.get("content-length") ?? "0");
    if (Number.isFinite(len) && len > MAX_JSON_BYTES) return null;
    const text = await req.text();
    if (text.length > MAX_JSON_BYTES) return null;
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}

/* ————— اعتبارسنجی ورودی‌ها ————— */

export function isEmail(v: unknown): v is string {
  return typeof v === "string" && v.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim());
}

/** نرمال‌سازی شماره موبایل ایران (و پذیرش فرمت جهانی E.164) → +989xxxxxxxxx یا +[1-9]… */
export function normalizePhone(input: unknown): string | null {
  if (typeof input !== "string") return null;
  let s = input.replace(/[\s\-()]/g, "").trim();
  if (/^0\d{10}$/.test(s)) s = "+98" + s.slice(1); // 09123456789
  else if (/^989\d{9}$/.test(s)) s = "+" + s; // 989123456789
  else if (/^00989\d{9}$/.test(s)) s = "+" + s.slice(2);
  else if (/^9\d{9}$/.test(s)) s = "+98" + s; // 9123456789
  if (/^\+[1-9]\d{7,14}$/.test(s)) return s;
  return null;
}

export function cleanName(v: unknown): string | null {
  if (typeof v !== "string") return null;
  const s = v.replace(/\s+/g, " ").trim();
  if (s.length < 2 || s.length > 40) return null;
  return s;
}

export function isStrongPassword(v: unknown): v is string {
  return typeof v === "string" && v.length >= 8 && v.length <= 72;
}

export function cleanText(v: unknown, min: number, max: number): string | null {
  if (typeof v !== "string") return null;
  const s = v.trim().replace(/\r\n/g, "\n");
  if (s.length < min || s.length > max) return null;
  return s;
}
