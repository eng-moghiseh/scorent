"use client";

/* ————— صفحه جزئیات بازی (دوزبانه) ————— */

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Building2,
  CheckCircle2,
  ChevronRight,
  Clock3,
  FlaskConical,
  Heart,
  Info,
  KeyRound,
  Star,
  ThumbsUp,
  Timer,
  Trophy,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { GameCover } from "@/components/scorent/game-cover";
import { DemoNotice, PriceTag, PurchaseDialog, RentDialog } from "@/components/scorent/commerce";
import { DiscountBadge, EmptyState, GenreChip, IndieBadge, RatingBadge, SectionHeader } from "@/components/scorent/shared";
import { Link as RouteLink, navigate } from "@/components/scorent/router";
import { GAMES, getGame } from "@/lib/data/games";
import { seedHelpfulCount } from "@/lib/data/community";
import { finalPrice, rentalPrice, savingsAmount } from "@/lib/pricing";
import { gameTextOf, useFmt, useLang, useT, useTx, type GameText } from "@/lib/i18n";
import { displayName, useHydrated, useScorent } from "@/lib/store";
import type { Game } from "@/lib/types";
import { cn } from "@/lib/utils";

/** بازی‌های مشابه: هم‌پوشانی ژانر + محبوبیت — تابع خالص روی داده استاتیک */
function relatedGames(gameId: string) {
  const game = getGame(gameId);
  if (!game) return [];
  return GAMES.filter((g) => g.id !== gameId && g.available)
    .map((g) => ({
      g,
      score: g.genres.filter((x) => game.genres.includes(x)).length * 10 + g.popularity / 20,
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 4)
    .map((x) => x.g);
}

/** متن کاتالوگ (شعار/توضیح/نکات) به زبان فعال — نسخه null-safe:
 * useGameText به Game غیر-null نیاز دارد، اما همه هوک‌ها باید پیش از بازگشت
 * زودهنگامِ «بازی پیدا نشد» صدا زده شوند (قوانین هوک‌های ری‌اکت).
 */
function useGameTextSafe(game: Game | undefined): GameText {
  const lang = useLang();
  return useMemo(
    () => (game ? gameTextOf(game, lang) : { tagline: "", description: "", highlights: [] }),
    [game, lang]
  );
}

/** یادداشت دموی رسمی در لایه داده فارسی است و در en-map نیست؛
 * اینجا هر یادداشتِ شناخته‌شده به کلید dict-game نگاشت می‌شود و
 * یادداشت ناشناخته (اگر روزی اضافه شود) بدون ترجمه عبور می‌کند.
 */
const TRIAL_NOTE_KEYS: Record<string, string> = {
  "دموی رسمی ثبت‌شده‌ای در دسترس نیست.": "game.trialNoteNoDemo",
  "دموی رسمی ثبت‌شده‌ای در دسترس نیست؛ برای آزمودن، اجاره Scorent را پیشنهاد می‌کنیم.": "game.trialNoteNoDemoRent",
  "دموی رسمی ثبت‌شده‌ای در دسترس نیست؛ نسخه اجاره‌ای Scorent گزینه آزمودن است.": "game.trialNoteNoDemoRental",
  "فعلاً اجاره این عنوان فعال نیست؛ خرید نمایشی در دسترس است.": "game.trialNoteNoRental",
  "ویژگی رسمی Friends' Pass: دوستت می‌تواند نسخه همکاری را رایگان بازی کند (نمونه نمایشی).": "game.trialNoteFriendsPass",
  "دموی رسمی رایگان در استور بازی موجود است (اطلاعات نمونه).": "game.trialNoteStoreDemo",
  "دموی رسمی برای آزمودن گیم‌پلی منتشر شده است (اطلاعات نمونه).": "game.trialNoteGameplayDemo",
  "خود بازی رایگان (Free-to-Play) است؛ نیازی به خرید یا اجاره نیست (نمونه).": "game.trialNoteFreeToPlay",
};

function useTrialNote(): (note: string) => string {
  const t = useT();
  const tx = useTx();
  return useMemo(
    () => (note: string) => {
      const key = TRIAL_NOTE_KEYS[note];
      return key ? t(key) : tx(note);
    },
    [t, tx]
  );
}

function StarsInput({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const t = useT();
  const f = useFmt();
  return (
    <div className="flex gap-1" role="radiogroup" aria-label={t("game.ratingAria")}>
      {Array.from({ length: 5 }).map((_, i) => (
        <button
          key={i}
          type="button"
          role="radio"
          aria-checked={value === i + 1}
          aria-label={t("game.starN", { n: f.num(i + 1) })}
          onClick={() => onChange(i + 1)}
          className="rounded p-0.5 transition-transform hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Star className={cn("size-6", i < value ? "fill-amber-400 text-amber-400" : "text-muted-foreground/40")} />
        </button>
      ))}
    </div>
  );
}

function ReviewForm({ gameId }: { gameId: string }) {
  const [rating, setRating] = useState(0);
  const [text, setText] = useState("");
  const addReview = useScorent((s) => s.addReview);
  const profile = useScorent((s) => s.profile);
  const hydrated = useHydrated();
  const t = useT();
  const f = useFmt();
  const tx = useTx();

  if (!hydrated) return null;

  const submit = () => {
    const res = addReview(gameId, rating, text);
    if (res.ok) {
      toast.success(t("game.reviewAdded"), { description: t("game.reviewXpDesc") });
      setRating(0);
      setText("");
    } else {
      toast.error(tx(res.reason ?? t("game.reviewFailed")));
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h3 className="text-sm font-extrabold">{t("game.addReview")}</h3>
      <p className="mt-1 text-xs leading-6 text-muted-foreground">{t("game.reviewFormNote")}</p>
      <div className="mt-4 space-y-3">
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">{t("game.yourRating")}</span>
          <StarsInput value={rating} onChange={setRating} />
        </div>
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={t("game.reviewPlaceholder")}
          rows={3}
          maxLength={600}
          aria-label={t("game.reviewTextLabel")}
        />
        <div className="flex items-center justify-between">
          <span className="text-[0.68rem] text-muted-foreground tnum">
            {t("game.charCount", { n: f.num(text.trim().length), name: displayName(profile) })}
          </span>
          <Button onClick={submit} size="sm" disabled={rating === 0 || text.trim().length < 10}>
            {t("game.submitReview")}
          </Button>
        </div>
      </div>
    </div>
  );
}

function ReviewCard({
  id,
  author,
  rating,
  text,
  createdAt,
  mine,
}: {
  id: string;
  author: string;
  rating: number;
  text: string;
  createdAt: number;
  mine: boolean;
}) {
  const voted = useScorent((s) => s.votedReviewIds.includes(id));
  const delta = useScorent((s) => s.helpfulDelta[id] ?? 0);
  const voteHelpful = useScorent((s) => s.voteHelpful);
  const hydrated = useHydrated();
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const base = mine ? 0 : seedHelpfulCount(id);

  return (
    <div className={cn("rounded-2xl border p-4", mine ? "border-ai/30 bg-ai/5" : "border-border bg-card")}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-full bg-secondary text-xs font-bold">
            {author.slice(0, 2)}
          </span>
          <div>
            <p className="text-xs font-bold">
              {author}
              {mine ? <span className="ms-1.5 rounded-full bg-ai/15 px-1.5 py-0.5 text-[0.6rem] text-ai">{t("game.yourReview")}</span> : null}
            </p>
            <p className="text-[0.65rem] text-muted-foreground tnum">{hydrated ? f.date(createdAt) : ""}</p>
          </div>
        </div>
        <div className="flex items-center gap-0.5" aria-label={t("game.ratingOutOf5", { n: f.rating(rating) })}>
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} className={cn("size-3", i < rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground/40")} />
          ))}
        </div>
      </div>
      <p className="mt-3 text-xs leading-6 text-muted-foreground">{tx(text)}</p>
      <div className="mt-3 flex justify-end">
        <Button
          variant="ghost"
          size="sm"
          disabled={voted}
          onClick={() => {
            const res = voteHelpful(id);
            if (res.ok) toast.success(t("game.voteAdded"), { description: t("game.voteXpDesc") });
            else toast.info(tx(res.reason ?? t("game.voteAlready")));
          }}
          className={cn("gap-1.5 text-xs", voted ? "text-rent" : "text-muted-foreground")}
        >
          <ThumbsUp className={cn("size-3.5", voted && "fill-current")} />
          {t("game.helpful", { n: f.num(base + delta) })}
        </Button>
      </div>
    </div>
  );
}

export function GameDetailPage({ id }: { id: string }) {
  const game = getGame(id);
  const wishlist = useScorent((s) => s.wishlist);
  const toggleWishlist = useScorent((s) => s.toggleWishlist);
  const purchases = useScorent((s) => s.purchases);
  const allReviews = useScorent((s) => s.reviews);
  const reviews = allReviews.filter((r) => r.gameId === id);
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const lang = useLang();
  const gt = useGameTextSafe(game);
  const trialNote = useTrialNote();

  if (!game) {
    return (
      <div className="mx-auto w-full max-w-3xl px-4 py-20">
        <EmptyState
          icon={Info}
          title={t("game.notFound")}
          description={t("game.notFoundDesc", { id: id || t("game.unknownId") })}
          action={
            <RouteLink to="/store">
              <Button>{t("game.backToStore")}</Button>
            </RouteLink>
          }
        />
      </div>
    );
  }

  const wished = wishlist.includes(game.id);
  const owned = purchases.some((p) => p.gameId === game.id);
  const related = relatedGames(game.id);
  const userRating = reviews.length > 0 ? reviews.reduce((a, r) => a + r.rating, 0) / reviews.length : null;

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 md:px-6">
      <nav aria-label={t("game.breadcrumbAria")} className="mb-5 flex items-center gap-1 text-xs text-muted-foreground">
        <RouteLink to="/store" className="hover:text-foreground">
          {t("nav.store")}
        </RouteLink>
        <ChevronRight className="size-3.5 rotate-180" />
        <span className="text-foreground" dir="ltr">
          {game.title}
        </span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-[320px_1fr]">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <GameCover game={game} priority className="aspect-[3/4] w-full rounded-3xl border border-border shadow-2xl shadow-black/50" />
          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl border border-border bg-card p-2.5">
              <p className="text-[0.62rem] text-muted-foreground">{t("game.popularity")}</p>
              <p className="text-sm font-black text-deal tnum">{f.num(game.popularity)}</p>
            </div>
            <div className="rounded-xl border border-border bg-card p-2.5">
              <p className="text-[0.62rem] text-muted-foreground">{t("game.year")}</p>
              <p className="text-sm font-black tnum">{f.num(game.year)}</p>
            </div>
            <div className="rounded-xl border border-border bg-card p-2.5">
              <p className="text-[0.62rem] text-muted-foreground">{t("game.status")}</p>
              <p className={cn("text-sm font-black", game.available ? "text-rent" : "text-destructive")}>
                {game.available ? t("game.inStock") : t("game.outOfStock")}
              </p>
            </div>
          </div>
        </motion.div>

        <div>
          <div className="flex flex-wrap items-center gap-2">
            {game.indie ? <IndieBadge /> : null}
            <RatingBadge rating={game.rating} />
            {game.discountPercent > 0 ? <DiscountBadge percent={game.discountPercent} /> : null}
            {game.genres.map((g) => (
              <GenreChip key={g} label={tx(g)} />
            ))}
          </div>

          <h1 className="mt-4 text-4xl font-black" dir="ltr" style={{ textAlign: "start" }}>
            {game.title}
          </h1>
          <p className="mt-1.5 text-sm font-bold text-deal">{gt.tagline}</p>
          <p className="mt-4 max-w-3xl text-sm leading-8 text-muted-foreground">{gt.description}</p>

          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Building2, label: t("game.developer"), value: game.developer, ltr: true },
              { icon: Clock3, label: t("game.session"), value: f.minutes(game.sessionMinutes), ltr: false },
              {
                icon: Timer,
                label: t("game.campaign"),
                value: f.hours(game.campaignHours) ?? t("game.noCampaign"),
                ltr: false,
              },
              {
                icon: Users,
                label: t("game.modes"),
                value: game.modes.map(tx).join(lang === "fa" ? "، " : ", "),
                ltr: false,
              },
            ].map((m) => (
              <div key={m.label} className="rounded-2xl border border-border bg-card p-3.5">
                <p className="mb-1 flex items-center gap-1.5 text-[0.65rem] text-muted-foreground">
                  <m.icon className="size-3.5" />
                  {m.label}
                </p>
                <p className="text-xs font-bold" dir={m.ltr ? "ltr" : undefined} style={m.ltr ? { textAlign: "start" } : undefined}>
                  {m.value}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-6 rounded-3xl border border-border bg-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <PriceTag game={game} size="lg" />
                <div className="h-10 w-px bg-border" />
                <div>
                  <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <KeyRound className="size-3.5 text-rent" />
                    {t("game.rentFrom")}
                  </p>
                  <p className="text-sm font-extrabold text-rent tnum">
                    {game.rentalAvailable && game.rental ? f.toman(rentalPrice(game.rental, 1) ?? 0) : t("game.rentUnavailable")}
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <PurchaseDialog game={game} />
                {game.rentalAvailable ? <RentDialog game={game} defaultDays={3} triggerLabel={t("game.rentTrigger")} /> : null}
                <Button
                  variant="outline"
                  onClick={() => {
                    const res = toggleWishlist(game.id);
                    toast[res === "added" ? "success" : "info"](
                      res === "added" ? t("game.wishAdded") : t("game.wishRemoved")
                    );
                  }}
                  className={cn("gap-2", wished && "border-[#ff6b8a]/50 text-[#ff8fa8]")}
                >
                  <Heart className={cn("size-4", wished && "fill-current")} />
                  {wished ? t("game.wished") : t("game.wishlist")}
                </Button>
              </div>
            </div>
            {game.discountPercent > 0 ? (
              <p className="mt-3 text-xs text-deal tnum">
                {t("game.discountNote", {
                  p: f.percent(game.discountPercent),
                  save: f.toman(savingsAmount(game)),
                  price: f.toman(game.originalPrice),
                })}
              </p>
            ) : null}
            {owned ? (
              <p className="mt-3 flex items-center gap-1.5 text-xs font-bold text-rent">
                <CheckCircle2 className="size-4" /> {t("game.ownedNote")}
              </p>
            ) : null}
            <div className="mt-4">
              <DemoNotice />
            </div>
          </div>

          <div className="mt-4 rounded-2xl border border-border bg-card/60 p-4">
            <p className="flex items-center gap-2 text-sm font-extrabold">
              <FlaskConical className="size-4 text-ai" />
              {t("game.trialStatus")}
              <span className="rounded-full bg-secondary px-2 py-0.5 text-[0.6rem] font-bold text-muted-foreground">{t("game.sample")}</span>
            </p>
            <p className="mt-2 text-xs leading-6 text-muted-foreground">{trialNote(game.trial.note)}</p>
            <RouteLink to="/trial" className="mt-2 inline-block text-xs font-bold text-ai hover:underline">
              {t("game.allTrials")}
            </RouteLink>
          </div>
        </div>
      </div>

      <section className="mt-12" aria-label={t("game.highlightsAria")}>
        <SectionHeader kicker={t("game.whyTry")} title={t("game.highlightsTitle")} icon={Trophy} />
        <div className="grid gap-3 md:grid-cols-3">
          {gt.highlights.map((h, i) => (
            <motion.div
              key={h}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07 }}
              className="flex items-start gap-3 rounded-2xl border border-border bg-card p-4"
            >
              <span className="flex size-8 shrink-0 items-center justify-center rounded-xl bg-deal/12 text-sm font-black text-deal tnum">
                {f.num(i + 1)}
              </span>
              <p className="text-sm leading-7">{h}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="mt-12" aria-label={t("game.reviewsAria")}>
        <SectionHeader
          kicker={t("game.communityKicker")}
          title={t("game.reviewsTitle")}
          description={
            userRating
              ? t("game.avgRating", { n: f.rating(userRating), c: f.num(reviews.length) })
              : t("game.reviewsEmptyDesc")
          }
          icon={Users}
        />
        <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
          <div className="space-y-3">
            {reviews.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-border bg-card/40 p-8 text-center text-sm text-muted-foreground">
                {t("game.noReviewsYet")}
              </div>
            ) : (
              reviews.map((r) => <ReviewCard key={r.id} {...r} />)
            )}
          </div>
          <ReviewForm gameId={game.id} />
        </div>
      </section>

      <section className="mt-12" aria-label={t("game.relatedAria")}>
        <SectionHeader
          kicker={t("game.relatedKicker")}
          title={t("game.relatedTitle")}
          icon={Heart}
          action={{ label: t("nav.store"), to: "/store" }}
        />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {related.map((g) => (
            <button key={g.id} type="button" onClick={() => navigate(`/game/${g.id}`)} className="group text-start">
              <GameCover game={g} className="aspect-[3/4] w-full rounded-2xl border border-border transition-transform duration-500 group-hover:scale-[1.03]" />
              <p className="mt-2 truncate text-sm font-bold" dir="ltr" style={{ textAlign: "start" }}>
                {g.title}
              </p>
              <p className="truncate text-xs text-muted-foreground">{tx(g.genres[0])}</p>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
