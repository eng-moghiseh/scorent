/* POST /api/auth/password — تغییر رمز عبور (کاربر متصل) */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, isStrongPassword, json, readJson, sameOrigin } from "@/lib/server/http";
import { userFromRequest, parseToken, SESSION_COOKIE } from "@/lib/server/session";
import { revokeSession } from "@/lib/server/session";
import { hashPassword, verifyPassword } from "@/lib/server/password";
import { publicUser } from "@/lib/server/auth-helpers";
import { audit } from "@/lib/server/audit";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";

interface Body {
  current?: string;
  next?: string;
}

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  const auth = await userFromRequest(req);
  if (!auth) return json({ ok: false, error: "UNAUTHORIZED" }, 401);

  // ضد brute-force روی رمز فعلی
  if (!(await rateLimit(`pwchange:${auth.id}:${clientIp(req)}`, 8, 10 * 60_000))) {
    return json({ ok: false, error: "RATE_LIMITED" }, 429);
  }

  const body = await readJson<Body>(req);
  if (!isStrongPassword(body?.next)) return json({ ok: false, error: "WEAK_PASSWORD" }, 400);

  if (auth.passwordHash) {
    const ok = typeof body?.current === "string" && (await verifyPassword(body.current, auth.passwordHash));
    if (!ok) {
      audit("LOGIN_FAIL", { actorId: auth.id, meta: "wrong current password on change", ip: clientIp(req) });
      return json({ ok: false, error: "WRONG_CURRENT" }, 400);
    }
  }

  const updated = await db.user.update({
    where: { id: auth.id },
    data: { passwordHash: await hashPassword(body.next) },
  });
  // ابطال نشست‌های دیگر دستگاه‌ها — نشست فعلی فعال می‌ماند
  const currentJti = parseToken(req.cookies.get(SESSION_COOKIE)?.value)?.jti;
  const sessions = await db.session.findMany({ where: { userId: auth.id, revokedAt: null }, select: { id: true } });
  for (const s of sessions) {
    if (s.id !== currentJti) await revokeSession(s.id);
  }
  audit("PASSWORD_CHANGED", { actorId: auth.id, target: auth.email ?? auth.phone, ip: clientIp(req) });
  audit("SESSIONS_REVOKED", { actorId: auth.id, target: "others", meta: "after password change" });
  return json({ ok: true, user: publicUser(updated) });
}
