/* ————— محدودکننده‌ی نرخ درخواست — پایدار و مشترک بین نمونه‌های serverless —————
 * شمارنده‌ی پنجره‌ی ثابت در دیتابیس (مدل RateLimit) — همه‌ی نمونه‌های تابع همان
 * شمارنده را می‌بینند؛ اگر DB در دسترس نبود، به حافظه‌ی همان نمونه برمی‌گردیم
 * (توافقی آگاهانه: دسترس‌پذیری بهتر از قطع کامل، و در تک‌نمونه معادل است).
 */

import { db } from "@/lib/db";

const memory = new Map<string, { windowStart: number; count: number }>();

/** شروع پنجره‌ی فعلی — منطق خالص برای تست */
export function windowStartFor(now: number, windowMs: number): number {
  return Math.floor(now / windowMs) * windowMs;
}

/** تصمیم خالص: آیا این شمارش مجاز است؟ */
export function isWithinLimit(count: number, limit: number): boolean {
  return count <= limit;
}

let callsSinceCleanup = 0;

async function dbLimit(key: string, limit: number, windowMs: number): Promise<boolean | null> {
  // null → خطای DB؛ caller به حافظه برمی‌گردد
  try {
    const ws = new Date(windowStartFor(Date.now(), windowMs));
    const rows = await db.$queryRaw<{ count: number }[]>`
      INSERT INTO "RateLimit" ("key", "windowStart", "count", "updatedAt")
      VALUES (${key}, ${ws}, 1, ${new Date()})
      ON CONFLICT ("key") DO UPDATE SET
        "count" = CASE WHEN "RateLimit"."windowStart" = ${ws} THEN "RateLimit"."count" + 1 ELSE 1 END,
        "windowStart" = ${ws},
        "updatedAt" = ${new Date()}
      RETURNING "count"`;
    const count = Number(rows[0]?.count ?? 1);
    if (++callsSinceCleanup >= 500) {
      callsSinceCleanup = 0;
      void db.rateLimit
        .deleteMany({ where: { windowStart: { lt: new Date(Date.now() - 2 * 3600_000) } } })
        .catch(() => undefined);
    }
    return isWithinLimit(count, limit);
  } catch {
    return null;
  }
}

function memoryLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const ws = windowStartFor(now, windowMs);
  const row = memory.get(key);
  const count = row && row.windowStart === ws ? row.count + 1 : 1;
  if (memory.size > 8000) {
    for (const [k, v] of memory) if (now - v.windowStart > 2 * windowMs) memory.delete(k);
  }
  memory.set(key, { windowStart: ws, count });
  return isWithinLimit(count, limit);
}

/** true → مجاز؛ false → از حد گذشته (شمارشِ همین درخواست هم ثبت می‌شود) */
export async function rateLimit(key: string, limit: number, windowMs: number): Promise<boolean> {
  const viaDb = await dbLimit(key, limit, windowMs);
  if (viaDb !== null) return viaDb;
  return memoryLimit(key, limit, windowMs);
}

/** کلید استاندارد از درخواست — ترجیح IP واقعی کلاینت از پراکسی‌های معتبر */
export function clientIp(req: Request): string {
  // Netlify واقعی کلاینت را اینجا می‌گذارد
  const nf = req.headers.get("x-nf-client-connection-ip");
  if (nf) return nf.trim();
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return req.headers.get("x-real-ip")?.trim() || "local";
}
