/* ————— کمک‌متریک‌های مشترک مسیرهای auth ————— */

import type { NextRequest, NextResponse } from "next/server";
import type { User } from "@prisma/client";
import { SESSION_COOKIE, sessionCookieAttrs } from "./session";
import { db } from "@/lib/db";
import { emailHtml, escapeHtml, isDemoMode, sendAndLog } from "./notify";
import { generateOtp, hashOtp } from "./seed";

/* شکل عمومی کاربر — هرگز passwordHash/نشست‌ها بیرون نمی‌رود */
export function publicUser(u: User) {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    phone: u.phone,
    role: u.role,
    status: u.status,
    emailVerified: u.emailVerified,
    phoneVerified: u.phoneVerified,
    emailOptIn: u.emailOptIn,
    smsOptIn: u.smsOptIn,
    lang: u.lang,
    googleLinked: Boolean(u.googleId),
    hasPassword: Boolean(u.passwordHash),
    createdAt: u.createdAt.toISOString(),
  };
}

export type PublicUser = ReturnType<typeof publicUser>;

/** آدرس پایه از هدرهای پروکسی (Caddy) — برای redirectهای OAuth */
export function baseUrl(req: NextRequest): string {
  const proto = req.headers.get("x-forwarded-proto") ?? req.nextUrl.protocol.replace(":", "");
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? req.nextUrl.host;
  return `${proto}://${host}`;
}

export function setSessionCookie(res: NextResponse, token: string, exp: number) {
  /* exp برحسب epoch-ms است؛ sessionCookieAttrs مدت‌زمان می‌گیرد */
  res.cookies.set({ ...sessionCookieAttrs(Math.max(1000, exp - Date.now())), value: token });
}

export function clearSessionCookie(res: NextResponse) {
  res.cookies.set({ ...sessionCookieAttrs(0), value: "" });
}

export async function findUserByIdentifier(identifier: string): Promise<User | null> {
  const s = identifier.trim();
  if (s.includes("@")) {
    return db.user.findUnique({ where: { email: s.toLowerCase() } });
  }
  const { normalizePhone } = await import("./http");
  const phone = normalizePhone(s);
  if (!phone) return null;
  return db.user.findUnique({ where: { phone } });
}

/* ————— کد یک‌بارمصرف: ساخت توکن + ارسال پیام ————— */

export type OtpKind = "EMAIL_VERIFY" | "PHONE_VERIFY" | "PASSWORD_RESET";

export function otpChannelFor(kind: OtpKind, user: User): "EMAIL" | "SMS" {
  if (kind === "EMAIL_VERIFY") return "EMAIL";
  if (kind === "PHONE_VERIFY") return "SMS";
  return user.email ? "EMAIL" : "SMS";
}

export async function issueOtp(user: User, kind: OtpKind): Promise<{ code: string; simulated: boolean; demoExposed: boolean }> {
  // کدهای قبلیِ همان نوع که مصرف/منقضی نشده‌اند باطل می‌شوند (تک‌کدِ فعال)
  await db.token.updateMany({
    where: { userId: user.id, kind, usedAt: null },
    data: { usedAt: new Date() },
  });

  const code = generateOtp();
  await db.token.create({
    data: {
      userId: user.id,
      kind,
      codeHash: hashOtp(code),
      expiresAt: new Date(Date.now() + 10 * 60_000),
    },
  });

  const fa = user.lang !== "en";
  const channel = otpChannelFor(kind, user);
  const recipient = channel === "EMAIL" ? user.email! : user.phone!;
  const demo = isDemoMode();
  /* در production (غیرنمایشی) کد در صندوق خروجی ماسک می‌شود — هیچ رابط مدیریتی کد واقعی را نشان نمی‌دهد */
  const mask = (text: string) => (demo ? text : text.replaceAll(code, "••••••"));

  if (channel === "EMAIL") {
    const subject = fa ? "کد تأیید Scorent" : "Your Scorent verification code";
    const title = fa ? "کد تأیید شما" : "Your verification code";
    const bodyHtml = `<p>${fa ? "کد یک‌بارمصرف شما:" : "Your one-time code:"}</p>
      <p style="font-size:28px;font-weight:800;letter-spacing:6px;color:#8B5CF6;direction:ltr;text-align:center;">${mask(code)}</p>
      <p style="font-size:12px;color:#6b7280;">${fa ? "این کد تا ۱۰ دقیقه معتبر است. اگر شما درخواست نداده‌اید، این پیام را نادیده بگیرید." : "Valid for 10 minutes. If you didn't request this, ignore this message."}</p>`;
    const res = await sendAndLog({
      userId: user.id,
      channel,
      recipient,
      subject,
      body: mask(fa ? `کد تأیید Scorent: ${code} (اعتبار ۱۰ دقیقه)` : `Scorent code: ${code} (valid 10 min)`),
      html: emailHtml(fa ? "fa" : "en", title, bodyHtml),
      kind: kind === "PASSWORD_RESET" ? "ACCOUNT" : "VERIFY",
    });
    return { code, simulated: res.provider === "demo", demoExposed: demo };
  }

  const rawBody = fa ? `Scorent — کد تأیید: ${code} (اعتبار ۱۰ دقیقه)` : `Scorent code: ${code} (valid 10 min)`;
  const res = await sendAndLog({ userId: user.id, channel: "SMS", recipient, body: mask(rawBody), kind: kind === "PASSWORD_RESET" ? "ACCOUNT" : "VERIFY" });
  return { code, simulated: res.provider === "demo", demoExposed: demo };
}

/* ————— پیام خوش‌آمد ————— */

export async function sendWelcome(user: User): Promise<void> {
  const fa = user.lang !== "en";
  if (user.email) {
    const title = fa ? "به Scorent خوش آمدی! 🦂" : "Welcome to Scorent!";
    const html = emailHtml(
      fa ? "fa" : "en",
      title,
      `<p>${fa ? `سلام <b>${escapeHtml(user.name)}</b>،` : `Hi <b>${escapeHtml(user.name)}</b>,`}</p>
       <p>${fa ? "حسابت ساخته شد. حالا می‌توانی با دستیار هوشمند بازی بعدی‌ات را پیدا کنی، اجاره کنی و از اطلاع‌رسانی رویدادها بهره‌مند شوی." : "Your account is ready. You can now discover your next game with the AI assistant, rent titles and receive event announcements."}</p>
       <p style="font-size:12px;color:#6b7280;">${fa ? "قبل از خرید، تجربه‌اش کن!" : "Try it before you buy it!"}</p>`
    );
    await sendAndLog({
      userId: user.id,
      channel: "EMAIL",
      recipient: user.email,
      subject: fa ? "خوش آمدی به Scorent" : "Welcome to Scorent",
      body: fa ? `سلام ${user.name}! حساب Scorent شما ساخته شد.` : `Hi ${user.name}! Your Scorent account is ready.`,
      html,
      kind: "WELCOME",
    });
  } else if (user.phone) {
    await sendAndLog({
      userId: user.id,
      channel: "SMS",
      recipient: user.phone,
      body: fa ? `Scorent — سلام ${user.name}! حساب شما ساخته شد. قبل از خرید، تجربه‌اش کن!` : `Scorent — Hi ${user.name}! Your account is ready.`,
      kind: "WELCOME",
    });
  }
}
