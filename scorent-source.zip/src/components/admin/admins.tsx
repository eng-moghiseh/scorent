"use client";

/* ————— مدیران و سطوح دسترسی — افزودن مدیر، تغییر نقش، سلب دسترسی، ماتریس مجوز ————— */

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ShieldCheck, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { api, useAuth } from "@/lib/auth";
import { PERM_LABELS } from "@/lib/permissions";
import { useFmt, useLang, useT, useUiDir } from "@/lib/i18n";
import { AdminHeader, AdminError, RolePill } from "./ui";
import { AuditTrail } from "./audit";

interface AdminRow {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  role: string;
  status: string;
  lastLoginAt: string | null;
  createdAt: string;
}

const ROLE_OPTIONS = ["ADMIN", "CONTENT_EDITOR", "SUPPORT_AGENT"] as const;

export function AdminAdmins() {
  const t = useT();
  const f = useFmt();
  const dir = useUiDir();
  const lang = useLang();
  const me = useAuth((s) => s.user);
  const [rows, setRows] = useState<AdminRow[] | null>(null);
  const [meId, setMeId] = useState("");
  const [err, setErr] = useState(false);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<string>("SUPPORT_AGENT");
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const res = await api.get<{ ok: boolean; admins: AdminRow[]; me: string }>("/api/admin/admins");
      setRows(res.admins);
      setMeId(res.me);
    } catch {
      setErr(true);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function addAdmin() {
    setBusy(true);
    try {
      await api.post("/api/admin/admins", { name: name.trim(), email: email.trim(), password, role });
      toast.success(t("admin.admins.created"));
      setName("");
      setEmail("");
      setPassword("");
      void load();
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "EMAIL_TAKEN" ? t("auth.errEmailTaken") : t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function changeRole(id: string, nextRole: string) {
    try {
      await api.patch(`/api/admin/admins/${id}`, { role: nextRole });
      toast.success(t("admin.users.updated"));
      void load();
    } catch {
      toast.error(t("admin.error"));
    }
  }

  async function demote(id: string) {
    try {
      await api.del(`/api/admin/admins/${id}`);
      toast.success(t("admin.admins.demoted"));
      void load();
    } catch {
      toast.error(t("admin.error"));
    }
  }

  if (err) return <AdminError />;

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.tab.admins")} description={t("admin.admins.addDesc")} icon={ShieldCheck} />

      {/* افزودن مدیر */}
      <section className="mb-6 rounded-3xl border border-border bg-card p-5" aria-label={t("admin.admins.add")}>
        <h2 className="mb-4 flex items-center gap-2 text-base font-extrabold">
          <UserPlus className="size-5 text-ai" /> {t("admin.admins.add")}
        </h2>
        <div className="grid gap-3 md:grid-cols-4">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-muted-foreground">{t("auth.name")}</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("auth.namePh")} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-muted-foreground">{t("account.email")}</Label>
            <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@scorent.ir" dir="ltr" className="text-start" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-muted-foreground">{t("admin.admins.tempPassword")}</Label>
            <Input value={password} onChange={(e) => setPassword(e.target.value)} type="password" dir="ltr" className="text-start" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-muted-foreground">{t("admin.admins.role")}</Label>
            <div className="flex gap-2">
              <Select dir={dir} value={role} onValueChange={setRole}>
                <SelectTrigger className="flex-1" aria-label={t("admin.admins.role")}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROLE_OPTIONS.map((r) => (
                    <SelectItem key={r} value={r}>
                      {t(`account.role.${r}`)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button onClick={addAdmin} disabled={busy || !name.trim() || !email.trim() || password.length < 8} className="bg-ai text-white hover:bg-ai/90">
                +
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* فهرست مدیران */}
      {rows === null ? (
        <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-14 animate-pulse rounded-2xl border border-border bg-card" />)}</div>
      ) : (
        <div className="mb-6 space-y-2.5">
          {rows.map((a) => {
            const isMe = a.id === meId;
            const isSuper = a.role === "SUPER_ADMIN";
            return (
              <div key={a.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-extrabold">{a.name}</p>
                    <RolePill role={a.role} />
                    {isMe && <span className="rounded-full bg-rent/15 px-2 py-0.5 text-[0.6rem] font-extrabold text-rent">{t("admin.admins.me")}</span>}
                  </div>
                  <p dir="ltr" className="mt-1 text-start text-[0.68rem] text-muted-foreground tnum">
                    {a.email ?? a.phone} · {t("admin.users.lastLogin")}: {a.lastLoginAt ? f.dateTime(new Date(a.lastLoginAt).getTime()) : t("admin.users.never")}
                  </p>
                </div>
                {!isMe && !isSuper && (
                  <div className="flex items-center gap-2">
                    <Select dir={dir} value={a.role} onValueChange={(v) => changeRole(a.id, v)}>
                      <SelectTrigger className="h-8 w-40 text-[0.68rem]" aria-label={t("admin.users.changeRole")}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USER">{t("account.role.USER")}</SelectItem>
                        {ROLE_OPTIONS.map((r) => (
                          <SelectItem key={r} value={r}>
                            {t(`account.role.${r}`)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="outline" className="h-8 border-destructive/40 text-[0.68rem] text-destructive hover:bg-destructive/10">
                          {t("admin.admins.demote")}
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent dir="rtl">
                        <AlertDialogHeader>
                          <AlertDialogTitle>{t("admin.admins.demote")}</AlertDialogTitle>
                          <AlertDialogDescription>{t("admin.admins.demoteConfirm")}</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>{t("admin.cancel")}</AlertDialogCancel>
                          <AlertDialogAction onClick={() => demote(a.id)} className="bg-destructive text-white hover:bg-destructive/90">{t("admin.confirm")}</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ماتریس سطوح دسترسی */}
      <section className="rounded-3xl border border-border bg-card p-5" aria-label={t("admin.admins.matrixTitle")}>
        <h2 className="text-base font-extrabold">{t("admin.admins.matrixTitle")}</h2>
        <p className="mt-1 text-xs leading-6 text-muted-foreground">{t("admin.admins.matrixDesc")}</p>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-125 text-xs">
            <thead>
              <tr className="border-b border-border text-start">
                <th className="p-2.5 text-start font-extrabold">{t("admin.users.role")}</th>
                {PERM_LABELS.map((p) => (
                  <th key={p.perm} className="p-2.5 text-start font-bold text-muted-foreground">{lang === "en" ? p.en : p.fa}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(["SUPER_ADMIN", "ADMIN", "CONTENT_EDITOR", "SUPPORT_AGENT"] as const).map((r) => (
                <tr key={r} className="border-b border-border/60">
                  <td className="p-2.5 font-extrabold">{t(`account.role.${r}`)}</td>
                  {PERM_LABELS.map((p) => {
                    const has =
                      r === "SUPER_ADMIN" ||
                      (r === "ADMIN" && ["stats", "users.read", "users.write", "content", "games", "notify", "tickets", "providers"].includes(p.perm)) ||
                      (r === "CONTENT_EDITOR" && ["stats", "content", "games"].includes(p.perm)) ||
                      (r === "SUPPORT_AGENT" && ["stats", "tickets", "users.read"].includes(p.perm));
                    return (
                      <td key={p.perm} className="p-2.5">
                        <span className={has ? "text-rent" : "text-muted-foreground/40"}>{has ? "✓" : "—"}</span>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 flex items-center gap-1.5 text-[0.65rem] text-muted-foreground">
          <ShieldCheck className="size-3.5 text-deal" /> {t("admin.admins.superNote")}
        </p>
      </section>

      <AuditTrail />
    </div>
  );
}
