/* ————— گزارش حسابرسی (Audit Log) — ثبت اقدامات حساس به‌صورت fail-safe —————
 * هرگونه خطا در ثبت، عملیات اصلی را متوقف نمی‌کند؛ فقط در لاگ سرور دیده می‌شود.
 */

import { db } from "@/lib/db";

export type AuditAction =
  | "LOGIN_OK"
  | "LOGIN_FAIL"
  | "LOGOUT"
  | "ACCOUNT_CREATED"
  | "EMAIL_VERIFIED"
  | "PHONE_VERIFIED"
  | "PASSWORD_CHANGED"
  | "PASSWORD_RESET"
  | "SESSIONS_REVOKED"
  | "GOOGLE_LINKED"
  | "ACCOUNT_SUSPENDED"
  | "ACCOUNT_UNSUSPENDED"
  | "ROLE_CHANGED"
  | "USER_DELETED"
  | "ADMIN_ADDED"
  | "ADMIN_UPDATED"
  | "ADMIN_REMOVED"
  | "CONTENT_UPDATED"
  | "CONTENT_DELETED"
  | "OVERRIDE_UPDATED"
  | "OVERRIDE_DELETED"
  | "ANNOUNCEMENT_SENT"
  | "NOTIFICATION_RETRIED"
  | "TICKET_REPLIED"
  | "TICKET_STATUS_CHANGED";

export function audit(
  action: AuditAction,
  opts: { actorId?: string | null; target?: string | null; meta?: string | null; ip?: string | null } = {}
): void {
  const { actorId, target, meta, ip } = opts;
  void db.auditLog
    .create({
      data: {
        actorId: actorId ?? null,
        action,
        target: target ? target.slice(0, 120) : null,
        meta: meta ? meta.slice(0, 500) : null,
        ip: ip ?? null,
      },
    })
    .catch((e) => {
      // حسابرسی هرگز عملیات اصلی را نشکند؛ اما بی‌صدا هم نیست
      console.error("[audit]", action, e instanceof Error ? e.message : e);
    });
}
