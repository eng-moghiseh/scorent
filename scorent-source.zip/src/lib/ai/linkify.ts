/* ————— لینک‌سازی قطعی عناوین بازی در پاسخ دستیار —————
 * مدل گاهی عنوان بازی را بدون لینک می‌نویسد؛ برای تضمین «یک کلیک تا صفحه بازی»،
 * عناوین شناخته‌شده کاتالوگ را به لینک مارک‌داون تبدیل می‌کنیم.
 * عنوان‌هایی که داخل لینک مارک‌داون هستند (بلافاصله بعد از «[») دست‌نخورده می‌مانند.
 */

import { GAMES } from "../data/games";

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

const TITLE_LINKERS: Array<{ re: RegExp; id: string; title: string }> = GAMES.filter((g) => g.title.length >= 4).map((g) => ({
  id: g.id,
  title: g.title,
  re: new RegExp(`(?<!\\[)\\b${escapeRegExp(g.title)}\\b(?!\\]\\()`, "g"),
}));

export function linkifyGameTitles(content: string): string {
  let out = content;
  for (const { re, id, title } of TITLE_LINKERS) {
    re.lastIndex = 0;
    out = out.replace(re, `[${title}](#/game/${id})`);
  }
  return out;
}
