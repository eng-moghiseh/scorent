import { GAMES } from "/home/z/my-project/src/lib/data/games.ts";
import { finalPrice } from "/home/z/my-project/src/lib/pricing.ts";
for (const id of ["stardew-valley", "gris", "unpacking"]) {
  const g = GAMES.find((x) => x.id === id);
  if (!g) { console.log(id, "NOT FOUND"); continue; }
  console.log(g.title, "| original:", g.originalPrice, "| discount:", g.discountPercent, "| final:", finalPrice(g));
}
