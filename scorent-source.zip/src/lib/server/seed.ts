/* ————— Seed خودکار: ادمین ارشد + محتوای پیش‌فرض سایت —————
 * idempotent — یک‌بار در هر فرایند اجرا می‌شود.
 *
 * سیاست امن ادمین (بدون اعتبارنامه‌ی عمومی پیش‌فرض):
 *  - اگر SUPER_ADMIN موجود باشد → دست نمی‌زنیم (هیچ reset خودکار در استارتاپ).
 *  - در غیر این صورت فقط وقتی ADMIN_EMAIL و ADMIN_PASSWORD هر دو از env ست شده
 *    باشند ادمین ساخته/ارتقا می‌یابد؛ بدون env فقط هشدار روشن در لاگ سرور.
 *  - اگر ADMIN_PASSWORD از env ست شده باشد و با رمز فعلی همان حساب متفاوت باشد،
 *    «قصد صریح عملیات» محسوب می‌شود و همگام می‌شود (چرخش رمز از طریق env).
 */

import { createHmac, randomInt, timingSafeEqual } from "node:crypto";
import { db } from "@/lib/db";
import { authSecret } from "./session";
import { hashPassword } from "./password";
import { audit } from "./audit";
import { DEFAULT_CONTENT } from "@/lib/site-content";

/* اعتبارنامه‌ی عمومی پیش‌فرض حذف شده — فقط از env خوانده می‌شود */
const PUBLIC_DEFAULT_PASSWORDS = new Set(["scorent@2026!", "admin", "12345678", "password"]);

let seeded: Promise<void> | null = null;

export function ensureSeed(): Promise<void> {
  if (!seeded) seeded = doSeed();
  return seeded;
}

async function doSeed(): Promise<void> {
  try {
    await provisionAdmin();

    for (const row of DEFAULT_CONTENT) {
      await db.siteContent.upsert({
        where: { key: row.key },
        update: {},
        create: { key: row.key, valueFa: row.valueFa, valueEn: row.valueEn, updatedBy: "system" },
      });
    }
  } catch (e) {
    // در محیط بدون دیتابیس خطا ثبت می‌شود؛ مسیرها خودشان خطای DB را می‌دهند
    console.error("[seed]", e instanceof Error ? e.message : e);
    seeded = null; // اجازه‌ی تلاش مجدد
  }
}

async function provisionAdmin(): Promise<void> {
  const envEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const envPassword = process.env.ADMIN_PASSWORD;
  const envName = process.env.ADMIN_NAME?.trim() || "مدیر ارشد Scorent";

  if (!envEmail || !envPassword) {
    const anySuper = await db.user.findFirst({ where: { role: "SUPER_ADMIN" } });
    if (!anySuper) {
      console.warn(
        "[seed] No SUPER_ADMIN exists and ADMIN_EMAIL/ADMIN_PASSWORD are not configured. " +
          "Set both environment variables to provision the initial administrator securely."
      );
    }
    return; // بدون پیکربندی صریح، هیچ ادمینی ساخته یا تغییر داده نمی‌شود
  }

  if (PUBLIC_DEFAULT_PASSWORDS.has(envPassword.toLowerCase())) {
    console.error("[seed] ADMIN_PASSWORD matches a publicly-known default — refusing to provision with it. Choose a unique strong password.");
    return;
  }

  const existingSuper = await db.user.findFirst({ where: { role: "SUPER_ADMIN" } });
  if (existingSuper) {
    // ادمین ارشد موجود است — هیچ تغییری در استارتاپ انجام نمی‌شود
    return;
  }

  const byEmail = await db.user.findUnique({ where: { email: envEmail } });
  if (byEmail) {
    // ارتقای صریح حساب موجود به ادمین ارشد با اعتبارنامه‌ی env (قصد عملیات، نه reset خودکار)
    await db.user.update({
      where: { id: byEmail.id },
      data: { role: "SUPER_ADMIN", status: "ACTIVE", passwordHash: await hashPassword(envPassword) },
    });
    audit("ROLE_CHANGED", { actorId: null, target: byEmail.email, meta: "provisioned via ADMIN_EMAIL/ADMIN_PASSWORD" });
    return;
  }

  await db.user.create({
    data: {
      name: envName,
      email: envEmail,
      passwordHash: await hashPassword(envPassword),
      role: "SUPER_ADMIN",
      emailVerified: true,
      lang: "fa",
    },
  });
  audit("ADMIN_ADDED", { actorId: null, target: envEmail, meta: "provisioned via env on empty database" });
}

/* ————— OTP: تولید امن + هش HMAC + مقایسه‌ی زمان-امن ————— */

/** کد ۶ رقمی با منبع آنتروپی رمزنگارانه (هرگز Math.random) */
export function generateOtp(): string {
  return String(randomInt(100_000, 1_000_000));
}

/** هش HMAC-SHA256 کد با کلید نشست — بدون کلید عمومی قابل حدس */
export function hashOtp(code: string): string {
  return createHmac("sha256", authSecret()).update(`otp:${code}`).digest("hex");
}

/** مقایسه‌ی زمان-امن کد واردشده با هش ذخیره‌شده */
export function otpMatches(code: string, storedHash: string): boolean {
  const a = Buffer.from(hashOtp(code), "hex");
  let b: Buffer;
  try {
    b = Buffer.from(storedHash, "hex");
  } catch {
    return false;
  }
  return a.length === b.length && timingSafeEqual(a, b);
}
