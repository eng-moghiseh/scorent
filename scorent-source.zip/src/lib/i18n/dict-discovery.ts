/* ————— fragment: dict-discovery —————
 * صفحات: کشف (discovery.*)، تخفیف‌ها (deals.*)، دموها و تریال‌ها (trial.*)،
 * جوایز و دستاوردها (rewards.*). هر کلید: [فارسی، English]؛ پارامترها {name}.
 * یادداشت‌های دمو (Game.trial.note) با «عین رشتهٔ داده» کلید شده‌اند:
 * t(g.trial.note) در فارسی همان رشتهٔ اصلی و در انگلیسی معادل را برمی‌گرداند.
 */

export const STR: Record<string, [string, string]> = {
  /* ————— کشف ————— */
  "discovery.tabsAria": ["مسیرهای کشف", "Discovery paths"],
  "discovery.title": ["کشف، نه فقط جستجو", "Discovery, not just search"],
  "discovery.desc": [
    "چهار مسیر منحنه برای پیدا کردن بازی بعدی. هر بازی یک دلیل کوتاه برای امتحان‌کردن دارد — همان چیزی که جعبه‌ها به تو نمی‌گویند.",
    "Four winding paths to your next game. Every game comes with a short reason to try it — the thing the box doesn't tell you.",
  ],
  "discovery.tabIndie": ["مستقل‌های درخشان", "Shining indies"],
  "discovery.tabIndieDesc": [
    "استودیوهای کوچک، ایده‌های درشت؛ بهترین نسبت کیفیت به قیمت کاتالوگ.",
    "Small studios, big ideas; the best quality-to-price ratio in the catalog.",
  ],
  "discovery.tabGems": ["گوهرهای پنهان", "Hidden gems"],
  "discovery.tabGemsDesc": [
    "امتیاز بالا، محبوبیت پایین‌تر — بازی‌هایی که جمعیت از کنارشان رد شده.",
    "High ratings, lower popularity — games the crowd walked right past.",
  ],
  "discovery.tabUnusual": ["انتخاب‌های غیرمعمول", "Unusual picks"],
  "discovery.tabUnusualDesc": [
    "تجربه‌های متفاوت و در برخی موارد ژانرشکن؛ برای وقتی که همه‌چیز تکراری شده.",
    "Different, sometimes genre-bending experiences; for when everything starts feeling repetitive.",
  ],
  "discovery.tabForYou": ["برای تو", "For you"],
  "discovery.tabForYouDesc": [
    "بر اساس پاسخ‌های پرسش‌نامه Scorent AI — بدون پاسخ، معنادار نیست.",
    "Based on your Scorent AI questionnaire answers — without them it stays empty.",
  ],
  "discovery.noPrefs1": ["فعلاً پاسخ‌ای ذخیره نشده؛", "No answers saved yet; complete the"],
  "discovery.noPrefsLink": ["پرسش‌نامه AI", "AI questionnaire"],
  "discovery.noPrefs2": ["را کامل کن تا این بخش زنده شود.", "to bring this section to life."],
  "discovery.quizEmptyTitle": ["پرسش‌نامه را کامل کن", "Complete the questionnaire"],
  "discovery.quizEmptyDesc": [
    "«برای تو» با موتور امتیازدهی و پاسخ‌های تو کار می‌کند. دو دقیقه وقت بگذار، نتیجه‌اش شخصی است.",
    "“For you” works with the scoring engine and your own answers. Give it two minutes — the result is personal.",
  ],
  "discovery.quizStart": ["شروع پرسش‌نامه", "Start the questionnaire"],
  "discovery.emptyTitle": ["چیزی اینجا نیست", "Nothing here yet"],
  "discovery.emptyDesc": ["بعداً سر بزن.", "Check back later."],
  "discovery.gemMeta": ["امتیاز {r} از ۵ • محبوبیت {p} از ۱۰۰", "Rating {r} out of 5 • Popularity {p} out of 100"],
  "discovery.stripKicker": ["کمتر دیده‌شده", "Lesser seen"],
  "discovery.stripTitle": ["مستقل‌های چشم‌گیر با کاورهای خاص", "Striking indies with distinctive covers"],

  /* ————— دلایل کوتاه امتحان‌کردن (کشف) ————— */
  "discovery.reason.default": [
    "به‌خاطر امتیاز بالا و تجربه متفاوتش ارزش امتحان دارد",
    "Worth a try for its high rating and one-of-a-kind experience",
  ],
  "discovery.reason.disco-elysium": [
    "هیچ اسلحه‌ای نداری؛ همه‌چیز با گفتگو پیش می‌رود",
    "You carry no weapons; everything moves forward through conversation",
  ],
  "discovery.reason.outer-wilds": [
    "پیشرفت با دانش است، نه تجهیزات — تجربه‌ای کمیاب",
    "Progress comes from knowledge, not equipment — a rare kind of experience",
  ],
  "discovery.reason.papers-please": [
    "ساده اما اخلاقیاتش تا مدت‌ها با تو می‌ماند",
    "Simple, yet its moral dilemmas stay with you for a long time",
  ],
  "discovery.reason.katana-zero": [
    "کمپین کوتاه، فشرده و تیز برای یک آخر هفته",
    "A short, dense, razor-sharp campaign for one weekend",
  ],
  "discovery.reason.tunic": ["خودِ راهنمای بازی بخشی از پازل است", "The manual itself is part of the puzzle"],
  "discovery.reason.gris": ["بدون شکست و استرس؛ مثل کتاب تصویری متحرک", "No failure, no stress; like a living picture book"],
  "discovery.reason.cuphead": ["چالش رترو با انیمیشن دست‌ساز دهه {n}", "A retro challenge with hand-drawn 1930s animation"],
  "discovery.reason.sifu": ["هر شکست تو را پیرتر و محتاط‌تر می‌کند", "Every defeat ages you and makes you more careful"],
  "discovery.reason.slay-the-spire": [
    "جلسه {n} دقیقه‌ای که ممکن است {m} اجرا شود",
    "A {n}-minute session that might turn into {m} runs",
  ],
  "discovery.reason.vampire-survivors": ["با کمترین پیچیدگی، بیشترین سرگرمی", "Maximum fun with minimum complexity"],
  "discovery.reason.celeste": ["سختی که با ری‌استارت فوری معذب نمی‌کند", "Difficulty that never punishes you with long restarts"],
  "discovery.reason.stardew-valley": ["آرامش خالص برای شب‌های شلوغ ذهن", "Pure calm for a noisy mind at night"],
  "discovery.reason.hollow-knight": ["کشف در اعماقی که نقشه‌شان را خودت می‌کشی", "Exploration in depths you map yourself"],
  "discovery.reason.hades": ["هر شکست داستان را جلو می‌برد", "Every defeat pushes the story forward"],

  /* ————— تخفیف‌ها ————— */
  "deals.badge": ["Scorent Deals — پیشنهادهای نمونه", "Scorent Deals — sample offers"],
  "deals.title": ["تخفیف‌های این هفته", "This week's deals"],
  "deals.desc": [
    "قیمت پایه، درصد تخفیف، قیمت نهایی و مبلغ صرفه‌جویی همیشه با یک ابزار محاسبه واحد به‌دست می‌آید؛ قیمت منفی یا تخفیف نامعتبر در سیستم ممکن نیست.",
    "Base price, discount percent, final price and savings always come from a single pricing engine; a negative price or an invalid discount is impossible in this system.",
  ],
  "deals.totalSavingsNote": [
    "مجموع صرفه‌جویی اگر همه را می‌خردی (فرض نمایشی)",
    "Total savings if you bought everything (demo assumption)",
  ],
  "deals.emptyTitle": ["فعلاً تخفیفی نیست", "No deals right now"],
  "deals.emptyDesc": ["دوباره سر بزن — پیشنهادها هر هفته به‌روز می‌شوند (نمونه).", "Check back soon — offers refresh every week (sample)."],
  "deals.bigBadge": ["{p}٪− تخفیف بزرگ هفته", "Big deal of the week −{p}%"],
  "deals.biggestActive": ["بیشترین تخفیف فعال", "Biggest active discount"],
  "deals.lessAmount": ["{a} کمتر", "{a} less"],
  "deals.details": ["جزئیات", "Details"],
  "deals.allTitle": ["همه پیشنهادهای فعال", "All active offers"],
  "deals.allCount": ["{n} عنوان با تخفیف نمونه", "{n} titles with sample discounts"],
  "deals.savingOf": ["صرفه‌جویی: {a}", "Saving: {a}"],

  /* ————— دموها و تریال‌ها ————— */
  "trial.badge": ["دموها و تریال‌ها", "Demos & trials"],
  "trial.title": ["قبل از هر تصمیم، امتحان کن", "Try before you decide"],
  "trial.desc": [
    "این صفحه وضعیت دموها را نشان می‌دهد و تفکیک می‌کند: چه چیزی «دموی رسمی سازنده» است و چه چیزی «شبیه‌سازی Scorent». Scorent هیچ‌وقت بازی تجاری را باز نمی‌کند یا قفل لایسنس را دور نمی‌زند.",
    "This page shows demo status and tells the two apart: what is an “official publisher demo” and what is a “Scorent simulation”. Scorent never unlocks a commercial game or circumvents license checks.",
  ],
  "trial.officialTitle": ["دموی رسمی سازنده", "Official publisher demo"],
  "trial.officialDesc": [
    "نسخه‌ای که خود سازنده/ناشر به‌صورت رسمی منتشر کرده و مستقیماً از استور بازی قابل دریافت است. وضعیت فعلی را همیشه در صفحه رسمی بازی چک کن — داده‌های اینجا نمونه دمو هستند.",
    "A version officially released by the developer/publisher and available directly from the game's store. Always check the game's official page for the current status — the data here is sample demo data.",
  ],
  "trial.simTitle": ["شبیه‌سازی Scorent", "Scorent simulation"],
  "trial.simDesc": [
    "برای بازی‌هایی که دموی رسمی ندارند، جریان «اجاره نمایشی» Scorent حس آزمودن را شبیه‌سازی می‌کند؛ بدون هیچ دسترسی واقعی به فایل یا لایسنس بازی.",
    "For games without an official demo, Scorent's “demo rental” flow simulates the feeling of trying it; with no real access to the game's files or license.",
  ],
  "trial.withTrialTitle": ["عنوان‌های دارای دمو یا ویژگی رسمی", "Titles with a demo or official feature"],
  "trial.withTrialCount": ["{n} عنوان (نمونه)", "{n} titles (sample)"],
  "trial.emptyTitle": ["فعلاً دمویی ثبت نشده", "No demos registered yet"],
  "trial.emptyDesc": ["به‌زودی.", "Coming soon."],
  "trial.kindOfficialDemo": ["دموی رسمی (نمونه)", "Official demo (sample)"],
  "trial.kindFriendsPass": ["ویژگی رسمی دوستانه (نمونه)", "Official friends feature (sample)"],
  "trial.kindNone": ["دموی رسمی ثبت‌شده نیست", "No official demo registered"],
  "trial.gamePage": ["صفحه بازی", "Game page"],
  "trial.simRent": ["اجاره شبیه‌سازی‌شده", "Simulated rental"],
  "trial.noneKicker": ["بدون دموی رسمی", "Without an official demo"],
  "trial.noneTitle": ["برای این‌ها، اجاره نمایشی جای دمو را می‌گیرد", "For these, a demo rental stands in for a demo"],
  "trial.noneDesc": [
    "فهرست نمونه؛ اطلاعات واقعی هر بازی را از صفحه رسمی آن بررسی کن.",
    "Sample list; check each game's official page for real information.",
  ],
  "trial.transparency": [
    "اصل شفافیت Scorent: هیچ‌کدام از امکانات این پروتوتایپ (خرید، اجاره، اشتراک‌گذاری، دمو) دسترسی واقعی به بازی اعطا نمی‌کند و رابطه‌ای با ناشران ندارد. هدف، نمایش طراحی محصول و جریان‌های کاربر است.",
    "Scorent transparency principle: none of this prototype's features (purchase, rental, sharing, demo) grant real access to any game, and Scorent has no relationship with publishers. The goal is to showcase product design and user flows.",
  ],

  /* ————— یادداشت‌های دمو (عین رشته‌های داده به‌عنوان کلید) ————— */
  "دموی رسمی رایگان در استور بازی موجود است (اطلاعات نمونه).": [
    "دموی رسمی رایگان در استور بازی موجود است (اطلاعات نمونه).",
    "A free official demo is available on the game store (sample info).",
  ],
  "دموی رسمی برای آزمودن گیم‌پلی منتشر شده است (اطلاعات نمونه).": [
    "دموی رسمی برای آزمودن گیم‌پلی منتشر شده است (اطلاعات نمونه).",
    "An official demo has been released for trying the gameplay (sample info).",
  ],
  "ویژگی رسمی Friends' Pass: دوستت می‌تواند نسخه همکاری را رایگان بازی کند (نمونه نمایشی).": [
    "ویژگی رسمی Friends' Pass: دوستت می‌تواند نسخه همکاری را رایگان بازی کند (نمونه نمایشی).",
    "Official Friends' Pass feature: your friend can play the co-op version for free (sample).",
  ],

  /* ————— جوایز و دستاوردها ————— */
  "rewards.title": ["جوایز و پیشرفت تو", "Your rewards & progress"],
  "rewards.totalXp": ["مجموع XP:", "Total XP:"],
  "rewards.formulaPre": ["— سطح از فرمول", "— level is computed from the formula"],
  "rewards.formula": ["۱۰۰ + (سطح−۱)×۵۰", "100 + (level−1)×50"],
  "rewards.formulaPost": ["محاسبه می‌شود.", ""],
  "rewards.toLevel": ["پیشرفت تا سطح {n}", "Progress to level {n}"],
  "rewards.progressPct": ["{n}٪", "{n}%"],
  "rewards.xpToNext": ["{n} XP تا سطح بعدی", "{n} XP to the next level"],
  "rewards.levelN": ["سطح {n}", "Level {n}"],
  "rewards.challengesAria": ["چالش‌های هفتگی", "Weekly challenges"],
  "rewards.kickerThisWeek": ["این هفته", "This week"],
  "rewards.challengesTitle": ["چالش‌های هفتگی", "Weekly challenges"],
  "rewards.challengesDesc": [
    "تکمیل هر چالش {n} XP دارد؛ برای هر هفته فقط یک‌بار ثبت می‌شود (شناسه هفته + چالش).",
    "Each completed challenge is worth {n} XP; it is recorded only once per week (week ID + challenge).",
  ],
  "rewards.doneBadge": ["تکمیل شد ✓", "Completed ✓"],
  "rewards.xpChip": ["{n} XP", "{n} XP"],
  "rewards.progressOf": ["{a} از {b}", "{a} of {b}"],
  "rewards.pendingNote": [" — جایزه به‌محض ثبت رویداد اعطا می‌شود", " — reward is granted as soon as the event is recorded"],
  "rewards.achievementsAria": ["دستاوردها", "Achievements"],
  "rewards.kickerGallery": ["گالری", "Gallery"],
  "rewards.achTitle": ["دستاوردها ({a} از {b})", "Achievements ({a} of {b})"],
  "rewards.achDesc": [
    "هر دستاورد یک‌بار باز می‌شود و به‌جز دستاوردهای سطحی، XP جایزه هم دارد.",
    "Each achievement unlocks once and, apart from level achievements, also grants an XP reward.",
  ],
  "rewards.myProfile": ["پروفایل من", "My profile"],
  "rewards.bonusXp": ["+{n} XP", "+{n} XP"],
  "rewards.historyAria": ["تاریخچه جوایز", "Rewards history"],
  "rewards.kickerLedger": ["دفتر رویدادها", "Event ledger"],
  "rewards.historyTitle": ["تاریخچه XP", "XP history"],
  "rewards.historyDesc": ["هر رویداد شناسه یکتا دارد؛ جایزه تکراری غیرممکن است.", "Every event has a unique ID; duplicate rewards are impossible."],
  "rewards.emptyTitle": ["هنوز XP نداری", "No XP yet"],
  "rewards.emptyDesc": [
    "پروفایل را کامل کن ({a})، اولین خرید نمایشی را انجام بده ({b}) یا نظری بنویس ({c}). XP امتیاز مجازی است و ارزش پولی ندارد.",
    "Complete your profile ({a}), make your first demo purchase ({b}) or write a review ({c}). XP is a virtual score with no monetary value.",
  ],
  "rewards.emptyCta": ["کامل‌کردن پروفایل", "Complete your profile"],
  "rewards.xpPlus": ["+{n}", "+{n}"],
};
