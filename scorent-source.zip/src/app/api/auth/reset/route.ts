/* POST /api/auth/reset — بازنشانی رمز با کد (همه نشست‌ها ابطال می‌شود) */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, isStrongPassword, json, readJson, sameOrigin } from "@/lib/server/http";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";
import { hashPassword } from "@/lib/server/password";
import { otpMatches } from "@/lib/server/seed";
import { audit } from "@/lib/server/audit";
import { findUserByIdentifier } from "@/lib/server/auth-helpers";

interface Body {
  identifier?: string;
  code?: string;
  next?: string;
}

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  if (!(await rateLimit(`reset:${clientIp(req)}`, 10, 10 * 60_000))) {
    return json({ ok: false, error: "RATE_LIMITED" }, 429);
  }

  const body = await readJson<Body>(req);
  const identifier = typeof body?.identifier === "string" ? body.identifier.trim() : "";
  const code = typeof body?.code === "string" ? body.code.replace(/\D/g, "") : "";
  if (!identifier || code.length !== 6 || !isStrongPassword(body?.next)) {
    return json({ ok: false, error: "INVALID_INPUT" }, 400);
  }

  const user = await findUserByIdentifier(identifier);
  if (!user) return json({ ok: false, error: "WRONG_CODE" }, 400);

  const token = await db.token.findFirst({
    where: { userId: user.id, kind: "PASSWORD_RESET", usedAt: null },
    orderBy: { createdAt: "desc" },
  });
  if (!token || token.expiresAt.getTime() < Date.now() || token.attempts >= 5) {
    return json({ ok: false, error: "CODE_EXPIRED" }, 400);
  }

  if (!otpMatches(code, token.codeHash)) {
    await db.token.update({ where: { id: token.id }, data: { attempts: { increment: 1 } } });
    return json({ ok: false, error: "WRONG_CODE" }, 400);
  }

  await db.token.update({ where: { id: token.id }, data: { usedAt: new Date() } });
  await db.user.update({ where: { id: user.id }, data: { passwordHash: await hashPassword(body.next) } });
  // ابطال همه‌ی نشست‌های فعال (امنیت پس از تغییر اعتبارنامه)
  await db.session.updateMany({ where: { userId: user.id, revokedAt: null }, data: { revokedAt: new Date() } });
  audit("PASSWORD_RESET", { actorId: user.id, target: user.email ?? user.phone });
  audit("SESSIONS_REVOKED", { actorId: user.id, target: "all", meta: "after password reset" });
  return json({ ok: true });
}
