"use client";

/* ————— کاتالوگ زنده: دیتاست اصلی + اورراید ادمین —————
 * اورراید از /api/overrides خوانده و «در همان آرایه‌ی GAMES» اعمال می‌شود؛
 * چون همه‌ی ماژول‌ها مرجع یکسان GAMES را ایمپورت کرده‌اند، همه‌ی صفحات و
 * سلکتورهای موجود (getGame، featuredGames، GAMES.length و ...) بدون تغییر
 * از اورراید پیروی می‌کنند. پس از hydrate، نسخه (version) بالا می‌رود تا
 * شِل اپ رندر مجدد شود.
 */

import { create } from "zustand";
import { GAMES } from "@/lib/data/games";
import type { Game } from "@/lib/types";

export interface GameOverrideData {
  hidden?: boolean;
  featured?: boolean;
  discountPct?: number;
  taglineFa?: string;
  taglineEn?: string;
  descriptionFa?: string;
  descriptionEn?: string;
}

interface CatalogState {
  overrides: Record<string, GameOverrideData>;
  version: number; // 0 = هنوز hydrate نشده
}

export const useCatalog = create<CatalogState>()(() => ({ overrides: {}, version: 0 }));

let hydrated = false;

export function hydrateCatalog(): void {
  if (hydrated) return;
  hydrated = true;
  (async () => {
    try {
      const res = await fetch("/api/overrides", { cache: "no-cache" });
      const data = (await res.json()) as { ok: boolean; overrides: Record<string, GameOverrideData> };
      if (!data.ok || !data.overrides) {
        useCatalog.setState({ version: 1 });
        return;
      }
      const overrides = data.overrides;
      // اعمال درجا: پنهان‌ها حذف، بقیه با مقادیر جدید جایگزین می‌شوند
      for (let i = GAMES.length - 1; i >= 0; i--) {
        const g = GAMES[i];
        const o = overrides[g.id];
        if (!o) continue;
        if (o.hidden) {
          GAMES.splice(i, 1);
          continue;
        }
        const next: Game = { ...g };
        if (typeof o.featured === "boolean") next.featured = o.featured;
        if (typeof o.discountPct === "number") {
          const pct = Math.max(0, Math.min(90, Math.round(o.discountPct)));
          next.originalPrice = next.originalPrice || next.price;
          next.discountPercent = pct;
          next.price = Math.max(1000, Math.round((next.originalPrice * (1 - pct / 100)) / 1000) * 1000);
        }
        if (o.taglineFa) next.tagline = o.taglineFa;
        if (o.taglineEn) next.taglineEn = o.taglineEn;
        if (o.descriptionFa) next.description = o.descriptionFa;
        if (o.descriptionEn) next.descriptionEn = o.descriptionEn;
        GAMES[i] = next;
      }
      useCatalog.setState({ overrides, version: 1 });
    } catch {
      useCatalog.setState({ version: 1 });
    }
  })();
}

/** هوک شِل: اولین دسترسی باعث hydrate می‌شود؛ تغییر نسخه → رندر مجدد درختی */
export function useCatalogReady(): boolean {
  const version = useCatalog((s) => s.version);
  if (!hydrated) hydrateCatalog();
  return version > 0;
}
