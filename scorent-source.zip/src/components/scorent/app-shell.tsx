"use client";

/* ————— پوسته اپلیکیشن: مسیریابی، ناوبری، فوتر، اعلان XP ————— */

import { Suspense, lazy, useEffect } from "react";
import { toast } from "sonner";
import { Navbar, BottomTabBar } from "./navbar";
import { Footer } from "./footer";
import { useRoute } from "./router";
import { useHydrated, useScorent } from "@/lib/store";
import { useFmt, useT, useTx } from "@/lib/i18n";
import { useAuth } from "@/lib/auth";
import { useCatalogReady } from "@/lib/catalog";
import { AnnouncementBanner } from "./announcement-banner";
import { HomePage } from "@/components/pages/home";
import { StorePage } from "@/components/pages/store";
import { GameDetailPage } from "@/components/pages/game-detail";
const AIPage = lazy(() => import("@/components/pages/ai").then((m) => ({ default: m.AIPage })));
const AIChatPage = lazy(() => import("@/components/pages/ai-chat").then((m) => ({ default: m.AIChatPage })));
const RentPage = lazy(() => import("@/components/pages/rent").then((m) => ({ default: m.RentPage })));
const RentalsPage = lazy(() => import("@/components/pages/rentals").then((m) => ({ default: m.RentalsPage })));
const SharePage = lazy(() => import("@/components/pages/share").then((m) => ({ default: m.SharePage })));
const DiscoveryPage = lazy(() => import("@/components/pages/discovery").then((m) => ({ default: m.DiscoveryPage })));
const DealsPage = lazy(() => import("@/components/pages/deals").then((m) => ({ default: m.DealsPage })));
const TrialPage = lazy(() => import("@/components/pages/trial").then((m) => ({ default: m.TrialPage })));
const RewardsPage = lazy(() => import("@/components/pages/rewards").then((m) => ({ default: m.RewardsPage })));
const ProfilePage = lazy(() => import("@/components/pages/profile").then((m) => ({ default: m.ProfilePage })));
const WishlistPage = lazy(() => import("@/components/pages/wishlist").then((m) => ({ default: m.WishlistPage })));
const SettingsPage = lazy(() => import("@/components/pages/settings").then((m) => ({ default: m.SettingsPage })));
import { AuthPage } from "@/components/pages/auth";
const SupportPage = lazy(() => import("@/components/pages/support").then((m) => ({ default: m.SupportPage })));
const AdminPage = lazy(() => import("@/components/admin/index").then((m) => ({ default: m.AdminPage })));
const NotFoundPage = lazy(() => import("@/components/pages/not-found").then((m) => ({ default: m.NotFoundPage })));
import { AIDock } from "./ai-dock";

/** اعلان‌های XP / دستاورد / چالش — ترجمه در زمان نمایش */
function XPFlash() {
  const flash = useScorent((s) => s.flash);
  const flashId = useScorent((s) => s.flashId);
  const clearFlash = useScorent((s) => s.clearFlash);
  const hydrated = useHydrated();
  const t = useT();
  const tx = useTx();
  const f = useFmt();

  useEffect(() => {
    if (!hydrated || flash.length === 0) return;
    for (const item of flash) {
      if (item.kind === "xp") {
        const label = tx(item.label ?? item.text);
        toast(t("flash.xp", { xp: f.num(item.xp ?? 0), label }), {
          icon: "⚡",
          style: { border: "1px solid rgba(255,159,67,0.35)" },
        });
      } else if (item.kind === "achievement") {
        toast.success(t("flash.achievement", { title: tx(item.title ?? item.text) }), {
          description: t("flash.xpDescAchievement"),
        });
      } else {
        toast.success(t("flash.challenge", { title: tx(item.title ?? item.text) }), {
          description: t("flash.xpDesc"),
        });
      }
    }
    clearFlash();
  }, [flashId, flash, hydrated, clearFlash, t, tx, f]);

  return null;
}

/** اسکن دوره‌ای اجاره‌های منقضی‌شده → تکمیل + اعطای XP یک‌بار */
function RentalLifecycle() {
  const completeExpiredRentals = useScorent((s) => s.completeExpiredRentals);
  const hydrated = useHydrated();

  useEffect(() => {
    if (!hydrated) return;
    completeExpiredRentals();
    const t = setInterval(() => completeExpiredRentals(), 30_000);
    return () => clearInterval(t);
  }, [hydrated, completeExpiredRentals]);

  return null;
}

/* لودر سبک برای chunk های lazy-loaded */
function PageLoader() {
  return (
    <div className="flex min-h-[50svh] items-center justify-center" role="status" aria-live="polite">
      <span className="size-8 animate-spin rounded-full border-2 border-border border-t-ai" />
    </div>
  );
}

function resolvePage(path: string, segments: string[]) {
  const head = segments[0] ?? "";
  switch (head) {
    case "":
      return <HomePage />;
    case "store":
      return <StorePage />;
    case "game":
      return <GameDetailPage id={segments[1] ?? ""} />;
    case "ai":
      return <AIPage />;
    case "ai-chat":
      return <AIChatPage />;
    case "rent":
      return <RentPage />;
    case "rentals":
      return <RentalsPage />;
    case "share":
      return <SharePage />;
    case "discovery":
      return <DiscoveryPage />;
    case "deals":
      return <DealsPage />;
    case "trial":
      return <TrialPage />;
    case "rewards":
      return <RewardsPage />;
    case "profile":
      return <ProfilePage />;
    case "wishlist":
      return <WishlistPage />;
    case "settings":
      return <SettingsPage />;
    case "auth":
      return <AuthPage />;
    case "support":
      return <SupportPage />;
    case "admin":
      return <AdminPage />;
    default:
      return <NotFoundPage attempted={path} />;
  }
}

/* بوت‌استرپ حساب: یک‌بار وضعیت نشست را از سرور می‌خواند */
function AuthBootstrap() {
  const refresh = useAuth((s) => s.refresh);
  useEffect(() => {
    void refresh();
  }, [refresh]);
  return null;
}

export function AppShell() {
  const route = useRoute();
  const catalogReady = useCatalogReady(); // hydrate اورراید کاتالوگ → رندر مجدد درختی

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [route.path, route.full]);

  return (
    <div className="flex min-h-svh flex-col bg-background">
      <AuthBootstrap />
      <Navbar />
      <AnnouncementBanner />
      <main className="flex-1 pb-16 lg:pb-0">
        <Suspense fallback={<PageLoader />}>{resolvePage(route.path, route.segments)}</Suspense>
      </main>
      <Footer />
      <BottomTabBar />
      <AIDock />
      <XPFlash />
      <RentalLifecycle />
    </div>
  );
}
