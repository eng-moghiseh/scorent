"use client";

/* ————— فروشگاه: جستجو + فیلترها + مرتب‌سازی (از طریق پارامترهای URL) — دوزبانه ————— */

import { useMemo, useCallback } from "react";
import { Filter, Search, SlidersHorizontal, XCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { GameCard } from "@/components/scorent/commerce";
import { EmptyState, GameCardSkeleton } from "@/components/scorent/shared";
import { Link, useRoute, navigate } from "@/components/scorent/router";
import { GAMES } from "@/lib/data/games";
import { ALL_GENRES, ALL_MODES, type GameMode, type Genre } from "@/lib/types";
import { finalPrice } from "@/lib/pricing";
import { useFmt, useT, useTx, useUiDir } from "@/lib/i18n";
import { useHydrated } from "@/lib/store";
import { cn } from "@/lib/utils";

const SORTS = [
  { value: "popular", key: "store.sortPopular" },
  { value: "rating", key: "store.sortRating" },
  { value: "price-asc", key: "store.sortPriceAsc" },
  { value: "price-desc", key: "store.sortPriceDesc" },
  { value: "discount", key: "store.sortDiscount" },
] as const;

type SortValue = (typeof SORTS)[number]["value"];

const MAX_PRICE = 2_500_000;

function StorePage() {
  const route = useRoute();
  const hydrated = useHydrated();
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();

  const q = route.query.get("q") ?? "";
  const genre = (route.query.get("genre") ?? "all") as Genre | "all";
  const mode = (route.query.get("mode") ?? "all") as GameMode | "all";
  const sort = (route.query.get("sort") ?? "popular") as SortValue;
  const maxPrice = Number(route.query.get("max") ?? MAX_PRICE);
  const minRating = Number(route.query.get("rating") ?? 0);

  const setParam = useCallback(
    (key: string, value: string | null) => {
      const next = new URLSearchParams(route.query.toString());
      if (value === null || value === "" || value === "all") next.delete(key);
      else next.set(key, value);
      const qs = next.toString();
      navigate(`/store${qs ? `?${qs}` : ""}`, { replace: true });
    },
    [route.query]
  );

  const results = useMemo(() => {
    let list = [...GAMES];
    if (q.trim()) {
      const needle = q.trim().toLowerCase();
      list = list.filter(
        (g) => g.title.toLowerCase().includes(needle) || g.tagline.includes(needle) || g.genres.some((x) => x.includes(needle))
      );
    }
    if (genre !== "all") list = list.filter((g) => g.genres.includes(genre));
    if (mode !== "all") list = list.filter((g) => g.modes.includes(mode));
    list = list.filter((g) => finalPrice(g) <= maxPrice);
    if (minRating > 0) list = list.filter((g) => g.rating >= minRating);

    switch (sort) {
      case "rating":
        list.sort((a, b) => b.rating - a.rating);
        break;
      case "price-asc":
        list.sort((a, b) => finalPrice(a) - finalPrice(b));
        break;
      case "price-desc":
        list.sort((a, b) => finalPrice(b) - finalPrice(a));
        break;
      case "discount":
        list.sort((a, b) => b.discountPercent - a.discountPercent);
        break;
      default:
        list.sort((a, b) => b.popularity - a.popularity);
    }
    return list;
  }, [q, genre, mode, sort, maxPrice, minRating]);

  const hasFilters = q !== "" || genre !== "all" || mode !== "all" || sort !== "popular" || maxPrice < MAX_PRICE || minRating > 0;

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      <header className="mb-8">
        <h1 className="text-3xl font-black">{t("store.heading")}</h1>
        <p className="mt-2 text-sm leading-7 text-muted-foreground">
          {t("store.desc", { n: f.num(GAMES.length) })}
        </p>
      </header>

      {/* نوار فیلترها */}
      <div className="mb-6 space-y-4 rounded-2xl border border-border bg-card p-4">
        <div className="grid gap-3 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div className="relative">
            <Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setParam("q", e.target.value)}
              placeholder={t("store.searchPlaceholder")}
              className="ps-9"
              aria-label={t("store.searchAria")}
            />
          </div>

          <Select value={genre} onValueChange={(v) => setParam("genre", v)} dir={dir}>
            <SelectTrigger aria-label={t("store.genreAria")}>
              <span className="text-muted-foreground text-xs">{t("store.genreLabel")}</span>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("store.genreAll")}</SelectItem>
              {ALL_GENRES.map((g) => (
                <SelectItem key={g} value={g}>
                  {tx(g)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={mode} onValueChange={(v) => setParam("mode", v)} dir={dir}>
            <SelectTrigger aria-label={t("store.modeAria")}>
              <span className="text-muted-foreground text-xs">{t("store.modeLabel")}</span>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("store.modeAll")}</SelectItem>
              {ALL_MODES.map((m) => (
                <SelectItem key={m} value={m}>
                  {tx(m)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sort} onValueChange={(v) => setParam("sort", v)} dir={dir}>
            <SelectTrigger aria-label={t("store.sortAria")}>
              <SlidersHorizontal className="size-4 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SORTS.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {t(s.key)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4 md:grid-cols-[1fr_1fr_auto] md:items-center">
          <div>
            <div className="mb-2 flex justify-between text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Filter className="size-3.5" />
                {t("store.maxPrice")}
              </span>
              <span className="font-bold text-foreground tnum">
                {maxPrice >= MAX_PRICE ? t("store.noCap") : f.toman(maxPrice)}
              </span>
            </div>
            <Slider
              value={[maxPrice]}
              min={100_000}
              max={MAX_PRICE}
              step={50_000}
              onValueChange={([v]) => setParam("max", String(v))}
              aria-label={t("store.maxPrice")}
            />
          </div>

          <div>
            <div className="mb-2 flex justify-between text-xs text-muted-foreground">
              <span>{t("store.minRating")}</span>
              <span className="font-bold text-foreground tnum">{minRating > 0 ? `${f.num(minRating)}+` : t("store.ratingAll")}</span>
            </div>
            <Slider
              value={[minRating]}
              min={0}
              max={5}
              step={0.5}
              onValueChange={([v]) => setParam("rating", String(v))}
              aria-label={t("store.minRatingAria")}
            />
          </div>

          {hasFilters ? (
            <Button variant="ghost" onClick={() => navigate("/store", { replace: true })} className="gap-2 text-muted-foreground">
              <XCircle className="size-4" />
              {t("store.clearFilters")}
            </Button>
          ) : null}
        </div>
      </div>

      {/* نتیجه */}
      <div className="mb-4 flex items-center justify-between text-sm text-muted-foreground">
        <span className="tnum">
          {t("store.count", { n: f.num(results.length) })}
          {q ? <> {t("store.countFor", { q })}</> : null}
        </span>
        {hasFilters ? <span className="text-xs">{t("store.filtersShared")}</span> : null}
      </div>

      {!hydrated ? (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <GameCardSkeleton key={i} />
          ))}
        </div>
      ) : results.length === 0 ? (
        <EmptyState
          icon={Search}
          title={t("store.emptyTitle")}
          description={t("store.emptyDesc")}
          action={
            <Button onClick={() => navigate("/store", { replace: true })} className="gap-2">
              <XCircle className="size-4" />
              {t("store.clearAllFilters")}
            </Button>
          }
        />
      ) : (
        <div className={cn("grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4")}>
          {results.map((g, i) => (
            <GameCard key={g.id} game={g} index={i} />
          ))}
        </div>
      )}

      <p className="mt-10 text-center text-xs text-muted-foreground">
        {t("store.aiPromptPre")}{" "}
        <Link to="/ai" className="font-bold text-ai hover:underline">
          {t("store.aiQuizLink")}
        </Link>{" "}
        {t("store.aiPromptPost")}
      </p>
    </div>
  );
}

export { StorePage };
