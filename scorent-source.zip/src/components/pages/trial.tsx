"use client";

/* ————— دموها و تریال‌ها: تفکیک شفاف دموی رسمی از شبیه‌سازی Scorent (دوزبانه) ————— */

import { motion } from "framer-motion";
import { FlaskConical, Gamepad2, Info, ShieldCheck, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { GameCover } from "@/components/scorent/game-cover";
import { EmptyState, SectionHeader } from "@/components/scorent/shared";
import { Link as RouteLink, navigate } from "@/components/scorent/router";
import { GAMES } from "@/lib/data/games";
import { useFmt, useT } from "@/lib/i18n";
import { cn } from "@/lib/utils";

const KIND_META = {
  "official-demo": { labelKey: "trial.kindOfficialDemo", cls: "bg-rent/12 text-rent", icon: ShieldCheck },
  "friends-pass": { labelKey: "trial.kindFriendsPass", cls: "bg-ai/12 text-[#c4b0f5]", icon: Users },
  none: { labelKey: "trial.kindNone", cls: "bg-secondary text-muted-foreground", icon: Info },
} as const;

export function TrialPage() {
  const t = useT();
  const f = useFmt();
  const withTrial = GAMES.filter((g) => g.available && g.trial.kind !== "none");
  const withoutTrial = GAMES.filter((g) => g.available && g.trial.kind === "none");

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 md:px-6">
      <header className="mb-8 max-w-2xl">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-ai/12 px-3.5 py-1.5 text-xs font-bold text-ai">
          <FlaskConical className="size-3.5" />
          {t("trial.badge")}
        </div>
        <h1 className="text-3xl font-black">{t("trial.title")}</h1>
        <p className="mt-2 text-sm leading-7 text-muted-foreground">{t("trial.desc")}</p>
      </header>

      <div className="mb-8 grid gap-3 md:grid-cols-2">
        <div className="rounded-2xl border border-rent/30 bg-card p-4">
          <p className="flex items-center gap-2 text-sm font-extrabold text-rent">
            <ShieldCheck className="size-4" />
            {t("trial.officialTitle")}
          </p>
          <p className="mt-1.5 text-xs leading-6 text-muted-foreground">{t("trial.officialDesc")}</p>
        </div>
        <div className="rounded-2xl border border-ai/30 bg-card p-4">
          <p className="flex items-center gap-2 text-sm font-extrabold text-[#c4b0f5]">
            <Gamepad2 className="size-4" />
            {t("trial.simTitle")}
          </p>
          <p className="mt-1.5 text-xs leading-6 text-muted-foreground">{t("trial.simDesc")}</p>
        </div>
      </div>

      <SectionHeader
        title={t("trial.withTrialTitle")}
        description={t("trial.withTrialCount", { n: f.num(withTrial.length) })}
        icon={ShieldCheck}
      />

      {withTrial.length === 0 ? (
        <EmptyState icon={FlaskConical} title={t("trial.emptyTitle")} description={t("trial.emptyDesc")} />
      ) : (
        <div className="mb-12 grid gap-4 md:grid-cols-3">
          {withTrial.map((g, i) => {
            const meta = KIND_META[g.trial.kind];
            return (
              <motion.div
                key={g.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                className="card-hover flex flex-col rounded-3xl border border-border bg-card p-4"
              >
                <button type="button" onClick={() => navigate(`/game/${g.id}`)} className="group relative overflow-hidden rounded-2xl">
                  <GameCover game={g} className="aspect-[16/10] w-full transition-transform duration-500 group-hover:scale-105" />
                </button>
                <div className="mt-3 flex items-center justify-between">
                  <p className="font-black" dir="ltr">
                    {g.title}
                  </p>
                  <span className={cn("rounded-full px-2.5 py-1 text-[0.62rem] font-bold", meta.cls)}>{t(meta.labelKey)}</span>
                </div>
                <p className="mt-2 flex-1 text-xs leading-6 text-muted-foreground">{t(g.trial.note)}</p>
                <div className="mt-3 flex gap-2">
                  <RouteLink to={`/game/${g.id}`}>
                    <Button size="sm" variant="outline">
                      {t("trial.gamePage")}
                    </Button>
                  </RouteLink>
                  <RouteLink to="/rent">
                    <Button size="sm" variant="ghost" className="text-rent">
                      {t("trial.simRent")}
                    </Button>
                  </RouteLink>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      <SectionHeader
        kicker={t("trial.noneKicker")}
        title={t("trial.noneTitle")}
        description={t("trial.noneDesc")}
        icon={Info}
      />
      <div className="flex flex-wrap gap-2">
        {withoutTrial.map((g) => (
          <button
            key={g.id}
            type="button"
            onClick={() => navigate(`/game/${g.id}`)}
            className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-xs font-bold text-muted-foreground transition-colors hover:border-ai/40 hover:text-foreground"
          >
            {g.title}
          </button>
        ))}
      </div>

      <p className="mt-10 flex items-start gap-2 rounded-2xl border border-border bg-card/60 p-4 text-xs leading-6 text-muted-foreground">
        <Info className="mt-0.5 size-4 shrink-0 text-deal" />
        {t("trial.transparency")}
      </p>
    </div>
  );
}
