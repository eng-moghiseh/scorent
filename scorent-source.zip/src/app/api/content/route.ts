/* GET /api/content — محتوای عمومی سایت (merged با پیش‌فرض‌ها) */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_CONTENT } from "@/lib/site-content";

export async function GET() {
  try {
    const rows = await db.siteContent.findMany();
    const map = new Map(rows.map((r) => [r.key, r]));
    const content = DEFAULT_CONTENT.map((def) => {
      const row = map.get(def.key);
      return row ? { key: def.key, valueFa: row.valueFa, valueEn: row.valueEn } : def;
    });
    const res = NextResponse.json({ ok: true, content });
    res.headers.set("Cache-Control", "public, max-age=30, stale-while-revalidate=120");
    return res;
  } catch {
    const res = NextResponse.json({ ok: true, content: DEFAULT_CONTENT });
    res.headers.set("Cache-Control", "no-store");
    return res;
  }
}
