/* ————— تست‌های سخت‌سازی امنیتی: OTP، حسابرسی پنجره‌ی نرخ، نرمال‌سازی ————— */

import { describe, it, expect } from "vitest";
import { generateOtp, hashOtp, otpMatches } from "../src/lib/server/seed";
import { windowStartFor, isWithinLimit } from "../src/lib/server/rate-limit";
import { sameOrigin, isEmail, normalizePhone } from "../src/lib/server/http";

describe("OTP generation", () => {
  it("returns a 6-digit numeric string in range (crypto-secure source)", () => {
    for (let i = 0; i < 200; i++) {
      const code = generateOtp();
      expect(code).toMatch(/^\d{6}$/);
      const n = Number(code);
      expect(n).toBeGreaterThanOrEqual(100_000);
      expect(n).toBeLessThanOrEqual(999_999);
    }
  });

  it("does not collapse to constant output", () => {
    const set = new Set<string>();
    for (let i = 0; i < 50; i++) set.add(generateOtp());
    // با منبع رمزنگارانه، ۵۰ نمونه نباید همه یکی باشند
    expect(set.size).toBeGreaterThan(1);
  });
});

describe("OTP hashing & timing-safe comparison", () => {
  it("hashes deterministically and never returns the plaintext", () => {
    const h1 = hashOtp("123456");
    const h2 = hashOtp("123456");
    expect(h1).toBe(h2);
    expect(h1).not.toContain("123456");
    expect(h1).toMatch(/^[0-9a-f]{64}$/);
  });

  it("different codes produce different hashes", () => {
    expect(hashOtp("123456")).not.toBe(hashOtp("654321"));
  });

  it("otpMatches accepts the correct code only", () => {
    const stored = hashOtp("654321");
    expect(otpMatches("654321", stored)).toBe(true);
    expect(otpMatches("123456", stored)).toBe(false);
    expect(otpMatches("", stored)).toBe(false);
  });

  it("otpMatches rejects malformed stored hashes safely", () => {
    expect(otpMatches("123456", "not-hex")).toBe(false);
    expect(otpMatches("123456", "zzzz")).toBe(false);
  });
});

describe("rate-limit window math", () => {
  it("windows align to fixed boundaries", () => {
    const W = 60_000;
    expect(windowStartFor(0, W)).toBe(0);
    expect(windowStartFor(W - 1, W)).toBe(0);
    expect(windowStartFor(W, W)).toBe(W);
    expect(windowStartFor(1_700_000_123_456, W)).toBe(Math.floor(1_700_000_123_456 / W) * W);
  });

  it("limit check is inclusive", () => {
    expect(isWithinLimit(1, 5)).toBe(true);
    expect(isWithinLimit(5, 5)).toBe(true);
    expect(isWithinLimit(6, 5)).toBe(false);
  });
});

describe("sameOrigin hardening", () => {
  const req = (over: Record<string, string>) =>
    ({
      method: "POST",
      headers: new Headers(over),
    }) as unknown as Request;

  it("rejects explicit cross-site fetch metadata", () => {
    expect(sameOrigin(req({ "sec-fetch-site": "cross-site", origin: "https://evil.example" }))).toBe(false);
  });

  it("allows same-origin and same-site fetch metadata", () => {
    expect(sameOrigin(req({ "sec-fetch-site": "same-origin", origin: "https://scorent.example", host: "scorent.example" }))).toBe(true);
    expect(sameOrigin(req({ "sec-fetch-site": "same-site" }))).toBe(true);
  });

  it("validates origin host against host header", () => {
    expect(sameOrigin(req({ origin: "https://scorent.example", host: "scorent.example" }))).toBe(true);
    expect(sameOrigin(req({ origin: "https://evil.example", host: "scorent.example" }))).toBe(false);
    expect(sameOrigin(req({ origin: "not a url" }))).toBe(false);
  });

  it("GET requests bypass the check", () => {
    expect(sameOrigin({ method: "GET", headers: new Headers() } as unknown as Request)).toBe(true);
  });
});

describe("input normalization", () => {
  it("normalizes Iranian mobile formats to E.164", () => {
    expect(normalizePhone("09123456789")).toBe("+989123456789");
    expect(normalizePhone("+98 912 345 6789")).toBe("+989123456789");
    expect(normalizePhone("00989123456789")).toBe("+989123456789");
    expect(normalizePhone("abc")).toBeNull();
  });

  it("rejects invalid emails", () => {
    expect(isEmail("a@b.io")).toBe(true);
    expect(isEmail("bad@@x")).toBe(false);
    expect(isEmail("no-tld@x")).toBe(false);
  });
});
