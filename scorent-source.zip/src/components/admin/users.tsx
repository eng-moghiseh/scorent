"use client";

/* ————— مدیریت کاربران — جستجو، تعلیق، تأیید، تغییر نقش، حذف ————— */

import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { ChevronLeft, ChevronRight, Search, ShieldCheck, Trash2, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { api, can, useAuth } from "@/lib/auth";
import { useFmt, useT, useUiDir } from "@/lib/i18n";
import { AdminHeader, AdminError, RolePill, StatusPill } from "./ui";
import { cn } from "@/lib/utils";

interface Row {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  role: string;
  status: string;
  emailVerified: boolean;
  phoneVerified: boolean;
  emailOptIn: boolean;
  smsOptIn: boolean;
  lang: string;
  passwordHash: boolean;
  googleLinked: boolean;
  lastLoginAt: string | null;
  createdAt: string;
}

export function AdminUsers() {
  const t = useT();
  const f = useFmt();
  const dir = useUiDir();
  const me = useAuth((s) => s.user);
  const [rows, setRows] = useState<Row[] | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");
  const [role, setRole] = useState("all");
  const [status, setStatus] = useState("all");
  const [err, setErr] = useState(false);

  const load = useCallback(async () => {
    setRows(null);
    try {
      const params = new URLSearchParams({ page: String(page) });
      if (q.trim()) params.set("q", q.trim());
      if (role !== "all") params.set("role", role);
      if (status !== "all") params.set("status", status);
      const res = await api.get<{ ok: boolean; users: Row[]; total: number }>(`/api/admin/users?${params.toString()}`);
      setRows(res.users);
      setTotal(res.total);
    } catch {
      setErr(true);
    }
  }, [page, q, role, status]);

  useEffect(() => {
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [load]);

  async function patch(id: string, data: Record<string, unknown>, okMsg: string) {
    try {
      await api.patch(`/api/admin/users/${id}`, data);
      toast.success(okMsg);
      void load();
    } catch (e) {
      toast.error(t("admin.error") + (e instanceof Error ? ` (${e.message})` : ""));
    }
  }

  async function remove(id: string) {
    try {
      await api.del(`/api/admin/users/${id}`);
      toast.success(t("admin.users.deleted"));
      void load();
    } catch (e) {
      toast.error(t("admin.error") + (e instanceof Error ? ` (${e.message})` : ""));
    }
  }

  const pages = Math.max(1, Math.ceil(total / 20));

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.tab.users")} description={t("admin.desc")} icon={Users} />

      {/* فیلترها */}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative min-w-56 flex-1">
          <Search className="absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder={t("admin.users.searchPh")} className="ps-9" />
        </div>
        <Select dir={dir} value={role} onValueChange={(v) => { setRole(v); setPage(1); }}>
          <SelectTrigger className="w-40" aria-label={t("admin.users.role")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.users.all")}</SelectItem>
            <SelectItem value="SUPER_ADMIN">{t("account.role.SUPER_ADMIN")}</SelectItem>
            <SelectItem value="ADMIN">{t("account.role.ADMIN")}</SelectItem>
            <SelectItem value="CONTENT_EDITOR">{t("account.role.CONTENT_EDITOR")}</SelectItem>
            <SelectItem value="SUPPORT_AGENT">{t("account.role.SUPPORT_AGENT")}</SelectItem>
            <SelectItem value="USER">{t("account.role.USER")}</SelectItem>
          </SelectContent>
        </Select>
        <Select dir={dir} value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger className="w-36" aria-label={t("admin.users.status")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.users.all")}</SelectItem>
            <SelectItem value="ACTIVE">{t("admin.users.active")}</SelectItem>
            <SelectItem value="SUSPENDED">{t("admin.users.suspended")}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {err ? (
        <AdminError />
      ) : rows === null ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-14 animate-pulse rounded-2xl border border-border bg-card" />)}</div>
      ) : rows.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">{t("admin.users.empty")}</p>
      ) : (
        <div className="space-y-2.5">
          {rows.map((u) => {
            const isSelf = me?.id === u.id;
            const isSuper = u.role === "SUPER_ADMIN";
            const canWrite = can(me?.role, "users.write") && !isSelf && (!isSuper || me?.role === "SUPER_ADMIN");
            const canDelete = can(me?.role, "users.delete") && !isSelf && !isSuper;
            const canRole = can(me?.role, "admins.manage") && !isSelf && !isSuper;
            return (
              <div key={u.id} className="rounded-2xl border border-border bg-card p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-extrabold">{u.name}</p>
                      <RolePill role={u.role} />
                      <StatusPill status={u.status} />
                      {u.googleLinked && <span className="rounded-full bg-secondary px-2 py-0.5 text-[0.6rem] font-bold text-muted-foreground">{t("admin.users.withGoogle")}</span>}
                      {u.passwordHash && <span className="rounded-full bg-secondary px-2 py-0.5 text-[0.6rem] font-bold text-muted-foreground">{t("admin.users.withPassword")}</span>}
                    </div>
                    <p dir="ltr" className="mt-1 truncate text-start text-[0.68rem] text-muted-foreground tnum">
                      {u.email ?? "—"} {u.phone ? `· ${u.phone}` : ""} · {t("admin.users.lastLogin")}: {u.lastLoginAt ? f.dateTime(new Date(u.lastLoginAt).getTime()) : t("admin.users.never")}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {canWrite && u.email && (
                      <Button size="sm" variant="outline" onClick={() => patch(u.id, { emailVerified: !u.emailVerified }, t("admin.users.updated"))} className="h-8 text-[0.68rem]">
                        {u.emailVerified ? t("admin.users.unverifyEmail") : t("admin.users.verifyEmail")}
                      </Button>
                    )}
                    {canWrite && u.phone && (
                      <Button size="sm" variant="outline" onClick={() => patch(u.id, { phoneVerified: !u.phoneVerified }, t("admin.users.updated"))} className="h-8 text-[0.68rem]">
                        {u.phoneVerified ? t("admin.users.unverifyPhone") : t("admin.users.verifyPhone")}
                      </Button>
                    )}
                    {canWrite && (
                      <Button size="sm" variant={u.status === "ACTIVE" ? "outline" : "default"} onClick={() => patch(u.id, { status: u.status === "ACTIVE" ? "SUSPENDED" : "ACTIVE" }, t("admin.users.updated"))} className={cn("h-8 text-[0.68rem]", u.status === "ACTIVE" ? "border-destructive/40 text-destructive hover:bg-destructive/10" : "bg-rent text-[#062012] hover:bg-rent/90")}>
                        {u.status === "ACTIVE" ? t("admin.users.suspend") : t("admin.users.activate")}
                      </Button>
                    )}
                    {canRole && (
                      <Select dir={dir} value={u.role} onValueChange={(v) => patch(u.id, { role: v }, t("admin.users.updated"))}>
                        <SelectTrigger className="h-8 w-36 text-[0.68rem]" aria-label={t("admin.users.changeRole")}>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="USER">{t("account.role.USER")}</SelectItem>
                          <SelectItem value="SUPPORT_AGENT">{t("account.role.SUPPORT_AGENT")}</SelectItem>
                          <SelectItem value="CONTENT_EDITOR">{t("account.role.CONTENT_EDITOR")}</SelectItem>
                          <SelectItem value="ADMIN">{t("account.role.ADMIN")}</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                    {canDelete && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="icon" variant="outline" className="size-8 border-destructive/40 text-destructive hover:bg-destructive/10" aria-label={t("admin.users.delete")}>
                            <Trash2 className="size-3.5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent dir="rtl">
                          <AlertDialogHeader>
                            <AlertDialogTitle>{t("admin.users.deleteConfirmTitle")}</AlertDialogTitle>
                            <AlertDialogDescription>{t("admin.users.deleteConfirmDesc")}</AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>{t("admin.cancel")}</AlertDialogCancel>
                            <AlertDialogAction onClick={() => remove(u.id)} className="bg-destructive text-white hover:bg-destructive/90">{t("admin.confirm")}</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* صفحه‌بندی */}
          {pages > 1 && (
            <div className="flex items-center justify-center gap-3 pt-2">
              <Button size="icon" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} aria-label={t("admin.prev")} className="size-8">
                <ChevronRight className="size-4 rtl:hidden" />
                <ChevronLeft className="size-4 ltr:hidden" />
              </Button>
              <span className="text-xs font-bold text-muted-foreground tnum">{t("admin.page", { n: f.num(page), total: f.num(pages) })}</span>
              <Button size="icon" variant="outline" disabled={page >= pages} onClick={() => setPage((p) => p + 1)} aria-label={t("admin.next")} className="size-8">
                <ChevronLeft className="size-4 rtl:hidden" />
                <ChevronRight className="size-4 ltr:hidden" />
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/** بخش کوچک برای نمایش نشان ابر-ادمین در جاهای دیگر */
export function SuperAdminNote() {
  const t = useT();
  return (
    <p className="flex items-center gap-1.5 text-[0.65rem] text-muted-foreground">
      <ShieldCheck className="size-3.5 text-deal" /> {t("admin.admins.superNote")}
    </p>
  );
}
