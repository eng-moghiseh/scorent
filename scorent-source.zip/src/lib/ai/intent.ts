/* ————— پارسر نیت کاربر (قطعی، بدون مدل) —————
 * این ماژول پیام فارسی/انگلیسی کاربر را به یک «نیت کاتالوگ» تبدیل می‌کند:
 * بازی‌های نام‌برده، بودجه، ژانرها، سبک‌ها و خواسته‌ها.
 * روی سرور قبل از فراخوانی مدل اجرا می‌شود تا حتی اگر مدل در استخراج نیت
 * خطا کند، پاسخ همیشه بر داده واقعی کاتالوگ سوار باشد.
 */

import { GAMES } from "../data/games";
import { toEnDigits } from "../format";
import { ALL_GENRES, ALL_MODES, ALL_PLAYSTYLES, ALL_GENRES as GENRES } from "../types";

export interface CatalogIntent {
  /** عناوین/شناسه بازی‌های نام‌برده در پیام */
  mentionedTitles: string[];
  genres: string[];
  playstyle: string | null;
  mode: string | null;
  sessionBucket: string | null;
  budgetToman: number | null;
  intent: "buy" | "rent" | "either";
  wantsRecommendation: boolean;
  wantsComparison: boolean;
  wantsDeals: boolean;
  wantsRental: boolean;
  wantsTrial: boolean;
  wantsStats: boolean;
}

export function emptyIntent(): CatalogIntent {
  return {
    mentionedTitles: [],
    genres: [],
    playstyle: null,
    mode: null,
    sessionBucket: null,
    budgetToman: null,
    intent: "either",
    wantsRecommendation: false,
    wantsComparison: false,
    wantsDeals: false,
    wantsRental: false,
    wantsTrial: false,
    wantsStats: false,
  };
}

/* ————— تشخیص بازی‌های نام‌برده —————
 * برای هر بازی، عنوان انگلیسی و «نامک» آن را در متن جستجو می‌کنیم.
 * نامک‌های رایج فارسی هم اضافه شده تا «الدرینگ» یا «هدز» پیدا شود.
 */
const TITLE_ALIASES: Record<string, string[]> = {
  "elden-ring": ["الدرینگ", "الدر رینگ", "eldening", "الدر"],
  hades: ["هدز", "هادز"],
  "hollow-knight": ["هالو نایت", "هالوکناینت", "هالوکایت"],
  "cyberpunk-2077": ["سایبرپانک", "cyberpunk"],
  "the-witcher-3": ["ویچر", "ویچر ۳", "witcher"],
  "stardew-valley": ["استاردیو", "استردیو", "stardew"],
  "celeste": ["سلست", "celeste"],
  "disco-elysium": ["دیسکو", "disco"],
  "outer-wilds": ["اوتروایلدز", "outer"],
  "red-dead-redemption-2": ["رد دد", "rdr2", "rdr"],
  "god-of-war": ["گاد آف وار", "god of war"],
  "the-legend-of-zelda-botw": ["زلدا", "zelda"],
  "portal-2": ["پورتال", "portal"],
  "cities-skylines": ["سیتیز", "cities"],
  "fifa-24": ["فیفا", "fifa"],
  "forza-horizon-5": ["فورزا", "forza"],
  "it-takes-two": ["ایت تیکز تو", "it takes two"],
  "overcooked-2": ["اورکوکت", "overcooked"],
  "doom-eternal": ["دوم", "doom"],
  "counter-strike-2": ["کانتر", "cs2", "cs:go", "csgo"],
  "valorant": ["والورنت", "valorant"],
  "apotheon": [],
};

function findMentionedTitles(message: string): string[] {
  const lower = message.toLowerCase();
  const found: string[] = [];
  for (const g of GAMES) {
    const t = g.title.toLowerCase();
    const aliases = TITLE_ALIASES[g.id] ?? [];
    if (lower.includes(t) || aliases.some((a) => lower.includes(a))) {
      found.push(g.id);
      continue;
    }
    // تطبیق جزئی برای عناوین چندکلمه‌ای: حداقل ۵ حرف از عنوان در متن
    if (t.length >= 5 && lower.includes(t.slice(0, Math.max(5, Math.floor(t.length * 0.6))))) {
      found.push(g.id);
    }
  }
  return [...new Set(found)];
}

/* ————— استخراج بودجه — «زیر ۵۰۰ هزار تومان»، «تا ۲ میلیون»، «بودجه 300000» ————— */

function extractBudgetToman(message: string): number | null {
  const m = toEnDigits(message).replace(/٬|,/g, "");
  const patterns: RegExp[] = [
    /(\d+(?:\.\d+)?)\s*(?:میلیون|million)\s*(?:تومان)?/gi,
    /(\d+(?:\.\d+)?)\s*(?:هزار|k)\s*(?:تومان)?/gi,
    /(?:بودجه|زیر|تا|حداکثر|کمتر از|under|max|budget)\s*(\d{4,9})/gi,
    /(\d{4,9})\s*(?:تومان|toman)/gi,
  ];
  const million = /(\d+(?:\.\d+)?)\s*(?:میلیون|million)/i.exec(m);
  if (million) return Math.round(parseFloat(million[1]) * 1_000_000);
  const hezar = /(\d+(?:\.\d+)?)\s*(?:هزار|k)\s*(?:تومان)?/i.exec(m);
  if (hezar) return Math.round(parseFloat(hezar[1]) * 1_000);
  for (const p of patterns.slice(2)) {
    const hit = p.exec(m);
    if (hit) {
      const n = parseInt(hit[1], 10);
      if (n >= 10_000 && n <= 50_000_000) return n;
    }
  }
  return null;
}

/* ————— کلیدواژه‌های نیت ————— */

export function extractIntentDeterministic(message: string): CatalogIntent {
  const intent = emptyIntent();
  intent.mentionedTitles = findMentionedTitles(message);
  intent.budgetToman = extractBudgetToman(message);

  for (const g of ALL_GENRES) {
    const bare = g.replace(/ی$/, ""); // «مسابقه‌ای» → «مسابقه‌» برای تطبیق انعطاف‌پذیر
    if (message.includes(g) || (bare.length >= 4 && message.includes(bare))) intent.genres.push(g);
  }
  /* کلیدواژه‌های انگلیسی ژانرها (پیام‌های انگلیسی) */
  const EN_GENRES: Array<[RegExp, string]> = [
    [/roguelike|rogue-lite|roguelite/i, "روگ‌لایت"],
    [/\brpg\b|role.?playing/i, "نقش‌آفرینی"],
    [/\baction\b/i, "اکشن"],
    [/\badventure\b/i, "ماجرایی"],
    [/\bstrategy\b/i, "استراتژیک"],
    [/\bsimulation|\bsim\b/i, "شبیه‌سازی"],
    [/\bpuzzle\b/i, "معمایی پازل"],
    [/\bshooter\b|\bfps\b|\btps\b/i, "تیراندازی"],
    [/\bplatformer\b/i, "سکوبازی"],
    [/\bracing\b/i, "مسابقه‌ای"],
    [/\bsports?\b/i, "ورزشی"],
  ];
  for (const [re, genre] of EN_GENRES) {
    if (re.test(message) && !intent.genres.includes(genre)) intent.genres.push(genre);
  }
  for (const p of ALL_PLAYSTYLES) {
    const stems: Record<string, string[]> = {
      "داستان‌محور": ["داستان‌محور", "داستان محور"],
      "رقابتی": ["رقابتی"],
      "آرام و دلنشین": ["آرام و دلنشین"],
      "چالشی": ["چالشی"],
      "اکتشافی": ["اکتشافی"],
      "تاکتیکی": ["تاکتیکی"],
    };
    if ((stems[p] ?? [p]).some((s) => message.includes(s))) intent.playstyle = p;
  }
  for (const mode of ALL_MODES) {
    if (message.includes(mode)) intent.mode = mode;
  }
  if (/جلسه.{0,8}(کوتاه|کم)|وقت کم|زیر یک ساعت|کوتاه/.test(message)) intent.sessionBucket = "کوتاه";
  else if (/متوسط|دو سه ساعت|۱ تا ۳/.test(message)) intent.sessionBucket = "متوسط";
  else if (/بلند|طولانی|چند ساعت|کل روز/.test(message)) intent.sessionBucket = "بلند";

  if (/اجاره|کرایه|rent/i.test(message)) {
    intent.wantsRental = true;
    intent.intent = "rent";
  }
  if (/بخرم|خرید|بخر|buy|purchase/i.test(message) && intent.intent !== "rent") intent.intent = "buy";

  intent.wantsRecommendation =
    /پیشنهاد|معرفی|چی بازی|چه بازی|بازی بعدی|چی بخرم|چی کنم|سلیقه|recommend|suggest|what.*game|example from|example.*catalog/i.test(message) ||
    intent.genres.length > 0 ||
    intent.playstyle !== null;
  intent.wantsComparison = /مقایسه|فرق|بهتره|بهتر است|کدوم|کدام|versus|\bvs\b|compare/i.test(message);
  intent.wantsDeals = /تخفیف|حراج|ارزون|ارزان|سود|deal|sale|discount/i.test(message);
  intent.wantsTrial = /دمو|تریال|نسخه آزمایشی|demo|trial/i.test(message);
  intent.wantsStats = /چند تا بازی|چند بازی|تعداد بازی|کاتالوگ چندتا|how many games/i.test(message);

  return intent;
}

/* ————— ادغام نیت مدل با نیت قطعی —————
 * مقادیر مدل فقط زمانی پذیرفته می‌شود که با واژگان مجاز (ژانر/سبک رسمی) منطبق باشد.
 */
export function mergeIntents(deterministic: CatalogIntent, model: Partial<CatalogIntent> | null): CatalogIntent {
  if (!model) return deterministic;
  const merged: CatalogIntent = { ...deterministic };
  if (Array.isArray(model.mentionedTitles)) {
    const valid = model.mentionedTitles
      .filter((t): t is string => typeof t === "string")
      .map((t) => {
        const lower = t.toLowerCase();
        return GAMES.find((g) => g.id === lower || g.title.toLowerCase() === lower)?.id;
      })
      .filter((x): x is string => Boolean(x));
    merged.mentionedTitles = [...new Set([...deterministic.mentionedTitles, ...valid])].slice(0, 4);
  }
  if (Array.isArray(model.genres)) {
    const valid = model.genres.filter((g): g is string => typeof g === "string" && (GENRES as string[]).includes(g));
    merged.genres = [...new Set([...deterministic.genres, ...valid])].slice(0, 4);
  }
  if (typeof model.budgetToman === "number" && model.budgetToman > 0 && deterministic.budgetToman === null) {
    merged.budgetToman = Math.min(50_000_000, Math.round(model.budgetToman));
  }
  if (model.intent === "buy" || model.intent === "rent" || model.intent === "either") {
    merged.intent = deterministic.intent !== "either" ? deterministic.intent : model.intent;
  }
  if (typeof model.playstyle === "string" && (ALL_PLAYSTYLES as string[]).includes(model.playstyle)) merged.playstyle = model.playstyle;
  if (typeof model.mode === "string" && (ALL_MODES as string[]).includes(model.mode)) merged.mode = model.mode;
  if (model.wantsRecommendation) merged.wantsRecommendation = true;
  if (model.wantsComparison) merged.wantsComparison = true;
  if (model.wantsDeals) merged.wantsDeals = true;
  if (model.wantsRental) merged.wantsRental = true;
  return merged;
}
