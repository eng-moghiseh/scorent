/* ————— fragment: dict-game — صفحه جزئیات بازی (بازگشت، مشخصات، خرید/اجاره، دمو، نظرات، مشابه‌ها) —————
 * هر کلید: [فارسی (عین متن اصلی)، English]. پارامترها با الگوی {name} جایگزین می‌شوند.
 */

export const STR: Record<string, [string, string]> = {
  /* ————— حالت «بازی پیدا نشد» ————— */
  "game.notFound": ["بازی پیدا نشد", "Game not found"],
  "game.notFoundDesc": [
    "شناسه «{id}» در کاتالوگ Scorent وجود ندارد. شاید نشانی اشتباه است.",
    "The ID “{id}” does not exist in the Scorent catalog. The link may be wrong.",
  ],
  "game.unknownId": ["نامشخص", "unknown"],
  "game.backToStore": ["بازگشت به فروشگاه", "Back to store"],

  /* ————— مسیر (breadcrumb) و کارت‌های اطلاعات کاور ————— */
  "game.breadcrumbAria": ["مسیر", "Breadcrumb"],
  "game.popularity": ["محبوبیت (نمونه)", "Popularity (sample)"],
  "game.year": ["سال انتشار", "Release year"],
  "game.status": ["وضعیت", "Availability"],
  "game.inStock": ["موجود", "In stock"],
  "game.outOfStock": ["ناموجود", "Out of stock"],

  /* ————— مشخصات (سازنده/جلسه/کمپین/حالت‌ها) ————— */
  "game.developer": ["سازنده", "Developer"],
  "game.session": ["یک جلسه بازی", "One session"],
  "game.campaign": ["طول کمپین", "Campaign length"],
  "game.modes": ["حالت‌ها", "Modes"],
  "game.noCampaign": ["کمپین کلاسیک ندارد", "No classic campaign"],

  /* ————— جعبه خرید/اجاره ————— */
  "game.rentFrom": ["اجاره از:", "Rent from:"],
  "game.rentUnavailable": ["در دسترس نیست", "Not available"],
  "game.rentTrigger": ["اجاره (۱/۳/۷ روز)", "Rent (1/3/7 days)"],
  "game.wishAdded": ["به علاقه‌مندی‌ها اضافه شد", "Added to your wishlist"],
  "game.wishRemoved": ["از علاقه‌مندی‌ها حذف شد", "Removed from your wishlist"],
  "game.wished": ["در علاقه‌مندی‌ها", "In wishlist"],
  "game.wishlist": ["علاقه‌مندی", "Wishlist"],
  "game.discountNote": [
    "تخفیف نمونه {p} — صرفه‌جویی {save} نسبت به قیمت {price}",
    "Sample {p} discount — you save {save} off the {price} price",
  ],
  "game.ownedNote": [
    "این بازی در کتابخانه توست (خرید نمایشی ثبت‌شده)",
    "This game is in your library (recorded demo purchase)",
  ],

  /* ————— وضعیت دموی رسمی (یادداشت‌های لایه داده با نگاشت TRIAL_NOTE_KEYS به این کلیدها می‌رسند) ————— */
  "game.trialStatus": ["وضعیت دموی رسمی", "Official demo status"],
  "game.sample": ["نمونه", "Sample"],
  "game.trialNoteNoDemo": ["دموی رسمی ثبت‌شده‌ای در دسترس نیست.", "No official demo is listed."],
  "game.trialNoteNoDemoRent": [
    "دموی رسمی ثبت‌شده‌ای در دسترس نیست؛ برای آزمودن، اجاره Scorent را پیشنهاد می‌کنیم.",
    "No official demo is listed; we suggest a Scorent rental to try it.",
  ],
  "game.trialNoteNoDemoRental": [
    "دموی رسمی ثبت‌شده‌ای در دسترس نیست؛ نسخه اجاره‌ای Scorent گزینه آزمودن است.",
    "No official demo is listed; Scorent's rental edition is the way to try it.",
  ],
  "game.trialNoteNoRental": [
    "فعلاً اجاره این عنوان فعال نیست؛ خرید نمایشی در دسترس است.",
    "Rental is not active for this title yet; demo purchase is available.",
  ],
  "game.trialNoteFriendsPass": [
    "ویژگی رسمی Friends' Pass: دوستت می‌تواند نسخه همکاری را رایگان بازی کند (نمونه نمایشی).",
    "Official Friends' Pass feature: a friend can play the co-op version for free (demo sample).",
  ],
  "game.trialNoteStoreDemo": [
    "دموی رسمی رایگان در استور بازی موجود است (اطلاعات نمونه).",
    "A free official demo is available on the game store (sample info).",
  ],
  "game.trialNoteGameplayDemo": [
    "دموی رسمی برای آزمودن گیم‌پلی منتشر شده است (اطلاعات نمونه).",
    "An official demo has been released to try the gameplay (sample info).",
  ],
  "game.trialNoteFreeToPlay": [
    "خود بازی رایگان (Free-to-Play) است؛ نیازی به خرید یا اجاره نیست (نمونه).",
    "The game itself is free-to-play; no purchase or rental is needed (sample).",
  ],
  "game.allTrials": ["همه دموها و تریال‌ها ←", "All demos & trials →"],

  /* ————— نکات کلیدی ————— */
  "game.highlightsAria": ["دلایل تجربه", "Reasons to play"],
  "game.whyTry": ["چرا امتحانش کنی؟", "Why try it?"],
  "game.highlightsTitle": ["نکات کلیدی", "Key highlights"],

  /* ————— نظرات جامعه ————— */
  "game.reviewsAria": ["نظرات جامعه", "Community reviews"],
  "game.communityKicker": ["جامعه", "Community"],
  "game.reviewsTitle": ["نظرات بازی‌کن‌ها", "Player reviews"],
  "game.avgRating": [
    "میانگین امتیاز کاربران محلی: {n} از ۵ ({c} نظر)",
    "Average local user rating: {n} out of 5 ({c} review(s))",
  ],
  "game.reviewsEmptyDesc": [
    "نظرات نمونه جامعه و نظرهای خودت اینجا نمایش داده می‌شوند.",
    "Sample community reviews and your own reviews appear here.",
  ],
  "game.noReviewsYet": [
    "هنوز نظری از خودت برای این بازی ثبت نشده؛ با اولین نظر معتبر ۳۰ XP بگیر.",
    "You haven't posted a review for this game yet; earn 30 XP with your first valid review.",
  ],
  "game.ratingOutOf5": ["امتیاز {n} از ۵", "Rating {n} out of 5"],

  /* ————— فرم ثبت نظر ————— */
  "game.addReview": ["نظر خودت را اضافه کن", "Add your review"],
  "game.reviewFormNote": [
    "نظرها به‌صورت محلی ذخیره می‌شوند و بخشی از داده نمایشی پروتوتایپ هستند. هر نظر معتبر ۳۰ XP دارد و برای هر بازی فقط یک‌بار امتیاز می‌گیری.",
    "Reviews are stored locally and are part of the prototype's demo data. Each valid review earns 30 XP, and you earn it once per game.",
  ],
  "game.yourRating": ["امتیاز تو:", "Your rating:"],
  "game.ratingAria": ["امتیاز از ۵", "Rating out of 5"],
  "game.starN": ["{n} ستاره", "{n} star"],
  "game.reviewPlaceholder": ["تجربه‌ات را بنویس… (حداقل ۱۰ نویسه)", "Write your experience… (at least 10 characters)"],
  "game.reviewTextLabel": ["متن نظر", "Review text"],
  "game.charCount": ["{n}/۶۰۰ — به‌عنوان {name}", "{n}/600 — as {name}"],
  "game.submitReview": ["ثبت نظر", "Post review"],
  "game.reviewAdded": ["نظرت ثبت شد", "Your review was posted"],
  "game.reviewXpDesc": ["نظر معتبر ۳۰ XP دارد", "A valid review earns 30 XP"],
  "game.reviewFailed": ["ثبت نظر ناموفق بود", "Posting the review failed"],

  /* ————— کارت نظر و رأی مفید ————— */
  "game.yourReview": ["نظر تو", "Your review"],
  "game.voteAdded": ["رأی ثبت شد", "Vote recorded"],
  "game.voteXpDesc": ["+۲۰ XP برای کمک به جامعه", "+20 XP for helping the community"],
  "game.voteAlready": ["رأی قبلاً ثبت شده", "You already voted"],
  "game.helpful": ["مفید بود ({n})", "Helpful ({n})"],

  /* ————— بازی‌های مشابه ————— */
  "game.relatedAria": ["بازی‌های مشابه", "Similar games"],
  "game.relatedKicker": ["مشابه‌ها", "Similar picks"],
  "game.relatedTitle": ["اگر این را دوست داشتی…", "If you liked this…"],
};
