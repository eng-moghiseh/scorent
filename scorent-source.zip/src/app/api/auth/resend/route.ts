/* POST /api/auth/resend — ارسال مجدد کد تأیید */

import type { NextRequest } from "next/server";
import { badRequest, json, readJson, sameOrigin } from "@/lib/server/http";
import { userFromRequest } from "@/lib/server/session";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";
import { issueOtp, type OtpKind } from "@/lib/server/auth-helpers";

interface Body {
  kind?: OtpKind;
}

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  const user = await userFromRequest(req);
  if (!user) return json({ ok: false, error: "UNAUTHORIZED" }, 401);

  const body = await readJson<Body>(req);
  const kind = body?.kind;
  if (kind !== "EMAIL_VERIFY" && kind !== "PHONE_VERIFY" && kind !== "PASSWORD_RESET") {
    return json({ ok: false, error: "INVALID_KIND" }, 400);
  }

  // محدودیت ارسال: هر ۹۰ ثانیه حداکثر یک‌بار (شمارنده‌ی پایدار مشترک)
  if (!(await rateLimit(`resend:${user.id}:${kind}`, 1, 90_000))) {
    return json({ ok: false, error: "RESEND_COOLDOWN" }, 429);
  }
  if (!(await rateLimit(`resend-day:${user.id}`, 10, 24 * 3600_000))) {
    return json({ ok: false, error: "TOO_MANY_CODES" }, 429);
  }

  const target = kind === "EMAIL_VERIFY" ? user.email : kind === "PHONE_VERIFY" ? user.phone : user.email ?? user.phone;
  if (!target) return json({ ok: false, error: "NO_TARGET" }, 400);

  const { code, demoExposed } = await issueOtp(user, kind);
  /* کد فقط در حالت نمایشی صادقانه در پاسخ می‌آید؛ در production هرگز */
  return json({ ok: true, demoCode: demoExposed ? code : undefined });
}
