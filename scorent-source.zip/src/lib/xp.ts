/* ————— XP & level progression (pure, documented) —————
 * فرمول پیشرفت:
 *   XP لازم برای عبور از سطح n به n+1:  next(n) = 100 + (n − 1) × 50
 *   یعنی 1→2: ۱۰۰ | 2→3: ۱۵۰ | 3→4: ۲۰۰ | ...
 *   مجموع XP لازم برای رسیدن به سطح L:  total(L) = Σ_{k=1..L−1} next(k)
 * سطح از مجموع XP رویدادها محاسبه می‌شود؛ هیچ‌جا هاردکد نیست.
 */

export function xpForNextLevel(level: number): number {
  const l = Math.max(1, Math.floor(level));
  return 100 + (l - 1) * 50;
}

/** مجموع XP لازم برای «رسیدن» به سطح L (سطح ۱ = صفر) */
export function totalXpForLevel(level: number): number {
  const L = Math.max(1, Math.floor(level));
  // Σ (100 + (k-1)*50) برای k=1..L-1
  const n = L - 1;
  return n * 100 + (50 * (n - 1) * n) / 2;
}

export interface LevelInfo {
  level: number;
  title: string;
  /** XP اندوخته‌شده در سطح فعلی */
  intoLevel: number;
  /** XP لازم برای سطح بعد */
  forNext: number;
  /** درصد پیشرفت ۰..۱۰۰ */
  progress: number;
  /** XP باقی‌مانده تا سطح بعد */
  remaining: number;
}

export const LEVEL_TITLES: { minLevel: number; title: string }[] = [
  { minLevel: 1, title: "تازه‌کار" },
  { minLevel: 5, title: "بازیکن" },
  { minLevel: 10, title: "شکارچی" },
  { minLevel: 20, title: "نخبه" },
  { minLevel: 30, title: "استاد" },
  { minLevel: 50, title: "افسانه" },
];

export function levelTitle(level: number): string {
  let title = LEVEL_TITLES[0].title;
  for (const t of LEVEL_TITLES) {
    if (level >= t.minLevel) title = t.title;
  }
  return title;
}

export function computeLevel(totalXp: number): LevelInfo {
  const xp = Math.max(0, Math.floor(totalXp));
  let level = 1;
  // سطح حداکثر ۵۰ در نظر گرفته می‌شود
  while (level < 50 && xp >= totalXpForLevel(level + 1)) {
    level++;
  }
  const base = totalXpForLevel(level);
  const next = totalXpForLevel(level + 1);
  const span = next - base;
  const intoLevel = Math.min(xp - base, span);
  const forNext = span;
  return {
    level,
    title: levelTitle(level),
    intoLevel,
    forNext,
    progress: span > 0 ? Math.round((intoLevel / span) * 100) : 100,
    remaining: Math.max(0, next - xp),
  };
}
