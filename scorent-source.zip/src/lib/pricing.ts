/* ————— Pricing & money utilities (integer-based, consistent everywhere) —————
 * همه مبالغ به تومان و به‌صورت عدد صحیح نگه‌داری می‌شوند تا خطای گردکردن تکراری رخ ندهد.
 */

export const PLATFORM_COMMISSION_RATE = 0.1; // ۱۰٪ کمیسیون پلتفرم

export interface PriceLike {
  price: number;
  originalPrice: number;
  discountPercent: number;
}

/** درصد تخفیف معتبر: بین ۰ تا ۹۰ */
export function sanitizeDiscount(pct: number): number {
  if (!Number.isFinite(pct)) return 0;
  return Math.max(0, Math.min(90, Math.round(pct)));
}

/** قیمت نهایی پس از تخفیف — هرگز منفی نمی‌شود */
export function finalPrice(g: PriceLike): number {
  const pct = sanitizeDiscount(g.discountPercent);
  const base = Math.max(0, Math.round(g.originalPrice));
  const value = Math.round((base * (100 - pct)) / 100);
  // قیمت ذخیره‌شده و قیمت محاسبه‌شده باید سازگار باشند؛ مبنای نهایی محاسبه است
  return Math.max(0, Math.min(value, base));
}

/** مبلغ صرفه‌جویی (تومان) */
export function savingsAmount(g: PriceLike): number {
  return Math.max(0, Math.round(g.originalPrice) - finalPrice(g));
}

export const RENTAL_DURATIONS = [1, 3, 7] as const;
export type RentalDays = (typeof RENTAL_DURATIONS)[number];

export function isRentalDays(d: number): d is RentalDays {
  return (RENTAL_DURATIONS as readonly number[]).includes(d);
}

export interface RentalRatesLike {
  d1: number;
  d3: number;
  d7: number;
}

/** قیمت اجاره بر اساس بازه — null اگر بازی اجاره‌ای ندارد */
export function rentalPrice(rates: RentalRatesLike | null, days: number): number | null {
  if (!rates) return null;
  switch (days) {
    case 1:
      return Math.max(0, Math.round(rates.d1));
    case 3:
      return Math.max(0, Math.round(rates.d3));
    case 7:
      return Math.max(0, Math.round(rates.d7));
    default:
      return null;
  }
}

/** سهم پلتفرم — گرد‌شده به عدد صحیح */
export function commissionOf(price: number): number {
  return Math.max(0, Math.round(price * PLATFORM_COMMISSION_RATE));
}

/** درآمد برآوردی مالک = مبلغ − کمیسیون */
export function ownerEarningsOf(price: number): number {
  const p = Math.max(0, Math.round(price));
  return p - commissionOf(p);
}
