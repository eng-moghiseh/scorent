"use client";

/* ————— لایه کلاینتی چندزبونگی و تم (فارسی/انگلیسی — تیره/روشن) —————
 * منطق محض در i18n-core.ts (قابل استفاده در سرور) است؛ اینجا فقط استور
 * zustand، هوک‌ها و اعمال تنظیمات روی document قرار دارد و همه‌ی خروجی‌های
 * هسته re-export می‌شود تا مسیر ایمپورت «@/lib/i18n» برای کلاینت ثابت بماند.
 *
 * - زبان و تم در localStorage کلید «scorent-ui:v1» ذخیره می‌شوند.
 * - اولین رندر کلاینت همیشه با مقادیر پیش‌فرض (فارسی/تیره) انجام می‌شود تا
 *   با SSR هم‌خوان باشد؛ سپس در اثر UiEffects مقدار ذخیره‌شده اعمال می‌شود.
 * - اسکریپت pre-paint در layout.tsx قبل از رندر، lang/dir/class را روی
 *   <html> تنظیم می‌کند تا فلشِ جهت و تم (FOUC) رخ ندهد.
 */

import { useMemo } from "react";
import { create } from "zustand";
import { UI_STORAGE_KEY, type Lang, type Theme, type TFn, type Fmt, type GameText } from "./i18n-core";
import { makeT, makeFmt, gameTextOf } from "./i18n-core";
import type { Game } from "./types";

export {
  UI_STORAGE_KEY,
  UI_BOOT_SCRIPT,
  makeT,
  txStatic,
  joinAnd,
  makeFmt,
  gameTextOf,
} from "./i18n-core";
export type { Lang, Theme, TFn, Fmt, GameText } from "./i18n-core";

/* ————— استور UI ————— */

interface UiState {
  locale: Lang;
  theme: Theme;
  ready: boolean;
  setLocale: (l: Lang) => void;
  setTheme: (t: Theme) => void;
  toggleTheme: () => void;
  load: () => void;
}

function applyDocument(locale: Lang, theme: Theme): void {
  if (typeof document === "undefined") return;
  const el = document.documentElement;
  el.lang = locale;
  el.dir = locale === "fa" ? "rtl" : "ltr";
  el.classList.toggle("light", theme === "light");
  el.classList.toggle("dark", theme !== "light");
  el.style.colorScheme = theme;
}

function persistUi(locale: Lang, theme: Theme): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(UI_STORAGE_KEY, JSON.stringify({ state: { locale, theme }, version: 1 }));
  } catch {
    /* حافظه غیرفعال — نادیده */
  }
}

export const useUi = create<UiState>()((set, get) => ({
  locale: "fa",
  theme: "dark",
  ready: false,
  setLocale: (locale) => {
    set({ locale });
    applyDocument(locale, get().theme);
    persistUi(locale, get().theme);
  },
  setTheme: (theme) => {
    set({ theme });
    applyDocument(get().locale, theme);
    persistUi(get().locale, theme);
  },
  toggleTheme: () => get().setTheme(get().theme === "dark" ? "light" : "dark"),
  load: () => {
    let locale: Lang = "fa";
    let theme: Theme = "dark";
    try {
      const raw = window.localStorage.getItem(UI_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as { state?: { locale?: Lang; theme?: Theme } };
        const st = parsed && typeof parsed === "object" ? parsed.state : undefined;
        if (st?.locale === "fa" || st?.locale === "en") locale = st.locale;
        if (st?.theme === "dark" || st?.theme === "light") theme = st.theme;
      }
    } catch {
      /* داده خراب — پیش‌فرض */
    }
    set({ locale, theme, ready: true });
    applyDocument(locale, theme);
  },
}));

/* ————— هوک‌ها ————— */

export function useLang(): Lang {
  return useUi((s) => s.locale);
}

export function useTheme(): Theme {
  return useUi((s) => s.theme);
}

/** جهت فعال UI — برای Radix، Sheetها و Toaster */
export function useUiDir(): "rtl" | "ltr" {
  return useUi((s) => (s.locale === "fa" ? "rtl" : "ltr"));
}

export function useT(): TFn {
  const lang = useLang();
  return useMemo(() => makeT(lang), [lang]);
}

/** ترجمه‌ی رشته‌های ثابت لایه داده در زمان رندر */
export function useTx(): (text: string) => string {
  const lang = useLang();
  return useMemo(() => (text: string) => txStatic(text, lang), [lang]);
}

import { txStatic } from "./i18n-core";

export function useFmt(): Fmt {
  const lang = useLang();
  return useMemo(() => makeFmt(lang), [lang]);
}

export function useGameText(game: Game): GameText {
  const lang = useLang();
  return useMemo(() => gameTextOf(game, lang), [game, lang]);
}
