/* ————— fragment: dict-profile — پروفایل، علاقه‌مندی‌ها، ۴۰۴ —————
 * هر کلید: [فارسی (عین متن اصلی)، English]. پارامترها با الگوی {name} جایگزین می‌شوند.
 */

export const STR: Record<string, [string, string]> = {
  /* ————— profile.* — ویرایش پروفایل ————— */
  "profile.edit": ["ویرایش پروفایل", "Edit profile"],
  "profile.editDesc": [
    "تکمیل نام کاربری ۵۰ XP و دستاورد «هویت گیمری» دارد — فقط یک‌بار.",
    "Completing your username grants 50 XP and the “{achievement}” achievement — one time only.",
  ],
  "profile.saved": ["پروفایل ذخیره شد", "Profile saved"],
  "profile.displayName": ["نام نمایشی", "Display name"],
  "profile.namePlaceholder": ["مثلاً شبح_دیجیتال", "e.g. digital_ghost"],
  "profile.nameMin": ["نام حداقل ۲ نویسه است", "Name must be at least 2 characters"],
  "profile.nameMax": ["نام حداکثر ۲۴ نویسه است", "Name must be at most 24 characters"],
  "profile.nameChars": ["نویسه‌های غیرمجاز", "Invalid characters"],
  "profile.avatar": ["آواتار", "Avatar"],
  "profile.avatarAria": ["آواتار {id}", "Avatar {id}"],
  "profile.cancel": ["انصراف", "Cancel"],
  "profile.save": ["ذخیره", "Save"],

  /* ————— profile.* — هدر پروفایل ————— */
  "profile.levelChip": ["سطح {n} — {title}", "Level {n} — {title}"],
  "profile.memberSince": ["عضو از {date}", "Member since {date}"],
  "profile.newcomer": ["تازه‌وارد Scorent", "New to Scorent"],
  "profile.xpToNext": ["{cur} / {max} XP تا سطح {n}", "{cur} / {max} XP to level {n}"],
  "profile.rewards": ["جوایز", "Rewards"],
  "profile.statLibrary": ["کتابخانه (خرید نمایشی)", "Library (demo purchases)"],
  "profile.statActiveRentals": ["اجاره فعال", "Active rentals"],
  "profile.statWishlist": ["علاقه‌مندی‌ها", "Wishlist"],
  "profile.statReviews": ["نظرات ثبت‌شده", "Reviews posted"],
  "profile.statListings": ["آگهی‌های فعال", "Active listings"],
  "profile.statAchievements": ["دستاوردها", "Achievements"],

  /* ————— profile.* — تب‌ها ————— */
  "profile.tabLibrary": ["کتابخانه", "Library"],
  "profile.tabRentals": ["اجاره‌ها", "Rentals"],
  "profile.tabListings": ["آگهی‌ها", "Listings"],
  "profile.tabReviews": ["نظرات", "Reviews"],
  "profile.tabActivity": ["فعالیت‌ها", "Activity"],

  /* ————— profile.* — کتابخانه ————— */
  "profile.emptyLibraryTitle": ["کتابخانه‌ات خالی است", "Your library is empty"],
  "profile.emptyLibraryDesc": [
    "خریدهای نمایشی اینجا جمع می‌شوند؛ هیچ پرداخت واقعی در کار نیست. با اولین خرید ۶۰ XP می‌گیری.",
    "Demo purchases collect here; no real payment is involved. Your first purchase earns you 60 XP.",
  ],
  "profile.goStore": ["رفتن به فروشگاه", "Go to Store"],
  "profile.demoBadge": ["خرید نمایشی", "Demo purchase"],

  /* ————— profile.* — اجاره‌ها ————— */
  "profile.emptyRentalsTitle": ["هیچ اجاره‌ای ثبت نشده", "No rentals yet"],
  "profile.emptyRentalsDesc": [
    "یک بازی را برای ۱، ۳ یا ۷ روز اجاره کن و جریان شمارش معکوس را ببین.",
    "Rent a game for 1, 3 or 7 days and watch the live countdown.",
  ],
  "profile.rentCatalog": ["کاتالوگ اجاره", "Rental catalog"],
  "profile.daysRental": ["{n} روزه", "{n}-day"],
  "profile.hezarToman": ["{n} هزار تومان", "{n}K Toman"],
  "profile.statusActive": ["فعال", "Active"],
  "profile.statusDone": ["تمام‌شده", "Completed"],
  "profile.track": ["پیگیری", "Track"],
  "profile.rentAgain": ["اجاره دوباره", "Rent again"],

  /* ————— profile.* — آگهی‌ها ————— */
  "profile.emptyListingsTitle": ["آگهی نساخته‌ای", "No listings yet"],
  "profile.emptyListingsDesc": [
    "در Scorent Share می‌توانی آگهی اجاره بسازی؛ کمیسیون پلتفرم ۱۰٪ است و همه‌چیز شبیه‌سازی است.",
    "You can create rental listings on Scorent Share; the platform commission is 10% and everything is simulated.",
  ],
  "profile.createListing": ["ساخت آگهی", "Create listing"],
  "profile.statusAvailable": ["در دسترس", "Available"],
  "profile.statusRented": ["اجاره‌شده", "Rented"],
  "profile.manage": ["مدیریت", "Manage"],

  /* ————— profile.* — نظرات ————— */
  "profile.emptyReviewsTitle": ["هنوز نظری ننوشتی", "No reviews yet"],
  "profile.emptyReviewsDesc": [
    "روی صفحه هر بازی می‌توانی امتیاز و نظر ثبت کنی؛ هر نظر معتبر ۳۰ XP دارد.",
    "You can post a rating and a review on any game page; each valid review earns 30 XP.",
  ],
  "profile.pickGame": ["انتخاب بازی", "Pick a game"],

  /* ————— profile.* — فعالیت‌ها و پانوشت ————— */
  "profile.emptyActivityTitle": ["فعالیتی ثبت نشده", "No activity yet"],
  "profile.emptyActivityDesc": ["با شروع تعامل، رویدادها اینجا دیده می‌شوند.", "Events will show up here as you interact."],
  "profile.derivedNote": [
    "همه شمارنده‌های این صفحه از رکوردهای واقعی ذخیره‌شده در مرورگر تو محاسبه می‌شوند — هیچ عدد دستی‌ای در کار نیست و بعد از رفرش هم سر جایشان هستند.",
    "Every counter on this page is computed from real records stored in your browser — nothing is entered manually, and everything stays in place after a refresh.",
  ],

  /* ————— wishlist.* — علاقه‌مندی‌ها ————— */
  "wishlist.badge": ["علاقه‌مندی‌ها", "Wishlist"],
  "wishlist.title": ["فهرست آرزوهای تو", "Your wishlist"],
  "wishlist.descEmpty": [
    "با قلب روی هر کارت، بازی را اینجا ذخیره کن — هر بازی فقط یک‌بار اضافه می‌شود.",
    "Tap the heart on any card to save games here — each game is added only once.",
  ],
  "wishlist.descCount": ["{n} بازی ذخیره شده؛ با قلب دوباره می‌توانی حذفش کنی.", "{n} games saved; tap the heart again to remove one."],
  "wishlist.emptyTitle": ["هنوز چیزی اینجا نیست", "Nothing here yet"],
  "wishlist.emptyDesc": [
    "از فروشگاه یا کشف، بازی‌های موردعلاقه‌ات را با قلب علامت بزن تا بعداً گم نشوند.",
    "Heart your favorite games from the Store or Discover so they don’t get lost later.",
  ],
  "wishlist.goStore": ["رفتن به فروشگاه", "Go to Store"],
  "wishlist.removedToast": ["«{game}» از علاقه‌مندی‌ها حذف شد", "“{game}” removed from your wishlist"],
  "wishlist.removeBtn": ["حذف از فهرست", "Remove from wishlist"],

  /* ————— notFound.* — صفحه ۴۰۴ ————— */
  "notFound.title": ["این مسیر در زمین‌های میانی Scorent پیدا نشد", "This path was not found in Scorent’s middle-earth"],
  "notFound.attemptedPre": ["نشانی", "The address"],
  "notFound.attemptedPost": ["وجود ندارد یا حذف شده است.", "does not exist or has been removed."],
  "notFound.plain": ["صفحه‌ای که دنبالش بودی اینجا نیست.", "The page you were looking for is not here."],
  "notFound.home": ["صفحه اصلی", "Home"],
  "notFound.discover": ["کشف {n} بازی", "Discover {n} games"],
};
