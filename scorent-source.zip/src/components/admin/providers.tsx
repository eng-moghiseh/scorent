"use client";

/* ————— وضعیت سرویس‌های خارجی + راهنمای متغیرهای محیطی ————— */

import { useEffect, useState } from "react";
import { CheckCircle2, Mail, MessageSquare, Plug, ShieldCheck } from "lucide-react";
import { api } from "@/lib/auth";
import { useT } from "@/lib/i18n";
import { AdminHeader, AdminError } from "./ui";
import { cn } from "@/lib/utils";

interface Providers {
  email: { configured: boolean; host: string | null; user: string | null };
  sms: { configured: boolean; provider: string | null };
  google: { configured: boolean };
  adminPasswordEnv: boolean;
}

const ENV_DOCS: Record<string, string[]> = {
  email: ["SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASS", "SMTP_FROM", "SMTP_SECURE"],
  sms: ["SMS_PROVIDER=kavenegar", "SMS_API_KEY", "SMS_FROM", "یا SMS_WEBHOOK_URL"],
  google: ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"],
};

export function AdminProviders() {
  const t = useT();
  const [p, setP] = useState<Providers | null>(null);
  const [err, setErr] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get<{ ok: boolean; providers: Providers }>("/api/admin/providers");
        setP(res.providers);
      } catch {
        setErr(true);
      }
    })();
  }, []);

  if (err) return <AdminError />;

  const cards = [
    {
      id: "email",
      icon: Mail,
      title: t("admin.providers.email"),
      configured: p?.email.configured,
      detail: p?.email.configured ? `${p.email.host} · ${p.email.user ?? "—"}` : ENV_DOCS.email.join(" · "),
    },
    {
      id: "sms",
      icon: MessageSquare,
      title: t("admin.providers.sms"),
      configured: p?.sms.configured,
      detail: p?.sms.configured ? (p.sms.provider ?? "—") : ENV_DOCS.sms.join(" · "),
    },
    {
      id: "google",
      icon: ShieldCheck,
      title: t("admin.providers.google"),
      configured: p?.google.configured,
      detail: ENV_DOCS.google.join(" · "),
    },
  ];

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.providers.title")} description={t("admin.providers.desc")} icon={Plug} />

      <div className="grid gap-3 md:grid-cols-3">
        {cards.map((c) => (
          <section key={c.id} className={cn("rounded-3xl border p-5", c.configured ? "border-rent/40 bg-rent/5" : "border-deal/40 bg-deal/5")} aria-label={c.title}>
            <c.icon className={cn("size-6", c.configured ? "text-rent" : "text-deal")} />
            <h2 className="mt-3 text-sm font-extrabold">{c.title}</h2>
            <p className={cn("mt-1 flex items-center gap-1.5 text-xs font-extrabold", c.configured ? "text-rent" : "text-deal")}>
              <CheckCircle2 className="size-3.5" />
              {c.configured ? t("admin.providers.configured") : t("admin.providers.demo")}
            </p>
            <p dir="ltr" className="mt-3 break-all rounded-xl bg-secondary/40 p-2.5 text-start text-[0.62rem] leading-5 text-muted-foreground tnum">
              {c.detail}
            </p>
          </section>
        ))}
      </div>

      <section className="mt-6 rounded-3xl border border-border bg-card p-5" aria-label={t("admin.providers.howTo")}>
        <h2 className="text-sm font-extrabold">{t("admin.providers.howTo")}</h2>
        <div dir="ltr" className="mt-3 space-y-2 rounded-2xl bg-secondary/40 p-4 text-start text-[0.68rem] leading-6 text-muted-foreground tnum">
          <p># .env — email (SMTP)</p>
          <p>SMTP_HOST=smtp.example.com</p>
          <p>SMTP_PORT=587</p>
          <p>SMTP_USER=no-reply@example.com</p>
          <p>SMTP_PASS=••••••</p>
          <p>SMTP_FROM=&quot;Scorent &lt;no-reply@example.com&gt;&quot;</p>
          <p className="pt-2"># SMS (Kavenegar or generic webhook)</p>
          <p>SMS_PROVIDER=kavenegar</p>
          <p>SMS_API_KEY=••••••</p>
          <p>SMS_FROM=10008663</p>
          <p className="pt-2"># Google OAuth</p>
          <p>GOOGLE_CLIENT_ID=…apps.googleusercontent.com</p>
          <p>GOOGLE_CLIENT_SECRET=••••••</p>
          <p className="pt-2"># Admin bootstrap (optional — defaults are seeded)</p>
          <p>ADMIN_EMAIL=admin@scorent.ir</p>
          <p>ADMIN_PASSWORD=••••••</p>
        </div>
      </section>
    </div>
  );
}
