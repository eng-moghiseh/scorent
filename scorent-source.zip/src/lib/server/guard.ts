/* ————— گارد مجوزهای پنل مدیریت — ماتریس در lib/permissions مشترک است ————— */

import type { NextRequest, NextResponse } from "next/server";
import { userFromRequest } from "./session";
import { forbidden, unauthorized } from "./http";
import type { User } from "@prisma/client";

export { ROLES, STAFF_ROLES, can, isStaff, PERM_LABELS } from "@/lib/permissions";
export type { Perm, Role } from "@/lib/permissions";
import { isStaff } from "@/lib/permissions";

/** گارد سراسری: کاربر فعالِ دارای مجوز؛ در غیر این صورت پاسخ خطا */
export async function requirePerm(req: NextRequest, perm: import("@/lib/permissions").Perm): Promise<{ user: User } | NextResponse> {
  const user = await userFromRequest(req);
  if (!user) return unauthorized();
  if (!isStaff(user.role)) return forbidden();
  if (!(await import("@/lib/permissions")).can(user.role, perm)) return forbidden();
  return { user };
}

/** گارد ورود معمولی (هر کاربر فعال) */
export async function requireUser(req: NextRequest): Promise<{ user: User } | NextResponse> {
  const user = await userFromRequest(req);
  if (!user) return unauthorized();
  return { user };
}

/** کمک‌کننده‌ی کوتاه: اگر گارد پاسخ خطا داد همان را برگردان */
export function isGuardError(v: { user: unknown } | NextResponse): v is NextResponse {
  return v instanceof Response;
}
