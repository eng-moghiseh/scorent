"use client";

/* ————— Scorent Rewards: XP، سطح‌ها، دستاوردها، چالش‌های هفتگی، تاریخچه (دوزبانه) ————— */

import { motion } from "framer-motion";
import { CalendarDays, Gift, History, Lock, Medal, ScrollText, Target, Trophy } from "lucide-react";
import { AnimatedNumber, EmptyState, IconByName, SectionHeader, XPBar } from "@/components/scorent/shared";
import { Link as RouteLink } from "@/components/scorent/router";
import { Button } from "@/components/ui/button";
import { ACHIEVEMENTS, WEEKLY_CHALLENGES } from "@/lib/data/community";
import { XP_REWARDS, useHydrated, useLevelInfo, useScorent } from "@/lib/store";
import { LEVEL_TITLES, totalXpForLevel } from "@/lib/xp";
import { useFmt, useT, useTx } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function RewardsPage() {
  const hydrated = useHydrated();
  const level = useLevelInfo();
  const achievements = useScorent((s) => s.achievements);
  const xpEvents = useScorent((s) => s.xpEvents);
  const completedChallenges = useScorent((s) => s.completedChallenges);
  const challengeProgress = useScorent((s) => s.challengeProgress);
  const t = useT();
  const f = useFmt();
  const tx = useTx();

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-16">
        <div className="skeleton-shimmer h-48 rounded-3xl" />
      </div>
    );
  }

  const unlockedCount = Object.keys(achievements).length;

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-10 md:px-6">
      {/* هدر XP */}
      <motion.header
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-10 overflow-hidden rounded-3xl border border-deal/25 bg-card p-6 glow-brand md:p-8"
      >
        <div className="flex flex-wrap items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="relative flex size-20 items-center justify-center rounded-3xl bg-deal/12">
              <span className="text-3xl font-black text-deal tnum">{f.num(level.level)}</span>
              <span className="absolute -bottom-2 rounded-full bg-deal px-2 py-0.5 text-[0.6rem] font-black text-[#3a1c00]">
                {tx(level.title)}
              </span>
            </div>
            <div>
              <h1 className="flex items-center gap-2 text-2xl font-black">
                <Trophy className="size-6 text-deal" />
                {t("rewards.title")}
              </h1>
              <p className="mt-1.5 text-sm text-muted-foreground">
                {t("rewards.totalXp")}{" "}
                <b className="text-foreground tnum">
                  <AnimatedNumber value={xpEvents.reduce((a, e) => a + e.amount, 0)} />
                </b>{" "}
                {t("rewards.formulaPre")} <span className="tnum">{t("rewards.formula")}</span> {t("rewards.formulaPost")}
              </p>
            </div>
          </div>
          <div className="w-full max-w-xs">
            <div className="mb-1.5 flex justify-between text-xs">
              <span className="text-muted-foreground">{t("rewards.toLevel", { n: f.num(level.level + 1) })}</span>
              <span className="font-bold text-deal tnum">{t("rewards.progressPct", { n: f.num(level.progress) })}</span>
            </div>
            <XPBar value={level.intoLevel} max={level.forNext} />
            <p className="mt-2 text-[0.68rem] text-muted-foreground tnum">{t("rewards.xpToNext", { n: f.num(level.remaining) })}</p>
          </div>
        </div>

        {/* نقاط عطف سطح */}
        <div className="mt-7 grid grid-cols-3 gap-2 sm:grid-cols-6">
          {LEVEL_TITLES.map((lt) => {
            const reached = level.level >= lt.minLevel;
            return (
              <div
                key={lt.minLevel}
                className={cn(
                  "rounded-xl border p-2.5 text-center transition-colors",
                  reached ? "border-deal/40 bg-deal/8" : "border-border bg-secondary/40 opacity-60"
                )}
              >
                <p className={cn("text-[0.62rem]", reached ? "text-deal" : "text-muted-foreground")}>
                  {t("rewards.levelN", { n: f.num(lt.minLevel) })}
                </p>
                <p className="mt-0.5 text-xs font-extrabold">{tx(lt.title)}</p>
                <p className="mt-0.5 text-[0.58rem] text-muted-foreground tnum">{f.num(totalXpForLevel(lt.minLevel))} XP</p>
              </div>
            );
          })}
        </div>
      </motion.header>

      {/* چالش‌های هفتگی */}
      <section className="mb-12" aria-label={t("rewards.challengesAria")}>
        <SectionHeader
          kicker={t("rewards.kickerThisWeek")}
          title={t("rewards.challengesTitle")}
          description={t("rewards.challengesDesc", { n: f.num(100) })}
          icon={Target}
          tone="deal"
        />
        <div className="grid gap-4 md:grid-cols-3">
          {WEEKLY_CHALLENGES.map((ch) => {
            const done = Boolean(completedChallenges[Object.keys(completedChallenges).find((k) => k.endsWith(`:${ch.id}`)) ?? ""]);
            const progress = Math.min(challengeProgress(ch.metric), ch.target);
            const pct = Math.round((progress / ch.target) * 100);
            return (
              <div key={ch.id} className={cn("rounded-2xl border p-5", done ? "border-rent/40 bg-rent/5" : "border-border bg-card")}>
                <div className="flex items-center justify-between">
                  <span className="flex size-10 items-center justify-center rounded-2xl bg-deal/12 text-deal">
                    <IconByName name={ch.icon} className="size-5" />
                  </span>
                  <span
                    className={cn(
                      "rounded-full px-2.5 py-1 text-[0.62rem] font-extrabold tnum",
                      done ? "bg-rent/15 text-rent" : "bg-secondary text-muted-foreground"
                    )}
                  >
                    {done ? t("rewards.doneBadge") : t("rewards.xpChip", { n: f.num(ch.xp) })}
                  </span>
                </div>
                <h3 className="mt-3 font-extrabold">{tx(ch.title)}</h3>
                <p className="mt-1 text-xs leading-6 text-muted-foreground">{tx(ch.description)}</p>
                <div className="mt-3">
                  <XPBar value={progress} max={ch.target} tone={done ? "rent" : "brand"} />
                  <p className="mt-1.5 text-[0.65rem] text-muted-foreground tnum">
                    {t("rewards.progressOf", { a: f.num(progress), b: f.num(ch.target) })}
                    {pct === 100 && !done ? t("rewards.pendingNote") : ""}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* گالری دستاوردها */}
      <section className="mb-12" aria-label={t("rewards.achievementsAria")}>
        <SectionHeader
          kicker={t("rewards.kickerGallery")}
          title={t("rewards.achTitle", { a: f.num(unlockedCount), b: f.num(ACHIEVEMENTS.length) })}
          description={t("rewards.achDesc")}
          icon={Medal}
          action={{ label: t("rewards.myProfile"), to: "/profile" }}
        />
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {ACHIEVEMENTS.map((a, i) => {
            const rec = achievements[a.id];
            const unlocked = Boolean(rec);
            return (
              <motion.div
                key={a.id}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: Math.min(i * 0.03, 0.25) }}
                className={cn(
                  "rounded-2xl border p-4 transition-all",
                  unlocked ? "border-deal/40 bg-deal/6" : "border-border bg-card/50"
                )}
              >
                <div className="flex items-start justify-between">
                  <span
                    className={cn(
                      "flex size-11 items-center justify-center rounded-2xl",
                      unlocked ? "bg-deal/15 text-deal" : "bg-secondary text-muted-foreground/50"
                    )}
                  >
                    {unlocked ? <IconByName name={a.icon} className="size-5.5" /> : <Lock className="size-5" />}
                  </span>
                  {a.bonusXp > 0 ? (
                    <span className={cn("rounded-full px-2 py-0.5 text-[0.6rem] font-extrabold tnum", unlocked ? "bg-deal/15 text-deal" : "bg-secondary text-muted-foreground/60")}>
                      {t("rewards.bonusXp", { n: f.num(a.bonusXp) })}
                    </span>
                  ) : null}
                </div>
                <h3 className={cn("mt-3 text-sm font-extrabold", !unlocked && "text-muted-foreground")}>{tx(a.title)}</h3>
                <p className="mt-1 text-[0.7rem] leading-5 text-muted-foreground">{tx(a.description)}</p>
                {unlocked && rec ? (
                  <p className="mt-2 flex items-center gap-1 text-[0.6rem] text-deal tnum">
                    <CalendarDays className="size-3" />
                    {f.dateTime(rec.unlockedAt)}
                  </p>
                ) : null}
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* تاریخچه جوایز */}
      <section aria-label={t("rewards.historyAria")}>
        <SectionHeader kicker={t("rewards.kickerLedger")} title={t("rewards.historyTitle")} description={t("rewards.historyDesc")} icon={History} />
        {xpEvents.length === 0 ? (
          <EmptyState
            icon={Gift}
            title={t("rewards.emptyTitle")}
            description={t("rewards.emptyDesc", { a: f.num(50), b: f.num(60), c: f.num(30) })}
            action={
              <RouteLink to="/profile">
                <Button>{t("rewards.emptyCta")}</Button>
              </RouteLink>
            }
          />
        ) : (
          <div className="max-h-96 overflow-y-auto rounded-2xl border border-border">
            <ul className="divide-y divide-border">
              {[...xpEvents].reverse().map((e) => (
                <li key={e.id} className="flex items-center justify-between gap-3 bg-card px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className="flex size-8 items-center justify-center rounded-xl bg-deal/10 text-deal">
                      <ScrollText className="size-4" />
                    </span>
                    <div>
                      <p className="text-xs font-bold">{tx(e.label)}</p>
                      <p className="text-[0.62rem] text-muted-foreground tnum">{f.dateTime(e.at)}</p>
                    </div>
                  </div>
                  <span className="shrink-0 rounded-full bg-deal/12 px-2.5 py-1 text-xs font-black text-deal tnum">
                    {t("rewards.xpPlus", { n: f.num(e.amount) })}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </section>
    </div>
  );
}
