import { describe, expect, it } from "vitest";
import { DAY_MS, isExpired, remainingMs, renewalExpiry } from "../src/lib/rental-time";

describe("rental time", () => {
  const now = 1_700_000_000_000;

  it("انقضا از timestamp محاسبه می‌شود", () => {
    const active = { startedAt: now - DAY_MS, expiresAt: now + DAY_MS, status: "active" as const };
    const expired = { startedAt: now - 3 * DAY_MS, expiresAt: now - DAY_MS, status: "active" as const };
    expect(isExpired(active, now)).toBe(false);
    expect(isExpired(expired, now)).toBe(true);
    expect(remainingMs(active, now)).toBe(DAY_MS);
    expect(remainingMs(expired, now)).toBe(0);
  });

  it("تمدید اجاره فعال از انتهای مهلت فعلی اضافه می‌شود", () => {
    const rental = { startedAt: now - DAY_MS, expiresAt: now + 2 * DAY_MS, status: "active" as const };
    expect(renewalExpiry(rental, now, 3)).toBe(now + 2 * DAY_MS + 3 * DAY_MS);
  });

  it("تمدید اجاره منقضی‌شده از لحظه فعلی شروع می‌شود", () => {
    const rental = { startedAt: now - 5 * DAY_MS, expiresAt: now - DAY_MS, status: "active" as const };
    expect(renewalExpiry(rental, now, 7)).toBe(now + 7 * DAY_MS);
  });

  it("حداقل یک روز تمدید می‌شود", () => {
    const rental = { startedAt: now, expiresAt: now + DAY_MS, status: "active" as const };
    expect(renewalExpiry(rental, now, 0)).toBe(now + DAY_MS + DAY_MS);
  });
});
