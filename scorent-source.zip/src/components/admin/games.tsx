"use client";

/* ————— مدیریت بازی‌ها — اورراید نمایش/تخفیف/متن روی دیتاست ————— */

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Gamepad2, Pencil, RotateCcw, Save, Search, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { GAMES } from "@/lib/data/games";
import { api, useAuth } from "@/lib/auth";
import { useFmt, useT } from "@/lib/i18n";
import type { GameOverrideData } from "@/lib/catalog";
import { AdminHeader, AdminError } from "./ui";
import { cn } from "@/lib/utils";

interface OverrideRow {
  gameId: string;
  data: string;
  updatedAt: string;
}

export function AdminGames() {
  const t = useT();
  const f = useFmt();
  const me = useAuth((s) => s.user);
  const [rows, setRows] = useState<OverrideRow[] | null>(null);
  const [err, setErr] = useState(false);
  const [q, setQ] = useState("");
  const [onlyOverridden, setOnlyOverridden] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const [form, setForm] = useState<GameOverrideData>({});
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const res = await api.get<{ ok: boolean; overrides: OverrideRow[] }>("/api/admin/overrides");
      setRows(res.overrides);
    } catch {
      setErr(true);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const overrideMap = useMemo(() => {
    const m: Record<string, GameOverrideData> = {};
    for (const r of rows ?? []) {
      try {
        m[r.gameId] = JSON.parse(r.data) as GameOverrideData;
      } catch {
        /* ignore */
      }
    }
    return m;
  }, [rows]);

  const list = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return GAMES.filter((g) => (!qq || g.title.toLowerCase().includes(qq) || g.id.includes(qq)) && (!onlyOverridden || overrideMap[g.id]));
  }, [q, onlyOverridden, overrideMap]);

  function openEditor(gameId: string) {
    setEditing(gameId);
    setForm({ ...(overrideMap[gameId] ?? {}) });
  }

  async function save() {
    if (!editing) return;
    setBusy(true);
    try {
      await api.post("/api/admin/overrides", { gameId: editing, data: form });
      toast.success(t("admin.games.saved"));
      setEditing(null);
      await load();
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "EMPTY_OVERRIDE" ? t("admin.error") : t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function reset(gameId: string) {
    try {
      await api.del(`/api/admin/overrides/${gameId}`);
      toast.success(t("admin.games.resetDone"));
      await load();
    } catch {
      toast.error(t("admin.error"));
    }
  }

  if (err) return <AdminError />;
  const canGames = Boolean(me && (me.role === "SUPER_ADMIN" || me.role === "ADMIN" || me.role === "CONTENT_EDITOR"));

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.games.title")} description={t("admin.games.desc")} icon={Gamepad2} />

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative min-w-56 flex-1">
          <Search className="absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("admin.search")} className="ps-9" />
        </div>
        <label className="flex cursor-pointer items-center gap-2 text-xs font-bold text-muted-foreground">
          <Switch checked={onlyOverridden} onCheckedChange={setOnlyOverridden} aria-label={t("admin.games.filterOverridden")} />
          {t("admin.games.filterOverridden")}
        </label>
        <span className="text-xs text-muted-foreground tnum">{f.num(list.length)}</span>
      </div>

      <div className="grid gap-2.5 md:grid-cols-2">
        {list.map((g) => {
          const o = overrideMap[g.id];
          return (
            <div key={g.id} className={cn("rounded-2xl border bg-card p-4", o ? "border-ai/40" : "border-border")}>
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="truncate text-sm font-extrabold" dir="ltr">{g.title}</p>
                    {o?.hidden && (
                      <span className="flex items-center gap-1 rounded-full bg-destructive/15 px-2 py-0.5 text-[0.6rem] font-extrabold text-destructive">
                        <EyeOff className="size-3" /> {t("admin.games.hidden")}
                      </span>
                    )}
                    {o && <span className="rounded-full bg-ai/15 px-2 py-0.5 text-[0.6rem] font-extrabold text-ai">{t("admin.games.hasOverride")}</span>}
                  </div>
                  <p className="mt-1 truncate text-[0.65rem] text-muted-foreground">{g.tagline}</p>
                  {(o?.discountPct !== undefined || g.discountPercent > 0) && (
                    <p className="mt-1 text-[0.62rem] font-bold text-deal tnum">
                      {t("admin.games.discountPct")} {f.num(o?.discountPct ?? g.discountPercent)} · {f.toman(g.price, false)}
                    </p>
                  )}
                </div>
                {canGames && (
                  <div className="flex shrink-0 items-center gap-1.5">
                    <Button size="icon" variant="outline" className="size-8" onClick={() => openEditor(g.id)} aria-label={t("admin.games.edit")}>
                      <Pencil className="size-3.5" />
                    </Button>
                    {o && (
                      <Button size="icon" variant="outline" className="size-8" onClick={() => reset(g.id)} aria-label={t("admin.games.reset")}>
                        <RotateCcw className="size-3.5" />
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* ویرایشگر اورراید */}
      <Dialog open={editing !== null} onOpenChange={(v) => !v && setEditing(null)}>
        <DialogContent dir="rtl" className="max-h-[85svh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle dir="ltr" className="text-start">{GAMES.find((g) => g.id === editing)?.title ?? editing}</DialogTitle>
            <DialogDescription>{t("admin.games.desc")}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <label className="flex items-center justify-between rounded-xl border border-border bg-secondary/30 px-3 py-2.5">
                <span className="text-xs font-bold">{t("admin.games.hidden")}</span>
                <Switch checked={Boolean(form.hidden)} onCheckedChange={(v) => setForm((s) => ({ ...s, hidden: v }))} aria-label={t("admin.games.hidden")} />
              </label>
              <label className="flex items-center justify-between rounded-xl border border-border bg-secondary/30 px-3 py-2.5">
                <span className="text-xs font-bold">{t("admin.games.featured")}</span>
                <Switch checked={Boolean(form.featured)} onCheckedChange={(v) => setForm((s) => ({ ...s, featured: v }))} aria-label={t("admin.games.featured")} />
              </label>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-muted-foreground">{t("admin.games.discountPct")}</Label>
              <Input
                type="number"
                min={0}
                max={90}
                value={form.discountPct ?? ""}
                onChange={(e) => setForm((s) => ({ ...s, discountPct: e.target.value === "" ? undefined : Math.max(0, Math.min(90, Number(e.target.value))) }))}
              />
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-muted-foreground">{t("admin.games.taglineFa")}</Label>
                <Input value={form.taglineFa ?? ""} onChange={(e) => setForm((s) => ({ ...s, taglineFa: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-muted-foreground">{t("admin.games.taglineEn")}</Label>
                <Input dir="ltr" className="text-start" value={form.taglineEn ?? ""} onChange={(e) => setForm((s) => ({ ...s, taglineEn: e.target.value }))} />
              </div>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-muted-foreground">{t("admin.games.descFa")}</Label>
                <Textarea rows={4} value={form.descriptionFa ?? ""} onChange={(e) => setForm((s) => ({ ...s, descriptionFa: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-muted-foreground">{t("admin.games.descEn")}</Label>
                <Textarea rows={4} dir="ltr" className="text-start" value={form.descriptionEn ?? ""} onChange={(e) => setForm((s) => ({ ...s, descriptionEn: e.target.value }))} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={save} disabled={busy} className="w-full bg-ai text-white hover:bg-ai/90">
              <Save className="size-4" /> {t("admin.save")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
