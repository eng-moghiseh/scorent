# Scorent — Multi-Agent Worklog

Project: Scorent (سکورنت) — Persian-first gaming discovery & rental platform prototype.
Stack: Next.js 16 (App Router) + React 19 + TS strict + Tailwind 4 + shadcn/ui + zustand + framer-motion + LocalStorage persistence.

Environment constraint: sandbox only exposes the `/` route → full multi-page experience implemented with a typed hash router (`#/store`, `#/game/:id`, …) inside `src/app/page.tsx`.

---
Task ID: 1
Agent: main (Z.ai)
Task: Project inspection, environment init, plan.

Work Log:
- Loaded fullstack-dev skill; ran init script; verified dev server on port 3000 (200 OK).
- Inspected scaffold: Next 16.1.1, React 19, Tailwind 4, full shadcn/ui set, framer-motion 12, zustand 5, rhf + zod 4, sonner, lucide.
- Created 19-step TODO plan (domain layer → data → store → shell → pages → tests → QA).

Stage Summary:
- Decision: hash router instead of App Router paths (sandbox constraint), zustand + validated LocalStorage for persistence, procedural SVG cover art system, hand-crafted scorpion SVG logo, Vazirmatn font (local), vitest for pure-logic tests.

---
Task ID: 2
Agent: main (Z.ai)
Task: Build the complete Scorent platform (all modules, pages, data, store, tests, QA).

Work Log:
- Design tokens in globals.css (exact spec palette), utilities (glow, grid bg, shimmer, reduced-motion guard).
- layout.tsx: lang=fa dir=rtl, Vazirmatn Variable (local via fontsource), Radix DirectionProvider RTL, sonner Toaster RTL; scorpion SVG favicon.
- lib layer: types, format (deterministic Persian digits/toman/dates), pricing (final price, savings, 10% commission, rental rates), xp (documented curve 100+(n-1)x50, titles at 1/5/10/20/30/50), rental-time (timestamp expiry, documented renewal rule + cooldown), recommendation (weights 35/25/15/15/10, neutral half-scores for missing prefs, Persian matched[]+tradeoffs[], deterministic tie-breaking).
- data: 28 games with full metadata + sample-data designations, 12 achievements, 3 weekly challenges (ISO-week keys), avatars, seed reviews/activity/listings.
- store: zustand persist v1, safeStorage with shape validation + corruption fallback, idempotent XP events, activity log, flash->toast queue, export/import/reset.
- Router: hash-based (useSyncExternalStore); AppShell: sticky navbar (animated underline), mobile Sheet + bottom tab bar, footer, XPFlash, RentalLifecycle (30s expiry scan).
- Components: procedural GameCover (10 motifs x per-game palettes), GameCard, dialogs with demo disclaimers, XPBar, AnimatedNumber, EmptyState, skeletons.
- Pages: home (10 sections), store (URL-param filters), game detail (reviews + helpful votes), AI (4-step questionnaire + % rings + Persian explanations), rent, rentals (live countdown + renewal), share (RHF+zod, commission preview, CRUD), discovery, deals, trial, rewards, profile, wishlist, settings, 404.
- Tests: 25 vitest tests (all passing) incl. documented 200,000->20,000/180,000 commission example.
- QA via agent-browser: all 15 routes 0 page errors; golden paths verified (purchase persists across reload, 7d rental live countdown, listing commission math, AI flow XP toast + level chip). Fixed during QA: circular data import, 4 wrong-module imports, hero cover aspect collapse, unstable zustand selectors (infinite loop), storage validator version-check bug wiping data on reload, hooks-order violations.

Stage Summary:
- ~8,300 lines TS/TSX. Lint: 0 errors. tsc strict: 0 errors in src/. Tests: 25/25. All routes verified in browser (desktop + mobile).
- Honest limitations (stated in-product): all purchases/rentals simulated; no real licenses; prices/ratings are demo data; recommendation engine is rule-based (AI-API-ready); agent-browser verification instead of Playwright (sandbox constraint).
---
Task ID: 3
Agent: main (Z.ai)
Task: ULTIMATE PROJECT UPGRADE — real AI companion, cinematic polish, full QA, deploy new version.

Work Log:
- Audited existing 7k-line codebase (Next 16 + React 19 + TS strict, hash router, zustand store, 28-game dataset, 25 tests) — preserved everything.
- Real AI backend: src/lib/ai/catalog-tools.ts (7 deterministic tools over central GAMES dataset: search, budget-filter, detail, compare, recommend via existing rankGames engine, deals/rentable/hidden-gems, playstyle keywords, stats), intent.ts (deterministic Persian/English intent parser: titles+aliases, million/hezar budget patterns, genre whitelists, EN genre keywords, merge-sandbox for model output), prompt.ts (grounded persona with 9 hard rules, CATALOG_DATA injection, language hint), linkify.ts (client-side deterministic deep-linking of game titles).
- /api/chat route: zod validation (2k msg, 24 history caps), per-IP rate limit 20/min (verified 429 on 21st), two-phase flow (model planner 7s timeout → deterministic fallback always available), SSE streaming passthrough with 90s timeout + client-abort relay, graceful error events. Keys stay server-side (z-ai-web-dev-sdk, model glm).
- Chat client: chat-store.ts (persisted conversations, streaming reader, stop via AbortController, retry, sanitize-on-load), full page #/ai-chat (sidebar history + new chat + delete, welcome hero, 6 suggested prompts wired to real queries, markdown+tables via remark-gfm, code LTR, deep links intercepted to hash router, streaming cursor, thinking dots, copy, retry), floating AIDock (Sheet mini-chat, shared store, auto-close on hashchange, hidden on /ai-chat, badge count).
- Integrations: AppShell route+dock, navbar «دستیار AI» pill + mobile menu, footer link, home hero CTA + rewritten AI section (real capabilities + chat mockup with REAL catalog prices), questionnaire page cross-links.
- Fixes: double-hash navigate from markdown links, composer/tab-bar overlap on mobile (8.4rem calc), SSR log spam in safeStorage, dock lint rules (set-state-in-effect → hashchange subscription).
- Grounding verified numerically: model answer for Hades/Elden Ring matched dataset exactly (560k/30%, 1.92M/20%, rentals 60/140/225k & 240/600/960k, ratings 4.8/4.9).
- Tests: +20 vitest (tools/intent/merge/clamp/linkify) = 45/45 passing. Lint: 0 errors (1 pre-existing warning). tsc strict src/: 0 errors.
- Browser QA (agent-browser): 16 routes swept 0 page errors; golden paths verified — budget recommendation streams with real prices + deep links, comparison table grounded, deals answer, English question → English answer with catalog example, Enter-send, stop button, copy, new conversation, mobile chat + dock (390px), desktop 1440px, RTL correct throughout.

Stage Summary:
- Assistant is REAL (glm via z-ai-web-dev-sdk, server-only) and fully data-grounded: deterministic tools + sandboxed planner merge; model only interprets, never prices. Demo-data disclaimers enforced in persona + UI.
- Honest limits: no write-actions from chat (wishlist edits stay in UI — documented as roadmap), rate limiter is in-memory (per-instance), provider 429s under 21-parallel burst surface graceful SSE errors.

---
Task ID: 4
Agent: main (Z.ai)
Task: Brand refresh — new scorpion logo, official brand slogan strip, copywriting polish, modern design upgrades.

Work Log:
- Logo redesign: iterated 4 visual rounds (top-view -> side-view -> hook-tail -> final) via throwaway HTML harnesses + agent-browser screenshots; AI-generated candidates (3x) rejected as mascot-like. Final mark: dark gradient tile + thin orange gradient border + radial glow + geometric scorpion (open pac-man pincers, filled taper hook tail with teardrop stinger, capsule body, 4 legs). Updated src/components/scorent/logo.tsx (same API), src/app/icon.svg, public/logo.svg — all 7 consumer files update automatically.
- Brand slogan system: BRAND_SLOGAN «کشف کن، تجربه کن، بازی کن» + RENT_SLOGAN «قبل از خرید، تجربه‌اش کن!» exported from logo.tsx.
- New BrandStrip at very top of sticky navbar (gradient strip, diamond separators, slogan, demo-note on lg). Updated navbar mobile-sheet footer, metadata title/description/OG (layout.tsx), footer (new mark + slogan + polished description + rent chip + hairline-brand gradient border + mark in copyright line), settings.tsx about text, ai.tsx questionnaire H1 (gradient span), ai-chat.tsx welcome copy.
- Copywriting polish (home.tsx): hero badge/sub, watermark replaced with new scorpion silhouette (fills+strokes at 5% opacity), featured/AI/deals/discovery/rent/rewards/community section headers + descriptions rewritten in consistent semi-informal Persian; AI capability cards fixed (spacing typo, tone).
- Design upgrades (globals.css): .brand-strip gradient, .slogan-diamond, .hairline-brand, .aurora-orb; aurora orb behind hero collage.
- QA: route sweep (16 routes incl. 404) 0 page errors; screenshots desktop 1440 + mobile 390 (home, menu sheet, footer, AI chat, 404); title verified.
- Gates: lint 0 errors (1 pre-existing warning), tsc src/ 0 errors, vitest 45/45.

Stage Summary:
- Scorent now has a coherent premium identity: modern dark scorpion mark everywhere (navbar/favicon/footer/AI/404), official slogan displayed as brand strip on top of every page, and consistent polished Persian copy. No data/logic touched; all 45 tests pass.
---
Task ID: 5-a
Agent: general-purpose (store page i18n)
Task: Convert store.tsx to bilingual fa/en

Work Log:
- Read I18N_GUIDE.md, home.tsx (canonical), i18n.ts/en-map.ts/dict-core.ts; confirmed dict-store.ts already wired into dict.ts aggregator.
- Converted src/components/pages/store.tsx: added useT/useFmt/useTx/useUiDir at component top; every Persian UI literal → t("store.*") keys (heading, desc {n}, search placeholder/aria, genre/mode/sort labels + "all" items, max-price + no-cap, min-rating + "All", clear-filter buttons, result count {n} + "for «q»" fragment, URL-share note, empty-state title/desc/action, AI questionnaire prompt 3-part).
- Genre/mode option values (data-layer vocab: ALL_GENRES/ALL_MODES) wrapped with tx() — EN translations come from existing EN_MAP; SelectValue inherits translated text automatically.
- SORTS module array: Persian labels replaced with dict `key` fields (per guide rule 9), resolved at render via t(s.key); SortValue type + all filter/sort/URL-param logic, hasFilters, setParam, navigate, skeletons, hydration gating untouched.
- dir="rtl" on 3 Selects → dir={dir} (useUiDir); toFaDigits → f.num (×3), formatToman → f.toman; removed now-unused "@/lib/format" import.
- Wrote src/lib/i18n/dict-store.ts fragment: 31 keys, namespace "store.*", [fa verbatim, en natural]; en strings use {n}/{q} params, «…» kept in fa, “…” in en.

Stage Summary:
- Keys added (31, all "store.*"): heading, desc, searchPlaceholder, searchAria, genreAria, genreLabel, genreAll, modeAria, modeLabel, modeAll, sortAria, sortPopular, sortRating, sortPriceAsc, sortPriceDesc, sortDiscount, maxPrice, noCap, minRating, minRatingAria, ratingAll, clearFilters, clearAllFilters, count, countFor, filtersShared, emptyTitle, emptyDesc, aiPromptPre, aiQuizLink, aiPromptPost.
- Verification: npx tsc --noEmit | grep '^src/' → zero output (0 errors); npx eslint store.tsx + dict-store.ts → zero errors/warnings. No strings left untranslated (remaining Persian in file = code comments only, matching home.tsx convention). No logic/layout/class changes.
---
Task ID: 5-d
Agent: general-purpose (share i18n)
Task: Convert share.tsx to bilingual fa/en

Work Log:
- Read I18N_GUIDE.md, home.tsx (canonical), i18n.ts/en-map.ts/dict-core.ts; confirmed dict.ts already aggregates dict-share.ts.
- Converted src/components/pages/share.tsx: all UI literals → t("share.*"); store error reasons → tx(res.reason) with t() fallbacks (share.editErr / share.rentErr); seed listing descriptions → tx(listing.description); achievement name in create-toast → tx("کارآفرین") (en-map) + xp param f.num(25).
- Zod: module-level listingSchema → makeListingSchema(t, f) factory; schema built via useMemo in ListingFormDialog; type derived as z.infer<ReturnType<typeof makeListingSchema>>; all validation messages are dict keys, numeric thresholds passed as params (f.num for counts, f.toman(v,false) for price bounds). Validation rules/thresholds unchanged (2/24 chars, 10k–5M int, 10/300 chars, days union 1|3|7).
- Format migration: toFaDigits → f.num, formatToman → f.toman, formatDateTimeFa → f.dateTime; removed "@/lib/format" import. Integer toman math and 10% commission (commissionOf/ownerEarningsOf) untouched; commission preview + page math note now use t() with f.toman params computed from the same pricing engine (200k → 20k/180k identical output).
- DAY_OPTIONS → labelKey fields resolved at render (share.day1/3/7); dir="rtl" on DialogContent/Select/AlertDialogContent → dir={useUiDir()}; removed textAlign:"right" from the LTR game-title <p> (kept dir="ltr").
- Cross-checked: 74 share.* keys defined in dict-share.ts ↔ 74 referenced in share.tsx (0 missing, 0 unused).

Stage Summary:
- Keys added: 74 in dict-share.ts (share.* namespace only): page header/stats (5), toolbar (4), my-listings (4), market/empty-state (6), math note (1), listing dialog incl. day options & commission preview (23), zod validation messages (9), toasts (8), listing card incl. delete confirm (14).
- Verification: npx tsc --noEmit | grep '^src/' → clean; eslint share.tsx + dict-share.ts → 0 errors, 1 warning (react-hooks/incompatible-library on watch() — pre-existing, byte-identical usage confirmed on HEAD version); vitest 45/45 pass; zero Persian UI literals left in JSX (comments + tx("کارآفرین") data-layer string only).
---
Task ID: 5-c
Agent: general-purpose (rent+rentals i18n)
Task: Convert rent.tsx and rentals.tsx to bilingual fa/en

Work Log:
- Read I18N_GUIDE.md, worklog context, canonical home.tsx; confirmed infrastructure (useT/useTx/useFmt/useUiDir, dict fragment already wired into dict.ts, en-map covers all store renewal reasons incl. cooldown).
- dict-rent.ts: filled fragment with 15 "rent.*" + 22 "rentals.*" keys ([fa verbatim, natural EN]; {n}/{game}/{start}/{end}/{source}/{price}/{when}/{xp} params; «…»→“…”; Latin digits in EN).
- rent.tsx: h1/desc, 3 info chips (array switched from `t` field to `k` key-resolved per guide rule 9 — no translator shadowing), «اجاره‌های من» button, catalog SectionHeader + "{n} عنوان آماده اجاره" count (cn() join replaced by t() param, cn import dropped), RentCard: genre chips → tx(), active-rental chip, day cells {n} روز + f.toman(…, false), RentDialog triggerLabel, details link (←→ per direction in EN), EmptyState, DemoNotice; card title dir="ltr" textAlign right→start; toFaDigits/formatToman imports removed.
- rentals.tsx: header badge/h1/desc, stat tiles (f.num/f.toman + «فعال»/«مجموع هزینه (نمایشی)»), active+history section aria/SectionHeaders, EmptyState + CTA, history empty note with {xp}=f.num(40), completed rows "{n} روز — {price}" + optional "پایان: {when}", status chips «فعال»/«تمام‌شده», source line ({srcShare}|{srcStore} — {n} روزه), date range "شروع/پایان" via f.dateTime, remaining label + f.remaining(ms) live countdown, RenewDialog: title {game}, active/expired descriptions, day options, cancel/confirm, success toast {n} روزه + error toast tx(res.reason ?? t("rentals.renewErr")); DialogContent dir="rtl"→dir={dir}; LTR titles textAlign right→start; format imports removed; hooks placed before early returns (React rules).
- Verification: npx tsc --noEmit → 0 errors in src/; eslint on both files → clean. Browser QA (agent-browser): #/rent & #/rentals in fa AND en (fresh document loads via storage preset) → 0 page errors; EN strings verified via a11y snapshot (headings, chips, empty state, renewal rule, dates "Start: … — End: …", "store rental — 3-day rental", "Time remaining", Renew dialog, EN success toast "3-day renewal completed (demo)"); renewal actually extended expiry (11-day remaining in fa countdown); fa output byte-identical to original literals.

Stage Summary:
- Keys added: 37 in src/lib/i18n/dict-rent.ts — rent.*: pageTitle, pageDesc, chipTimestamp, chipRenew, chipP2p, myRentals, catalogTitle, catalogCount, emptyTitle, emptyDesc, demoNotice, startRent, detailsLink, activeRentalChip, dayCount (15). rentals.*: myRentals, pageTitle, pageDesc, statusActive, totalSpent, kickerOngoing, activeTitle, emptyTitle, emptyDesc, goCatalog, remainingLabel, dates, srcShare, srcStore, sourceLine, dayCount, renew, renewTitle, renewActiveDesc, renewExpiredDesc, cancel, confirmRenew, renewOk, renewErr, historyAria, kickerArchive, historyTitle, historyEmpty, completedRow, endedAt, statusCompleted, renewalRule (22).
- Gates: tsc 0 errors, eslint 0 errors, browser sweep fa/en 0 page errors.
- Flag for infra owner (pre-existing, NOT from this task, not fixed per read-only constraint): "commerce.startRent" is referenced by src/components/scorent/commerce.tsx (RentDialog confirm button) but missing from every dict fragment → renders the raw key in BOTH locales on every RentDialog (home + rent pages). Needs a dict-core.ts entry.
---
Task ID: 5-f
Agent: general-purpose (profile/wishlist/404 i18n)
Task: Convert profile, wishlist, not-found pages to bilingual fa/en

Work Log:
- Read I18N_GUIDE + home.tsx canonical pattern + i18n.ts/en-map/dict-core; confirmed ActivityEvent key/p shape and displayName «گیمر مهمان» fallback in en-map.
- profile.tsx: all UI literals → t("profile.*"); activity log renders `a.key ? t(a.key, a.p ?? {}) : tx(a.text)` (legacy fa-only entries fall back to tx); review texts → tx(r.text); displayName → tx(); level chip title → tx(level.title) with param; «هویت گیمری» in edit dialog desc → tx(); dates → f.dateTime(); all numbers → f.num(); formatTomanLite → locale-aware t("profile.hezarToman", {n: f.num(round(price/1000))}); zod validation messages switched to dict keys translated at render (validation logic unchanged); dir="rtl" on DialogContent + Tabs → dir={dir}; game-title <p>s dir="ltr" textAlign right→start (per guide rule 7); removed format imports, added i18n hooks before the !hydrated early-return (hook order preserved).
- wishlist.tsx: badge/title/desc/empty-state/buttons/toast → t("wishlist.*"); count desc uses {n} + f.num; removed toFaDigits import.
- not-found.tsx: ۴۰۴ → f.num(404); h1, attempted-address sentence (pre/hash-span/post split to keep the dir="ltr" #route span), plain fallback, buttons → t("notFound.*"); «کشف ۲۸ بازی» → {n} + f.num(28); removed toFaDigits import.
- dict-profile.ts: filled fragment with 68 keys [fa verbatim, natural en] across profile.*, wishlist.*, notFound.*; no other files touched.

Stage Summary:
- 68 dict keys added (52 profile.*, 9 wishlist.*, 6 notFound.* — incl. 3 zod-message keys); all 68 verified used, 0 missing, 0 unused (script cross-check).
- Gates: npx tsc --noEmit → 0 errors under src/ (only pre-existing examples//skills/ noise outside src); eslint on the 3 files → 0 errors, 0 warnings.
- Data/logic/layout untouched; activity/XP/achievement/data-layer strings via tx() reuse en-map; nothing left untranslated in the three pages.
---
Task ID: 5-b
Agent: general-purpose (game-detail i18n)
Task: Convert game-detail.tsx to bilingual fa/en

Work Log:
- Read I18N_GUIDE.md, home.tsx (canonical), i18n.ts/en-map.ts/dict-core.ts, commerce.tsx/shared.tsx (already i18n-ready), types/store/format/community data.
- Converted src/components/pages/game-detail.tsx: all UI literals → t("game.*"); genre/mode chips + review texts → tx(); tagline/description/highlights → active-language catalog text; toFaDigits/formatToman/formatRatingFa/formatMinutesFa/formatHoursFa/formatDateFa → f.num/f.toman/f.rating/f.minutes/f.hours/f.date; removed "@/lib/format" import; dir="ltr" textAlign:right → textAlign:start (rule 7); dynamic values into {n}/{c}/{p}/{save}/{price}/{id}/{name} params.
- Hooks-order safety: page has an early return for "game not found" and the router renders the same component instance for all /game/:id routes, so ALL hooks stay above the return. Since useGameText(game) requires a non-null Game, added local null-safe useGameTextSafe (wraps exported gameTextOf + useLang, identical output) — documented in code comment.
- game.trial.note is a data-layer string NOT present in en-map (read-only): added module-level TRIAL_NOTE_KEYS mapping the 8 exact Persian notes → new game.trialNote* keys, resolved via useTrialNote() with tx() fallback for unknown notes.
- Reused existing core keys where exact ("nav.store" for breadcrumb/related action); everything else new in dict-game.ts.
- Kept ALL logic identical (relatedGames, forms, votes, toasts, motion, classNames); usernames/display names intentionally untranslated.
- Verification: npx tsc --noEmit → 0 src errors; eslint on both files → clean; vitest 45/45; agent-browser QA: #/game/elden-ring in fa + en (hero, meta grid, prices, discount note, trial note, highlights, reviews, related), review posted in EN (rating avg line, "Your review" badge, f.date, tx pass-through of user text), helpful vote (+20 XP), same-instance navigation hades→bogus-id renders not-found without hook errors, rocket-league "No classic campaign" + free-to-play note, #/game/nonexistent-id EN empty state. Restored default fa locale afterwards.

Stage Summary:
- 65 keys added to src/lib/i18n/dict-game.ts (namespace "game.*", zero edits outside assigned files). Notable: 8 game.trialNote* keys for data-layer demo notes (en-map lacks them); game.avgRating EN uses "{c} review(s)" per dict-core pluralization convention.
- tsc strict: 0 errors in src/; eslint: 0 errors/warnings in game-detail.tsx + dict-game.ts; tests 45/45; browser sweep of the page in both locales: 0 page errors.
- Out-of-scope observation for the owner of shared components: GameCover's internal aria-label («کاور {title}») still shows Persian in EN mode (game-cover.tsx — not in my assignment).
---
Task ID: 5-e
Agent: general-purpose (discovery/deals/trial/rewards i18n)
Task: Convert discovery, deals, trial, rewards pages to bilingual fa/en

Work Log:
- Read I18N_GUIDE.md, canonical home.tsx, i18n.ts/en-map.ts/catalog-en.ts API and assigned pages; scoped all Persian UI literals, data-layer strings and Persian-digit literals in the 4 pages.
- Filled dict-discovery.ts fragment with ~90 keys in namespaces discovery.* / deals.* / trial.* / rewards.* ([fa, en] tuples, params via {name}); Persian [0] copied verbatim from source; Game.trial.note strings added as exact-string (self-keyed) dict entries so t(g.trial.note) returns verbatim fa in Persian and EN translation in English (en-map untouched, per assignment).
- discovery.tsx: TABS → {id,labelKey,descKey} resolved with t() at render (store.tsx pattern); REASONS → {key, p?} record (digits in cuphead/slay-the-spire reasons moved to {n}/{m} params fed via f.num); reasonFor keeps default fallback + dead "tunic-game" entry; extracted GemCard subcomponent (hooks-safe) using useGameText().tagline + t("discovery.gemMeta") param line; header/tabs/aria/empty-states/section-header/button strings → t(); toFaDigits removed; dir="ltr" titles keep dir, textAlign:right style removed per rule 7.
- deals.tsx: extracted HeroDeal subcomponent (hooks-safe useGameText for hero description); all header/empty/section/button strings → t(); formatToman→f.toman, toFaDigits→f.num; big-deal badge "٪−" fa order preserved via deals.bigBadge param key; savings strings parametrized; DEMO_DATA_NOTE → tx(); PriceTag import untouched (pre-existing).
- trial.tsx: KIND_META → {labelKey, cls, icon} resolved via t(); header/explainer cards/section headers/empty state/buttons/transparency note → t(); withTrial count param via f.num; trial notes → t(g.trial.note) self-keyed dict entries (all 3 data strings verified char-exact); dir="ltr" title style cleanup.
- rewards.tsx: hooks (useT/useFmt/useTx) added before !hydrated early-return; level number/XP/dates → f.num/f.dateTime; level.title & LEVEL_TITLES titles → tx(); achievement/challenge title+description → tx(); XP event labels → tx(e.label); "۷۵٪" digit-order preserved via rewards.progressPct param key; XP-curve formula split into formulaPre/formula/formulaPost keys (fa digits verbatim, EN latin); challengesDesc/emptyDesc digit literals → f.num params; all aria-labels, section headers, badges ("تکمیل شد ✓", "+{n} XP"), progress "{a} از {b}" and pending-grant note → t().
- Verification: npx tsc --noEmit → 0 errors in src/; npx eslint on the 4 files → clean; agent-browser sweep of #/discovery (all 4 tabs incl. gems/foryou empty paths), #/deals, #/trial, #/rewards in BOTH fa and en → 0 page errors, EN shows translated copy + catalog-en taglines/descriptions + en-map achievement/challenge/level strings, fa output byte-identical to pre-conversion rendering.

Stage Summary:
- dict-discovery.ts: 4 namespaces (discovery.* 28 keys, deals.* 13, trial.* 21, rewards.* 25) + 3 self-keyed Game.trial.note entries; no keys outside assigned namespaces; dict.ts/en-map.ts/i18n.ts/catalog-en.ts untouched.
- Gates: tsc src/ 0 errors; eslint 4 files 0 errors/warnings; runtime fa/en sweep 0 page errors; no strings left untranslated on these pages (Persian visible only in code comments, GameCover procedural art text — shared component outside assignment — and untranslated-by-design game titles/usernames).
---
Task ID: 5
Agent: main (Z.ai)
Task: Bottom navigation (all screens) + dark/light theme toggle + full fa/en bilingual site.

Work Log:
- i18n architecture: src/lib/i18n-core.ts (pure, server-safe: makeT, txStatic, joinAnd, makeFmt, gameTextOf, UI_BOOT_SCRIPT) + src/lib/i18n.ts (client: useUi zustand store for locale+theme persisted in scorent-ui:v1, hooks useT/useTx/useFmt/useLang/useTheme/useUiDir/useGameText). "use client" split fixed server crash: /api/chat called txStatic via recommendation -> moved pure layer out of client module.
- Dictionary: dict.ts aggregator over fragments dict-core (shell/commerce/home), dict-store, dict-game, dict-rent, dict-share, dict-discovery, dict-profile, dict-settings, dict-ai — ~600 keys [fa, en] tuples, {param} interpolation.
- Theme: html.light token overrides in globals.css (+light variants for brand-strip/hairline/aurora/bg-grid/card-hover/skeleton/glows/text-gradient/scrollbars/selection), @custom-variant light; pre-paint boot script in layout head (no FOUC, suppressHydrationWarning on <html>); UiEffects client component wires Radix DirectionProvider + sonner Toaster dir + document.title + meta theme-color dynamically.
- Bottom nav for ALL screens: BottomTabBar = mobile full-width 5-tab bar (active pill layoutId) + desktop floating centered dock with 7 entries (home/store/ai/ai-chat/rent/deals/profile); footer padding adjusted (pb-28 lg:pb-32).
- Toggles: ThemeToggle (sun/moon animated) + LangToggle (EN/فا) in desktop navbar, mobile sheet footer, plus full pickers with preview swatches on settings page.
- Language switch: dir flips rtl<->ltr on <html>, Radix DirectionProvider, sheets/dialogs/dropdowns use useUiDir; digits via useFmt (Persian/Latin), dates Gregorian en-GB vs Persian calendar; EN_MAP render-time translation of data-layer strings (genres, playstyles, structures, modes, session buckets, achievements, challenges, level titles, store reasons, XP labels, seed listings/reviews/activity, notes); catalog-en.ts translates tagline/description/highlights of all 28 games (useGameText; covers localized too).
- Pages converted: home (hand-converted), store, game-detail, rent, rentals, share (zod schema as function of t), discovery, deals, trial, rewards, profile (activity items render via new key/p fields), wishlist, not-found, settings (new theme+lang sections), ai (questionnaire lang-aware rankGames), ai-chat, ai-chat-view (suggested prompts localized; sent in UI language) — 6 parallel subagents with I18N_GUIDE.md, disjoint dict fragments.
- Libs: recommendation.ts scoreGame/rankGames/spendLabel accept lang (bilingual matched/tradeoffs); store.ts flash items carry xp/label/title for translated toasts; ActivityEvent.key/p for multilingual activity log (legacy falls back to tx).
- AI: /api/chat accepts uiLang; languageHint uses message language first, UI language for no-letter messages; verified grounded EN answer (Slay the Spire 357,500 / Hades 560,000-30% rentals 60/140/225K = exact dataset values).
- Fixed during QA: missing commerce.startRent key, game-cover aria + tagline localization, settings.enSub swap, AnimatedNumber reduced-motion setState-in-effect lint error.
- Gates: tsc src/ 0 errors; eslint 0 errors (1 pre-existing RHF warning); vitest 45/45; next build OK; agent-browser sweep 16 routes x fa/en = 0 page errors; screenshots: home/store/game/ai-chat/settings/mobile in dark-light x fa-en; theme+lang persistence verified across reload.

Stage Summary:
- Scorent is now fully bilingual (fa RTL default / en LTR) with one-tap language and theme switches (navbar + mobile sheet + settings), an app-style bottom navigation on every screen (mobile tab bar + desktop floating dock), and locale-aware numbers/dates/catalog text. All prior functionality preserved; data layer unchanged (Persian source-of-truth, translated at render). Preview: dev server on :3000 behind Caddy (live), production build passes.

---
Task ID: 6
Agent: main (Z.ai)
Task: ساخت اکانت واقعی (Sign up/Sign in با ایمیل و موبایل + Google)، اطلاع‌رسانی ایمیل/پیامک رویدادها و پنل مدیریت کامل با سطوح دسترسی

Work Log:
- Prisma schema (10 مدل): User(email/phone/passwordHash/googleId/role/status/verified/optIn/lang)، Session(قابل ابطال)، Token(OTP هش‌شده)، Notification(صندوق خروجی)، Announcement، SupportTicket/TicketMessage، SiteContent(key/valueFa/valueEn)، GameOverride(JSON جزئی). db push + generate.
- لایه سرور: password.ts (scrypt + passwordStrength مشترک)، session.ts (توکن HMAC-SHA256 در کوکی httpOnly + رکورد Session + AUTH_SECRET از env/فایل db/.auth-secret)، rate-limit.ts (پنجره لغزان per-IP)، http.ts (اعتبارسنجی + normalizePhone ایران + sameOrigin ضد CSRF)، guard.ts (ماتریس دسترسی مشترک با lib/permissions.ts)، notify.ts (آداپتور SMTP/nodemailer + Kavenegar/webhook + حالت SIMULATED صادقانه + قالب ایمیل برندشده دوزبانه)، seed.ts (ادمین ارشد پیش‌فرض admin@scorent.ir/Scorent@2026! + محتوای پیش‌فرض).
- API auth (12 مسیر): register/login/logout/me/verify/resend/password/forgot/reset/preferences + google (OAuth کد واقعی؛ بدون اعتبارنامه → حساب نمایشی با برچسب) + google/callback.
- API ادمین catch-all [...path]: stats/users/admins/announcements/notifications+retry/content/overrides/tickets+reply/providers با گارد requirePerm در هر دستور؛ محافظت از SUPER_ADMIN، ممنوعیت خودتخریبی.
- API عمومی: /api/content (merged با پیش‌فرض)، /api/overrides، /api/support/tickets (مهمان + کاربر) و [id] (مشاهده/پاسخ/بستن توسط صاحب تیکت).
- کلاینت: lib/auth.ts (zustand + apiFetch + نقشه خطاها)، صفحه /auth (ورود/ثبت‌نام/OTP با InputOTP/بازیابی رمز/Google دوزبانه + strength meter)، avatar-menu دوارژن (مهمان: دکمه ورود؛ کاربر: نشان نقش/تأیید/پنل مدیریت/خروج)، /support (ثبت تیکت مهمان/کاربر + پیگیری زنده)، AccountCard در profile (تغییر رمز، optIn ایمیل/پیامک، زبان پیام‌ها)، بنر اعلان سراسری کنترل‌شده از پنل.
- پنل /admin (9 زبانه): داشبورد (آمار واقعی)، کاربران (جستجو/فیلتر/تعلیق/تأیید/تغییر نقش/حذف)، مدیران و دسترسی‌ها (افزودن مدیر، تغییر نقش، سلب دسترسی، ماتریس مجوز)، محتوای سایت (ویرایش fa/en + انتشار فوری)، بازی‌ها (اورراید hidden/featured/discount/متن)، اعلان رویداد (دوزبانه، مخاطب، کانال‌ها، تاریخچه)، صندوق خروجی (فیلتر + retry)، تیکت‌ها (پاسخ + اطلاع‌رسانی)، سرویس‌ها (وضعیت واقعی/نمایشی + راهنمای env).
- اورراید کاتالوگ: hydrate in-place روی آرایه GAMES (همه صفحات/سلکتورهای موجود خودکار پیروی می‌کنند) + useCatalogReady در AppShell؛ gameTextOf اولویت متن اورراید EN؛ سلکتورهای games.ts پارامتری.
- اتصال هیرو/شعار به SiteContent با fallback دیکشنری؛ HeroTitle بازنویسی (کلمه آخر گرادیانی).
- i18n: dict-auth (75 کلید)، dict-support (45)، dict-admin (110) + اتصال به dict.ts — همه دوزبانه.
- رفع باگ: AnimatedNumber fallback برای لود اولیه بدون اسکرول (IO گاهی آتش نمی‌زد)؛ react-hooks/set-state-in-effect با setTimeout(0)/microtask در 8 افکت.
- QA: curl ایزوله register→OTP→verify→admin→announcement→ticket→reply→outbox→content→override→google-demo ✓؛ مرورگر: auth fa/en، ثبت‌نام→کد نمایشی→تأیید، گارد ادمین (403 کاربر)، داشبورد/کاربران/اعلان/محتوا/سرویس‌ها، ویرایش زنده hero و بازگردانی، EN+light، guest ticket، پیمایش خطا 0.
- گیت‌ها: tsc 0 خطا؛ eslint 0 خطا (1 هشدار قدیمی RHF)؛ vitest 60/60 (15 تست جدید: scrypt/session-HMAC/permissions/normalizePhone)؛ next build موفق (همه مسیرها ثبت).

Stage Summary:
- سیستم اکانت واقعی و امن (scrypt+HMAC+httpOnly cookie+rate limit+RBAC server-side) با ورود ایمیل/موبایل/گوگل واقعی و حالت نمایشی صادقانه گوگل.
- اطلاع‌رسانی همزمان ایمیل+پیامک: خوش‌آمد، کد تأیید، پاسخ تیکت، اعلان رویداد از پنل — با صندوق خروجی و وضعیت واقعی هر پیام (SENT/SIMULATED/FAILED+retry). بدون اعتبارنامه env همه با برچسب «شبیه‌سازی‌شده» ثبت می‌شوند.
- پنل مدیریت کامل: محتوا (CMS زنده هیرو/بنر/شعار)، بازی‌ها (اورراید)، کاربران/مدیران و 4 سطح دسترسی (SUPER_ADMIN/ADMIN/CONTENT_EDITOR/SUPPORT_AGENT با ماتریس)، تیکت پشتیبانی، آمار واقعی، وضعیت سرویس‌ها.
- اعتبارنامه پیش‌فرض: admin@scorent.ir / Scorent@2026! (قابل override با ADMIN_EMAIL/ADMIN_PASSWORD).

---
Task ID: 9
Agent: main (Z.ai)
Task: رفع مشکل «Continue with Google» (خطای پروتکل امنیتی گوگل در محیط تعبیه‌شده) + تأیید دسترسی داشبورد ادمین.

Work Log:
- علت ریشه‌ای: گوگل جریان OAuth داخل iframe/وب‌ویو تعبیه‌شده را مسدود می‌کند (صفحه‌ی «پیروی از پروتکل امنیتی») و GOOGLE_CLIENT_ID/SECRET نیز تنظیم نشده است؛ کوکی نشست SameSite=Lax در فریم تعبیه‌شده پایدار نمی‌ماند.
- /api/auth/google: حالت probe (?mode=probe → JSON وضعیت پیکربندی) + گارد Sec-Fetch-Dest iframe/frame/embed/object → وقتی OAuth واقعی تنظیم شده و درخواست از فریم باشد، به‌جای صفحه خطای گوگل به /#/auth?google=embedded برمی‌گردد؛ حالت نمایشی بدون اعتبارنامه در هر مکانی کار می‌کند.
- callback: عبور شفاف خطای گوگل (access_denied، redirect_uri_mismatch و…) به کلاینت با reason.
- کوکی نشست: sessionCookieAttrs واحد — در production: SameSite=None + Secure + Partitioned (CHIPS) برای سازگاری با پیش‌نمایش تعبیه‌شده؛ dev: Lax. همه‌ی مسیرها (login/register/google/callback/logout) به همین تابع متصل شد؛ باگ واحد exp (epoch در برابر مدت) اصلاح شد.
- کلاینت auth.tsx: دکمه‌ی گوگل هوشمند — بالای صفحه: پیمایش عادی؛ داخل فریم + حالت نمایشی: همان‌جا؛ داخل فریم + OAuth واقعی: تب جدید (window.open بدون opener) + refresh نشست در بازه‌ها + پیام راهنما؛ خطاها با reason مشخص دوزبانه.
- i18n: ۶ کلید جدید fa/en (googleEmbeddedToast/googleNewTabToast/googleDemoNote/googleReasonDenied/googleReasonConfig/googleReasonNotConfigured) + یادداشت صادقانه‌ی حالت نمایشی زیر دکمه.
- گیت‌ها: tsc خطای src=0؛ eslint فایل‌های تغییر یافته پاک؛ vitest 60/60؛ next build موفق.
- تست سرور: با اعتبارنامه موقت تستی — فریم → google=embedded ✓، top-level → ریدایرکت واقعی accounts.google.com ✓؛ بدون اعتبارنامه → probe configured:false و demo ✓؛ ورود ادمین 200 ✓؛ HOME 200 ✓.

Stage Summary:
- Continue with Google در هر سه محیط (بالای صفحه، iframe پیش‌نمایش، بدون اعتبارنامه) رفتار درست و صادقانه دارد؛ دیگر هرگز صفحه‌ی خطای امنیتی گوگل به کاربر نشان داده نمی‌شود.
- راه‌اندازی ورود واقعی گوگل: ساخت OAuth client در Google Cloud Console + ثبت Redirect URI «<دامنه>/api/auth/google/callback» + ست‌کردن GOOGLE_CLIENT_ID/SECRET و ری‌استارت.
- دسترسی ادمین تأیید شد: ورود با admin@scorent.ir / Scorent@2026! (پیش‌فرض seed؛ قابل override با ADMIN_EMAIL/ADMIN_PASSWORD) → منوی پروفایل → «پنل مدیریت» یا مسیر مستقیم /#/admin.
