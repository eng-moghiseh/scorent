/* POST /api/auth/preferences — به‌روزرسانی ترجیحات اطلاع‌رسانی و زبان */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, json, readJson, sameOrigin } from "@/lib/server/http";
import { userFromRequest } from "@/lib/server/session";
import { publicUser } from "@/lib/server/auth-helpers";

interface Body {
  emailOptIn?: boolean;
  smsOptIn?: boolean;
  lang?: string;
}

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  const auth = await userFromRequest(req);
  if (!auth) return json({ ok: false, error: "UNAUTHORIZED" }, 401);

  const body = await readJson<Body>(req);
  if (!body || typeof body !== "object") return json({ ok: false, error: "INVALID_INPUT" }, 400);

  const data: { emailOptIn?: boolean; smsOptIn?: boolean; lang?: "fa" | "en" } = {};
  if (typeof body.emailOptIn === "boolean") data.emailOptIn = body.emailOptIn;
  if (typeof body.smsOptIn === "boolean") data.smsOptIn = body.smsOptIn;
  if (body.lang === "fa" || body.lang === "en") data.lang = body.lang;
  if (Object.keys(data).length === 0) return json({ ok: false, error: "NOTHING_TO_UPDATE" }, 400);

  const updated = await db.user.update({ where: { id: auth.id }, data });
  return json({ ok: true, user: publicUser(updated) });
}
