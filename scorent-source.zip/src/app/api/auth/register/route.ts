/* POST /api/auth/register — ثبت‌نام با ایمیل یا شماره موبایل + رمز */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, cleanName, isEmail, isStrongPassword, json, normalizePhone, readJson, sameOrigin } from "@/lib/server/http";
import { hashPassword } from "@/lib/server/password";
import { createSession } from "@/lib/server/session";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";
import { ensureSeed } from "@/lib/server/seed";
import { audit } from "@/lib/server/audit";
import { issueOtp, publicUser, sendWelcome, setSessionCookie } from "@/lib/server/auth-helpers";

interface Body {
  name?: string;
  identifier?: string;
  password?: string;
  uiLang?: string;
}

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  await ensureSeed();

  const ip = clientIp(req);
  if (!(await rateLimit(`register:${ip}`, 6, 5 * 60_000))) {
    return json({ ok: false, error: "RATE_LIMITED" }, 429);
  }

  const body = await readJson<Body>(req);
  if (!body) return badRequest("BAD_JSON");

  const name = cleanName(body.name);
  if (!name) return json({ ok: false, error: "INVALID_NAME" }, 400);

  const identifier = typeof body.identifier === "string" ? body.identifier.trim() : "";
  if (!identifier) return json({ ok: false, error: "IDENTIFIER_REQUIRED" }, 400);

  const email = isEmail(identifier) ? identifier.toLowerCase() : null;
  const phone = !email ? normalizePhone(identifier) : null;
  if (!email && !phone) return json({ ok: false, error: "INVALID_IDENTIFIER" }, 400);

  if (!isStrongPassword(body.password)) {
    return json({ ok: false, error: "WEAK_PASSWORD" }, 400);
  }

  // جلوگیری از ثبت‌نام تکراری
  const clash = await db.user.findFirst({ where: { OR: [...(email ? [{ email }] : []), ...(phone ? [{ phone }] : [])] } });
  if (clash) {
    const which = clash.email === email ? "EMAIL_TAKEN" : "PHONE_TAKEN";
    return json({ ok: false, error: which }, 409);
  }

  const passwordHash = await hashPassword(body.password);
  const user = await db.user.create({
    data: {
      name,
      email,
      phone,
      passwordHash,
      lang: body.uiLang === "en" ? "en" : "fa",
      lastLoginAt: new Date(),
    },
  });

  // خوش‌آمد + کد تأیید (کد فقط در حالت نمایشی صادقانه در پاسخ می‌آید)
  await sendWelcome(user);
  const kind = email ? "EMAIL_VERIFY" : "PHONE_VERIFY";
  const otp = await issueOtp(user, kind);

  const { token, exp } = await createSession(user.id, { ip, userAgent: req.headers.get("user-agent") ?? undefined });
  const res = json({
    ok: true,
    user: publicUser(user),
    verify: { kind, simulated: otp.simulated, demoCode: otp.demoExposed ? otp.code : undefined },
  });
  audit("ACCOUNT_CREATED", { actorId: user.id, target: email ?? phone, ip });
  setSessionCookie(res, token, exp);
  return res;
}
