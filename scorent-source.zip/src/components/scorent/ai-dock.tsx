"use client";

/* ————— داک شناور دستیار — نقطه ورود فشرده در همه صفحات —————
 * دکمه گرد شناور + شیت گفتگوی فشرده که از همان استور چت استفاده می‌کند
 * (مکالمات بین داک و صفحه کامل مشترک‌اند). روی موبایل بالای تب‌بار می‌نشیند.
 */

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MessageCircle, Sparkles, X } from "lucide-react";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { ChatView, PromptGrid } from "@/components/scorent/ai-chat-view";
import { useChatStore } from "@/lib/ai/chat-store";
import { useT, useUiDir } from "@/lib/i18n";
import { useRoute } from "./router";
import { ScorentMark } from "./logo";

function DockHeader({ onClose }: { onClose: () => void }) {
  const t = useT();
  return (
    <div className="flex items-center gap-2.5 border-b border-border bg-surface/60 px-4 py-3">
      <span className="relative flex size-9 items-center justify-center rounded-2xl border border-ai/40 bg-ai/10">
        <ScorentMark size={24} />
        <span className="absolute -bottom-0.5 -end-0.5 size-3 rounded-full border-2 border-background bg-rent" aria-label={t("dock.online")} />
      </span>
      <div className="flex-1">
        <p className="text-sm font-extrabold leading-5">{t("dock.title")}</p>
        <p className="text-[0.62rem] text-muted-foreground">{t("dock.subtitle")}</p>
      </div>
      <button
        type="button"
        onClick={onClose}
        aria-label={t("dock.closeAria")}
        className="flex size-8 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
      >
        <X className="size-4.5" />
      </button>
    </div>
  );
}

export function AIDock() {
  const [open, setOpen] = useState(false);
  const streaming = useChatStore((s) => s.streaming);
  const messagesCount = useChatStore((s) => s.conversations.find((c) => c.id === s.activeId)?.messages.length ?? 0);
  const route = useRoute();
  const t = useT();
  const dir = useUiDir();

  /* با تغییر مسیر (مثلاً کلیک لینک بازی داخل پاسخ) شیت بسته شود تا صفحه دیده شود.
   * اشتراک به رویداد خارجی hashchange — setState در callback مجاز است. */
  useEffect(() => {
    const onHash = () => setOpen(false);
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  /* روی خود صفحه چت داک تکراری است */
  if (route.path === "/ai-chat") return null;

  return (
    <>
      {/* دکمه شناور */}
      <AnimatePresence>
        {!open ? (
          <motion.button
            key="dock-fab"
            type="button"
            initial={{ opacity: 0, scale: 0.7, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.7, y: 12 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            onClick={() => setOpen(true)}
            aria-label={t("dock.openAria")}
            className={cn(
              "fixed bottom-20 z-40 flex size-13 items-center justify-center rounded-2xl border border-ai/40 bg-card shadow-2xl shadow-black/50 transition-all hover:border-ai/70 hover:bg-ai/15 glow-ai lg:bottom-6",
              "end-4 lg:end-6"
            )}
          >
            {streaming ? (
              <motion.span
                className="absolute inset-0 rounded-2xl border-2 border-ai/60"
                animate={{ opacity: [0.9, 0.2, 0.9] }}
                transition={{ duration: 1.4, repeat: Infinity }}
              />
            ) : null}
            <span className="relative flex flex-col items-center">
              <MessageCircle className="size-5.5 text-ai" />
              <Sparkles className="absolute -end-2.5 -top-2 size-3 text-ai" />
              {messagesCount > 0 ? (
                <span className="absolute -top-1.5 -start-2.5 flex size-4 items-center justify-center rounded-full bg-ai px-1 text-[0.55rem] font-extrabold text-white tnum">
                  {messagesCount}
                </span>
              ) : null}
            </span>
          </motion.button>
        ) : null}
      </AnimatePresence>

      {/* شیت گفتگوی فشرده */}
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent
          side="left"
          className={cn(
            "flex w-full flex-col gap-0 border-border bg-background p-0 sm:max-w-md",
            "h-[100dvh] rounded-none sm:h-[100dvh]"
          )}
          dir={dir}
        >
          <SheetTitle className="sr-only">{t("dock.sheetTitle")}</SheetTitle>
          <DockHeader onClose={() => setOpen(false)} />
          <ChatView
            compact
            emptyState={
              <div className="pt-1">
                <p className="mb-3 text-center text-xs leading-6 text-muted-foreground">{t("dock.empty")}</p>
                <PromptGrid compact onPick={() => undefined} />
              </div>
            }
          />
        </SheetContent>
      </Sheet>
    </>
  );
}
