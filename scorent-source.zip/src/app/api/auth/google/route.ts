/* GET /api/auth/google — شروع ورود با گوگل
 * با اعتبارنامه‌ی واقعی (GOOGLE_CLIENT_ID/SECRET) → ریدایرکت به صفحه رضایت گوگل.
 * بدون اعتبارنامه → حالت نمایشی صادقانه: ساخت/ورود حساب نمایشی با برچسب واضح.
 *
 * نکته‌ی مهم: گوگل جریان OAuth داخل iframe/وب‌ویو تعبیه‌شده را مسدود می‌کند
 * («این سایت از پروتکل امنیتی ما پیروی نمی‌کند»). بنابراین:
 *  - ?mode=probe → JSON وضعیت پیکربندی برای کلاینت (تصمیم هوشمند دکمه).
 *  - اگر درخواست از داخل frame باشد و OAuth واقعی تنظیم شده باشد، به‌جای ارسال
 *    کاربر به صفحه‌ی خطای گوگل، با کد google=embedded برمی‌گردیم تا کلاینت
 *    جریان را در «تب جدید» باز کند.
 */

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { db } from "@/lib/db";
import { baseUrl } from "@/lib/server/auth-helpers";
import { ensureSeed } from "@/lib/server/seed";
import { googleConfigured } from "@/lib/server/notify";
import { createSession } from "@/lib/server/session";
import { sessionCookieAttrs } from "@/lib/server/session";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";

const DEMO_EMAIL = "demo.google@scorent.demo";
const OAUTH_STATE = "scorent_oauth_state";

/** آیا درخواست از داخل iframe / فریم تعبیه‌شده آمده است؟ */
function isFramed(req: NextRequest): boolean {
  const dest = req.headers.get("sec-fetch-dest");
  return dest === "iframe" || dest === "frame" || dest === "embed" || dest === "object";
}

export async function GET(req: NextRequest) {
  const base = baseUrl(req);
  const uiLang = req.nextUrl.searchParams.get("lang") === "en" ? "en" : "fa";

  /* حالت probe: کلاینت بدون ریدایرکت، وضعیت را می‌پرسد */
  if (req.nextUrl.searchParams.get("mode") === "probe") {
    if (!(await rateLimit(`google-probe:${clientIp(req)}`, 60, 5 * 60_000))) {
      return NextResponse.json({ ok: false, error: "RATE" }, { status: 429 });
    }
    return NextResponse.json(
      { ok: true, configured: googleConfigured(), embeddedHint: isFramed(req) },
      { headers: { "cache-control": "no-store" } }
    );
  }

  if (!(await rateLimit(`google:${clientIp(req)}`, 10, 5 * 60_000))) {
    return NextResponse.redirect(`${base}/#/auth?google=rate`);
  }
  await ensureSeed();

  if (googleConfigured()) {
    /* گوگل فریم‌های تعبیه‌شده را مسدود می‌کند — کاربر را به خطای گوگل نفرستیم */
    if (isFramed(req)) {
      return NextResponse.redirect(`${base}/#/auth?google=embedded&lang=${uiLang}`);
    }
    const state = randomBytes(16).toString("hex");
    const redirectUri = `${base}/api/auth/google/callback`;
    const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
    url.searchParams.set("client_id", process.env.GOOGLE_CLIENT_ID!);
    url.searchParams.set("redirect_uri", redirectUri);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("scope", "openid email profile");
    url.searchParams.set("state", state);
    url.searchParams.set("prompt", "select_account");
    const res = NextResponse.redirect(url.toString());
    res.cookies.set({ name: OAUTH_STATE, value: state, httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 600 });
    return res;
  }

  // ————— حالت نمایشی — حساب نمایشی با برچسب واضح —————
  const demo = await db.user.findUnique({ where: { email: DEMO_EMAIL } });
  const user =
    demo ??
    (await db.user.create({
      data: {
        name: uiLang === "en" ? "Google Demo User" : "کاربر نمایشی گوگل",
        email: DEMO_EMAIL,
        googleId: "demo-google-account",
        emailVerified: true,
        lang: uiLang,
      },
    }));
  if (user.status === "SUSPENDED") return NextResponse.redirect(`${base}/#/auth?google=suspended`);

  const { token, exp } = await createSession(user.id, { ip: clientIp(req), userAgent: req.headers.get("user-agent") ?? undefined });
  const res = NextResponse.redirect(`${base}/#/auth?google=demo`);
  res.cookies.set({ ...sessionCookieAttrs((exp - Date.now()) || 1), value: token });
  return res;
}
