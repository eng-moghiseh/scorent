/* GET /api/overrides — اورراید بازی‌ها (عمومی؛ کلاینت روی دیتاست اعمال می‌کند) */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const rows = await db.gameOverride.findMany();
    const overrides = Object.fromEntries(rows.map((r) => [r.gameId, JSON.parse(r.data) as Record<string, unknown>]));
    const res = NextResponse.json({ ok: true, overrides });
    res.headers.set("Cache-Control", "public, max-age=30, stale-while-revalidate=120");
    return res;
  } catch {
    const res = NextResponse.json({ ok: true, overrides: {} });
    res.headers.set("Cache-Control", "no-store");
    return res;
  }
}
