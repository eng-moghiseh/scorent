import { GAMES } from "/home/z/my-project/src/lib/data/games.ts";
import { rankGames } from "/home/z/my-project/src/lib/recommendation.ts";
const res = rankGames(GAMES, { genres: [], playstyle: "آرام و دلنشین", structure: null, mode: null, sessionBucket: null, budgetToman: 500000, intent: "buy" }, { limit: 4 });
for (const r of res) console.log(r.game.title, "|", r.percentage + "%", "|", r.game.price, "|", r.game.discountPercent, "| final:", r.game.price);
