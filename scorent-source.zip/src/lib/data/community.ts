import type { Game, Review } from "../types";
import { GAMES } from "./games";

/* ————— دستاوردها (Achievements) —————
 * هر دستاورد یک شناسه یکتا دارد و فقط یک‌بار باز می‌شود (idempotent).
 * bonusXp به‌عنوان رویداد XP با شناسه achievement:{id} ثبت می‌شود.
 */

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  icon: string; // نام آیکون در lucide-react
  bonusXp: number;
  /** برای دستاوردهای سطحی */
  minLevel?: number;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: "profile-complete", title: "هویت گیمری", description: "نام کاربری و آواتارت را در پروفایل کامل کن", icon: "UserRound", bonusXp: 25 },
  { id: "first-purchase", title: "اولین خرید", description: "اولین خرید نمایشی خود را انجام بده", icon: "ShoppingBag", bonusXp: 25 },
  { id: "collector-3", title: "کلکسیونر", description: "۳ بازی را در کتابخانه‌ات داشته باش", icon: "Library", bonusXp: 30 },
  { id: "first-rental", title: "مستأجر تازه‌کار", description: "اولین اجاره‌ات را شروع کن", icon: "KeyRound", bonusXp: 20 },
  { id: "rental-7d", title: "هفت‌روزه‌نشین", description: "یک اجاره ۷ روزه را کامل کن", icon: "CalendarCheck", bonusXp: 30 },
  { id: "first-review", title: "نظر تیزبین", description: "اولین نظر معتبر خود را ثبت کن", icon: "MessageSquareQuote", bonusXp: 20 },
  { id: "critic-3", title: "منتقد جامعه", description: "۳ نظر معتبر روی بازی‌های مختلف بنویس", icon: "PenLine", bonusXp: 30 },
  { id: "wishlist-5", title: "لیست آرزوها", description: "۵ بازی را به علاقه‌مندی‌ها اضافه کن", icon: "Heart", bonusXp: 20 },
  { id: "ai-explorer", title: "همسفر هوشمند", description: "پرسش‌نامه Scorent AI را کامل کن", icon: "Sparkles", bonusXp: 30 },
  { id: "first-listing", title: "کارآفرین", description: "اولین آگهی اجاره‌ات را در Scorent Share بساز", icon: "Store", bonusXp: 25 },
  { id: "level-5", title: "بازیکن", description: "به سطح ۵ برس", icon: "TrendingUp", bonusXp: 0, minLevel: 5 },
  { id: "level-10", title: "شکارچی", description: "به سطح ۱۰ برس", icon: "Crosshair", bonusXp: 0, minLevel: 10 },
];

/* ————— چالش‌های هفتگی — با week key جلوگیری از جایزه تکراری ————— */

export interface ChallengeDef {
  id: string;
  title: string;
  description: string;
  icon: string;
  xp: number;
  /** هدف هفتگی */
  target: number;
  metric: "wishlist" | "review" | "rental";
}

export const WEEKLY_CHALLENGES: ChallengeDef[] = [
  {
    id: "wk-discover",
    title: "کشف‌گر هفته",
    description: "۳ بازی را این هفته به علاقه‌مندی‌ها اضافه کن",
    icon: "Compass",
    xp: 100,
    target: 3,
    metric: "wishlist",
  },
  {
    id: "wk-critic",
    title: "منتقد هفته",
    description: "۱ نظر معتبر این هفته بنویس",
    icon: "MessageSquarePlus",
    xp: 100,
    target: 1,
    metric: "review",
  },
  {
    id: "wk-renter",
    title: "مستأجر هفته",
    description: "یک اجاره این هفته شروع کن",
    icon: "Timer",
    xp: 100,
    target: 1,
    metric: "rental",
  },
];

/* ————— آواتارهای آماده (بدون آپلود فایل) ————— */

export const AVATARS: { id: string; icon: string; color: string }[] = [
  { id: "scorpion", icon: "Bug", color: "#FF9F43" },
  { id: "flame", icon: "Flame", color: "#F87171" },
  { id: "ghost", icon: "Ghost", color: "#A5ACB8" },
  { id: "zap", icon: "Zap", color: "#39E58C" },
  { id: "rocket", icon: "Rocket", color: "#8B5CF6" },
  { id: "crown", icon: "Crown", color: "#F2B545" },
  { id: "target", icon: "Target", color: "#FF6B8A" },
  { id: "sword", icon: "Swords", color: "#E8842B" },
  { id: "shield", icon: "Shield", color: "#67C7A2" },
  { id: "sparkles", icon: "Sparkles", color: "#C4A5FF" },
  { id: "moon", icon: "MoonStar", color: "#9AA7FF" },
  { id: "star", icon: "Star", color: "#FFD166" },
];

/* ————— داده نمونه جامعه (نظرات اولیه با برچسب نمونه) ————— */

const DAY = 86_400_000;
const NOW_ANCHOR = 1_760_000_000_000; // نقطه لنگر ثابت برای داده نمونه (تاریخ‌های نسبی نمایشی)

interface SeedReviewDef {
  gameId: string;
  author: string;
  rating: number;
  text: string;
  helpful: number;
  daysAgo: number;
}

const SEED_REVIEW_DEFS: SeedReviewDef[] = [
  {
    gameId: "elden-ring",
    author: "آرمان_شبح",
    rating: 5,
    text: "برای کشف کردن ساخته شده؛ هر غار و برجی یک راز دارد. اگر با شکست کنار می‌آیی، یکی از بهترین تجربه‌های عمرت خواهد بود.",
    helpful: 24,
    daysAgo: 9,
  },
  {
    gameId: "elden-ring",
    author: "Nimaaa",
    rating: 4,
    text: "چالش واقعی است ولی منصفانه. پیشنهاد من: اول با اجاره امتحانش کن تا مطمئن شوی سبکش دوست‌داشتنی‌ات است.",
    helpful: 11,
    daysAgo: 4,
  },
  {
    gameId: "hollow-knight",
    author: "ستاره_کوچک",
    rating: 5,
    text: "با این قیمت چه چیزی ساختند؟! آرت، موسیقی و نقشه‌کشی همه بی‌نقص‌اند. به هرکسی پیشنهاد می‌کنم.",
    helpful: 31,
    daysAgo: 12,
  },
  {
    gameId: "stardew-valley",
    author: "Farmer_Ali",
    rating: 5,
    text: "بعد از یک روز سخت درسی، فقط مزرعه‌ام را مرتب می‌کنم و حال دلم خوب می‌شود. بهترین بازی آرام.",
    helpful: 18,
    daysAgo: 6,
  },
  {
    gameId: "it-takes-two",
    author: "دوقلوهای_گیمر",
    rating: 5,
    text: "با خواهرم تمامش کردیم؛ هر مرحله کلی خنده و سورپرایز داشت. برای دونفره واقعاً بی‌رقیب است.",
    helpful: 15,
    daysAgo: 3,
  },
  {
    gameId: "portal-2",
    author: "LogicHunter",
    rating: 5,
    text: "۱۴ سال گذشت و هنوز بهترین نویسندگی پازل را دارد. کمپین همکاری‌اش هم عالی است.",
    helpful: 21,
    daysAgo: 15,
  },
  {
    gameId: "outer-wilds",
    author: "ستاره‌بین",
    rating: 5,
    text: "این بازی به تو اعتماد می‌کند و رازهایش را خودت کشف می‌کنی. کاش می‌توانستم دوباره برای اولین بار بازی‌اش کنم.",
    helpful: 27,
    daysAgo: 7,
  },
  {
    gameId: "cyberpunk-2077",
    author: "V_Sabzi",
    rating: 4,
    text: "بعد از آپدیت‌ها واقعاً درخشید. داستان Phantom Liberty هم فوق‌العاده است؛ با تخفیف فعلی ارزشش را دارد.",
    helpful: 13,
    daysAgo: 2,
  },
];

export const SEED_REVIEWS: Review[] = SEED_REVIEW_DEFS.map((d, i) => ({
  id: `seed-r${i + 1}`,
  gameId: d.gameId,
  author: d.author,
  rating: d.rating,
  text: d.text,
  createdAt: NOW_ANCHOR - d.daysAgo * DAY,
  mine: false,
}));

export function seedHelpfulCount(reviewId: string): number {
  const idx = Number(reviewId.replace("seed-r", "")) - 1;
  const def = SEED_REVIEW_DEFS[idx];
  return def ? def.helpful : 0;
}

/** فعالیت‌های نمونه برای بخش جامعه صفحه اصلی */
export const SEED_ACTIVITY: { author: string; text: string; gameId: string; daysAgo: number }[] = [
  { author: "آرمان_شبح", text: "Elden Ring را اجاره کرد و ۲۰ ساعت تجربه‌اش کرد", gameId: "elden-ring", daysAgo: 1 },
  { author: "ستاره_کوچک", text: "به Hollow Knight امتیاز کامل داد", gameId: "hollow-knight", daysAgo: 2 },
  { author: "Farmer_Ali", text: "Stardew Valley را به علاقه‌مندی‌ها اضافه کرد", gameId: "stardew-valley", daysAgo: 2 },
  { author: "LogicHunter", text: "Slay the Spire را با تخفیف خرید", gameId: "slay-the-spire", daysAgo: 3 },
  { author: "V_Sabzi", text: "آگهی اجاره Cyberpunk 2077 ساخت", gameId: "cyberpunk-2077", daysAgo: 4 },
];

export const COMMUNITY_NOTE =
  "نظرات و فعالیت‌های نمونه بخشی از داده نمایشی دمو هستند؛ نظرات خودت به‌صورت محلی ذخیره می‌شوند.";

export function gamesOf(ids: string[]): Game[] {
  return ids.map((id) => GAMES.find((g) => g.id === id)).filter((g): g is Game => Boolean(g));
}
