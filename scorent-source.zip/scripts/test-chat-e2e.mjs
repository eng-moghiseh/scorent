/* تست E2E پاسخ کامل دستیار — جمع‌کردن استریم SSE */
const BASE = "http://localhost:3000/api/chat";

async function ask(message, history = []) {
  const res = await fetch(BASE, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ history, message }),
  });
  if (!res.ok) return `[HTTP ${res.status}] ${await res.text()}`;
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  let out = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const events = buf.split("\n\n");
    buf = events.pop() ?? "";
    for (const evt of events) {
      for (const line of evt.split("\n")) {
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (payload === "[DONE]") continue;
        try {
          const j = JSON.parse(payload);
          if (j.t === "delta") out += j.v;
          if (j.t === "error") out += `\n[ERROR] ${j.v}`;
        } catch {}
      }
    }
  }
  return out;
}

const q = process.argv[2] ?? "یه بازی روگ‌لایت زیر ۵۰۰ هزار تومان پیشنهاد بده و بگو چرا";
console.log("Q:", q, "\n" + "—".repeat(60));
const answer = await ask(q);
console.log(answer);
console.log("—".repeat(60), "\nLEN:", answer.length);
