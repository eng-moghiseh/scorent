"use client";

/* ————— پنل مدیریت: گارد نقش + پوسته‌ی زبانه‌ای ————— */

import { useEffect, useState } from "react";
import {
  Bell,
  Gamepad2,
  Inbox,
  LayoutDashboard,
  LifeBuoy,
  Loader2,
  ShieldCheck,
  Users,
  FileText,
  Plug,
} from "lucide-react";
import { Link } from "@/components/scorent/router";
import { can, isStaff, useAuth } from "@/lib/auth";
import type { Perm } from "@/lib/auth";
import { useT } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { AdminDashboard } from "./dashboard";
import { AdminUsers } from "./users";
import { AdminAdmins } from "./admins";
import { AdminContent } from "./content";
import { AdminGames } from "./games";
import { AdminAnnouncements, AdminOutbox } from "./notifications";
import { AdminTickets } from "./tickets";
import { AdminProviders } from "./providers";

interface TabDef {
  id: string;
  labelKey: string;
  icon: React.ElementType;
  perm: Perm;
}

const TABS: TabDef[] = [
  { id: "dashboard", labelKey: "admin.tab.dashboard", icon: LayoutDashboard, perm: "stats" },
  { id: "users", labelKey: "admin.tab.users", icon: Users, perm: "users.read" },
  { id: "admins", labelKey: "admin.tab.admins", icon: ShieldCheck, perm: "admins.manage" },
  { id: "content", labelKey: "admin.tab.content", icon: FileText, perm: "content" },
  { id: "games", labelKey: "admin.tab.games", icon: Gamepad2, perm: "games" },
  { id: "announce", labelKey: "admin.tab.announce", icon: Bell, perm: "notify" },
  { id: "outbox", labelKey: "admin.tab.outbox", icon: Inbox, perm: "notify" },
  { id: "tickets", labelKey: "admin.tab.tickets", icon: LifeBuoy, perm: "tickets" },
  { id: "providers", labelKey: "admin.tab.providers", icon: Plug, perm: "providers" },
];

export function AdminPage() {
  const t = useT();
  const { user, ready } = useAuth();
  const [tab, setTab] = useState<string>("dashboard");
  const [hashTab, setHashTab] = useState<string | null>(null);

  /* زبانه از مسیر: /admin/users و ... */
  useEffect(() => {
    if (typeof window === "undefined") return;
    const seg = window.location.hash.replace(/^#\/admin\/?/, "").split("?")[0];
    if (seg && TABS.some((x) => x.id === seg)) setHashTab(seg);
  }, []);

  useEffect(() => {
    if (hashTab && TABS.some((x) => x.id === hashTab)) setTab(hashTab);
  }, [hashTab]);

  if (!ready || !useAuth.getState().ready) {
    return (
      <div className="flex min-h-[50svh] items-center justify-center gap-3 text-sm font-bold text-muted-foreground">
        <Loader2 className="size-5 animate-spin" /> {t("admin.loading")}
      </div>
    );
  }

  if (!user || !isStaff(user.role)) {
    return (
      <div className="mx-auto flex min-h-[50svh] max-w-lg flex-col items-center justify-center gap-4 px-4 text-center">
        <ShieldCheck className="size-12 text-ai" />
        <h1 className="text-xl font-black">{t("admin.title")}</h1>
        <p className="text-sm leading-7 text-muted-foreground">{t(user ? "admin.noAccess" : "admin.signInFirst")}</p>
        {!user && (
          <Link to="/auth?next=/admin" className="rounded-xl bg-ai px-5 py-2.5 text-sm font-extrabold text-white hover:bg-ai/90">
            {t("admin.signIn")}
          </Link>
        )}
      </div>
    );
  }

  const visible = TABS.filter((x) => can(user.role, x.perm));

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 md:px-6 md:py-10">
      <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
        {/* سایدبار زبانه‌ها */}
        <nav aria-label={t("admin.title")} className="lg:sticky lg:top-28 lg:self-start">
          <div className="flex gap-1.5 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible lg:pb-0" role="tablist">
            {visible.map(({ id, labelKey, icon: Icon }) => {
              const active = tab === id;
              return (
                <button
                  key={id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => {
                    setTab(id);
                    try {
                      window.history.replaceState(null, "", `#/admin/${id}`);
                    } catch {
                      /* ignore */
                    }
                  }}
                  className={cn(
                    "flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-bold transition-colors",
                    active ? "bg-ai/15 text-ai" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <Icon className="size-4.5" />
                  {t(labelKey)}
                </button>
              );
            })}
            <Link to="/" className="mt-1 flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-bold text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground">
              ← {t("admin.backToSite")}
            </Link>
          </div>
        </nav>

        {/* محتوای زبانه */}
        <div className="min-w-0">
          {tab === "dashboard" && <AdminDashboard />}
          {tab === "users" && <AdminUsers />}
          {tab === "admins" && <AdminAdmins />}
          {tab === "content" && <AdminContent />}
          {tab === "games" && <AdminGames />}
          {tab === "announce" && <AdminAnnouncements />}
          {tab === "outbox" && <AdminOutbox />}
          {tab === "tickets" && <AdminTickets />}
          {tab === "providers" && <AdminProviders />}
        </div>
      </div>
    </div>
  );
}
