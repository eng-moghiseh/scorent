"use client";

/* ————— ناوبری Scorent — نوار برند، دسکتاپ، موبایل، تب‌بار پایین و داک شناور —————
 * - تب‌بار پایین در همه اندازه‌ها فعال است: موبایل نوار کامل عرض و دسکتاپ داک شناور
 *   مرکزی (سبک منوهای اپ موبایل).
 * - دکمه تغییر تم (تیره/روشن) و تغییر زبان (فارسی/English) در نوار بالا و منوی موبایل.
 */

import { useState } from "react";
import { motion } from "framer-motion";
import { Compass, Heart, KeyRound, Languages, Menu, MessageCircle, Moon, Route as RouteIcon, ShoppingBag, Sparkles, Sun, Trophy, UserRound, X, BadgePercent as BadgePercentIcon } from "lucide-react";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { AvatarFallbackMenu } from "./avatar-menu";
import { ScorentLogo, ScorpionMark } from "./logo";
import { Link, useRoute } from "./router";
import { useHydrated, useLevelInfo, useScorent } from "@/lib/store";
import { useContentValue } from "@/lib/site-content-client";
import { useFmt, useLang, useT, useTheme, useTx, useUi, useUiDir } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { AVATARS } from "@/lib/data/community";
import { IconByName } from "./shared";

export const NAV_LINKS = [
  { to: "/store", labelKey: "nav.store", icon: ShoppingBag },
  { to: "/ai", labelKey: "nav.ai", icon: Sparkles },
  { to: "/rent", labelKey: "nav.rent", icon: KeyRound },
  { to: "/share", labelKey: "nav.share", icon: RouteIcon },
  { to: "/discovery", labelKey: "nav.discovery", icon: Compass },
  { to: "/deals", labelKey: "nav.deals", icon: BadgePercentIcon },
] as const;

function isActive(current: string, to: string): boolean {
  if (to === "/store") return current === "/store" || current.startsWith("/game/");
  return current === to;
}

/* ————— دکمه تغییر تم (خورشید/ماه) ————— */

export function ThemeToggle({ className }: { className?: string }) {
  const theme = useTheme();
  const t = useT();
  const setTheme = useUi((s) => s.setTheme);
  const isDark = theme === "dark";
  return (
    <button
      type="button"
      onClick={() => setTheme(isDark ? "light" : "dark")}
      aria-label={t("ui.toggleTheme")}
      title={isDark ? t("ui.themeLight") : t("ui.themeDark")}
      className={cn(
        "relative flex size-10 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground",
        className
      )}
    >
      <motion.span
        key={theme}
        initial={{ rotate: -60, opacity: 0, scale: 0.6 }}
        animate={{ rotate: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
        className="flex"
      >
        {isDark ? <Sun className="size-5" /> : <Moon className="size-5" />}
      </motion.span>
    </button>
  );
}

/* ————— دکمه تغییر زبان (فارسی ↔ English) ————— */

export function LangToggle({ className }: { className?: string }) {
  const lang = useLang();
  const t = useT();
  const setLocale = useUi((s) => s.setLocale);
  return (
    <button
      type="button"
      onClick={() => setLocale(lang === "fa" ? "en" : "fa")}
      aria-label={t("ui.toggleLang")}
      title={t("ui.toggleLang")}
      className={cn(
        "flex h-10 items-center gap-1.5 rounded-full px-3 text-xs font-extrabold text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground",
        className
      )}
    >
      <Languages className="size-4.5" />
      <span dir="ltr" className="min-w-6 text-center tracking-wide">
        {lang === "fa" ? "EN" : "فا"}
      </span>
    </button>
  );
}

/* ————— نوار برند: شعار رسمی Scorent در بالای سایت ————— */

export function BrandStrip() {
  const t = useT();
  const slogan = useContentValue("brand.slogan");
  return (
    <div className="brand-strip relative" role="presentation">
      <div className="mx-auto flex h-7 w-full max-w-7xl items-center justify-center gap-2.5 px-4 md:h-8 md:px-6">
        <span className="slogan-diamond" aria-hidden />
        <p className="flex items-center gap-2 text-[0.66rem] font-extrabold tracking-wide text-deal md:text-xs">
          <span className="hidden sm:inline">Scorent — </span>
          <span className="text-foreground/90">{slogan ?? t("brand.slogan")}</span>
        </p>
        <span className="slogan-diamond" aria-hidden />
        <span className="absolute end-4 hidden text-[0.65rem] font-medium text-muted-foreground/70 md:end-6 lg:inline">
          {t("brand.demoNote")}
        </span>
      </div>
    </div>
  );
}

export function Navbar() {
  const route = useRoute();
  const [open, setOpen] = useState(false);
  const hydrated = useHydrated();
  const level = useLevelInfo();
  const wishlistCount = useScorent((s) => s.wishlist.length);
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-xl">
      <BrandStrip />
      <div className="mx-auto flex h-16 w-full max-w-7xl items-center gap-3 px-4 md:px-6">
        {/* لوگو */}
        <Link to="/" ariaLabel={t("brand.homeAria")} className="shrink-0 transition-opacity hover:opacity-90">
          <ScorentLogo size={34} />
        </Link>

        {/* لینک‌های دسکتاپ */}
        <nav className="mx-auto hidden items-center gap-1 lg:flex" aria-label={t("nav.mainAria")}>
          {NAV_LINKS.map(({ to, labelKey }) => {
            const active = isActive(route.path, to);
            return (
              <Link
                key={to}
                to={to}
                className={cn(
                  "relative rounded-full px-3.5 py-2 text-sm font-bold transition-colors",
                  active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t(labelKey)}
                {active ? (
                  <motion.span
                    layoutId="nav-underline"
                    className="absolute inset-x-3 -bottom-[13px] h-0.5 rounded-full bg-deal"
                    transition={{ type: "spring", stiffness: 500, damping: 40 }}
                  />
                ) : null}
              </Link>
            );
          })}
        </nav>

        {/* اکشن‌ها */}
        <div className="me-0 ms-auto flex items-center gap-1 lg:ms-0">
          {hydrated && level.level > 1 ? (
            <Link
              to="/rewards"
              className="hidden items-center gap-1.5 rounded-full border border-deal/30 bg-deal/10 px-3 py-1.5 text-xs font-extrabold text-deal sm:flex"
              title={t("nav.rewardsAria")}
            >
              <Trophy className="size-3.5" />
              <span className="tnum">{t("nav.level", { n: f.num(level.level), title: tx(level.title) })}</span>
            </Link>
          ) : null}

          <LangToggle className="hidden sm:flex" />
          <ThemeToggle />

          <Link
            to="/ai-chat"
            ariaLabel={t("nav.aiChatAria")}
            title={t("nav.aiChatTitle")}
            className="hidden items-center gap-1.5 rounded-full border border-ai/35 bg-ai/10 px-3 py-1.5 text-xs font-extrabold text-ai transition-colors hover:bg-ai/20 sm:flex"
          >
            <MessageCircle className="size-3.5" />
            {t("nav.aiChat")}
          </Link>

          <Link
            to="/wishlist"
            ariaLabel={t("nav.wishlistAria")}
            className="relative flex size-10 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          >
            <Heart className="size-5" />
            {hydrated && wishlistCount > 0 ? (
              <span className="absolute -top-0.5 end-0 flex size-4.5 min-w-4.5 items-center justify-center rounded-full bg-[#ff6b8a] px-1 text-[0.62rem] font-extrabold text-[#2b060f] tnum">
                {f.num(wishlistCount)}
              </span>
            ) : null}
          </Link>

          <AvatarFallbackMenu />

          {/* منوی موبایل */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" aria-label={t("nav.openMenu")}>
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80 border-border bg-surface p-0" dir={dir}>
              <div className="flex h-full flex-col">
                <div className="flex items-center justify-between border-b border-border p-4">
                  <SheetTitle>
                    <ScorentLogo size={30} showTagline />
                  </SheetTitle>
                  <Button variant="ghost" size="icon" onClick={() => setOpen(false)} aria-label={t("nav.closeMenu")}>
                    <X className="size-5" />
                  </Button>
                </div>
                <nav className="flex-1 overflow-y-auto p-3" aria-label={t("nav.mobileAria")}>
                  {NAV_LINKS.map(({ to, labelKey, icon: Icon }) => (
                    <Link
                      key={to}
                      to={to}
                      onClick={() => setOpen(false)}
                      className={cn(
                        "mb-1 flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold transition-colors",
                        isActive(route.path, to) ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/60"
                      )}
                    >
                      <Icon className="size-4.5" />
                      {t(labelKey)}
                    </Link>
                  ))}
                  <div className="my-3 border-t border-border" />
                  {[
                    { to: "/ai-chat", labelKey: "nav.aiChatFull" },
                    { to: "/rewards", labelKey: "nav.rewards" },
                    { to: "/rentals", labelKey: "nav.rentals" },
                    { to: "/wishlist", labelKey: "nav.wishlist" },
                    { to: "/trial", labelKey: "nav.trial" },
                    { to: "/support", labelKey: "account.support" },
                    { to: "/profile", labelKey: "nav.profile" },
                    { to: "/settings", labelKey: "nav.settings" },
                  ].map(({ to, labelKey }) => (
                    <Link
                      key={to}
                      to={to}
                      onClick={() => setOpen(false)}
                      className="mb-1 flex items-center rounded-xl px-4 py-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground"
                    >
                      {t(labelKey)}
                    </Link>
                  ))}
                </nav>
                <div className="flex items-center justify-between gap-2.5 border-t border-border p-4">
                  <div className="flex items-center gap-2.5 text-xs leading-6 text-muted-foreground">
                    <ScorpionMark size={26} />
                    <p>{t("brand.rentSlogan")}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <LangToggle />
                    <ThemeToggle />
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

/* ————— تب‌بار پایین (همه اندازه‌ها) —————
 * موبایل: نوار کامل عرض با ۵ زبانه | دسکتاپ: داک شناور مرکزی با ۷ زبانه
 */

const DOCK_LINKS = [
  { to: "/", labelKey: "nav.home", icon: Compass },
  { to: "/store", labelKey: "nav.store", icon: ShoppingBag },
  { to: "/ai", labelKey: "nav.ai", icon: Sparkles },
  { to: "/ai-chat", labelKey: "nav.aiChat", icon: MessageCircle },
  { to: "/rent", labelKey: "nav.rent", icon: KeyRound },
  { to: "/deals", labelKey: "nav.deals", icon: BadgePercentIcon },
  { to: "/profile", labelKey: "nav.profile", icon: UserRound },
] as const;

const TAB_LINKS = [
  { to: "/", labelKey: "nav.home", icon: Compass },
  { to: "/store", labelKey: "nav.store", icon: ShoppingBag },
  { to: "/ai", labelKey: "nav.aiShort", icon: Sparkles },
  { to: "/rent", labelKey: "nav.rent", icon: KeyRound },
  { to: "/profile", labelKey: "nav.profile", icon: UserRound },
] as const;

function dockActive(current: string, to: string): boolean {
  if (to === "/") return current === "/";
  if (to === "/ai-chat") return current === "/ai-chat";
  return isActive(current, to);
}

export function BottomTabBar() {
  const route = useRoute();
  const t = useT();

  return (
    <>
      {/* موبایل: نوار کامل عرض */}
      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/92 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden"
        aria-label={t("nav.quickAria")}
      >
        <div className="grid grid-cols-5">
          {TAB_LINKS.map(({ to, labelKey, icon: Icon }) => {
            const active = dockActive(route.path, to);
            return (
              <Link
                key={to}
                to={to}
                ariaLabel={t(labelKey)}
                className={cn(
                  "relative flex flex-col items-center gap-1 py-2.5 text-[0.65rem] font-bold transition-colors",
                  active ? "text-deal" : "text-muted-foreground"
                )}
              >
                {active ? (
                  <motion.span
                    layoutId="tab-pill"
                    className="absolute inset-x-3 top-1 bottom-1 rounded-xl bg-deal/12"
                    transition={{ type: "spring", stiffness: 500, damping: 40 }}
                  />
                ) : null}
                <span className="relative">
                  <Icon className="size-5" />
                  {active ? <span className="absolute -bottom-1.5 start-1/2 size-1 -translate-x-1/2 rounded-full bg-deal" /> : null}
                </span>
                <span className="relative">{t(labelKey)}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* دسکتاپ: داک شناور مرکزی — سبک اپ موبایل */}
      <div className="pointer-events-none fixed inset-x-0 bottom-5 z-40 hidden justify-center px-6 lg:flex">
        <nav
          className="pointer-events-auto flex items-center gap-1 rounded-2xl border border-border/80 bg-surface/88 p-1.5 shadow-2xl shadow-black/30 backdrop-blur-xl"
          aria-label={t("nav.quickAria")}
        >
          {DOCK_LINKS.map(({ to, labelKey, icon: Icon }) => {
            const active = dockActive(route.path, to);
            return (
              <Link
                key={to}
                to={to}
                ariaLabel={t(labelKey)}
                title={t(labelKey)}
                className={cn(
                  "relative flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-[0.8rem] font-bold transition-colors",
                  active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {active ? (
                  <motion.span
                    layoutId="dock-pill"
                    className="absolute inset-0 rounded-xl border border-deal/25 bg-deal/12"
                    transition={{ type: "spring", stiffness: 500, damping: 40 }}
                  />
                ) : null}
                <Icon className={cn("relative size-4.5", active && "text-deal")} />
                <span className="relative">{t(labelKey)}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </>
  );
}

export function AvatarBubble({ size = 36 }: { size?: number }) {
  const profile = useScorent((s) => s.profile);
  const hydrated = useHydrated();
  const av = AVATARS.find((a) => a.id === profile.avatar) ?? AVATARS[0];
  if (!hydrated || !profile.name.trim()) {
    return (
      <span
        className="flex items-center justify-center rounded-full border border-border bg-secondary text-muted-foreground"
        style={{ width: size, height: size }}
      >
        <UserRound className="size-5" />
      </span>
    );
  }
  return (
    <span
      className="flex items-center justify-center rounded-full border"
      style={{ width: size, height: size, background: `${av.color}22`, borderColor: `${av.color}55` }}
    >
      <IconByName name={av.icon} className="size-5" />
    </span>
  );
}
