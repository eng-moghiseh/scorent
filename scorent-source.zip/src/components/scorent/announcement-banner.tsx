"use client";

/* ————— بنر اعلان سراسری — متنش از پنل مدیریت محتوا کنترل می‌شود ————— */

import { useEffect, useState } from "react";
import { Megaphone, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useAnnouncementBanner } from "@/lib/site-content-client";
import { useT } from "@/lib/i18n";

const DISMISS_KEY = "scorent-banner-dismissed";

export function AnnouncementBanner() {
  const { enabled, text } = useAnnouncementBanner();
  const t = useT();
  const [dismissed, setDismissed] = useState<string | null>(null);

  useEffect(() => {
    Promise.resolve().then(() => {
      try {
        setDismissed(localStorage.getItem(DISMISS_KEY));
      } catch {
        /* ignore */
      }
    });
  }, []);

  if (!enabled || !text || dismissed === text) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: "auto", opacity: 1 }}
        exit={{ height: 0, opacity: 0 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        className="overflow-hidden border-b border-deal/25 bg-deal/10"
        role="status"
      >
        <div className="mx-auto flex w-full max-w-7xl items-center gap-3 px-4 py-2.5 md:px-6">
          <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-deal/20 text-deal">
            <Megaphone className="size-3.5" />
          </span>
          <p className="flex-1 text-xs font-bold leading-6 text-deal md:text-[0.8rem]">{text}</p>
          <button
            type="button"
            aria-label={t("banner.dismiss")}
            title={t("banner.dismiss")}
            onClick={() => {
              setDismissed(text);
              try {
                localStorage.setItem(DISMISS_KEY, text);
              } catch {
                /* ignore */
              }
            }}
            className="flex size-7 shrink-0 items-center justify-center rounded-full text-deal/70 transition-colors hover:bg-deal/15 hover:text-deal"
          >
            <X className="size-4" />
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
