"use client";

/* ————— کشف: مسیرهای منحنه برای پیدا کردن بازی بعدی (دوزبانه) ————— */

import { useMemo } from "react";
import { Compass, Gem, Shapes, Sparkles } from "lucide-react";
import { GameCard } from "@/components/scorent/commerce";
import { GameCover } from "@/components/scorent/game-cover";
import { EmptyState, SectionHeader } from "@/components/scorent/shared";
import { Link as RouteLink, useRoute, navigate } from "@/components/scorent/router";
import { GAMES, getGame, hiddenGems, indieGames, unusualPicks } from "@/lib/data/games";
import { rankGames } from "@/lib/recommendation";
import { useFmt, useT, useGameText } from "@/lib/i18n";
import { useHydrated, useScorent } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import type { Game } from "@/lib/types";

const TABS = [
  { id: "indie", labelKey: "discovery.tabIndie", icon: Sparkles, descKey: "discovery.tabIndieDesc" },
  { id: "gems", labelKey: "discovery.tabGems", icon: Gem, descKey: "discovery.tabGemsDesc" },
  { id: "unusual", labelKey: "discovery.tabUnusual", icon: Shapes, descKey: "discovery.tabUnusualDesc" },
  { id: "foryou", labelKey: "discovery.tabForYou", icon: Compass, descKey: "discovery.tabForYouDesc" },
] as const;

type TabId = (typeof TABS)[number]["id"];

interface Reason {
  key: string;
  p?: Record<string, number>;
}

const REASONS: Record<string, Reason> = {
  "disco-elysium": { key: "discovery.reason.disco-elysium" },
  "outer-wilds": { key: "discovery.reason.outer-wilds" },
  "papers-please": { key: "discovery.reason.papers-please" },
  "katana-zero": { key: "discovery.reason.katana-zero" },
  tunic: { key: "discovery.reason.tunic" },
  gris: { key: "discovery.reason.gris" },
  cuphead: { key: "discovery.reason.cuphead", p: { n: 30 } },
  sifu: { key: "discovery.reason.sifu" },
  "slay-the-spire": { key: "discovery.reason.slay-the-spire", p: { n: 30, m: 5 } },
  "vampire-survivors": { key: "discovery.reason.vampire-survivors" },
  celeste: { key: "discovery.reason.celeste" },
  "stardew-valley": { key: "discovery.reason.stardew-valley" },
  "hollow-knight": { key: "discovery.reason.hollow-knight" },
  hades: { key: "discovery.reason.hades" },
  "tunic-game": { key: "" },
};

function reasonFor(id: string): Reason {
  return REASONS[id] ?? { key: "discovery.reason.default" };
}

/* گوهرهای پنهان: کارت تحریریه‌ای با متن کاتالوگ به زبان فعال */
function GemCard({ game, reason }: { game: Game; reason: string }) {
  const t = useT();
  const f = useFmt();
  const gt = useGameText(game);
  return (
    <button
      type="button"
      onClick={() => navigate(`/game/${game.id}`)}
      className="card-hover group flex gap-4 rounded-3xl border border-border bg-card p-4 text-start"
    >
      <GameCover game={game} showTitle={false} className="h-36 w-27 shrink-0 rounded-2xl" />
      <div className="min-w-0">
        <p className="font-black" dir="ltr">
          {game.title}
        </p>
        <p className="mt-1 text-[0.68rem] text-muted-foreground">
          {t("discovery.gemMeta", { r: f.num(game.rating), p: f.num(game.popularity) })}
        </p>
        <p className="mt-2 rounded-xl bg-rent/10 px-3 py-2 text-xs leading-6 text-rent">{reason}</p>
        <p className="mt-2 line-clamp-2 text-xs leading-6 text-muted-foreground">{gt.tagline}</p>
      </div>
    </button>
  );
}

export function DiscoveryPage() {
  const route = useRoute();
  const hydrated = useHydrated();
  const prefs = useScorent((s) => s.prefs);
  const t = useT();
  const f = useFmt();
  const tabParam = route.query.get("tab") as TabId | null;
  const tab: TabId = TABS.some((t) => t.id === tabParam) ? (tabParam as TabId) : "indie";
  const active = TABS.find((t) => t.id === tab)!;

  const reason = (id: string): string => {
    const r = reasonFor(id);
    if (!r.p) return t(r.key);
    const params: Record<string, string> = {};
    for (const [k, v] of Object.entries(r.p)) params[k] = f.num(v);
    return t(r.key, params);
  };

  const games = useMemo(() => {
    switch (tab) {
      case "indie":
        return indieGames().sort((a, b) => b.rating - a.rating);
      case "gems":
        return hiddenGems();
      case "unusual":
        return unusualPicks();
      case "foryou":
        return prefs ? rankGames(GAMES, prefs, { limit: 12 }).map((r) => r.game) : [];
    }
  }, [tab, prefs]);

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      <header className="mb-8">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-rent/12 px-3.5 py-1.5 text-xs font-bold text-rent">
          <Compass className="size-3.5" />
          Scorent Discovery
        </div>
        <h1 className="text-3xl font-black">{t("discovery.title")}</h1>
        <p className="mt-2 max-w-2xl text-sm leading-7 text-muted-foreground">{t("discovery.desc")}</p>
      </header>

      {/* تب‌ها */}
      <div className="mb-8 flex flex-wrap gap-2" role="tablist" aria-label={t("discovery.tabsAria")}>
        {TABS.map((item) => (
          <button
            key={item.id}
            role="tab"
            aria-selected={tab === item.id}
            onClick={() => navigate(`/discovery?tab=${item.id}`)}
            className={cn(
              "flex items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-bold transition-all",
              tab === item.id ? "border-rent bg-rent/12 text-rent" : "border-border bg-card text-muted-foreground hover:text-foreground"
            )}
          >
            <item.icon className="size-4" />
            {t(item.labelKey)}
          </button>
        ))}
      </div>

      <p className="mb-6 max-w-2xl rounded-2xl border border-border bg-card px-4 py-3 text-sm leading-7 text-muted-foreground">
        {t(active.descKey)}
        {tab === "foryou" && !prefs ? (
          <>
            {" "}
            {t("discovery.noPrefs1")}{" "}
            <RouteLink to="/ai" className="font-bold text-ai hover:underline">
              {t("discovery.noPrefsLink")}
            </RouteLink>{" "}
            {t("discovery.noPrefs2")}
          </>
        ) : null}
      </p>

      {tab === "foryou" ? (
        hydrated && prefs ? (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {games.map((g, i) => (
              <div key={g.id}>
                <GameCard game={g} index={i} />
                <p className="mt-2 rounded-xl bg-ai/8 px-3 py-2 text-[0.7rem] leading-6 text-[#c4b0f5]">{reason(g.id)}</p>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={Compass}
            title={t("discovery.quizEmptyTitle")}
            description={t("discovery.quizEmptyDesc")}
            action={
              <RouteLink to="/ai">
                <Button className="gap-2 bg-ai text-white hover:bg-ai/90">
                  <Sparkles className="size-4" />
                  {t("discovery.quizStart")}
                </Button>
              </RouteLink>
            }
          />
        )
      ) : games.length === 0 ? (
        <EmptyState icon={Compass} title={t("discovery.emptyTitle")} description={t("discovery.emptyDesc")} />
      ) : tab === "gems" ? (
        /* گوهرهای پنهان: چیدمان تحریریه‌ای با دلایل */
        <div className="grid gap-4 md:grid-cols-2">
          {games.map((g) => (
            <GemCard key={g.id} game={g} reason={reason(g.id)} />
          ))}
        </div>
      ) : tab === "unusual" ? (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {games.map((g, i) => (
            <div key={g.id}>
              <GameCard game={g} index={i} />
              <p className="mt-2 rounded-xl bg-deal/10 px-3 py-2 text-[0.7rem] leading-6 text-deal">{reason(g.id)}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {games.map((g, i) => (
            <GameCard key={g.id} game={g} index={i} />
          ))}
        </div>
      )}

      {tab === "indie" ? (
        <section className="mt-12">
          <SectionHeader kicker={t("discovery.stripKicker")} title={t("discovery.stripTitle")} icon={Gem} />
          <div className="flex gap-3 overflow-x-auto pb-3 no-scrollbar mask-fade-edges-x">
            {indieGames()
              .slice(4, 10)
              .map((g) => (
                <button key={g.id} type="button" onClick={() => navigate(`/game/${g.id}`)} className="group w-40 shrink-0 text-start">
                  <GameCover game={g} className="aspect-[3/4] w-full rounded-2xl border border-border transition-transform duration-500 group-hover:scale-[1.03]" />
                  <p className="mt-2 truncate text-xs font-bold">{getGame(g.id)?.title}</p>
                </button>
              ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
