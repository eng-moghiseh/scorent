import { describe, it, expect } from "vitest";
import { hashPassword, verifyPassword } from "../src/lib/server/password";
import { issueToken, parseToken } from "../src/lib/server/session";

describe("password hashing (scrypt)", () => {
  it("hashes and verifies", async () => {
    const h = await hashPassword("Scorent@2026!");
    expect(h.startsWith("scrypt$")).toBe(true);
    expect(await verifyPassword("Scorent@2026!", h)).toBe(true);
    expect(await verifyPassword("wrong-password", h)).toBe(false);
  });

  it("produces unique salts", async () => {
    const a = await hashPassword("same-password");
    const b = await hashPassword("same-password");
    expect(a).not.toBe(b);
  });

  it("rejects malformed stored hashes", async () => {
    expect(await verifyPassword("x", "garbage")).toBe(false);
    expect(await verifyPassword("x", "bcrypt$1$2$3$4$5")).toBe(false);
  });
});

describe("session tokens", () => {
  it("issues and parses a valid token", () => {
    const { token } = issueToken("user-123");
    const payload = parseToken(token);
    expect(payload).not.toBeNull();
    expect(payload!.uid).toBe("user-123");
    expect(payload!.exp).toBeGreaterThan(Date.now());
  });

  it("rejects tampered tokens", () => {
    const { token } = issueToken("user-123");
    const [body, sig] = token.split(".");
    // تغییر payload با همان امضا
    expect(parseToken(`${body}x.${sig}`)).toBeNull();
    // امضای جعلی
    expect(parseToken(`${body}.fakesig123`)).toBeNull();
  });

  it("rejects garbage", () => {
    expect(parseToken("")).toBeNull();
    expect(parseToken(undefined)).toBeNull();
    expect(parseToken("no-dot-here")).toBeNull();
    expect(parseToken("a.b")).toBeNull();
  });
});
