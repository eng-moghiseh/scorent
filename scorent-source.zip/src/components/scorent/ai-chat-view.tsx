"use client";

/* ————— نمای مشترک گفتگو: فهرست پیام + کمپوزر (دوزبانه) —————
 * هم در صفحه کامل #/ai-chat و هم در داک شناور استفاده می‌شود.
 * RTL/LTR درست، مارک‌داون با جدول، لینک‌های #/game وصل به روتر، استریم زنده.
 */

import { useEffect, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Check, Copy, CornerDownLeft, RotateCcw, SendHorizonal, Sparkles, Square } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { navigate } from "./router";
import { useChatStore, type ChatMessage } from "@/lib/ai/chat-store";
import { useT } from "@/lib/i18n";
import { AvatarBubble } from "./navbar";
import { ScorentMark } from "./logo";
import { linkifyGameTitles } from "@/lib/ai/linkify";

const MAX_LEN = 2000;

/* ————— لینک‌های داخلی #/game → روتر Scorent ————— */

function MarkdownLink({ href, children }: { href?: string; children: ReactNode }) {
  if (href && href.startsWith("#/")) {
    return (
      <button
        type="button"
        onClick={() => navigate(href.replace(/^#+/, ""))}
        className="inline-flex items-center gap-0.5 rounded-md bg-ai/12 px-1.5 py-0.5 font-bold text-ai underline decoration-ai/40 underline-offset-4 transition-colors hover:bg-ai/20"
      >
        {children}
      </button>
    );
  }
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="text-ai underline underline-offset-4">
      {children}
    </a>
  );
}

function AssistantMarkdown({ content }: { content: string }) {
  return (
    <div className="space-y-2.5 text-sm leading-7 [word-break:break-word]">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: ({ href, children }) => <MarkdownLink href={href}>{children}</MarkdownLink>,
          p: ({ children }) => <p>{children}</p>,
          ul: ({ children }) => <ul className="list-disc space-y-1 pe-5">{children}</ul>,
          ol: ({ children }) => <ol className="list-decimal space-y-1 pe-5">{children}</ol>,
          li: ({ children }) => <li className="ps-1 leading-7">{children}</li>,
          h1: ({ children }) => <p className="text-base font-extrabold">{children}</p>,
          h2: ({ children }) => <p className="text-base font-extrabold">{children}</p>,
          h3: ({ children }) => <p className="text-sm font-extrabold">{children}</p>,
          strong: ({ children }) => <b className="font-extrabold text-foreground">{children}</b>,
          code: ({ className, children, ...rest }) => {
            const isBlock = typeof className === "string" && className.includes("language-");
            if (isBlock) {
              return (
                <code dir="ltr" className="block overflow-x-auto rounded-xl border border-border bg-[#14161d] p-3 text-left font-mono text-xs leading-6 text-[#d7dce6]" {...rest}>
                  {children}
                </code>
              );
            }
            return (
              <code dir="ltr" className="rounded-md bg-[#14161d] px-1.5 py-0.5 font-mono text-[0.78rem] text-[#d7dce6]" {...rest}>
                {children}
              </code>
            );
          },
          pre: ({ children }) => <>{children}</>,
          table: ({ children }) => (
            <div className="overflow-x-auto rounded-xl border border-border" dir="ltr">
              <table className="w-full text-left text-xs">{children}</table>
            </div>
          ),
          th: ({ children }) => <th className="border-b border-border bg-secondary/70 px-3 py-2 font-extrabold">{children}</th>,
          td: ({ children }) => <td className="border-b border-border/60 px-3 py-2 align-top">{children}</td>,
          blockquote: ({ children }) => <blockquote className="border-e-2 border-ai/50 pe-3 text-muted-foreground">{children}</blockquote>,
        }}
      >
        {linkifyGameTitles(content)}
      </ReactMarkdown>
    </div>
  );
}

/* ————— حباب پیام ————— */

function MessageBubble({ msg, isLast, streaming }: { msg: ChatMessage; isLast: boolean; streaming: boolean }) {
  const [copied, setCopied] = useState(false);
  const t = useT();
  const isUser = msg.role === "user";
  const showCursor = !isUser && isLast && streaming && msg.content.length > 0;
  const thinking = !isUser && isLast && streaming && msg.content.length === 0;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(msg.content);
      setCopied(true);
      toast.success(t("chat.copied"));
      setTimeout(() => setCopied(false), 1600);
    } catch {
      toast.error(t("chat.copyDenied"));
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
      className={cn("flex w-full gap-2.5", isUser ? "flex-row-reverse" : "flex-row")}
    >
      {/* آواتار */}
      {isUser ? (
        <span className="mt-1 shrink-0">
          <AvatarBubble size={32} />
        </span>
      ) : (
        <span className="mt-1 flex size-8 shrink-0 items-center justify-center rounded-full border border-ai/40 bg-gradient-to-br from-ai/30 to-ai/10 text-ai">
          <ScorentMark size={18} />
        </span>
      )}

      <div className={cn("group min-w-0 max-w-[calc(100%-3rem)] flex-1", isUser && "flex flex-col items-end")}>
        {isUser ? (
          <div dir="auto" className="inline-block max-w-full whitespace-pre-wrap rounded-2xl rounded-te-md border border-border bg-secondary px-4 py-2.5 text-sm leading-7">
            {msg.content}
          </div>
        ) : (
          <div className="inline-block max-w-full rounded-2xl rounded-ts-md border border-border bg-card px-4 py-3" dir="auto">
            {thinking ? (
              <div className="flex items-center gap-1.5 py-1" aria-label={t("chat.thinkingAria")}>
                {[0, 1, 2].map((i) => (
                  <motion.span
                    key={i}
                    className="size-2 rounded-full bg-ai"
                    animate={{ opacity: [0.25, 1, 0.25], y: [0, -3, 0] }}
                    transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.18 }}
                  />
                ))}
                <span className="ms-1.5 text-xs text-muted-foreground">{t("chat.thinking")}</span>
              </div>
            ) : (
              <>
                <AssistantMarkdown content={msg.content} />
                {showCursor ? <span className="ms-0.5 inline-block h-4 w-[7px] animate-pulse rounded-[2px] bg-ai align-middle" aria-hidden /> : null}
              </>
            )}
          </div>
        )}

        {/* ابزار پیام */}
        {!isUser && !thinking && !streaming ? (
          <div className="mt-1.5 flex items-center gap-1 opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100">
            <button
              type="button"
              onClick={copy}
              className="flex items-center gap-1 rounded-lg px-2 py-1 text-[0.68rem] font-bold text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              aria-label={t("chat.copyAria")}
            >
              {copied ? <Check className="size-3 text-rent" /> : <Copy className="size-3" />}
              {copied ? t("chat.copiedShort") : t("chat.copy")}
            </button>
            {isLast && msg.error ? <RetryButton /> : null}
          </div>
        ) : null}
        {isUser && isLast && !streaming && msg.error ? <RetryButton /> : null}
      </div>
    </motion.div>
  );
}

function RetryButton() {
  const retry = useChatStore((s) => s.retry);
  const streaming = useChatStore((s) => s.streaming);
  const t = useT();
  return (
    <Button
      size="sm"
      variant="outline"
      onClick={() => void retry()}
      disabled={streaming}
      className="h-7 gap-1.5 rounded-lg border-deal/40 px-2.5 text-[0.7rem] text-deal hover:bg-deal/10"
    >
      <RotateCcw className="size-3" />
      {t("chat.retry")}
    </Button>
  );
}

/* ————— کمپوزر ————— */

function Composer({ compact = false }: { compact?: boolean }) {
  const [text, setText] = useState("");
  const [composing, setComposing] = useState(false);
  const send = useChatStore((s) => s.send);
  const stop = useChatStore((s) => s.stop);
  const streaming = useChatStore((s) => s.streaming);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const t = useT();

  const canSend = text.trim().length > 0 && !streaming;

  const autoGrow = () => {
    const el = taRef.current;
    if (!el) return;
    el.style.height = "0px";
    el.style.height = `${Math.min(el.scrollHeight, compact ? 120 : 168)}px`;
  };

  useEffect(autoGrow, [text]);

  const doSend = () => {
    if (!canSend || composing) return;
    const msg = text;
    setText("");
    void send(msg);
  };

  return (
    <div className="border-t border-border bg-background/80 p-3 backdrop-blur md:p-4">
      <div className="mx-auto w-full max-w-3xl">
        <div
          className={cn(
            "flex items-end gap-2 rounded-2xl border bg-card p-2 transition-colors focus-within:border-ai/50",
            "border-border"
          )}
        >
          <label htmlFor={compact ? "chat-input-dock" : "chat-input-page"} className="sr-only">
            {t("chat.inputLabel")}
          </label>
          <textarea
            id={compact ? "chat-input-dock" : "chat-input-page"}
            ref={taRef}
            value={text}
            onChange={(e) => setText(e.target.value.slice(0, MAX_LEN))}
            onCompositionStart={() => setComposing(true)}
            onCompositionEnd={() => setComposing(false)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey && !composing) {
                e.preventDefault();
                doSend();
              }
            }}
            rows={1}
            dir="auto"
            placeholder={t("chat.placeholder")}
            className="max-h-[168px] min-h-[42px] w-full resize-none bg-transparent px-2.5 py-2.5 text-sm leading-7 outline-none placeholder:text-muted-foreground"
          />
          {streaming ? (
            <Button
              size="icon"
              onClick={stop}
              aria-label={t("chat.stopAria")}
              className="size-10 shrink-0 rounded-xl border border-destructive/40 bg-destructive/10 text-destructive hover:bg-destructive/20 hover:text-destructive"
            >
              <Square className="size-4 fill-current" />
            </Button>
          ) : (
            <Button
              size="icon"
              onClick={doSend}
              disabled={!canSend}
              aria-label={t("chat.sendAria")}
              className="size-10 shrink-0 rounded-xl bg-ai text-white hover:bg-ai/90"
            >
              <SendHorizonal className="size-4.5 -scale-x-100" />
            </Button>
          )}
        </div>
        <div className="mt-2 flex items-center justify-between px-1 text-[0.65rem] text-muted-foreground">
          <p>{t("chat.disclaimer")}</p>
          <span className="tnum hidden sm:block" aria-live="off">
            {text.length > 0 ? `${text.length}/${MAX_LEN}` : ""}
          </span>
        </div>
      </div>
    </div>
  );
}

export { Composer, MAX_LEN };
export const SendHint = () => {
  const t = useT();
  return (
    <span className="inline-flex items-center gap-1 text-[0.68rem] text-muted-foreground">
      <CornerDownLeft className="size-3" /> {t("chat.sendHint")}
    </span>
  );
};

/* ————— نمای گفتگو ————— */

export function ChatView({
  compact = false,
  header,
  emptyState,
  className,
}: {
  compact?: boolean;
  header?: ReactNode;
  emptyState?: ReactNode;
  className?: string;
}) {
  const conversation = useChatStore((s) => s.conversations.find((c) => c.id === s.activeId) ?? null);
  const streaming = useChatStore((s) => s.streaming);
  const selectConversation = useChatStore((s) => s.selectConversation);
  const scrollRef = useRef<HTMLDivElement>(null);
  const stickToBottom = useRef(true);

  const messages = useMemo(() => conversation?.messages ?? [], [conversation]);
  const lastId = messages.length > 0 ? messages[messages.length - 1].id : "";
  const lastContentLen = messages.length > 0 ? messages[messages.length - 1].content.length : 0;

  /* اگر کاربر نزدیک پایین است، با هر دلتا اسکرول بچسبد */
  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (stickToBottom.current) el.scrollTop = el.scrollHeight;
  }, [lastId, lastContentLen]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 90;
  };

  /* اگر گفتگوی فعلی خالی است ولی گفتگوهای دیگری هست، اولین را انتخاب کن — فقط برای صفحه کامل */
  useEffect(() => {
    if (compact) return;
    const s = useChatStore.getState();
    if (s.activeId === null && s.conversations.length > 0) selectConversation(s.conversations[0].id);
  }, [compact, selectConversation]);

  const isEmpty = messages.length === 0;

  return (
    <div className={cn("flex min-h-0 flex-1 flex-col", className)}>
      {header}
      <div
        ref={scrollRef}
        onScroll={onScroll}
        className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-3 py-5 md:px-6"
        aria-live="polite"
      >
        <div className="mx-auto w-full max-w-3xl space-y-5">
          {isEmpty && emptyState ? emptyState : messages.map((m, i) => <MessageBubble key={m.id} msg={m} isLast={i === messages.length - 1} streaming={streaming} />)}
        </div>
      </div>
      <Composer compact={compact} />
    </div>
  );
}

/* ————— حالت خالی مشترک (پیشنهادها — دوزبانه، به زبان UI ارسال می‌شود) ————— */

export interface SuggestedPrompt {
  icon: typeof Sparkles;
  labelKey: string;
  promptKey: string;
}

export const SUGGESTED_PROMPTS: SuggestedPrompt[] = [
  { icon: Sparkles, labelKey: "chat.prompt1Label", promptKey: "chat.prompt1" },
  { icon: Sparkles, labelKey: "chat.prompt2Label", promptKey: "chat.prompt2" },
  { icon: Sparkles, labelKey: "chat.prompt3Label", promptKey: "chat.prompt3" },
  { icon: Sparkles, labelKey: "chat.prompt4Label", promptKey: "chat.prompt4" },
  { icon: Sparkles, labelKey: "chat.prompt5Label", promptKey: "chat.prompt5" },
  { icon: Sparkles, labelKey: "chat.prompt6Label", promptKey: "chat.prompt6" },
];

export function PromptGrid({ onPick, compact = false }: { onPick: (prompt: string) => void; compact?: boolean }) {
  const send = useChatStore((s) => s.send);
  const t = useT();
  return (
    <div className={cn("grid gap-2", compact ? "grid-cols-1" : "grid-cols-1 sm:grid-cols-2")}>
      {SUGGESTED_PROMPTS.slice(0, compact ? 4 : 6).map(({ labelKey, promptKey }) => {
        const prompt = t(promptKey);
        return (
          <button
            key={promptKey}
            type="button"
            onClick={() => {
              onPick(prompt);
              void send(prompt);
            }}
            className="group flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-3.5 py-3 text-start text-xs font-bold transition-all hover:border-ai/45 hover:bg-ai/8"
          >
            <span>{prompt}</span>
            <SendHorizonal className="size-3.5 shrink-0 -scale-x-100 text-muted-foreground transition-colors group-hover:text-ai" />
          </button>
        );
      })}
    </div>
  );
}
