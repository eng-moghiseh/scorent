/* ————— موتور اطلاع‌رسانی چند-ارائه‌گاری (ایمیل + پیامک) —————
 * الگو مشابه لایه‌ی AI: اگر اعتبارنامه‌ی واقعی در env باشد → ارسال واقعی؛
 * در غیر این صورت پیام در صندوق خروجی با برچسب SIMULATED ثبت می‌شود
 * (هرگز ادعای ارسال واقعی نمی‌کنیم).
 *
 * متغیرهای محیطی پشتیبانی‌شده:
 *  ایمیل:  SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM, SMTP_SECURE(=true|false)
 *  پیامک:  SMS_PROVIDER=kavenegar, SMS_API_KEY, SMS_FROM (کاوه‌نگار)
 *          یا SMS_WEBHOOK_URL (وبهوک عمومی JSON: {to, body})
 */

import nodemailer from "nodemailer";
import type { Transporter } from "nodemailer";
import { db } from "@/lib/db";

export type Channel = "EMAIL" | "SMS";
export type SendStatus = "SENT" | "SIMULATED" | "FAILED";

export interface SendResult {
  ok: boolean;
  status: SendStatus;
  provider: string;
  error?: string;
}

/* ————— وضعیت پیکربندی (برای پنل مدیریت) ————— */

export function emailConfigured(): boolean {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_PORT);
}

export function smsConfigured(): boolean {
  return Boolean((process.env.SMS_PROVIDER === "kavenegar" && process.env.SMS_API_KEY) || process.env.SMS_WEBHOOK_URL);
}

export function googleConfigured(): boolean {
  return Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}

/** حالت نمایشی صادقانه: در dev فعال؛ در production فقط با DEMO_MODE=true
 * (این فلگ فقط «نمایش کد تأیید در پاسخ UI» را کنترل می‌کند — ادعای ارسال واقعی نمی‌شود).
 */
export function isDemoMode(): boolean {
  if (process.env.NODE_ENV !== "production") return true;
  return process.env.DEMO_MODE === "true";
}

let transporter: Transporter | null = null;
let transporterKey = "";

function getTransporter(): Transporter | null {
  if (!emailConfigured()) return null;
  const key = `${process.env.SMTP_HOST}:${process.env.SMTP_PORT}:${process.env.SMTP_USER ?? ""}`;
  if (transporter && key === transporterKey) return transporter;
  const port = Number(process.env.SMTP_PORT);
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: process.env.SMTP_SECURE ? process.env.SMTP_SECURE === "true" : port === 465,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS ?? "" } : undefined,
  });
  transporterKey = key;
  return transporter;
}

/* ————— قالب ایمیل برندشده (دو زبانه، RTL-aware) ————— */

const BRAND_PURPLE = "#8B5CF6";
const BRAND_DARK = "#111318";

export function emailHtml(lang: "fa" | "en", title: string, bodyHtml: string): string {
  const dir = lang === "fa" ? "rtl" : "ltr";
  const footer = lang === "fa" ? "این پیام از سوی Scorent ارسال شده است" : "This message was sent by Scorent";
  const demoNote = lang === "fa" ? "قبل از خرید، تجربه‌اش کن!" : "Try it before you buy it!";
  return `<!doctype html><html lang="${lang}" dir="${dir}"><body style="margin:0;padding:0;background:#f4f5f8;font-family:Vazirmatn,Tahoma,Segoe UI,sans-serif;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f8;padding:24px 12px;"><tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #e5e7ee;">
<tr><td style="background:${BRAND_DARK};padding:20px 28px;">
  <span style="font-size:20px;font-weight:800;color:#fff;letter-spacing:.5px;">Scorent</span>
  <span style="display:block;font-size:11px;color:#A5ACB8;margin-top:4px;">${demoNote}</span>
</td></tr>
<tr><td style="padding:28px;">
  <h1 style="margin:0 0 14px;font-size:19px;color:${BRAND_DARK};">${title}</h1>
  <div style="font-size:14px;line-height:2;color:#3a3f4a;">${bodyHtml}</div>
</td></tr>
<tr><td style="padding:16px 28px;border-top:1px solid #eef0f4;font-size:11px;color:#9aa1ad;">
  <span style="color:${BRAND_PURPLE};font-weight:700;">◆</span> ${footer}
</td></tr>
</table></td></tr></table></body></html>`;
}

/* ————— ارسال واقعی / شبیه‌سازی ————— */

async function deliverEmail(to: string, subject: string, html: string, text: string): Promise<SendResult> {
  const tx = getTransporter();
  if (!tx) {
    return { ok: true, status: "SIMULATED", provider: "demo" };
  }
  try {
    await tx.sendMail({
      from: process.env.SMTP_FROM ?? process.env.SMTP_USER ?? "Scorent <no-reply@scorent.local>",
      to,
      subject,
      html,
      text,
    });
    return { ok: true, status: "SENT", provider: "smtp" };
  } catch (e) {
    return { ok: false, status: "FAILED", provider: "smtp", error: e instanceof Error ? e.message : String(e) };
  }
}

async function deliverSms(to: string, body: string): Promise<SendResult> {
  if (!smsConfigured()) return { ok: true, status: "SIMULATED", provider: "demo" };
  try {
    if (process.env.SMS_PROVIDER === "kavenegar" && process.env.SMS_API_KEY) {
      const url = `https://api.kavenegar.com/v1/${process.env.SMS_API_KEY}/sms/send.json?receptor=${encodeURIComponent(to)}&sender=${encodeURIComponent(process.env.SMS_FROM ?? "")}&message=${encodeURIComponent(body)}`;
      const res = await fetch(url, { method: "POST" });
      if (!res.ok) return { ok: false, status: "FAILED", provider: "kavenegar", error: `HTTP ${res.status}` };
      return { ok: true, status: "SENT", provider: "kavenegar" };
    }
    if (process.env.SMS_WEBHOOK_URL) {
      const res = await fetch(process.env.SMS_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to, body }),
      });
      if (!res.ok) return { ok: false, status: "FAILED", provider: "webhook", error: `HTTP ${res.status}` };
      return { ok: true, status: "SENT", provider: "webhook" };
    }
    return { ok: true, status: "SIMULATED", provider: "demo" };
  } catch (e) {
    return { ok: false, status: "FAILED", provider: "sms", error: e instanceof Error ? e.message : String(e) };
  }
}

/* ————— ثبت در صندوق خروجی + ارسال ————— */

export interface QueueInput {
  userId?: string | null;
  channel: Channel;
  recipient: string;
  subject?: string | null;
  body: string;
  kind: string; // WELCOME | VERIFY | ANNOUNCEMENT | TICKET_REPLY | ACCOUNT | SYSTEM
  html?: string;
  meta?: Record<string, unknown>;
}

export async function sendAndLog(input: QueueInput): Promise<SendResult> {
  let result: SendResult;
  if (input.channel === "EMAIL") {
    result = await deliverEmail(input.recipient, input.subject ?? "Scorent", input.html ?? emailHtml("fa", input.subject ?? "Scorent", escapeHtml(input.body)), input.body);
  } else {
    result = await deliverSms(input.recipient, input.body);
  }
  await db.notification.create({
    data: {
      userId: input.userId ?? null,
      channel: input.channel,
      recipient: input.recipient,
      subject: input.subject ?? null,
      body: input.body,
      kind: input.kind,
      status: result.status,
      provider: result.provider,
      error: result.error ?? null,
      meta: input.meta ? JSON.stringify(input.meta) : null,
      sentAt: result.status === "FAILED" ? null : new Date(),
    },
  });
  return result;
}

export function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
