"use client";

/* ————— کارت حساب کاربری در پروفایل — هویت، تأیید، امنیت، اطلاع‌رسانی ————— */

import { useState } from "react";
import { toast } from "sonner";
import { BadgeCheck, KeyRound, LogIn, Mail, Phone, Save, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Link, useRoute } from "@/components/scorent/router";
import { api, useAuth } from "@/lib/auth";
import type { AuthUser } from "@/lib/auth";
import { useFmt, useT, useUiDir } from "@/lib/i18n";
import { cn } from "@/lib/utils";

function ContactRow({ icon: Icon, label, value, verified }: { icon: React.ElementType; label: string; value: string | null; verified: boolean }) {
  const t = useT();
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-secondary/40 px-3.5 py-2.5">
      <div className="flex min-w-0 items-center gap-2.5">
        <Icon className="size-4 shrink-0 text-ai" />
        <div className="min-w-0">
          <p className="text-[0.62rem] font-bold text-muted-foreground">{label}</p>
          <p dir="ltr" className="truncate text-start text-xs font-bold tnum">{value ?? t("account.notSet")}</p>
        </div>
      </div>
      <span className={cn("shrink-0 rounded-full border px-2 py-0.5 text-[0.6rem] font-extrabold", verified ? "border-rent/40 bg-rent/10 text-rent" : "border-border bg-secondary text-muted-foreground")}>
        {verified ? t("account.verified") : t("account.unverified")}
      </span>
    </div>
  );
}

function ChangePasswordDialog() {
  const t = useT();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);

  async function submit() {
    setBusy(true);
    try {
      await api.post("/api/auth/password", { current, next });
      toast.success(t("account.pwChanged"));
      setCurrent("");
      setNext("");
      setOpen(false);
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "WRONG_CURRENT" ? t("auth.errWrongCurrent") : t("auth.errWeakPassword"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5">
          <KeyRound className="size-3.5" /> {t("account.changePassword")}
        </Button>
      </DialogTrigger>
      <DialogContent dir="rtl" className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>{t("account.changePassword")}</DialogTitle>
          <DialogDescription>{t("auth.passwordPh")}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="cur-pw" className="text-xs font-bold text-muted-foreground">{t("account.currentPw")}</Label>
            <Input id="cur-pw" type="password" value={current} onChange={(e) => setCurrent(e.target.value)} dir="ltr" className="text-start" autoComplete="current-password" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="new-pw" className="text-xs font-bold text-muted-foreground">{t("account.newPw")}</Label>
            <Input id="new-pw" type="password" value={next} onChange={(e) => setNext(e.target.value)} dir="ltr" className="text-start" autoComplete="new-password" />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={busy || next.length < 8} className="w-full bg-ai text-white hover:bg-ai/90">
            <Save className="size-4" /> {busy ? "…" : t("admin.save")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function AccountCard() {
  const t = useT();
  const f = useFmt();
  const dir = useUiDir();
  const route = useRoute();
  const user = useAuth((s) => s.user);
  const setUser = useAuth((s) => s.setUser);

  const [emailOptIn, setEmailOptIn] = useState<boolean | null>(user?.emailOptIn ?? null);
  const [smsOptIn, setSmsOptIn] = useState<boolean | null>(user?.smsOptIn ?? null);
  const [lang, setLang] = useState<string>(user?.lang ?? "fa");
  const [busy, setBusy] = useState(false);

  if (!user) {
    return (
      <section className="mb-10 rounded-3xl border border-dashed border-border bg-card/40 p-6" aria-label={t("account.sectionTitle")}>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="flex items-center gap-2 text-lg font-extrabold">
              <ShieldCheck className="size-5 text-ai" /> {t("account.sectionTitle")}
            </h2>
            <p className="mt-1.5 text-sm leading-7 text-muted-foreground">{t("account.signedOutCard")}</p>
          </div>
          <Link to={route.path === "/auth" ? "/" : `/auth?next=${encodeURIComponent(route.path)}`} className="flex h-11 items-center gap-2 rounded-xl bg-ai px-5 text-sm font-extrabold text-white transition-colors hover:bg-ai/90">
            <LogIn className="size-4" /> {t("account.signIn")}
          </Link>
        </div>
      </section>
    );
  }

  async function savePrefs(next: { emailOptIn?: boolean; smsOptIn?: boolean; lang?: string }) {
    setBusy(true);
    try {
      const res = await api.post<{ ok: boolean; user: AuthUser }>("/api/auth/preferences", next);
      setUser(res.user);
      if (res.user.emailOptIn !== undefined) setEmailOptIn(res.user.emailOptIn);
      if (res.user.smsOptIn !== undefined) setSmsOptIn(res.user.smsOptIn);
      if (res.user.lang) setLang(res.user.lang);
      toast.success(t("account.saved"));
    } catch {
      toast.error(t("auth.errGeneric"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mb-10 rounded-3xl border border-border bg-card p-6" aria-label={t("account.sectionTitle")}>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-lg font-extrabold">
            <ShieldCheck className="size-5 text-ai" /> {t("account.sectionTitle")}
          </h2>
          <p className="mt-1 text-xs leading-6 text-muted-foreground">{t("account.sectionDesc")}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="rounded-full bg-ai/15 px-2.5 py-1 text-[0.65rem] font-extrabold text-ai">{t(`account.role.${user.role}`)}</span>
          <ChangePasswordDialog />
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <ContactRow icon={Mail} label={t("account.email")} value={user.email} verified={Boolean(user.emailVerified)} />
        <ContactRow icon={Phone} label={t("account.phone")} value={user.phone} verified={Boolean(user.phoneVerified)} />
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2 text-[0.65rem] text-muted-foreground">
        {user.googleLinked && (
          <span className="flex items-center gap-1 rounded-full border border-border bg-secondary px-2 py-1 font-bold">
            <BadgeCheck className="size-3 text-ai" /> {t("account.googleLinked")}
          </span>
        )}
        {user.hasPassword && (
          <span className="rounded-full border border-border bg-secondary px-2 py-1 font-bold">{t("account.passwordLogin")}</span>
        )}
        <span className="tnum">
          {t("account.memberSince")} {f.date(new Date(user.createdAt).getTime())}
        </span>
      </div>

      {/* ترجیحات اطلاع‌رسانی */}
      <div className="mt-5 rounded-2xl border border-border bg-secondary/30 p-4">
        <p className="text-sm font-extrabold">{t("account.notifPrefs")}</p>
        <p className="mt-1 text-[0.68rem] leading-6 text-muted-foreground">{t("account.notifDesc")}</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <label className="flex items-center justify-between gap-2 rounded-xl border border-border bg-card px-3 py-2.5">
            <span className="text-xs font-bold">{t("account.emailOptIn")}</span>
            <Switch
              checked={emailOptIn ?? user.emailOptIn}
              onCheckedChange={(v) => void savePrefs({ emailOptIn: v })}
              aria-label={t("account.emailOptIn")}
            />
          </label>
          <label className="flex items-center justify-between gap-2 rounded-xl border border-border bg-card px-3 py-2.5">
            <span className="text-xs font-bold">{t("account.smsOptIn")}</span>
            <Switch
              checked={smsOptIn ?? user.smsOptIn}
              onCheckedChange={(v) => void savePrefs({ smsOptIn: v })}
              aria-label={t("account.smsOptIn")}
            />
          </label>
          <div dir={dir} className="rounded-xl border border-border bg-card px-3 py-2">
            <p className="mb-1 text-[0.62rem] font-bold text-muted-foreground">{t("account.langPref")}</p>
            <Select dir={dir} value={lang} onValueChange={(v) => void savePrefs({ lang: v })}>
              <SelectTrigger className="h-8 text-xs" aria-label={t("account.langPref")}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="fa">فارسی</SelectItem>
                <SelectItem value="en">English</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        {busy && <p className="mt-2 text-[0.65rem] text-muted-foreground">…</p>}
      </div>
    </section>
  );
}
