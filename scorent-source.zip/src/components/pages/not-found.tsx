"use client";

/* ————— صفحه ۴۰۴ ————— */

import { Compass, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScorpionMark } from "@/components/scorent/logo";
import { Link as RouteLink } from "@/components/scorent/router";
import { useFmt, useT } from "@/lib/i18n";

export function NotFoundPage({ attempted }: { attempted?: string }) {
  const t = useT();
  const f = useFmt();
  return (
    <div className="mx-auto flex min-h-[60vh] w-full max-w-xl flex-col items-center justify-center px-4 py-16 text-center">
      <div className="float-slow">
        <ScorpionMark size={96} />
      </div>
      <p className="mt-8 text-6xl font-black text-gradient-brand tnum">{f.num(404)}</p>
      <h1 className="mt-3 text-xl font-extrabold">{t("notFound.title")}</h1>
      <p className="mt-3 text-sm leading-7 text-muted-foreground">
        {attempted && attempted !== "/" ? (
          <>
            {t("notFound.attemptedPre")} <span dir="ltr" className="font-bold text-foreground">#{attempted}</span> {t("notFound.attemptedPost")}
          </>
        ) : (
          t("notFound.plain")
        )}
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <RouteLink to="/">
          <Button className="gap-2">
            <Home className="size-4" />
            {t("notFound.home")}
          </Button>
        </RouteLink>
        <RouteLink to="/store">
          <Button variant="outline" className="gap-2">
            <Compass className="size-4" />
            {t("notFound.discover", { n: f.num(28) })}
          </Button>
        </RouteLink>
      </div>
    </div>
  );
}
