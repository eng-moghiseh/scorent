/* ————— ابزارهای کاتالوگ Scorent برای دستیار هوشمند (سمت سرور) —————
 *
 * ⚠️ اصل مهم: دستیار هرگز قیمت/امتیاز از خودش تولید نمی‌کند. همه اعداد از
 * همین توابع قطعی (deterministic) می‌آیند که مستقیماً از دیتاست مرکزی
 * GAMES و موتور پیشنهاد rankGames تغذیه می‌شوند (تک منبع حقیقت).
 *
 * خروجی هر ابزار یک شیء JSON فشرده است که در پرامپت سیستم تزریق می‌شود و
 * مدل فقط «تفسیر و توضیح» آن را بر عهده دارد.
 */

import { GAMES, dealGames, getGame, hiddenGems, indieGames } from "../data/games";
import { rankGames, effectiveSpend, type ScoreResult } from "../recommendation";
import { finalPrice, rentalPrice, savingsAmount } from "../pricing";
import { ALL_GENRES, ALL_MODES, ALL_PLAYSTYLES, type Game, type Genre, type GameMode, type Playstyle, type SessionBucket, type Structure } from "../types";

/* ————— شکل فشرده بازی برای تزریق در پرامپت ————— */

export interface GameBrief {
  id: string;
  title: string;
  tagline: string;
  genres: string[];
  playstyles: string[];
  structure: string;
  modes: string[];
  sessionMinutes: [number, number];
  campaignHours: [number, number] | null;
  rating: number;
  priceToman: number;
  originalPriceToman: number;
  discountPercent: number;
  savingsToman: number;
  rental: { d1: number; d3: number; d7: number } | null;
  rentalAvailable: boolean;
  trial: string | null;
  indie: boolean;
  available: boolean;
  popularity: number;
  highlights: string[];
  link: string;
}

export function toBrief(g: Game): GameBrief {
  return {
    id: g.id,
    title: g.title,
    tagline: g.tagline,
    genres: [...g.genres],
    playstyles: [...g.playstyles],
    structure: g.structure,
    modes: [...g.modes],
    sessionMinutes: [...g.sessionMinutes],
    campaignHours: g.campaignHours ? [...g.campaignHours] : null,
    rating: g.rating,
    priceToman: finalPrice(g),
    originalPriceToman: g.originalPrice,
    discountPercent: g.discountPercent,
    savingsToman: savingsAmount(g),
    rental: g.rental ? { d1: rentalPrice(g.rental, 1) ?? 0, d3: rentalPrice(g.rental, 3) ?? 0, d7: rentalPrice(g.rental, 7) ?? 0 } : null,
    rentalAvailable: g.rentalAvailable,
    trial: g.trial.kind !== "none" ? g.trial.note : null,
    indie: g.indie,
    available: g.available,
    popularity: g.popularity,
    highlights: [...g.highlights],
    link: `#/game/${g.id}`,
  };
}

/* ————— ۱) جستجو در کاتالوگ ————— */

export function searchCatalogTool(query: string, limit = 6): { query: string; count: number; results: GameBrief[] } {
  const q = query.trim().toLowerCase();
  if (!q) return { query, count: 0, results: [] };
  const scored = GAMES.map((g) => {
    let s = 0;
    const title = g.title.toLowerCase();
    if (title === q) s += 100;
    else if (title.includes(q)) s += 60;
    if (g.tagline.includes(query.trim())) s += 25;
    if (g.description.includes(query.trim())) s += 12;
    if (g.genres.some((x) => x.includes(q) || q.includes(x))) s += 30;
    if (g.playstyles.some((x) => x.includes(q))) s += 20;
    if (g.modes.some((x) => x.includes(q))) s += 18;
    if (g.developer.toLowerCase().includes(q)) s += 22;
    if (g.indie && (q.includes("مستقل") || q.includes("indie"))) s += 15;
    return { g, s };
  })
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s || b.g.popularity - a.g.popularity)
    .slice(0, limit);
  return { query, count: scored.length, results: scored.map((x) => toBrief(x.g)) };
}

/* ————— ۲) فیلتر بودجه (قیمت واقعی کاتالوگ، بدون استثنا) ————— */

export interface BudgetToolOptions {
  maxToman: number;
  intent?: "buy" | "rent" | "either";
  genres?: string[];
  limit?: number;
}

export function byBudgetTool(opts: BudgetToolOptions): {
  budgetToman: number;
  intent: string;
  genres: string[];
  withinBudget: GameBrief[];
  justAboveBudget: GameBrief[];
} {
  const { maxToman, intent = "either", genres = [], limit = 6 } = opts;
  const pool = GAMES.filter((g) => g.available && (genres.length === 0 || g.genres.some((x) => genres.includes(x))));
  const spend = (g: Game) => effectiveSpend(g, intent) ?? finalPrice(g);
  const within = pool
    .filter((g) => spend(g) <= maxToman)
    .sort((a, b) => spend(b) - spend(a)) // نزدیک‌ترین به سقف بودجه = بیشترین ارزش
    .slice(0, limit);
  const above = pool
    .filter((g) => spend(g) > maxToman)
    .sort((a, b) => spend(a) - spend(b)) // نزدیک‌ترین به بودجه برای پیشنهاد اجاره
    .slice(0, 3);
  return {
    budgetToman: maxToman,
    intent,
    genres,
    withinBudget: within.map(toBrief),
    justAboveBudget: above.map(toBrief),
  };
}

/* ————— ۳) جزئیات یک بازی ————— */

export function gameDetailTool(idOrTitle: string): GameBrief | null {
  const direct = getGame(idOrTitle.trim().toLowerCase());
  if (direct) return toBrief(direct);
  const found = searchCatalogTool(idOrTitle, 1);
  return found.results[0] ?? null;
}

/* ————— ۴) مقایسه دو یا چند بازی ————— */

export function compareGamesTool(queries: string[]): { games: GameBrief[]; notFound: string[] } {
  const games: GameBrief[] = [];
  const notFound: string[] = [];
  for (const q of queries.slice(0, 4)) {
    const brief = gameDetailTool(q);
    if (brief && !games.some((g) => g.id === brief.id)) games.push(brief);
    else if (!brief) notFound.push(q);
  }
  return { games, notFound };
}

/* ————— ۵) موتور پیشنهاد (همان موتور پرسش‌نامه — وزن‌های شفاف) ————— */

export interface RecommendToolOptions {
  genres?: string[];
  playstyle?: string | null;
  structure?: string | null;
  mode?: string | null;
  sessionBucket?: string | null;
  budgetToman?: number | null;
  intent?: "buy" | "rent" | "either";
  limit?: number;
}

const SESSION_BUCKETS: SessionBucket[] = ["کوتاه", "متوسط", "بلند"];

export type RecommendationBrief = GameBrief & { matchPercent: number; matched: string[]; tradeoffs: string[] };

export function recommendTool(opts: RecommendToolOptions): { usedWeights: Record<string, number>; results: RecommendationBrief[] } {
  const results = rankGames(
    GAMES,
    {
      genres: (opts.genres ?? []).filter((g): g is Genre => (ALL_GENRES as string[]).includes(g)),
      playstyle: (opts.playstyle && (ALL_PLAYSTYLES as string[]).includes(opts.playstyle) ? opts.playstyle : null) as Playstyle | null,
      structure: (opts.structure && ["دنیای آزاد", "نیمه‌آزاد", "خطی"].includes(opts.structure) ? opts.structure : null) as Structure | null,
      mode: (opts.mode && (ALL_MODES as string[]).includes(opts.mode) ? opts.mode : null) as GameMode | null,
      sessionBucket: (opts.sessionBucket && SESSION_BUCKETS.includes(opts.sessionBucket as SessionBucket) ? opts.sessionBucket : null) as SessionBucket | null,
      budgetToman: typeof opts.budgetToman === "number" && opts.budgetToman > 0 ? Math.min(50_000_000, Math.round(opts.budgetToman)) : null,
      intent: opts.intent ?? "either",
    },
    { limit: opts.limit ?? 5 }
  );
  return {
    usedWeights: { genre: 35, playstyleAndStructure: 25, mode: 15, budget: 15, session: 10 },
    results: results.map((r) => ({ ...toBrief(r.game), matchPercent: r.percentage, matched: r.matched, tradeoffs: r.tradeoffs })),
  };
}

/* ————— ۶) فهرست‌های آماده ————— */

export function dealsTool(limit = 6): GameBrief[] {
  return dealGames()
    .sort((a, b) => b.discountPercent - a.discountPercent)
    .slice(0, limit)
    .map(toBrief);
}

export function rentableTool(limit = 6): GameBrief[] {
  return GAMES.filter((g) => g.available && g.rentalAvailable)
    .sort((a, b) => (a.rental?.d3 ?? 0) - (b.rental?.d3 ?? 0))
    .slice(0, limit)
    .map(toBrief);
}

export function hiddenGemsTool(limit = 5): GameBrief[] {
  return hiddenGems()
    .slice(0, limit)
    .map(toBrief);
}

export function indieTool(limit = 5): GameBrief[] {
  return indieGames()
    .sort((a, b) => b.rating - a.rating)
    .slice(0, limit)
    .map(toBrief);
}

/* ————— ۷) پیشنهاد آرام/چالشی بر اساس کلیدواژه سبک (برای parser قطعی) ————— */

export function byPlaystyleKeyword(message: string, limit = 4): GameBrief[] {
  const hits: Playstyle[] = [];
  if (/آروم|آرام|دلنشین|ریلکس|relax/i.test(message)) hits.push("آرام و دلنشین");
  if (/چالش|سخت|دشوار|سوختن|challenge/i.test(message)) hits.push("چالشی");
  if (/داستان|روایت|story|narrative/i.test(message)) hits.push("داستان‌محور");
  if (/رقابت|رقابتی|حریف|pvp|competitive/i.test(message)) hits.push("رقابتی");
  if (/اکتشاف|گشت|کشف|explore|open.world/i.test(message)) hits.push("اکتشافی");
  if (/تاکتیک|استراتژ|tactic/i.test(message)) hits.push("تاکتیکی");
  if (hits.length === 0) return [];
  const pool = GAMES.filter((g) => g.available && g.playstyles.some((p) => hits.includes(p)));
  return pool.sort((a, b) => b.rating - a.rating).slice(0, limit).map(toBrief);
}

/** تعداد کل کاتالوگ — برای پاسخ به سؤالات آماری */
export function catalogStatsTool(): { total: number; available: number; rentable: number; onSale: number; indie: number; genres: string[] } {
  return {
    total: GAMES.length,
    available: GAMES.filter((g) => g.available).length,
    rentable: GAMES.filter((g) => g.rentalAvailable).length,
    onSale: dealGames().length,
    indie: indieGames().length,
    genres: [...ALL_GENRES],
  };
}
