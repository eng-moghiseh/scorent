"use client";

/* ————— کارت بازی + دیالوگ‌های خرید/اجاره (همه خریدها شبیه‌سازی‌شده‌اند) ————— */

import { useMemo, useState, type ReactNode } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Heart, Info, KeyRound, ShoppingBag } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import type { Game } from "@/lib/types";
import { finalPrice, rentalPrice, savingsAmount } from "@/lib/pricing";
import { useScorent } from "@/lib/store";
import { useFmt, useT, useTx, useUiDir } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { GameCover } from "./game-cover";
import { DiscountBadge, IndieBadge, RatingBadge } from "./shared";
import { Link as RouteLink } from "./router";

export function PriceTag({ game, size = "md" }: { game: Game; size?: "sm" | "md" | "lg" }) {
  const price = finalPrice(game);
  const f = useFmt();
  const t = useT();
  const cls = { sm: "text-sm", md: "text-base", lg: "text-2xl" }[size];
  if (game.price === 0) {
    return <span className={cn("font-extrabold text-rent", cls)}>{t("commerce.free")}</span>;
  }
  return (
    <span className="flex flex-col items-start gap-0.5">
      {game.discountPercent > 0 ? (
        <span className="text-xs text-muted-foreground line-through tnum">{f.toman(game.originalPrice)}</span>
      ) : null}
      <span className={cn("font-extrabold text-foreground tnum", cls)}>{f.toman(price)}</span>
    </span>
  );
}

export function GameCard({ game, index = 0 }: { game: Game; index?: number }) {
  const wishlist = useScorent((s) => s.wishlist);
  const toggleWishlist = useScorent((s) => s.toggleWishlist);
  const wished = wishlist.includes(game.id);
  const t = useT();
  const tx = useTx();

  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.45, delay: Math.min(index * 0.05, 0.3), ease: [0.22, 1, 0.36, 1] }}
      className="group card-hover relative overflow-hidden rounded-2xl border border-border bg-card"
    >
      <RouteLink to={`/game/${game.id}`} className="block" ariaLabel={t("commerce.detailsAria", { game: game.title })}>
        <div className="relative">
          <GameCover game={game} className="aspect-[3/4] w-full transition-transform duration-500 group-hover:scale-[1.04]" />
          <div className="absolute start-2 top-2 flex flex-col items-start gap-1.5">
            {game.discountPercent > 0 ? <DiscountBadge percent={game.discountPercent} /> : null}
            {game.indie ? <IndieBadge className="bg-black/40 backdrop-blur" /> : null}
          </div>
          <div className="absolute end-2 top-2">
            <RatingBadge rating={game.rating} />
          </div>
          {game.rentalAvailable ? (
            <span className="absolute bottom-2 end-2 inline-flex items-center gap-1 rounded-full bg-black/45 px-2 py-0.5 text-[0.68rem] font-bold text-rent backdrop-blur">
              <KeyRound className="size-3" />
              {t("commerce.rentable")}
            </span>
          ) : null}
        </div>
      </RouteLink>

      <button
        type="button"
        onClick={() => {
          const res = toggleWishlist(game.id);
          toast[res === "added" ? "success" : "info"](
            res === "added"
              ? t("commerce.wishAdded", { game: game.title })
              : t("commerce.wishRemoved", { game: game.title })
          );
        }}
        aria-label={wished ? t("commerce.wishRemoveAria") : t("commerce.wishAddAria")}
        className={cn(
          "absolute end-2 bottom-2 z-10 flex size-9 items-center justify-center rounded-full border backdrop-blur transition-all",
          wished
            ? "border-[#ff6b8a]/60 bg-[#ff6b8a]/20 text-[#ff8fa8]"
            : "border-white/15 bg-black/40 text-white/80 hover:border-[#ff6b8a]/50 hover:text-[#ff8fa8]"
        )}
      >
        <Heart className={cn("size-4", wished && "fill-current")} />
      </button>

      <div className="flex items-end justify-between gap-2 p-4">
        <div className="min-w-0">
          <RouteLink to={`/game/${game.id}`} className="block truncate font-bold hover:text-primary">
            {game.title}
          </RouteLink>
          <p className="mt-1 truncate text-xs text-muted-foreground">{game.genres.map(tx).join(" • ")}</p>
        </div>
        <PriceTag game={game} size="sm" />
      </div>
    </motion.article>
  );
}

/* ————— دیالوگ خرید نمایشی ————— */

export function PurchaseDialog({ game, children }: { game: Game; children?: ReactNode }) {
  const [open, setOpen] = useState(false);
  const purchase = useScorent((s) => s.purchase);
  const isOwned = useScorent((s) => s.isOwned(game.id));
  const price = finalPrice(game);
  const saved = savingsAmount(game);
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {isOwned ? (
          <Button variant="secondary" disabled className="gap-2">
            <ShoppingBag className="size-4" /> {t("commerce.inLibrary")}
          </Button>
        ) : (
          <Button className="gap-2" onClick={() => setOpen(true)}>
            <ShoppingBag className="size-4" /> {t("commerce.buyDemo", { what: price === 0 ? t("commerce.free") : t("commerce.demo") })}
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-md" dir={dir}>
        <DialogHeader>
          <DialogTitle>{t("commerce.purchaseTitle")}</DialogTitle>
          <DialogDescription>{t("commerce.purchaseDesc")}</DialogDescription>
        </DialogHeader>
        <div className="flex gap-3 rounded-xl border border-border bg-card p-3">
          <GameCover game={game} showTitle={false} className="h-24 w-18 shrink-0 rounded-lg" />
          <div className="min-w-0 flex-1">
            <p className="font-bold">{game.title}</p>
            <p className="mt-1 text-xs text-muted-foreground">{game.genres.map(tx).join(" • ")}</p>
            <div className="mt-2 flex items-center gap-2">
              <PriceTag game={game} />
              {game.discountPercent > 0 ? <DiscountBadge percent={game.discountPercent} /> : null}
            </div>
          </div>
        </div>
        {game.discountPercent > 0 ? (
          <p className="text-xs text-deal tnum">{t("commerce.savingNote", { amount: f.toman(saved) })}</p>
        ) : null}
        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => setOpen(false)}>
            {t("commerce.cancel")}
          </Button>
          <Button
            onClick={() => {
              const res = purchase(game.id);
              if (res.ok) {
                toast.success(t("commerce.purchaseOk", { game: game.title }), {
                  description: t("commerce.purchaseOkDesc"),
                });
                setOpen(false);
              } else {
                toast.error(tx(res.reason ?? t("commerce.purchaseErr")));
              }
            }}
          >
            {t("commerce.confirmPurchase")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ————— دیالوگ اجاره نمایشی ————— */

export function RentDialog({
  game,
  defaultDays = 3,
  children,
  triggerLabel,
}: {
  game: Game;
  defaultDays?: 1 | 3 | 7;
  children?: ReactNode;
  triggerLabel?: string;
}) {
  const [open, setOpen] = useState(false);
  const [days, setDays] = useState<1 | 3 | 7>(defaultDays);
  const rent = useScorent((s) => s.rent);
  const price = useMemo(() => (game.rental ? rentalPrice(game.rental, days) : null), [game, days]);
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();

  if (!game.rentalAvailable || !game.rental) return null;

  const durations: { d: 1 | 3 | 7 }[] = [{ d: 1 }, { d: 3 }, { d: 7 }];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children ?? (
          <Button variant="outline" className="gap-2 border-rent/40 text-rent hover:bg-rent/10" onClick={() => setOpen(true)}>
            <KeyRound className="size-4" />
            {triggerLabel ?? t("commerce.rent")}
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-md" dir={dir}>
        <DialogHeader>
          <DialogTitle>{t("commerce.rentTitle")}</DialogTitle>
          <DialogDescription>{t("commerce.rentDesc")}</DialogDescription>
        </DialogHeader>

        <div className="flex gap-3 rounded-xl border border-border bg-card p-3">
          <GameCover game={game} showTitle={false} className="h-24 w-18 shrink-0 rounded-lg" />
          <div>
            <p className="font-bold">{game.title}</p>
            <p className="mt-1 text-xs text-muted-foreground">{game.genres.map(tx).join(" • ")}</p>
            <RatingBadge rating={game.rating} className="mt-2" />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label={t("commerce.rentPeriodAria")}>
          {durations.map(({ d }) => (
            <button
              key={d}
              type="button"
              role="radio"
              aria-checked={days === d}
              onClick={() => setDays(d)}
              className={cn(
                "rounded-xl border px-3 py-3 text-center transition-all",
                days === d ? "border-rent bg-rent/12 text-rent glow-rent" : "border-border bg-card hover:border-rent/40"
              )}
            >
              <span className="block text-sm font-extrabold">{t("commerce.dayCount", { n: f.num(d) })}</span>
              <span className="mt-1 block text-[0.7rem] text-muted-foreground tnum">{f.toman(rentalPrice(game.rental!, d) ?? 0)}</span>
            </button>
          ))}
        </div>

        <div className="flex items-center justify-between rounded-xl bg-rent/10 px-4 py-3 text-sm">
          <span className="text-muted-foreground">{t("commerce.rentTotal", { n: f.num(days) })}</span>
          <span className="font-extrabold text-rent tnum">{f.toman(price ?? 0)}</span>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => setOpen(false)}>
            {t("commerce.cancel")}
          </Button>
          <Button
            className="bg-rent text-[#062b18] hover:bg-rent/90"
            onClick={() => {
              const res = rent(game.id, days);
              if (res.ok) {
                toast.success(t("commerce.rentOk", { game: game.title, n: f.num(days) }), {
                  description: t("commerce.rentOkDesc"),
                });
                setOpen(false);
              } else {
                toast.error(tx(res.reason ?? t("commerce.rentErr")));
              }
            }}
          >
            {t("commerce.startRent")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function DemoNotice({ children }: { children?: ReactNode }) {
  const t = useT();
  return (
    <p className="flex items-start gap-2 rounded-xl border border-border bg-card/60 px-3.5 py-3 text-xs leading-6 text-muted-foreground">
      <Info className="mt-0.5 size-4 shrink-0 text-deal" />
      <span>{children ?? t("commerce.demoNotice")}</span>
    </p>
  );
}

export { Link as NextLink };
