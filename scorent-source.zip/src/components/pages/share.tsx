"use client";

/* ————— Scorent Share: بازار اجاره همتا‌به‌همتا (شبیه‌سازی) — دوزبانه —————
 * کمیسیون پلتفرم ۱۰٪ — محاسبات با اعداد صحیح تومان انجام می‌شود.
 * اجاره واقعی به مجوز ناشر و مجوزهای پلتفرم نیاز دارد؛ اینجا فقط شبیه‌سازی است.
 */

import { useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import {
  BadgeCheck,
  Coins,
  HandCoins,
  Info,
  ListPlus,
  Pencil,
  Route as RouteIcon,
  Search,
  Store,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { GameCover } from "@/components/scorent/game-cover";
import { EmptyState, SectionHeader } from "@/components/scorent/shared";
import { Link as RouteLink } from "@/components/scorent/router";
import { GAMES, getGame } from "@/lib/data/games";
import { commissionOf, ownerEarningsOf, PLATFORM_COMMISSION_RATE } from "@/lib/pricing";
import { displayName, useHydrated, useScorent } from "@/lib/store";
import { useFmt, useT, useTx, useUiDir, type Fmt, type TFn } from "@/lib/i18n";
import type { Listing } from "@/lib/types";
import { cn } from "@/lib/utils";

/* ————— اعتبارسنجی فرم (پیام‌ها در زمان ساخت اسکیما با t() دوزبانه می‌شوند) ————— */

const makeListingSchema = (t: TFn, f: Fmt) =>
  z.object({
    gameId: z.string().min(1, t("share.pickGame")),
    ownerName: z
      .string()
      .trim()
      .min(2, t("share.nameMin", { n: f.num(2) }))
      .max(24, t("share.nameMax", { n: f.num(24) })),
    price: z
      .number({ message: t("share.priceRequired") })
      .int(t("share.priceInt"))
      .min(10_000, t("share.priceMin", { n: f.toman(10_000, false) }))
      .max(5_000_000, t("share.priceMax", { n: f.toman(5_000_000, false) })),
    days: z.union([z.literal(1), z.literal(3), z.literal(7)]),
    description: z
      .string()
      .trim()
      .min(10, t("share.descMin", { n: f.num(10) }))
      .max(300, t("share.descMax", { n: f.num(300) })),
  });

type ListingForm = z.infer<ReturnType<typeof makeListingSchema>>;

const DAY_OPTIONS: { v: 1 | 3 | 7; labelKey: string }[] = [
  { v: 1, labelKey: "share.day1" },
  { v: 3, labelKey: "share.day3" },
  { v: 7, labelKey: "share.day7" },
];

/* ————— فرم ساخت/ویرایش آگهی ————— */

function ListingFormDialog({ editing, trigger }: { editing?: Listing; trigger?: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const createListing = useScorent((s) => s.createListing);
  const updateListing = useScorent((s) => s.updateListing);
  const profile = useScorent((s) => s.profile);
  const hydrated = useHydrated();
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();

  const schema = useMemo(() => makeListingSchema(t, f), [t, f]);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors },
  } = useForm<ListingForm>({
    resolver: zodResolver(schema),
    defaultValues: {
      gameId: editing?.gameId ?? "",
      ownerName: editing?.ownerName ?? "",
      price: editing?.price ?? 100_000,
      days: editing?.days ?? 3,
      description: editing?.description ?? "",
    },
  });

  const price = Number(watch("price") || 0);
  const safePrice = Math.max(0, Math.min(5_000_000, Math.round(price)));
  const commission = commissionOf(safePrice);
  const earnings = ownerEarningsOf(safePrice);

  const onSubmit = (data: ListingForm) => {
    if (editing) {
      const res = updateListing(editing.id, { price: data.price, days: data.days, description: data.description });
      if (res.ok) toast.success(t("share.updatedToast"));
      else toast.error(res.reason ? tx(res.reason) : t("share.editErr"));
    } else {
      createListing({ gameId: data.gameId, ownerName: data.ownerName, price: data.price, days: data.days, description: data.description });
      toast.success(t("share.createdToast"), {
        description: t("share.createdToastDesc", { title: tx("کارآفرین"), xp: f.num(25) }),
      });
    }
    setOpen(false);
    if (!editing) reset();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button className="gap-2" onClick={() => hydrated && !editing && setValue("ownerName", displayName(profile))}>
            <ListPlus className="size-4" />
            {t("share.newListing")}
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto" dir={dir}>
        <DialogHeader>
          <DialogTitle>{editing ? t("share.editTitle") : t("share.createTitle")}</DialogTitle>
          <DialogDescription>{t("share.ethicsNote")}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {!editing ? (
            <div className="space-y-1.5">
              <Label htmlFor="sh-game">{t("share.gameLabel")}</Label>
              <Select value={watch("gameId")} onValueChange={(v) => setValue("gameId", v, { shouldValidate: true })} dir={dir}>
                <SelectTrigger id="sh-game" aria-label={t("share.gameSelectAria")}>
                  <SelectValue placeholder={t("share.gamePlaceholder")} />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  {GAMES.filter((g) => g.available).map((g) => (
                    <SelectItem key={g.id} value={g.id}>
                      {g.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.gameId ? <p className="text-xs text-destructive">{errors.gameId.message}</p> : null}
            </div>
          ) : null}

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="sh-owner">{t("share.ownerLabel")}</Label>
              <Input id="sh-owner" {...register("ownerName")} placeholder={t("share.ownerPlaceholder")} />
              {errors.ownerName ? <p className="text-xs text-destructive">{errors.ownerName.message}</p> : null}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sh-price">{t("share.priceLabel")}</Label>
              <Input id="sh-price" type="number" inputMode="numeric" {...register("price", { valueAsNumber: true })} min={10000} max={5000000} step={5000} />
              {errors.price ? <p className="text-xs text-destructive">{errors.price.message}</p> : null}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>{t("share.daysLabel")}</Label>
            <div className="grid grid-cols-3 gap-2">
              {DAY_OPTIONS.map((o) => (
                <button
                  key={o.v}
                  type="button"
                  role="radio"
                  aria-checked={Number(watch("days")) === o.v}
                  onClick={() => setValue("days", o.v, { shouldValidate: true })}
                  className={cn(
                    "rounded-xl border px-3 py-2.5 text-sm font-bold transition-all",
                    Number(watch("days")) === o.v ? "border-ai bg-ai/12 text-[#c4b0f5]" : "border-border hover:border-ai/40"
                  )}
                >
                  {t(o.labelKey)}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="sh-desc">{t("share.descLabel")}</Label>
            <Textarea id="sh-desc" rows={3} {...register("description")} placeholder={t("share.descPlaceholder")} maxLength={300} />
            {errors.description ? <p className="text-xs text-destructive">{errors.description.message}</p> : null}
          </div>

          {/* محاسبه زنده کمیسیون */}
          <div className="rounded-2xl border border-deal/25 bg-deal/5 p-4">
            <p className="mb-2.5 flex items-center gap-1.5 text-xs font-bold text-deal">
              <Coins className="size-3.5" />
              {t("share.earningsEstimate", { n: f.num(PLATFORM_COMMISSION_RATE * 100) })}
            </p>
            <dl className="grid grid-cols-3 gap-2 text-center text-xs">
              <div>
                <dt className="text-muted-foreground">{t("share.rentPriceLabel")}</dt>
                <dd className="mt-1 font-extrabold tnum">{f.toman(safePrice, false)}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">{t("share.platformShare")}</dt>
                <dd className="mt-1 font-extrabold text-deal tnum">{f.toman(commission, false)}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">{t("share.yourEarnings")}</dt>
                <dd className="mt-1 font-extrabold text-rent tnum">{f.toman(earnings, false)}</dd>
              </div>
            </dl>
            <p className="mt-2 text-[0.65rem] leading-5 text-muted-foreground">
              {t("share.commissionPreview", {
                price: f.toman(200_000, false),
                commission: f.toman(commissionOf(200_000), false),
                earnings: f.toman(ownerEarningsOf(200_000), false),
              })}
            </p>
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              {t("share.cancel")}
            </Button>
            <Button type="submit">{editing ? t("share.saveChanges") : t("share.publish")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/* ————— کارت آگهی ————— */

function ListingCard({ listing, index }: { listing: Listing; index: number }) {
  const game = getGame(listing.gameId);
  const rentListing = useScorent((s) => s.rentListing);
  const removeListing = useScorent((s) => s.removeListing);
  const myEarnings = useScorent((s) => s.shareOrders.filter((o) => o.listingId === listing.id).reduce((a, o) => a + o.ownerEarnings, 0));
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();
  if (!game) return null;

  const commission = commissionOf(listing.price);
  const earnings = ownerEarningsOf(listing.price);

  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.04, 0.2) }}
      className={cn(
        "flex flex-col gap-3 rounded-2xl border p-4 sm:flex-row",
        listing.mine ? "border-ai/30 bg-ai/5" : "border-border bg-card",
        !listing.available && "opacity-70"
      )}
    >
      <RouteLink to={`/game/${game.id}`} className="shrink-0 overflow-hidden rounded-xl">
        <GameCover game={game} showTitle={false} className="h-32 w-24" />
      </RouteLink>

      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="truncate font-black" dir="ltr">
              {game.title}
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {t("share.ownerPrefix")} <b className="text-foreground">{listing.ownerName}</b>
              {listing.mine ? <span className="ms-1.5 rounded-full bg-ai/15 px-1.5 py-0.5 text-[0.6rem] text-ai">{t("share.yourListing")}</span> : null}
            </p>
          </div>
          <div className="text-end">
            <p className="text-base font-black text-rent tnum">{f.toman(listing.price)}</p>
            <p className="text-[0.62rem] text-muted-foreground tnum">{t("share.forDays", { n: f.num(listing.days) })}</p>
          </div>
        </div>

        <p className="mt-2 line-clamp-2 text-xs leading-6 text-muted-foreground">{tx(listing.description)}</p>

        <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[0.66rem] text-muted-foreground tnum">
          <span className="flex items-center gap-1">
            <HandCoins className="size-3 text-deal" />
            {t("share.commissionChip", { amount: f.toman(commission, false) })}
          </span>
          <span className="flex items-center gap-1">
            <BadgeCheck className="size-3 text-rent" />
            {t("share.ownerEarningsChip", { amount: f.toman(earnings, false) })}
          </span>
          <span>{t("share.postedAt", { date: f.dateTime(listing.createdAt) })}</span>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          {listing.available ? (
            <Button
              size="sm"
              className="gap-1.5 bg-rent text-[#062b18] hover:bg-rent/90"
              onClick={() => {
                const res = rentListing(listing.id);
                if (res.ok) {
                  toast.success(t("share.rentedToast"), {
                    description: t("share.rentedToastDesc", { c: f.toman(commission), e: f.toman(earnings) }),
                  });
                } else {
                  toast.error(res.reason ? tx(res.reason) : t("share.rentErr"));
                }
              }}
            >
              {t("share.rentThis")}
            </Button>
          ) : (
            <span className="rounded-full bg-secondary px-3 py-1.5 text-[0.65rem] font-bold text-muted-foreground">{t("share.rentedBadge")}</span>
          )}
          {listing.mine ? (
            <>
              <ListingFormDialog
                editing={listing}
                trigger={
                  <Button size="sm" variant="outline" className="gap-1.5">
                    <Pencil className="size-3.5" />
                    {t("share.edit")}
                  </Button>
                }
              />
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button size="sm" variant="ghost" className="gap-1.5 text-destructive hover:bg-destructive/10">
                    <Trash2 className="size-3.5" />
                    {t("share.delete")}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent dir={dir}>
                  <AlertDialogHeader>
                    <AlertDialogTitle>{t("share.deleteTitle", { game: game.title })}</AlertDialogTitle>
                    <AlertDialogDescription>{t("share.deleteDesc")}</AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>{t("share.cancel")}</AlertDialogCancel>
                    <AlertDialogAction
                      className="bg-destructive text-white hover:bg-destructive/90"
                      onClick={() => {
                        removeListing(listing.id);
                        toast.info(t("share.deletedToast"));
                      }}
                    >
                      {t("share.deleteConfirm")}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              {myEarnings > 0 ? (
                <span className="ms-auto rounded-full bg-rent/12 px-3 py-1 text-[0.66rem] font-bold text-rent tnum">
                  {t("share.realEarningsChip", { amount: f.toman(myEarnings, false) })}
                </span>
              ) : null}
            </>
          ) : null}
        </div>
      </div>
    </motion.article>
  );
}

/* ————— صفحه ————— */

export function SharePage() {
  const hydrated = useHydrated();
  const listings = useScorent((s) => s.listings);
  const t = useT();
  const f = useFmt();
  const [q, setQ] = useState("");
  const [onlyAvailable, setOnlyAvailable] = useState(false);

  const filtered = useMemo(() => {
    let list = [...listings];
    if (q.trim()) {
      const needle = q.trim().toLowerCase();
      list = list.filter((l) => {
        const game = getGame(l.gameId);
        return (game?.title.toLowerCase().includes(needle) ?? false) || l.ownerName.includes(needle) || l.description.includes(needle);
      });
    }
    if (onlyAvailable) list = list.filter((l) => l.available);
    return list.sort((a, b) => Number(b.available) - Number(a.available) || b.createdAt - a.createdAt);
  }, [listings, q, onlyAvailable]);

  const mine = listings.filter((l) => l.mine);
  const myPotential = mine.filter((l) => l.available).reduce((a, l) => a + ownerEarningsOf(l.price), 0);
  const myReal = useScorent((s) =>
    s.shareOrders.filter((o) => mine.some((l) => l.id === o.listingId)).reduce((a, o) => a + o.ownerEarnings, 0)
  );

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16">
        <div className="skeleton-shimmer h-48 rounded-3xl" />
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 md:px-6">
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div className="max-w-2xl">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-ai/12 px-3.5 py-1.5 text-xs font-bold text-ai">
            <RouteIcon className="size-3.5" />
            {t("share.p2pBadge")}
          </div>
          <h1 className="text-3xl font-black">{t("share.title")}</h1>
          <p className="mt-2 text-sm leading-7 text-muted-foreground">
            {t("share.subtitle", { n: f.num(PLATFORM_COMMISSION_RATE * 100) })}
          </p>
        </div>
        <div className="flex gap-3">
          <div className="rounded-2xl border border-rent/25 bg-card px-5 py-3 text-center">
            <p className="text-lg font-black text-rent tnum">{f.toman(myPotential, false)}</p>
            <p className="text-[0.62rem] text-muted-foreground">{t("share.potentialEarnings")}</p>
          </div>
          <div className="rounded-2xl border border-deal/25 bg-card px-5 py-3 text-center">
            <p className="text-lg font-black text-deal tnum">{f.toman(myReal, false)}</p>
            <p className="text-[0.62rem] text-muted-foreground">{t("share.realEarnings")}</p>
          </div>
        </div>
      </header>

      <div className="mb-8 flex flex-wrap items-center gap-3">
        <ListingFormDialog />
        <div className="relative min-w-56 flex-1">
          <Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("share.searchPlaceholder")} className="ps-9" aria-label={t("share.searchAria")} />
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2">
          <Switch id="sh-avail" checked={onlyAvailable} onCheckedChange={setOnlyAvailable} />
          <Label htmlFor="sh-avail" className="text-xs">
            {t("share.onlyAvailable")}
          </Label>
        </div>
      </div>

      <section className="mb-10" aria-label={t("share.myListingsAria")}>
        <SectionHeader kicker={t("share.manageKicker")} title={t("share.myListingsTitle")} icon={Store} tone="ai" />
        {mine.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card/40 p-8 text-center">
            <p className="text-sm text-muted-foreground">{t("share.mineEmpty", { n: f.num(25) })}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {mine.map((l, i) => (
              <ListingCard key={l.id} listing={l} index={i} />
            ))}
          </div>
        )}
      </section>

      <section aria-label={t("share.allListingsAria")}>
        <SectionHeader
          kicker={t("share.marketKicker")}
          title={t("share.allListingsTitle", { n: f.num(filtered.length) })}
          description={t("share.sortNote")}
          icon={RouteIcon}
        />
        {filtered.length === 0 ? (
          <EmptyState
            icon={Search}
            title={t("share.noResultsTitle")}
            description={t("share.noResultsDesc")}
            action={<ListingFormDialog />}
          />
        ) : (
          <div className="space-y-3">
            {filtered.map((l, i) => (
              <ListingCard key={l.id} listing={l} index={i} />
            ))}
          </div>
        )}
      </section>

      <p className="mt-8 flex items-start gap-2 rounded-2xl border border-border bg-card/60 p-4 text-xs leading-6 text-muted-foreground">
        <Info className="mt-0.5 size-4 shrink-0 text-deal" />
        {t("share.mathNote", {
          price: f.toman(200_000, false),
          commission: f.toman(commissionOf(200_000), false),
          earnings: f.toman(ownerEarningsOf(200_000), false),
        })}
      </p>
    </div>
  );
}
