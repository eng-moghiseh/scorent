"use client";

/* ————— کاتالوگ اجاره Scorent Rent ————— */

import { motion } from "framer-motion";
import { Clock3, KeyRound, Info, Route as RouteIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { GameCover } from "@/components/scorent/game-cover";
import { RentDialog, DemoNotice } from "@/components/scorent/commerce";
import { EmptyState, RatingBadge, SectionHeader } from "@/components/scorent/shared";
import { Link as RouteLink } from "@/components/scorent/router";
import { GAMES } from "@/lib/data/games";
import { useFmt, useT, useTx } from "@/lib/i18n";
import { rentalPrice } from "@/lib/pricing";
import { useScorent } from "@/lib/store";

const DAYS: (1 | 3 | 7)[] = [1, 3, 7];

function RentCard({ gameId, index }: { gameId: string; index: number }) {
  const game = GAMES.find((g) => g.id === gameId)!;
  const activeRentals = useScorent((s) => s.rentals.filter((r) => r.gameId === gameId && r.status === "active").length);
  const t = useT();
  const f = useFmt();
  const tx = useTx();

  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.45, delay: Math.min(index * 0.04, 0.25) }}
      className="card-hover flex gap-4 rounded-2xl border border-border bg-card p-4"
    >
      <RouteLink to={`/game/${game.id}`} className="group shrink-0 overflow-hidden rounded-xl">
        <GameCover game={game} showTitle={false} className="h-36 w-27 transition-transform duration-500 group-hover:scale-105" />
      </RouteLink>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <RouteLink to={`/game/${game.id}`} className="block truncate font-black hover:text-rent" dir="ltr" style={{ textAlign: "start" }}>
              {game.title}
            </RouteLink>
            <div className="mt-1 flex flex-wrap items-center gap-1.5">
              <RatingBadge rating={game.rating} />
              <span className="text-[0.68rem] text-muted-foreground">{game.genres.slice(0, 2).map(tx).join(" • ")}</span>
            </div>
          </div>
          {activeRentals > 0 ? (
            <span className="shrink-0 rounded-full bg-rent/15 px-2.5 py-1 text-[0.65rem] font-bold text-rent">
              {t("rent.activeRentalChip")}
            </span>
          ) : null}
        </div>

        <div className="mt-3 grid flex-1 grid-cols-3 gap-1.5">
          {DAYS.map((d) => (
            <div key={d} className="rounded-lg border border-border bg-secondary/40 px-2 py-1.5 text-center">
              <p className="text-[0.62rem] text-muted-foreground tnum">{t("rent.dayCount", { n: f.num(d) })}</p>
              <p className="text-xs font-extrabold text-rent tnum">{f.toman(rentalPrice(game.rental!, d) ?? 0, false)}</p>
            </div>
          ))}
        </div>

        <div className="mt-3 flex items-center gap-2">
          <RentDialog game={game} defaultDays={3} triggerLabel={t("rent.startRent")}>
            <Button size="sm" className="gap-1.5 bg-rent text-[#062b18] hover:bg-rent/90">
              <KeyRound className="size-3.5" />
              {t("rent.startRent")}
            </Button>
          </RentDialog>
          <RouteLink to={`/game/${game.id}`} className="text-xs font-bold text-muted-foreground hover:text-foreground">
            {t("rent.detailsLink")}
          </RouteLink>
        </div>
      </div>
    </motion.article>
  );
}

export function RentPage() {
  const rentable = GAMES.filter((g) => g.available && g.rentalAvailable && g.rental);
  const t = useT();
  const f = useFmt();
  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      <header className="mb-8 max-w-2xl">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-rent/12 px-3.5 py-1.5 text-xs font-bold text-rent">
          <KeyRound className="size-3.5" />
          Scorent Rent
        </div>
        <h1 className="text-3xl font-black">{t("rent.pageTitle")}</h1>
        <p className="mt-2 text-sm leading-7 text-muted-foreground">{t("rent.pageDesc")}</p>
      </header>

      <div className="mb-6 flex flex-wrap gap-2 text-xs">
        {[
          { icon: Clock3, k: "rent.chipTimestamp" },
          { icon: Info, k: "rent.chipRenew" },
          { icon: RouteIcon, k: "rent.chipP2p" },
        ].map(({ icon: Icon, k }) => (
          <span key={k} className="flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-muted-foreground">
            <Icon className="size-3.5 text-rent" />
            {t(k)}
          </span>
        ))}
      </div>

      <RouteLink to="/rentals">
        <Button variant="outline" className="mb-8 gap-2">
          <KeyRound className="size-4" />
          {t("rent.myRentals")}
        </Button>
      </RouteLink>

      <SectionHeader
        title={t("rent.catalogTitle")}
        description={t("rent.catalogCount", { n: f.num(rentable.length) })}
        icon={KeyRound}
        tone="rent"
      />
      <div className="grid gap-4 lg:grid-cols-2">
        {rentable.map((g, i) => (
          <RentCard key={g.id} gameId={g.id} index={i} />
        ))}
      </div>

      {rentable.length === 0 ? (
        <EmptyState icon={KeyRound} title={t("rent.emptyTitle")} description={t("rent.emptyDesc")} />
      ) : null}

      <div className="mt-8 max-w-2xl">
        <DemoNotice>{t("rent.demoNotice")}</DemoNotice>
      </div>
    </div>
  );
}
