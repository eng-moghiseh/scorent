import { describe, it, expect } from "vitest";
import { passwordStrength } from "../src/lib/password-strength";
import { can, isStaff, PERM_MATRIX } from "../src/lib/permissions";
import { normalizePhone, isEmail, cleanName, cleanText } from "../src/lib/server/http";

describe("password strength", () => {
  it("scores weak to strong", () => {
    expect(passwordStrength("short")).toBe(0);
    expect(passwordStrength("abcdefgh")).toBe(1);
    expect(passwordStrength("abcdefgh1234")).toBe(2);
    expect(passwordStrength("Abcdefgh1234!@")).toBe(3);
  });
});

describe("permission matrix", () => {
  it("super admin can do everything", () => {
    for (const p of PERM_MATRIX.SUPER_ADMIN) {
      expect(can("SUPER_ADMIN", p)).toBe(true);
    }
  });
  it("admin cannot manage admins", () => {
    expect(can("ADMIN", "admins.manage")).toBe(false);
    expect(can("ADMIN", "users.write")).toBe(true);
  });
  it("content editor limited to content/games", () => {
    expect(can("CONTENT_EDITOR", "content")).toBe(true);
    expect(can("CONTENT_EDITOR", "games")).toBe(true);
    expect(can("CONTENT_EDITOR", "notify")).toBe(false);
  });
  it("support agent limited to tickets", () => {
    expect(can("SUPPORT_AGENT", "tickets")).toBe(true);
    expect(can("SUPPORT_AGENT", "users.delete")).toBe(false);
  });
  it("regular user is not staff", () => {
    expect(isStaff("USER")).toBe(false);
    expect(isStaff("ADMIN")).toBe(true);
    expect(isStaff(undefined)).toBe(false);
  });
});

describe("input validation", () => {
  it("accepts valid emails", () => {
    expect(isEmail("user@example.com")).toBe(true);
    expect(isEmail("not-an-email")).toBe(false);
    expect(isEmail("a@b")).toBe(false);
  });

  it("normalizes iranian phone formats to +98", () => {
    expect(normalizePhone("09123456789")).toBe("+989123456789");
    expect(normalizePhone("9123456789")).toBe("+989123456789");
    expect(normalizePhone("989123456789")).toBe("+989123456789");
    expect(normalizePhone("00989123456789")).toBe("+989123456789");
    expect(normalizePhone("+1 415 555 0100".replace(/\s/g, ""))).toBe("+14155550100");
    expect(normalizePhone("0912")).toBeNull();
    expect(normalizePhone("hello")).toBeNull();
  });

  it("cleans names and texts", () => {
    expect(cleanName("  علی   رضایی ")).toBe("علی رضایی");
    expect(cleanName("a")).toBeNull();
    expect(cleanName("x".repeat(41))).toBeNull();
    expect(cleanText("  سلام  ", 2, 10)).toBe("سلام");
    expect(cleanText("ک", 2, 10)).toBeNull();
  });
});
