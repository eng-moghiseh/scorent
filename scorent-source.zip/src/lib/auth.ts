"use client";

/* ————— استور حساب کاربری + کلاینت API —————
 * وضعیت احراز هویت از /api/auth/me خوانده می‌شود؛ کوکی httpOnly سمت سرور
 * نگه‌داری می‌شود و توکن هرگز در JS در دسترس نیست.
 * ماتریس مجوزها سمت کلاینت فقط برای UI است — اجرای واقعی در API انجام می‌شود.
 */

import { create } from "zustand";
import type { PublicUser } from "@/lib/server/auth-helpers";
import { can as canBase, isStaff as isStaffBase, ROLES as BASE_ROLES } from "@/lib/permissions";

export type { Perm } from "@/lib/permissions";
export const ROLES = BASE_ROLES;
export type AuthUser = PublicUser;

export function can(role: string | undefined, perm: import("@/lib/permissions").Perm): boolean {
  return canBase(role, perm);
}

export function isStaff(role: string | undefined): boolean {
  return isStaffBase(role);
}

interface AuthState {
  user: AuthUser | null;
  ready: boolean;
  refresh: () => Promise<void>;
  setUser: (u: AuthUser | null) => void;
  logout: () => Promise<void>;
}

export const useAuth = create<AuthState>()((set) => ({
  user: null,
  ready: false,
  setUser: (user) => set({ user, ready: true }),
  refresh: async () => {
    try {
      const res = await apiFetch<{ ok: boolean; user: AuthUser | null }>("/api/auth/me", { method: "GET" });
      set({ user: res?.user ?? null, ready: true });
    } catch {
      set({ user: null, ready: true });
    }
  },
  logout: async () => {
    try {
      await apiFetch("/api/auth/logout", { method: "POST" });
    } finally {
      set({ user: null });
    }
  },
}));

/* ————— کلاینت API — ارسال JSON + بررسی Origin + مدیریت ۴۰۱ ————— */

export class ApiError extends Error {
  code: string;
  status: number;
  constructor(code: string, status: number) {
    super(code);
    this.code = code;
    this.status = status;
  }
}

export async function apiFetch<T = Record<string, unknown>>(url: string, init?: RequestInit & { json?: unknown }): Promise<T> {
  const { json, headers, ...rest } = init ?? {};
  const res = await fetch(url, {
    ...rest,
    credentials: "same-origin",
    headers: {
      ...(json !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(headers ?? {}),
    },
    body: json !== undefined ? JSON.stringify(json) : rest.body,
  });
  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    /* پاسخ غیر-JSON */
  }
  if (!res.ok) {
    const code = (data as { error?: string } | null)?.error ?? `HTTP_${res.status}`;
    throw new ApiError(code, res.status);
  }
  return data as T;
}

export const api = {
  get: <T>(url: string) => apiFetch<T>(url, { method: "GET" }),
  post: <T>(url: string, json?: unknown) => apiFetch<T>(url, { method: "POST", json }),
  patch: <T>(url: string, json?: unknown) => apiFetch<T>(url, { method: "PATCH", json }),
  del: <T>(url: string) => apiFetch<T>(url, { method: "DELETE" }),
};

/** نقشه‌ی پیام خطای سرور به کلید دیکشنری */
export const AUTH_ERROR_KEYS: Record<string, string> = {
  RATE_LIMITED: "auth.errRateLimited",
  TOO_MANY_ATTEMPTS: "auth.errTooManyAttempts",
  INVALID_CREDENTIALS: "auth.errInvalidCredentials",
  WEAK_PASSWORD: "auth.errWeakPassword",
  EMAIL_TAKEN: "auth.errEmailTaken",
  PHONE_TAKEN: "auth.errPhoneTaken",
  INVALID_IDENTIFIER: "auth.errInvalidIdentifier",
  INVALID_NAME: "auth.errInvalidName",
  MISSING_FIELDS: "auth.errMissingFields",
  SUSPENDED: "auth.errSuspended",
  WRONG_CODE: "auth.errWrongCode",
  CODE_EXPIRED: "auth.errCodeExpired",
  TOO_MANY_CODES: "auth.errTooManyCodes",
  RESEND_COOLDOWN: "auth.errResendCooldown",
  NO_PENDING_CODE: "auth.errNoPendingCode",
  WRONG_CURRENT: "auth.errWrongCurrent",
  IDENTITY_REQUIRED: "auth.errIdentifierRequired",
  IDENTIFIER_REQUIRED: "auth.errIdentifierRequired",
};
