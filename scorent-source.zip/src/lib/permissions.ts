/* ————— ماتریس سطوح دسترسی — مشترک بین سرور و کلاینت (بدون وابستگی node) —————
 * اجرای واقعی در API سرور انجام می‌شود؛ نسخه‌ی کلاینت فقط برای UI است.
 */

export type Perm =
  | "stats"
  | "users.read"
  | "users.write"
  | "users.delete"
  | "admins.manage"
  | "content"
  | "games"
  | "notify"
  | "tickets"
  | "providers";

export const PERM_MATRIX: Record<string, Perm[]> = {
  SUPER_ADMIN: ["stats", "users.read", "users.write", "users.delete", "admins.manage", "content", "games", "notify", "tickets", "providers"],
  ADMIN: ["stats", "users.read", "users.write", "content", "games", "notify", "tickets", "providers"],
  CONTENT_EDITOR: ["stats", "content", "games"],
  SUPPORT_AGENT: ["stats", "tickets", "users.read"],
};

export const ROLES = ["SUPER_ADMIN", "ADMIN", "CONTENT_EDITOR", "SUPPORT_AGENT", "USER"] as const;
export type Role = (typeof ROLES)[number];

export const STAFF_ROLES: Role[] = ["SUPER_ADMIN", "ADMIN", "CONTENT_EDITOR", "SUPPORT_AGENT"];

export function can(role: string | undefined | null, perm: Perm): boolean {
  if (!role) return false;
  return PERM_MATRIX[role]?.includes(perm) ?? false;
}

export function isStaff(role: string | undefined | null): boolean {
  return Boolean(role && STAFF_ROLES.includes(role as Role));
}

export const PERM_LABELS: { perm: Perm; fa: string; en: string }[] = [
  { perm: "stats", fa: "مشاهده داشبورد", en: "View dashboard" },
  { perm: "users.read", fa: "مشاهده کاربران", en: "View users" },
  { perm: "users.write", fa: "مدیریت کاربران (تعلیق/تأیید)", en: "Manage users (suspend/verify)" },
  { perm: "users.delete", fa: "حذف کاربر", en: "Delete users" },
  { perm: "admins.manage", fa: "مدیریت مدیران و سطوح دسترسی", en: "Manage admins & roles" },
  { perm: "content", fa: "مدیریت محتوای سایت", en: "Manage site content" },
  { perm: "games", fa: "مدیریت بازی‌ها", en: "Manage games" },
  { perm: "notify", fa: "ارسال اعلان و رویداد", en: "Send announcements" },
  { perm: "tickets", fa: "بررسی تیکت‌های پشتیبانی", en: "Handle support tickets" },
  { perm: "providers", fa: "مشاهده وضعیت سرویس‌ها", en: "View provider status" },
];
