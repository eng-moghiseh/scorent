import { describe, expect, it } from "vitest";
import { rankGames, RECOMMENDATION_WEIGHTS, scoreGame } from "../src/lib/recommendation";
import { GAMES, getGame } from "../src/lib/data/games";
import type { Game, Preferences } from "../src/lib/types";

const basePrefs: Preferences = {
  genres: [],
  playstyle: null,
  structure: null,
  mode: null,
  sessionBucket: null,
  budgetToman: null,
  intent: "either",
};

function makeGame(patch: Partial<Game>): Game {
  const template = getGame("hades")!;
  return { ...template, ...patch };
}

describe("recommendation engine (rule-based)", () => {
  it("وزن‌ها مجموعاً ۱۰۰ هستند", () => {
    const sum = Object.values(RECOMMENDATION_WEIGHTS).reduce((a, b) => a + b, 0);
    expect(sum).toBe(100);
  });

  it("همخوانی ژانر نسبت به تعداد ترجیحات نرمال می‌شود", () => {
    const game = makeGame({ genres: ["روگ‌لایت", "اکشن"] });
    const oneOfTwo = scoreGame(game, { ...basePrefs, genres: ["روگ‌لایت", "استراتژیک"] });
    const twoOfTwo = scoreGame(game, { ...basePrefs, genres: ["روگ‌لایت", "اکشن"] });
    expect(oneOfTwo.score).toBeCloseTo(RECOMMENDATION_WEIGHTS.genre / 2, 5);
    expect(twoOfTwo.score).toBeCloseTo(RECOMMENDATION_WEIGHTS.genre, 5);
    expect(twoOfTwo.percentage).toBeGreaterThan(oneOfTwo.percentage);
  });

  it("بودجه سخت: بازی بسیار گران‌تر امتیاز بودجه را از دست می‌دهد و توضیح می‌گیرد", () => {
    const game = makeGame({ originalPrice: 2_000_000, discountPercent: 0 });
    const res = scoreGame(game, { ...basePrefs, budgetToman: 300_000, intent: "buy" });
    expect(res.percentage).toBeLessThan(60);
    expect(res.tradeoffs.join(" ")).toContain("اجاره");
  });

  it("بودجه کافی → امتیاز کامل بودجه", () => {
    const game = makeGame({ originalPrice: 400_000, discountPercent: 0, popularity: 0 });
    const res = scoreGame(game, { ...basePrefs, budgetToman: 500_000, intent: "buy" });
    // بدون ترجیح دیگر: فقط امتیاز بودجه (خنثی بودجه = ۰، پس امتیاز کامل ۱۵ داده می‌شود)
    expect(res.score).toBeCloseTo(RECOMMENDATION_WEIGHTS.budget, 5);
    expect(res.matched.join(" ")).toContain("بودجه");
  });

  it("بدون هیچ ترجیح، خروجی قطعی و مرتب بر اساس محبوبیت است", () => {
    const a = rankGames(GAMES, basePrefs, { limit: 5 });
    const b = rankGames(GAMES, basePrefs, { limit: 5 });
    expect(a.map((r) => r.game.id)).toEqual(b.map((r) => r.game.id));
    expect(a[0].score).toBeGreaterThanOrEqual(a[1].score);
  });

  it("تغییر ترجیحات رتبه‌بندی را عوض می‌کند", () => {
    const before = rankGames(GAMES, { ...basePrefs, genres: ["تیراندازی"] }, { limit: 8 });
    const after = rankGames(GAMES, { ...basePrefs, genres: ["شبیه‌سازی"] }, { limit: 8 });
    expect(before[0].game.id).not.toBe(after[0].game.id);
    expect(before[0].game.genres).toContain("تیراندازی");
    expect(after[0].game.genres).toContain("شبیه‌سازی");
  });

  it("تساوی امتیاز با امتیاز منتقدان و محبوبیت شکسته می‌شود (قطعی)", () => {
    const res = rankGames(GAMES, basePrefs);
    for (let i = 1; i < res.length; i++) {
      const prev = res[i - 1];
      const cur = res[i];
      if (prev.score === cur.score) {
        // prev باید «بهتر» باشد: امتیاز بالاتر ← محبوبیت بالاتر ← شناسه کوچکتر
        const ratingDiff = cur.game.rating - prev.game.rating;
        if (ratingDiff !== 0) {
          expect(ratingDiff).toBeLessThanOrEqual(0);
        } else {
          const popDiff = cur.game.popularity - prev.game.popularity;
          if (popDiff !== 0) {
            expect(popDiff).toBeLessThanOrEqual(0);
          } else {
            expect(prev.game.id.localeCompare(cur.game.id)).toBeLessThanOrEqual(0);
          }
        }
      }
    }
  });

  it("نیت اجاره روی بازی بدون اجاره، توضیح محدودیت می‌دهد", () => {
    const game = makeGame({ rentalAvailable: false, rental: null });
    const res = scoreGame(game, { ...basePrefs, intent: "rent" });
    expect(res.tradeoffs.length).toBeGreaterThanOrEqual(0);
    // بازی بدون اجاره در نیت اجاره، گزینه «ارزان‌ترین» نمی‌شود مگر خرید
    const ranks = rankGames([game], { ...basePrefs, intent: "rent" });
    expect(ranks[0].game.id).toBe(game.id);
  });

  it("درصد بین ۰ تا ۱۰۰ می‌ماند", () => {
    for (const g of GAMES) {
      const r = scoreGame(g, {
        genres: ["اکشن", "نقش‌آفرینی", "ماجرایی", "استراتژیک"],
        playstyle: "چالشی",
        structure: "دنیای آزاد",
        mode: "تک‌نفره",
        sessionBucket: "بلند",
        budgetToman: 100_000,
        intent: "buy",
      });
      expect(r.percentage).toBeGreaterThanOrEqual(0);
      expect(r.percentage).toBeLessThanOrEqual(100);
    }
  });
});
