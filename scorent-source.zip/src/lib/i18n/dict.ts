/* ————— دیکشنری مرکزی — جمع fragments —————
 * هر ناحیه صفحه فایل fragment خودش دارد: dict-core (پوسته/مشترک)،
 * dict-store، dict-game، ... . t() از همین شیء تلفیقی می‌خواند.
 */

import { STR as Core } from "./dict-core";
import { STR as StorePage } from "./dict-store";
import { STR as GamePage } from "./dict-game";
import { STR as RentPages } from "./dict-rent";
import { STR as SharePage } from "./dict-share";
import { STR as DiscoveryPages } from "./dict-discovery";
import { STR as ProfilePages } from "./dict-profile";
import { STR as SettingsPage } from "./dict-settings";
import { STR as AIPage } from "./dict-ai";
import { STR as AuthPage } from "./dict-auth";
import { STR as SupportPage } from "./dict-support";
import { STR as AdminPage } from "./dict-admin";

export const STR: Record<string, [string, string]> = {
  ...Core,
  ...StorePage,
  ...GamePage,
  ...RentPages,
  ...SharePage,
  ...DiscoveryPages,
  ...ProfilePages,
  ...SettingsPage,
  ...AIPage,
  ...AuthPage,
  ...SupportPage,
  ...AdminPage,
};
