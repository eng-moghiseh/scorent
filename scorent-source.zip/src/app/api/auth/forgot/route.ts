/* POST /api/auth/forgot — درخواست کد بازنشانی رمز (پاسخ همیشه ok — ضد شمارش کاربران) */

import type { NextRequest } from "next/server";
import { badRequest, json, readJson, sameOrigin } from "@/lib/server/http";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";
import { findUserByIdentifier, issueOtp } from "@/lib/server/auth-helpers";
import type { OtpKind } from "@/lib/server/auth-helpers";
import { isDemoMode } from "@/lib/server/notify";

interface Body {
  identifier?: string;
}

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  const ip = clientIp(req);
  if (!(await rateLimit(`forgot:${ip}`, 5, 10 * 60_000))) {
    return json({ ok: false, error: "RATE_LIMITED" }, 429);
  }

  const body = await readJson<Body>(req);
  const identifier = typeof body?.identifier === "string" ? body.identifier.trim() : "";
  if (!identifier) return json({ ok: false, error: "INVALID_INPUT" }, 400);

  const user = await findUserByIdentifier(identifier);
  if (user && user.status === "ACTIVE") {
    const kind: OtpKind = "PASSWORD_RESET";
    const { code, demoExposed } = await issueOtp(user, kind);
    /* کد نمایشی فقط در حالت نمایشی و فقط برای حساب موجود — و در production
     * نه کد و نه فلگ simulated برمی‌گردد تا وجود حساب قابل تشخیص نباشد */
    if (demoExposed) return json({ ok: true, simulated: true, demoCode: code });
    return json({ ok: true });
  }
  // پاسخ یکسان تا وجود/عدم وجود حساب قابل تشخیص نباشد
  return json({ ok: true });
}
