"use client";

/* ————— محتوای سایت سمت کلاینت — از /api/content با fallback به پیش‌فرض‌ها ————— */

import { create } from "zustand";
import { DEFAULT_CONTENT } from "@/lib/site-content";

export interface ContentRow {
  key: string;
  valueFa: string;
  valueEn: string;
}

interface SiteContentState {
  rows: ContentRow[];
  loaded: boolean;
  load: () => Promise<void>;
}

function rowsToMap(rows: ContentRow[]): Record<string, ContentRow> {
  return Object.fromEntries(rows.map((r) => [r.key, r]));
}

const store = create<SiteContentState>()((set) => ({
  rows: DEFAULT_CONTENT,
  loaded: false,
  load: async () => {
    try {
      const res = await fetch("/api/content", { cache: "no-cache" });
      const data = (await res.json()) as { ok: boolean; content: ContentRow[] };
      if (data.ok && Array.isArray(data.content) && data.content.length > 0) {
        set({ rows: data.content, loaded: true });
      } else {
        set({ loaded: true });
      }
    } catch {
      set({ loaded: true });
    }
  },
}));

/** مقدار محلی‌شده‌ی یک کلید محتوا؛ اگر ادمین خالی گذاشته باشد پیش‌فرض برمی‌گردد */
export function contentValue(map: Record<string, ContentRow>, key: string, lang: "fa" | "en"): string | null {
  const row = map[key];
  if (!row) return null;
  const v = lang === "en" ? row.valueEn || row.valueFa : row.valueFa || row.valueEn;
  return v.trim() === "" ? null : v;
}

export function useSiteContentMap(): Record<string, ContentRow> {
  const rows = store((s) => s.rows);
  const loaded = store((s) => s.loaded);
  // لود یک‌بار در اولین استفاده
  if (!loaded) void store.getState().load();
  return rowsToMap(rows);
}

export function useContentValue(key: string): string | null {
  const map = useSiteContentMap();
  const lang = (typeof document !== "undefined" && document.documentElement.lang === "en" ? "en" : "fa") as "fa" | "en";
  return contentValue(map, key, lang);
}

export function useBanner(): { enabled: boolean; text: string | null } {
  const map = useSiteContentMap();
  const lang = (typeof document !== "undefined" && document.documentElement.lang === "en" ? "en" : "fa") as "fa" | "en";
  const enabled = (map["banner.enabled"]?.[lang === "en" ? "valueEn" : "valueFa"] ?? "false") === "true";
  const text = contentValue(map, "banner.text", lang);
  return { enabled: enabled && Boolean(text), text: enabled ? text : null };
}

export function useAnnouncementBanner(): { enabled: boolean; text: string | null } {
  return useBanner();
}
