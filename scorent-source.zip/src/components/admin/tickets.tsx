"use client";

/* ————— تیکت‌های پشتیبانی — بررسی، پاسخ (با اطلاع‌رسانی)، وضعیت و اولویت ————— */

import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { LifeBuoy, Search, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { api } from "@/lib/auth";
import { useFmt, useT, useUiDir } from "@/lib/i18n";
import { AdminHeader, AdminError } from "./ui";
import { cn } from "@/lib/utils";

interface TMsg {
  id: string;
  authorName: string;
  authorRole: string;
  body: string;
  createdAt: string;
}
interface TRow {
  id: string;
  subject: string;
  category: string;
  status: string;
  priority: string;
  contact: string;
  guestName: string | null;
  createdAt: string;
  updatedAt: string;
  messages: TMsg[];
  user?: { name: string; email: string | null } | null;
  _count?: { messages: number };
}

function statusCls(status: string): string {
  if (status === "OPEN") return "border-rent/40 bg-rent/10 text-rent";
  if (status === "PENDING") return "border-deal/40 bg-deal/10 text-deal";
  return "border-border bg-secondary text-muted-foreground";
}

export function AdminTickets() {
  const t = useT();
  const f = useFmt();
  const dir = useUiDir();
  const [rows, setRows] = useState<TRow[] | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [detail, setDetail] = useState<TRow | null>(null);
  const [reply, setReply] = useState("");
  const [status, setStatus] = useState("all");
  const [q, setQ] = useState("");
  const [err, setErr] = useState(false);

  const load = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (status !== "all") params.set("status", status);
      if (q.trim()) params.set("q", q.trim());
      const res = await api.get<{ ok: boolean; tickets: TRow[] }>(`/api/admin/tickets?${params.toString()}`);
      setRows(res.tickets);
    } catch {
      setErr(true);
    }
  }, [status, q]);

  useEffect(() => {
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [load]);

  const openDetail = useCallback(async (id: string) => {
    try {
      const res = await api.get<{ ok: boolean; ticket: TRow }>(`/api/admin/tickets/${id}`);
      setDetail(res.ticket);
      setOpenId(id);
    } catch {
      toast.error(t("admin.error"));
    }
  }, [t]);

  async function sendReply() {
    if (!openId || reply.trim().length < 2) return;
    try {
      await api.post(`/api/admin/tickets/${openId}/reply`, { body: reply.trim() });
      setReply("");
      toast.success(t("admin.tickets.replySent"));
      await openDetail(openId);
      void load();
    } catch {
      toast.error(t("admin.error"));
    }
  }

  async function patchTicket(id: string, data: Record<string, unknown>) {
    try {
      await api.patch(`/api/admin/tickets/${id}`, data);
      void load();
      if (openId === id) await openDetail(id);
    } catch {
      toast.error(t("admin.error"));
    }
  }

  if (err) return <AdminError />;

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.tab.tickets")} description={t("support.desc")} icon={LifeBuoy} tone="deal" />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative min-w-56 flex-1">
          <Search className="absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("admin.search")} className="ps-9" />
        </div>
        <Select dir={dir} value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-44" aria-label={t("admin.tickets.setStatus")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.users.all")}</SelectItem>
            <SelectItem value="OPEN">{t("support.status.OPEN")}</SelectItem>
            <SelectItem value="PENDING">{t("support.status.PENDING")}</SelectItem>
            <SelectItem value="CLOSED">{t("support.status.CLOSED")}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {rows === null ? (
        <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-2xl border border-border bg-card" />)}</div>
      ) : rows.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">{t("admin.tickets.empty")}</p>
      ) : (
        <div className="space-y-2.5">
          {rows.map((tk) => (
            <div key={tk.id} className="rounded-2xl border border-border bg-card p-4">
              <button type="button" className="flex w-full flex-wrap items-center justify-between gap-3 text-start" onClick={() => (openId === tk.id ? setOpenId(null) : openDetail(tk.id))} aria-expanded={openId === tk.id}>
                <div className="min-w-0">
                  <p className="truncate text-sm font-extrabold">{tk.subject}</p>
                  <p className="mt-1 text-[0.65rem] text-muted-foreground">
                    <span className="tnum">#{tk.id.slice(-8).toUpperCase()}</span> · {t(`support.cat.${tk.category}`)} ·{" "}
                    {tk.user ? tk.user.name : `${t("admin.tickets.guest")}: ${tk.guestName ?? "—"}`} · {f.dateTime(new Date(tk.updatedAt).getTime())}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  {tk.priority === "HIGH" && <span className="rounded-full border border-destructive/40 bg-destructive/10 px-2 py-0.5 text-[0.6rem] font-extrabold text-destructive">{t("support.priority.HIGH")}</span>}
                  <span className={cn("rounded-full border px-2.5 py-0.5 text-[0.62rem] font-extrabold", statusCls(tk.status))}>{t(`support.status.${tk.status}`)}</span>
                </div>
              </button>

              {openId === tk.id && detail && detail.id === tk.id && (
                <div className="mt-4 border-t border-border pt-4" dir={dir}>
                  <div className="space-y-2.5">
                    {detail.messages.map((m) => (
                      <div key={m.id} className={cn("max-w-[92%] rounded-2xl px-3.5 py-2.5 text-xs leading-6", m.authorRole === "ADMIN" ? "ms-auto border border-ai/30 bg-ai/10" : "me-auto border border-border bg-secondary/50")}>
                        <p className="mb-1 text-[0.62rem] font-extrabold text-muted-foreground">
                          {m.authorRole === "ADMIN" ? t("support.staff") : m.authorName} · {f.dateTime(new Date(m.createdAt).getTime())}
                        </p>
                        <p className="whitespace-pre-wrap">{m.body}</p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    <Select dir={dir} value={detail.status} onValueChange={(v) => patchTicket(tk.id, { status: v })}>
                      <SelectTrigger className="h-9 w-40 text-xs" aria-label={t("admin.tickets.setStatus")}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="OPEN">{t("support.status.OPEN")}</SelectItem>
                        <SelectItem value="PENDING">{t("support.status.PENDING")}</SelectItem>
                        <SelectItem value="CLOSED">{t("support.status.CLOSED")}</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select dir={dir} value={detail.priority} onValueChange={(v) => patchTicket(tk.id, { priority: v })}>
                      <SelectTrigger className="h-9 w-36 text-xs" aria-label={t("admin.tickets.setPriority")}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="LOW">{t("support.priority.LOW")}</SelectItem>
                        <SelectItem value="NORMAL">{t("support.priority.NORMAL")}</SelectItem>
                        <SelectItem value="HIGH">{t("support.priority.HIGH")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {detail.status !== "CLOSED" && (
                    <div className="mt-3 flex gap-2">
                      <Input value={reply} onChange={(e) => setReply(e.target.value)} placeholder={t("admin.tickets.replyPh")} className="flex-1" />
                      <Button size="icon" onClick={() => void sendReply()} aria-label={t("support.sendReply")} className="shrink-0 bg-ai text-white hover:bg-ai/90">
                        <Send className="size-4" />
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
