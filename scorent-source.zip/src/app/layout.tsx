import type { Metadata, Viewport } from "next";
import "@fontsource-variable/vazirmatn";
import "./globals.css";
import { UiEffects } from "@/components/scorent/ui-effects";
import { UI_BOOT_SCRIPT } from "@/lib/i18n";

export const metadata: Metadata = {
  title: {
    default: "Scorent | کشف کن، تجربه کن، بازی کن",
    template: "%s | Scorent",
  },
  description:
    "Scorent پلتفرم کشف و اجاره‌ی بازی است: با دستیار هوشمند متصل به کاتالوگ و موتور پیشنهاد شفاف، بازی بعدی‌ات را با سلیقه، بودجه و زمان خودت پیدا کن؛ اول تجربه کن، بعد با خیال راحت خرید کن.",
  keywords: ["Scorent", "بازی", "اجاره بازی", "پیشنهاد هوشمند بازی", "دستیار AI گیمینگ", "فروشگاه بازی", "کشف بازی"],
  authors: [{ name: "Team Scorent" }],
  applicationName: "Scorent",
  openGraph: {
    title: "Scorent | کشف کن، تجربه کن، بازی کن",
    description:
      "پلتفرم کشف و اجاره‌ی بازی؛ با دستیار هوشمند، کاتالوگ شفاف و اجاره‌ی ۱/۳/۷ روزه، قبل از خرید تجربه کن.",
    siteName: "Scorent",
    type: "website",
    locale: "fa_IR",
  },
};

export const viewport: Viewport = {
  themeColor: "#111318",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        {/* تنظیم زبان/جهت/تم قبل از اولین رنگ‌آمیزی — جلوگیری از FOUC */}
        <script dangerouslySetInnerHTML={{ __html: UI_BOOT_SCRIPT }} />
      </head>
      <body className="antialiased bg-background text-foreground min-h-screen font-sans">
        <UiEffects>{children}</UiEffects>
      </body>
    </html>
  );
}
