/* POST /api/auth/logout — ابطال نشست فعلی */

import type { NextRequest } from "next/server";
import { json, sameOrigin } from "@/lib/server/http";
import { SESSION_COOKIE, revokeSession } from "@/lib/server/session";
import { clearSessionCookie } from "@/lib/server/auth-helpers";

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return json({ ok: false, error: "BAD_ORIGIN" }, 400);
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (token) {
    const dot = token.lastIndexOf(".");
    if (dot > 0) {
      try {
        const payload = JSON.parse(Buffer.from(token.slice(0, dot), "base64url").toString("utf8")) as { jti?: string };
        if (payload.jti) await revokeSession(payload.jti);
      } catch {
        /* توکن خراب — فقط کوکی پاک می‌شود */
      }
    }
  }
  const res = json({ ok: true });
  clearSessionCookie(res);
  return res;
}
