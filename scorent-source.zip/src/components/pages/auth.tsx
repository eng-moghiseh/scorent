"use client";

/* ————— صفحه حساب کاربری: ورود، ثبت‌نام، تأیید کد، بازیابی رمز، گوگل ————— */

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { AlertTriangle, AtSign, Eye, EyeOff, KeyRound, LogIn, Mail, Phone, ShieldCheck, Sparkles, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { ScorentLogo, ScorpionMark } from "@/components/scorent/logo";
import { navigate, useRoute } from "@/components/scorent/router";
import { AUTH_ERROR_KEYS, api, useAuth } from "@/lib/auth";
import type { AuthUser } from "@/lib/auth";
import { useFmt, useT, useUiDir } from "@/lib/i18n";
import { passwordStrength } from "@/lib/password-strength";
import { cn } from "@/lib/utils";

type Step = "login" | "register" | "verify" | "forgot" | "reset";

/* دلیل خطای گوگل → کلید ترجمه */
const GOOGLE_REASON_KEYS: Record<string, string> = {
  access_denied: "auth.googleReasonDenied",
  redirect_uri_mismatch: "auth.googleReasonConfig",
  invalid_client: "auth.googleReasonConfig",
  admin_policy_enforced: "auth.googleReasonConfig",
  not_configured: "auth.googleReasonNotConfigured",
};

function isInIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="size-4.5" aria-hidden>
      <path fill="#4285F4" d="M23.5 12.27c0-.85-.08-1.66-.22-2.45H12v4.64h6.45a5.52 5.52 0 0 1-2.39 3.62v3h3.87c2.26-2.09 3.57-5.17 3.57-8.81Z" />
      <path fill="#34A853" d="M12 24c3.24 0 5.96-1.07 7.94-2.91l-3.87-3c-1.08.72-2.45 1.15-4.07 1.15-3.13 0-5.78-2.11-6.73-4.96H1.29v3.1A12 12 0 0 0 12 24Z" />
      <path fill="#FBBC05" d="M5.27 14.28A7.2 7.2 0 0 1 4.89 12c0-.79.14-1.56.38-2.28v-3.1H1.29a12 12 0 0 0 0 10.76l3.98-3.1Z" />
      <path fill="#EA4335" d="M12 4.77c1.76 0 3.35.61 4.6 1.8l3.42-3.42A11.98 11.98 0 0 0 12 0 12 12 0 0 0 1.29 6.62l3.98 3.1C6.22 6.88 8.87 4.77 12 4.77Z" />
    </svg>
  );
}

function Field({ id, label, icon: Icon, children }: { id: string; label: string; icon: React.ElementType; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground">
        <Icon className="size-3.5 text-ai" /> {label}
      </Label>
      {children}
    </div>
  );
}

export function AuthPage() {
  const t = useT();
  const f = useFmt();
  const dir = useUiDir();
  const route = useRoute();
  const { user, ready, setUser, refresh } = useAuth();

  const [step, setStep] = useState<Step>("login");
  const [tab, setTab] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [pendingKind, setPendingKind] = useState<"EMAIL_VERIFY" | "PHONE_VERIFY">("EMAIL_VERIFY");
  const [pendingTarget, setPendingTarget] = useState("");
  const [verifySimulated, setVerifySimulated] = useState(false);
  const [demoCode, setDemoCode] = useState<string | null>(null);
  const [otp, setOtp] = useState("");
  const [resendIn, setResendIn] = useState(0);
  const [resetCode, setResetCode] = useState("");
  const [forgotSent, setForgotSent] = useState(false);
  const [nextPath, setNextPath] = useState("/");
  const [googleDemo, setGoogleDemo] = useState<boolean | null>(null);

  const isPhone = useMemo(() => {
    const s = identifier.trim();
    return /^[+0-9][0-9\s\-()]{7,}$/.test(s) && !s.includes("@");
  }, [identifier]);

  const strength = passwordStrength(password);

  /* پارامترهای بازگشت از گوگل و next */
  useEffect(() => {
    const g = route.query.get("google");
    const nx = route.query.get("next");
    if (nx && nx.startsWith("/")) setNextPath(nx);
    if (g === "demo") {
      toast.info(t("auth.googleDemoToast"));
      void refresh();
      navigate("/auth", { replace: true });
    } else if (g === "ok") {
      toast.success(t("auth.googleOkToast"));
      void refresh();
      navigate("/auth", { replace: true });
    } else if (g === "embedded") {
      toast.error(t("auth.googleEmbeddedToast"), { duration: 8000 });
      navigate("/auth", { replace: true });
    } else if (g === "rate") {
      toast.error(t("auth.errRateLimited"));
      navigate("/auth", { replace: true });
    } else if (g === "suspended") {
      toast.error(t("auth.googleSuspendedToast"));
    } else if (g === "err") {
      const reason = route.query.get("reason") ?? "";
      toast.error(t(GOOGLE_REASON_KEYS[reason] ?? "auth.googleErrToast"), { duration: 8000 });
    }
  }, []);

  /* وضعیت پیکربندی گوگل — برای یادداشت صادقانه زیر دکمه */
  useEffect(() => {
    let alive = true;
    fetch("/api/auth/google?mode=probe", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d: { configured?: boolean } | null) => {
        if (alive) setGoogleDemo(d ? !d.configured : null);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, []);

  /* شمارش معکوس ارسال مجدد */
  useEffect(() => {
    if (resendIn <= 0) return;
    const id = setInterval(() => setResendIn((v) => Math.max(0, v - 1)), 1000);
    return () => clearInterval(id);
  }, [resendIn]);

  /* اگر کاربر وارد شده و در مرحله فرم است → به مقصد برو */
  useEffect(() => {
    if (ready && user && (step === "login" || step === "register" || step === "forgot")) {
      navigate(nextPath || "/", { replace: true });
    }
  }, [ready, user]);

  function errToast(e: unknown) {
    const code = e instanceof Error ? e.message : "GENERIC";
    toast.error(t(AUTH_ERROR_KEYS[code] ?? "auth.errGeneric"));
  }

  /* گوگل جریان OAuth داخل iframe/وب‌ویو را مسدود می‌کند؛
   * داخل فریم → تب جدید (جریان واقعی) یا همان‌جا (حالت نمایشی)؛
   * بالای صفحه → پیمایش عادی. */
  function handleGoogle(e: React.MouseEvent) {
    e.preventDefault();
    const url = `/api/auth/google?lang=${document.documentElement.lang === "en" ? "en" : "fa"}`;
    if (!isInIframe()) {
      window.location.href = url;
      return;
    }
    if (googleDemo === true) {
      // حالت نمایشی: هیچ تماسی با گوگل در کار نیست — همان‌جا کامل می‌شود
      window.location.href = url;
      return;
    }
    const win = window.open(url, "_blank");
    if (win) {
      try {
        win.opener = null;
      } catch {
        /* ignore */
      }
      toast.info(t("auth.googleNewTabToast"), { duration: 8000 });
      // وقتی تب جدید نشست را ساخت، اینجا هم تلاش می‌کنیم نشست را بگیریم
      for (const d of [2500, 6000, 11000]) setTimeout(() => void refresh(), d);
    } else {
      window.location.href = url;
    }
  }

  async function submitLogin() {
    if (!identifier.trim() || !password) {
      toast.error(t("auth.errMissingFields"));
      return;
    }
    setBusy(true);
    try {
      const res = await api.post<{ ok: boolean; user: AuthUser }>("/api/auth/login", { identifier: identifier.trim(), password });
      setUser(res.user);
      toast.success(t("auth.loginTitle"));
      navigate(nextPath || "/", { replace: true });
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  }

  async function submitRegister() {
    if (!name.trim() || !identifier.trim() || !password) {
      toast.error(t("auth.errMissingFields"));
      return;
    }
    setBusy(true);
    try {
      const res = await api.post<{ ok: boolean; user: AuthUser; verify: { kind: "EMAIL_VERIFY" | "PHONE_VERIFY"; simulated: boolean; demoCode?: string } }>("/api/auth/register", {
        name: name.trim(),
        identifier: identifier.trim(),
        password,
        uiLang: document.documentElement.lang === "en" ? "en" : "fa",
      });
      setUser(res.user);
      setPendingKind(res.verify.kind);
      setPendingTarget(identifier.trim());
      setVerifySimulated(Boolean(res.verify.simulated));
      setDemoCode(res.verify.demoCode ?? null);
      setOtp("");
      setResendIn(90);
      setStep("verify");
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  }

  async function submitVerify() {
    if (otp.length !== 6) return;
    setBusy(true);
    try {
      const res = await api.post<{ ok: boolean; user: AuthUser }>("/api/auth/verify", { kind: pendingKind, code: otp });
      setUser(res.user);
      toast.success(t("auth.verifyOk"));
      navigate(nextPath || "/", { replace: true });
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  }

  async function resendCode() {
    setBusy(true);
    try {
      const res = await api.post<{ ok: boolean; simulated: boolean; demoCode?: string }>("/api/auth/resend", { kind: pendingKind });
      setDemoCode(res.demoCode ?? null);
      setResendIn(90);
      toast.success(t("auth.resend"));
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  }

  async function submitForgot() {
    if (!identifier.trim()) {
      toast.error(t("auth.errIdentifierRequired"));
      return;
    }
    setBusy(true);
    try {
      const res = await api.post<{ ok: boolean; simulated: boolean; demoCode?: string }>("/api/auth/forgot", { identifier: identifier.trim() });
      setForgotSent(true);
      setDemoCode(res.demoCode ?? null);
      setStep("reset");
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  }

  async function submitReset() {
    if (resetCode.length !== 6 || password.length < 8) {
      toast.error(t("auth.errWeakPassword"));
      return;
    }
    setBusy(true);
    try {
      await api.post("/api/auth/reset", { identifier: identifier.trim(), code: resetCode, next: password });
      toast.success(t("auth.resetOk"));
      setStep("login");
      setTab("login");
      setPassword("");
      setResetCode("");
      setDemoCode(null);
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  }

  function switchTab(v: string) {
    setTab(v === "register" ? "register" : "login");
    setStep(v === "register" ? "register" : "login");
    setDemoCode(null);
    setForgotSent(false);
  }

  const brandPanel = (
    <aside className="relative hidden overflow-hidden rounded-3xl border border-border bg-surface p-8 lg:flex lg:flex-col" aria-hidden>
      <div className="pointer-events-none absolute -top-24 -end-24 size-64 rounded-full bg-ai/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -start-24 size-64 rounded-full bg-rent/15 blur-3xl" />
      <div className="relative">
        <ScorentLogo size={40} showTagline />
      </div>
      <div className="relative mt-10 space-y-5">
        {[
          { icon: Mail, text: t("auth.why1") },
          { icon: ShieldCheck, text: t("auth.why2") },
          { icon: Sparkles, text: t("auth.why3") },
        ].map(({ icon: Icon, text }, i) => (
          <motion.div
            key={text}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 + i * 0.12, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="flex items-start gap-3 rounded-2xl border border-border/70 bg-card/60 p-4"
          >
            <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-ai/15 text-ai">
              <Icon className="size-4.5" />
            </span>
            <p className="text-sm font-semibold leading-7 text-foreground/90">{text}</p>
          </motion.div>
        ))}
      </div>
      <div className="relative mt-auto flex items-center gap-3 pt-10 text-muted-foreground">
        <ScorpionMark size={30} />
        <p className="text-xs leading-6">{t("auth.terms")}</p>
      </div>
    </aside>
  );

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 md:px-6 md:py-14">
      <div className="grid items-stretch gap-6 lg:grid-cols-[1.05fr_1fr]">
        {brandPanel}

        <motion.section
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-3xl border border-border bg-card p-6 md:p-8"
          aria-label={t("auth.pageKicker")}
          dir={dir}
        >
          <div className="mb-6 flex items-center justify-between gap-3">
            <div>
              <p className="text-[0.7rem] font-extrabold uppercase tracking-widest text-ai">{t("auth.pageKicker")}</p>
              <h1 className="mt-1 text-2xl font-black">
                {step === "verify" ? t("auth.verifyTitle") : step === "forgot" || step === "reset" ? t("auth.forgotTitle") : tab === "login" ? t("auth.loginTitle") : t("auth.registerTitle")}
              </h1>
            </div>
            <span className="hidden sm:block">
              <ScorpionMark size={38} />
            </span>
          </div>

          {(step === "login" || step === "register") && (
            <Tabs value={tab} onValueChange={switchTab} className="mb-5">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">{t("auth.tabLogin")}</TabsTrigger>
                <TabsTrigger value="register">{t("auth.tabRegister")}</TabsTrigger>
              </TabsList>
            </Tabs>
          )}

          {step === "login" && (
            <div className="space-y-4">
              <Field id="identifier" label={t("auth.identifier")} icon={AtSign}>
                <Input
                  id="identifier"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={t("auth.identifierPh")}
                  autoComplete="username"
                  dir="ltr"
                  className="text-start"
                  onKeyDown={(e) => e.key === "Enter" && submitLogin()}
                />
              </Field>
              <Field id="password" label={t("auth.password")} icon={KeyRound}>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPw ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={t("auth.passwordPh")}
                    autoComplete="current-password"
                    dir="ltr"
                    className="pe-11 text-start"
                    onKeyDown={(e) => e.key === "Enter" && submitLogin()}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw((v) => !v)}
                    aria-label={showPw ? "hide" : "show"}
                    className="absolute inset-y-0 end-3 my-auto flex size-6 items-center justify-center text-muted-foreground hover:text-foreground"
                  >
                    {showPw ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
              </Field>
              <div className="flex justify-end">
                <button type="button" onClick={() => { setStep("forgot"); setDemoCode(null); }} className="text-xs font-bold text-ai hover:underline">
                  {t("auth.forgot")}
                </button>
              </div>
              <Button onClick={submitLogin} disabled={busy} className="w-full bg-ai text-white hover:bg-ai/90">
                <LogIn className="size-4" /> {busy ? t("auth.working") : t("auth.signInBtn")}
              </Button>
            </div>
          )}

          {step === "register" && (
            <div className="space-y-4">
              <Field id="name" label={t("auth.name")} icon={UserRound}>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("auth.namePh")} autoComplete="name" onKeyDown={(e) => e.key === "Enter" && submitRegister()} />
              </Field>
              <Field id="reg-identifier" label={t("auth.identifier")} icon={isPhone ? Phone : AtSign}>
                <Input
                  id="reg-identifier"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={t("auth.identifierPh")}
                  autoComplete="email"
                  dir="ltr"
                  className="text-start"
                  onKeyDown={(e) => e.key === "Enter" && submitRegister()}
                />
                <p className="flex items-center gap-1 text-[0.68rem] text-muted-foreground">
                  {isPhone ? <Phone className="size-3" /> : <Mail className="size-3" />}
                  {isPhone ? t("account.phone") : t("account.email")}
                </p>
              </Field>
              <Field id="reg-password" label={t("auth.password")} icon={KeyRound}>
                <Input
                  id="reg-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t("auth.passwordPh")}
                  autoComplete="new-password"
                  dir="ltr"
                  className="text-start"
                  onKeyDown={(e) => e.key === "Enter" && submitRegister()}
                />
                {password.length > 0 && (
                  <div className="flex items-center gap-2 pt-1">
                    <div className="flex flex-1 gap-1">
                      {[0, 1, 2, 3].map((i) => (
                        <span key={i} className={cn("h-1.5 flex-1 rounded-full transition-colors", i <= strength ? (strength <= 1 ? "bg-destructive" : strength === 2 ? "bg-deal" : "bg-rent") : "bg-border")} />
                      ))}
                    </div>
                    <span className="text-[0.68rem] font-bold text-muted-foreground">{t(`auth.strength.${strength}`)}</span>
                  </div>
                )}
              </Field>
              <Button onClick={submitRegister} disabled={busy} className="w-full bg-rent text-[#062012] hover:bg-rent/90">
                <UserRound className="size-4" /> {busy ? t("auth.working") : t("auth.signUpBtn")}
              </Button>
            </div>
          )}

          {step === "verify" && (
            <div className="space-y-5">
              <p className="text-sm leading-7 text-muted-foreground">
                {t(pendingKind === "EMAIL_VERIFY" ? "auth.verifyEmailDesc" : "auth.verifyPhoneDesc", { target: pendingTarget })}
              </p>
              {verifySimulated && !demoCode && (
                <div className="flex items-start gap-2 rounded-2xl border border-deal/40 bg-deal/10 p-3 text-xs leading-6 text-deal" role="alert">
                  <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                  <span>{t("auth.noProviderNote")}</span>
                </div>
              )}
              <div dir="ltr" className="flex justify-center py-2">
                <InputOTP maxLength={6} value={otp} onChange={setOtp}>
                  <InputOTPGroup>
                    {[0, 1, 2, 3, 4, 5].map((i) => (
                      <InputOTPSlot key={i} index={i} />
                    ))}
                  </InputOTPGroup>
                </InputOTP>
              </div>
              {demoCode && (
                <div className="flex items-start gap-2 rounded-2xl border border-deal/40 bg-deal/10 p-3 text-xs leading-6 text-deal" role="note">
                  <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                  <span>
                    {t("auth.demoCodeNote")} <b dir="ltr" className="tnum">{f.num(demoCode)}</b>
                  </span>
                </div>
              )}
              <Button onClick={submitVerify} disabled={busy || otp.length !== 6} className="w-full bg-ai text-white hover:bg-ai/90">
                <ShieldCheck className="size-4" /> {busy ? t("auth.working") : t("auth.verifyBtn")}
              </Button>
              <div className="flex items-center justify-between text-xs font-bold">
                <button type="button" disabled={resendIn > 0 || busy} onClick={resendCode} className="text-ai disabled:text-muted-foreground disabled:no-underline hover:underline">
                  {resendIn > 0 ? t("auth.resendIn", { n: f.num(resendIn) }) : t("auth.resend")}
                </button>
                <button type="button" onClick={() => { navigate(nextPath || "/", { replace: true }); }} className="text-muted-foreground hover:text-foreground">
                  {t("auth.verifyLater")}
                </button>
              </div>
            </div>
          )}

          {(step === "forgot" || (step === "reset" && !forgotSent)) && (
            <div className="space-y-4">
              <p className="text-sm leading-7 text-muted-foreground">{t("auth.forgotDesc")}</p>
              <Field id="forgot-id" label={t("auth.identifier")} icon={AtSign}>
                <Input id="forgot-id" value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder={t("auth.identifierPh")} dir="ltr" className="text-start" />
              </Field>
              <Button onClick={submitForgot} disabled={busy} className="w-full bg-ai text-white hover:bg-ai/90">
                <Mail className="size-4" /> {busy ? t("auth.working") : t("auth.sendCode")}
              </Button>
              <button type="button" onClick={() => { setStep("login"); setTab("login"); }} className="mx-auto flex w-full justify-center text-xs font-bold text-muted-foreground hover:text-foreground">
                {t("auth.backToLogin")}
              </button>
            </div>
          )}

          {step === "reset" && forgotSent && (
            <div className="space-y-4">
              <p className="text-sm leading-7 text-muted-foreground">{t("auth.forgotSent")}</p>
              <Field id="reset-code" label={t("auth.resetCode")} icon={KeyRound}>
                <Input id="reset-code" value={resetCode} onChange={(e) => setResetCode(e.target.value.replace(/\D/g, "").slice(0, 6))} dir="ltr" className="text-center text-lg tracking-[0.5em] tnum" inputMode="numeric" maxLength={6} />
              </Field>
              {demoCode && (
                <div className="flex items-start gap-2 rounded-2xl border border-deal/40 bg-deal/10 p-3 text-xs leading-6 text-deal" role="note">
                  <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                  <span>
                    {t("auth.demoCodeNote")} <b dir="ltr" className="tnum">{f.num(demoCode)}</b>
                  </span>
                </div>
              )}
              <Field id="new-password" label={t("auth.newPassword")} icon={KeyRound}>
                <Input id="new-password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder={t("auth.passwordPh")} dir="ltr" className="text-start" autoComplete="new-password" />
              </Field>
              <Button onClick={submitReset} disabled={busy} className="w-full bg-ai text-white hover:bg-ai/90">
                <KeyRound className="size-4" /> {busy ? t("auth.working") : t("auth.resetBtn")}
              </Button>
              <button type="button" onClick={() => { setStep("login"); setTab("login"); setDemoCode(null); }} className="mx-auto flex w-full justify-center text-xs font-bold text-muted-foreground hover:text-foreground">
                {t("auth.backToLogin")}
              </button>
            </div>
          )}

          {(step === "login" || step === "register") && (
            <>
              <div className="my-5 flex items-center gap-3 text-[0.68rem] font-bold text-muted-foreground" role="separator">
                <span className="h-px flex-1 bg-border" />
                {t("auth.orDivider")}
                <span className="h-px flex-1 bg-border" />
              </div>
              <a href={`/api/auth/google?lang=${document.documentElement.lang === "en" ? "en" : "fa"}`} onClick={handleGoogle} className="flex h-11 w-full items-center justify-center gap-2.5 rounded-xl border border-border bg-secondary/50 text-sm font-extrabold transition-colors hover:bg-secondary" aria-label={t("auth.googleBtn")}>
                <GoogleIcon />
                {t("auth.googleBtn")}
              </a>
              {googleDemo === true && (
                <p className="mt-2 text-center text-[0.68rem] leading-5 text-muted-foreground" role="note">
                  {t("auth.googleDemoNote")}
                </p>
              )}
              <p className="mt-5 text-center text-xs font-bold text-muted-foreground">
                {tab === "login" ? t("auth.noAccount") : t("auth.hasAccount")}{" "}
                <button type="button" onClick={() => switchTab(tab === "login" ? "register" : "login")} className="text-ai hover:underline">
                  {tab === "login" ? t("auth.goRegister") : t("auth.goLogin")}
                </button>
              </p>
            </>
          )}
        </motion.section>
      </div>
    </div>
  );
}
