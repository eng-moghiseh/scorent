# Scorent i18n Conversion Guide (Persian → Bilingual fa/en)

Scorent is being converted from Persian-only to bilingual (fa/en). The infrastructure is DONE and working. Your job: convert assigned page files to use it, and put your new dictionary keys in YOUR assigned fragment file.

## Infrastructure (read-only, do NOT modify)

- `src/lib/i18n.ts` — helpers. `src/lib/i18n/dict.ts` — aggregator (do not touch).
- `src/lib/i18n/en-map.ts` — reverse map: static Persian data-layer strings → English (genres, playstyles, structures, modes, session buckets, achievement titles/descriptions, weekly challenge titles/descriptions, store error reasons, seed listing/review texts, community activity texts, level names, demo notes, "گیمر مهمان" → "Guest Gamer").
- `src/lib/i18n/catalog-en.ts` — English tagline/description/highlights for all 28 games.

## Helper API — import from "@/lib/i18n"

```ts
import { useT, useTx, useFmt, useLang, useUiDir, useGameText } from "@/lib/i18n";

// at top of EACH component:
const t = useT();     // t("ns.key", { param: value }) → string; params replace {name} tokens
const tx = useTx();   // tx(persianDataString) → English equivalent when locale=en, else unchanged
const f = useFmt();   // locale-aware formatting:
//   f.num(1200)            → "۱٬۲۰۰" | "1,200"   (accepts number | string)
//   f.toman(560000)        → "۵۶۰٬۰۰۰ تومان" | "560,000 Toman"; f.toman(v, false) omits unit
//   f.percent(20)          → "٪۲۰" | "20%"
//   f.rating(4.8)          → "۴٫۸" | "4.8"
//   f.minutes([90,120])    → "۹۰ تا ۱۲۰ دقیقه" | "90–120 min"
//   f.hours([45,60])       → "۴۵ تا ۶۰ ساعت" | "45–60 h" (null-safe)
//   f.remaining(ms)        → "۲ روز و ۵ ساعت" | "2 days and 5 hours" / "Ended"
//   f.date(ts), f.dateTime(ts)
//   f.group(1200000)       → grouped digits without unit
const dir = useUiDir(); // "rtl" | "ltr" — use for dir={dir} on Sheet/Dialog/DropdownMenu
const lang = useLang(); // "fa" | "en" — only if you truly need branching
const gt = useGameText(game); // → { tagline, description, highlights } in the active language
```

## Conversion rules

1. **UI literals** — every Persian UI string (headings, buttons, labels, descriptions, toasts, aria-labels, titles) becomes `t("ns.key")`. Persian strings with embedded dynamic values become keys with params: `t("ns.key", { game: game.title, n: f.num(days) })` and the dict entry contains `{game}` / `{n}` tokens.
2. **Dict fragments** — add keys to YOUR fragment file (e.g. `src/lib/i18n/dict-store.ts`), format:
```ts
export const STR: Record<string, [string, string]> = {
  "store.title": ["فروشگاه Scorent", "Scorent Store"],
  "store.count": ["{n} بازی پیدا شد", "{n} games found"],
};
```
   - [0] = exact Persian original (copy it verbatim), [1] = natural, professional English. No machine-y translations. Keep Persian tone in fa, and write idiomatic EN in en.
3. **Numbers** — replace `toFaDigits(x)` → `f.num(x)`, `formatToman(x)` → `f.toman(x)`, `formatPercentFa(x)` → `f.percent(x)`, `formatRatingFa(x)` → `f.rating(x)`, `formatMinutesFa` → `f.minutes`, `formatHoursFa` → `f.hours`, `formatRemainingFa` → `f.remaining`, `formatDateFa` → `f.date`, `formatDateTimeFa` → `f.dateTime`. Remove now-unused imports from "@/lib/format".
4. **Data-layer strings** (values coming from the dataset/store, not UI): wrap with `tx(...)`:
   - `game.genres.join(" • ")` → `game.genres.map(tx).join(" • ")`
   - genre/playstyle/structure/mode/session-bucket chips and labels → `tx(value)`
   - achievement `def.title`/`def.description`, challenge `ch.title`/`ch.description` → `tx(...)`
   - store action `res.reason` → `tx(res.reason)` (all reasons are already in en-map)
   - seed review `r.text`, listing `l.description`, community activity `a.text`, `COMMUNITY_NOTE`, `DEMO_DATA_NOTE` → `tx(...)`
   - author/usernames: do NOT translate.
5. **Catalog text**: `game.tagline` / `game.description` / `game.highlights` → use `const gt = useGameText(game);` and render `gt.tagline` etc.
6. **Direction props**: `dir="rtl"` on `<SheetContent>`, `<DialogContent>`, `<DropdownMenu>` → `dir={dir}`.
7. **LTR titles**: `dir="ltr"` spans/p with `style={{ textAlign: "right" }}` → remove the textAlign style (or change to `"start"`). Keep `dir="ltr"` on English-only titles.
8. **Persian digits INSIDE literal strings**: e.g. `"بازه ۷ روزه"` in UI copy → move the number into the key with param `f.num(7)`.
9. **Module-level arrays with Persian labels** (e.g. filter option lists, tab definitions): either move inside the component and use `t()` there, or store a `key` field and resolve at render: `OPTS.map(o => ({ ...o, label: t(o.key) }))`.
10. **Do NOT change**: logic, layout, class names, colors, motion, data files, routing. Strings + i18n wiring only.
11. **Toast strings**: use `t()` with params the same way.
12. **Quotation marks**: fa keeps «…», en uses “…”.
13. **Numbers as Latin in EN mode**: never hardcode Persian digits in new dict EN strings; use `{n}` params fed with `f.num(...)`.

## Self-check (MANDATORY before you finish)

```bash
cd /home/z/my-project
npx tsc --noEmit 2>&1 | grep -E '^src/'   # must print NOTHING for your files
npx eslint src/components/pages/<your files> 2>&1 | tail -20
```
Fix all errors/warnings you introduced. Pre-existing warnings in other files: ignore.

## Reference implementation

Read `src/components/pages/home.tsx` (already converted) as the canonical pattern, and `src/lib/i18n/dict-core.ts` for dict style (the "home.*" namespace is there).

## Parallel-safety

Other agents are converting other pages simultaneously. ONLY touch: your assigned page files + your assigned fragment file. Do not edit dict.ts, dict-core.ts, i18n.ts, en-map.ts, catalog-en.ts, or any file outside your assignment.
