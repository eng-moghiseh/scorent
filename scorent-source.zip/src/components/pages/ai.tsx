"use client";

/* ————— Scorent AI: پرسش‌نامه و نتایج (دوزبانه) —————
 * موتور امتیازدهی «قاعده‌محور و قابل توضیح» است (نه مدل آموزش‌دیده).
 * معماری آماده اتصال به API هوش مصنوعی واقعی در آینده است.
 */

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Clock3,
  Gamepad2,
  Layers,
  MessageCircle,
  RotateCcw,
  Sparkles,
  Wallet,
  Wand2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { PurchaseDialog, RentDialog } from "@/components/scorent/commerce";
import { GameCover } from "@/components/scorent/game-cover";
import { EmptyState, GenreChip, RatingBadge, SectionHeader } from "@/components/scorent/shared";
import { Link as RouteLink, navigate } from "@/components/scorent/router";
import { GAMES } from "@/lib/data/games";
import { rankGames, type ScoreResult } from "@/lib/recommendation";
import { ALL_GENRES, ALL_MODES, ALL_PLAYSTYLES, type GameMode, type Playstyle, type Preferences, type Structure } from "@/lib/types";
import { useFmt, useLang, useT, useTx } from "@/lib/i18n";
import { useHydrated, useScorent } from "@/lib/store";
import { cn } from "@/lib/utils";

const STEPS = [
  { id: 0, titleKey: "ai.step1Title", icon: Layers, descKey: "ai.step1Desc" },
  { id: 1, titleKey: "ai.step2Title", icon: Wand2, descKey: "ai.step2Desc" },
  { id: 2, titleKey: "ai.step3Title", icon: Clock3, descKey: "ai.step3Desc" },
  { id: 3, titleKey: "ai.step4Title", icon: Wallet, descKey: "ai.step4Desc" },
] as const;

const STRUCTURES: Structure[] = ["دنیای آزاد", "نیمه‌آزاد", "خطی"];
const SESSION_BUCKETS: { v: Preferences["sessionBucket"]; hintKey: string }[] = [
  { v: "کوتاه", hintKey: "ai.sessionShortHint" },
  { v: "متوسط", hintKey: "ai.sessionMediumHint" },
  { v: "بلند", hintKey: "ai.sessionLongHint" },
];
const MODES: GameMode[] = ALL_MODES;

const DEFAULT_PREFS: Preferences = {
  genres: [],
  playstyle: null,
  structure: null,
  mode: null,
  sessionBucket: null,
  budgetToman: null,
  intent: "either",
};

const BUDGET_PRESETS = [500_000, 1_000_000, 2_000_000];

export function AIPage() {
  const hydrated = useHydrated();
  const savedPrefs = useScorent((s) => s.prefs);
  const setPrefs = useScorent((s) => s.setPrefs);
  const completeAI = useScorent((s) => s.completeAI);
  const aiCompleted = useScorent((s) => s.aiCompleted);

  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState<Preferences | null>(null);
  const [started, setStarted] = useState(false);

  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const lang = useLang();

  const prefs: Preferences = draft ?? savedPrefs ?? DEFAULT_PREFS;

  const results: ScoreResult[] = useMemo(() => rankGames(GAMES, prefs, { limit: 6, lang }), [prefs, lang]);
  const hasAnyPref =
    prefs.genres.length > 0 || prefs.playstyle !== null || prefs.structure !== null || prefs.mode !== null || prefs.sessionBucket !== null || prefs.budgetToman !== null;

  const update = (patch: Partial<Preferences>) =>
    setDraft((d) => ({ ...(d ?? savedPrefs ?? DEFAULT_PREFS), ...patch }));

  const finish = () => {
    setPrefs(prefs);
    completeAI();
    setStarted(false);
  };

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16">
        <div className="skeleton-shimmer h-64 rounded-3xl" />
      </div>
    );
  }

  /* نمایش نتایج: تا وقتی کاربر «ویرایش» را نزده و پاسخ ذخیره‌شده دارد */
  const showResults = !started && savedPrefs !== null;

  /* ————— نتایج ————— */
  if (showResults) {
    return (
      <div className="mx-auto w-full max-w-5xl px-4 py-10 md:px-6">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-ai/12 px-3.5 py-1.5 text-xs font-bold text-ai">
              <Sparkles className="size-3.5" />
              {t("ai.resultsBadge")}
            </div>
            <h1 className="text-3xl font-black">{t("ai.resultsTitle")}</h1>
            <p className="mt-2 max-w-2xl text-sm leading-7 text-muted-foreground">
              {hasAnyPref ? t("ai.resultsDescPrefs") : t("ai.resultsDescNoPrefs")}
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setStarted(true);
                setStep(0);
              }}
              className="gap-2"
            >
              <RotateCcw className="size-4" />
              {t("ai.editAnswers")}
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate("/ai-chat")}
              className="gap-2 border-ai/40 text-ai hover:bg-ai/10"
            >
              <MessageCircle className="size-4" />
              {t("ai.chatWithAssistant")}
            </Button>
          </div>
        </div>

        {/* خلاصه پاسخ‌ها */}
        <div className="mb-8 flex flex-wrap gap-2">
          {prefs.genres.map((g) => (
            <GenreChip key={g} label={tx(g)} tone="ai" />
          ))}
          {prefs.playstyle ? <GenreChip label={t("ai.chipStyle", { v: tx(prefs.playstyle) })} tone="ai" /> : null}
          {prefs.structure ? <GenreChip label={t("ai.chipStructure", { v: tx(prefs.structure) })} tone="ai" /> : null}
          {prefs.mode ? <GenreChip label={tx(prefs.mode)} tone="ai" /> : null}
          {prefs.sessionBucket ? <GenreChip label={t("ai.chipSession", { v: tx(prefs.sessionBucket) })} tone="ai" /> : null}
          {prefs.budgetToman !== null ? <GenreChip label={t("ai.chipBudget", { v: f.toman(prefs.budgetToman) })} tone="ai" /> : null}
          <GenreChip label={prefs.intent === "buy" ? t("ai.intentBuy") : prefs.intent === "rent" ? t("ai.intentRent") : t("ai.intentEither")} tone="ai" />
        </div>

        <div className="space-y-4">
          {results.map((r, i) => (
            <motion.article
              key={r.game.id}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06, duration: 0.45 }}
              className="grid gap-4 rounded-3xl border border-border bg-card p-4 sm:grid-cols-[140px_1fr]"
            >
              <RouteLink to={`/game/${r.game.id}`} className="group relative overflow-hidden rounded-2xl">
                <GameCover game={r.game} className="aspect-[3/4] w-full transition-transform duration-500 group-hover:scale-105" />
                <span className="absolute start-2 top-2 flex size-7 items-center justify-center rounded-full bg-black/60 text-xs font-black text-ai tnum">
                  {f.num(i + 1)}
                </span>
              </RouteLink>

              <div className="min-w-0">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <RouteLink to={`/game/${r.game.id}`} className="text-lg font-black hover:text-ai" dir="ltr" style={{ textAlign: "start" }}>
                      {r.game.title}
                    </RouteLink>
                    <div className="mt-1.5 flex flex-wrap items-center gap-2">
                      <RatingBadge rating={r.game.rating} />
                      {r.game.genres.slice(0, 2).map((g) => (
                        <GenreChip key={g} label={tx(g)} />
                      ))}
                      {r.game.indie ? <GenreChip label={t("shared.indie")} tone="rent" /> : null}
                    </div>
                  </div>

                  {/* درصد همخوانی */}
                  <div className="flex items-center gap-3">
                    <div className="text-end">
                      <p className="text-2xl font-black text-ai tnum">{f.percent(r.percentage)}</p>
                      <p className="text-[0.62rem] text-muted-foreground">{t("ai.matchWithYou")}</p>
                    </div>
                    <div className="relative size-14" aria-hidden>
                      <svg viewBox="0 0 36 36" className="size-full -rotate-90">
                        <circle cx="18" cy="18" r="15.5" fill="none" stroke="#303541" strokeWidth="3.5" />
                        <motion.circle
                          cx="18"
                          cy="18"
                          r="15.5"
                          fill="none"
                          stroke="#8B5CF6"
                          strokeWidth="3.5"
                          strokeLinecap="round"
                          strokeDasharray={97.4}
                          initial={{ strokeDashoffset: 97.4 }}
                          animate={{ strokeDashoffset: 97.4 * (1 - r.percentage / 100) }}
                          transition={{ duration: 0.9, delay: 0.2 + i * 0.06, ease: "easeOut" }}
                        />
                      </svg>
                    </div>
                  </div>
                </div>

                {/* دلایل و توضیح تجاری */}
                <div className="mt-3 grid gap-2 md:grid-cols-2">
                  <ul className="space-y-1">
                    {r.matched.slice(0, 3).map((m) => (
                      <li key={m} className="flex items-start gap-1.5 text-xs leading-6 text-rent/90">
                        <Check className="mt-1 size-3 shrink-0" />
                        {m}
                      </li>
                    ))}
                  </ul>
                  <ul className="space-y-1">
                    {r.tradeoffs.slice(0, 2).map((tf) => (
                      <li key={tf} className="flex items-start gap-1.5 text-xs leading-6 text-[#f2b545]">
                        <span className="mt-[7px] size-1.5 shrink-0 rounded-full bg-[#f2b545]" />
                        {tf}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <RouteLink to={`/game/${r.game.id}`}>
                    <Button size="sm" variant="outline">
                      {t("ai.details")}
                    </Button>
                  </RouteLink>
                  <PurchaseDialog game={r.game}>
                    <Button size="sm" variant="secondary">
                      {t("ai.demoBuy")}
                    </Button>
                  </PurchaseDialog>
                  {r.game.rentalAvailable ? (
                    <RentDialog game={r.game} defaultDays={3}>
                      <Button size="sm" variant="outline" className="border-rent/40 text-rent hover:bg-rent/10">
                        {t("ai.rent")}
                      </Button>
                    </RentDialog>
                  ) : null}
                </div>
              </div>
            </motion.article>
          ))}
        </div>

        {!hasAnyPref ? (
          <div className="mt-6">
            <EmptyState
              icon={Sparkles}
              title={t("ai.emptyTitle")}
              description={t("ai.emptyDesc")}
              action={
                <Button onClick={() => setStarted(true)} className="gap-2 bg-ai text-white hover:bg-ai/90">
                  {t("ai.fillQuiz")}
                </Button>
              }
            />
          </div>
        ) : null}

        <p className="mt-8 rounded-2xl border border-ai/20 bg-ai/5 p-4 text-xs leading-6 text-ai">
          {t("ai.transparency")}
        </p>
      </div>
    );
  }

  /* ————— پرسش‌نامه ————— */
  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-10 md:px-6">
      <div className="mb-8 text-center">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-ai/12 px-4 py-1.5 text-xs font-bold text-ai">
          <Sparkles className="size-3.5" />
          {aiCompleted ? t("ai.welcomeBack") : "Scorent AI"}
        </div>
        <h1 className="text-3xl font-black">
          {t("ai.quizTitlePre")} <span className="text-gradient-ai">{t("ai.quizTitleGrad")}</span>
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-sm leading-7 text-muted-foreground">{t("ai.quizDesc")}</p>
      </div>

      {/* نشانگر پیشرفت */}
      <ol className="mb-8 flex items-center gap-2" aria-label={t("ai.stepsAria")}>
        {STEPS.map((s, i) => (
          <li key={s.id} className="flex flex-1 flex-col gap-1.5">
            <div className={cn("h-1.5 rounded-full transition-colors", i <= step ? "bg-ai" : "bg-secondary")} />
            <span className={cn("text-[0.65rem] font-bold", i === step ? "text-ai" : "text-muted-foreground")}>{t(s.titleKey)}</span>
          </li>
        ))}
      </ol>

      <AnimatePresence mode="wait">
        <motion.section
          key={step}
          initial={{ opacity: 0, x: -24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 24 }}
          transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-3xl border border-border bg-card p-6"
          aria-label={t(STEPS[step].titleKey)}
        >
          <div className="mb-5 flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-2xl bg-ai/12 text-ai">
              {(() => {
                const Icon = STEPS[step].icon;
                return <Icon className="size-5" />;
              })()}
            </span>
            <div>
              <h2 className="font-extrabold">{t(STEPS[step].titleKey)}</h2>
              <p className="text-xs text-muted-foreground">{t(STEPS[step].descKey)}</p>
            </div>
          </div>

          {step === 0 ? (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {ALL_GENRES.map((g) => {
                const active = prefs.genres.includes(g);
                return (
                  <button
                    key={g}
                    type="button"
                    aria-pressed={active}
                    onClick={() =>
                      update({
                        genres: active ? prefs.genres.filter((x) => x !== g) : [...prefs.genres, g],
                      })
                    }
                    className={cn(
                      "rounded-xl border px-3 py-3 text-sm font-bold transition-all",
                      active ? "border-ai bg-ai/15 text-ai" : "border-border bg-secondary/40 hover:border-ai/40"
                    )}
                  >
                    {tx(g)}
                  </button>
                );
              })}
            </div>
          ) : null}

          {step === 1 ? (
            <div className="space-y-6">
              <div>
                <p className="mb-2.5 text-sm font-bold">{t("ai.playstyleLabel")}</p>
                <div className="flex flex-wrap gap-2">
                  {ALL_PLAYSTYLES.map((p) => (
                    <button
                      key={p}
                      type="button"
                      aria-pressed={prefs.playstyle === p}
                      onClick={() => update({ playstyle: prefs.playstyle === p ? null : p })}
                      className={cn(
                        "rounded-full border px-4 py-2 text-sm font-bold transition-all",
                        prefs.playstyle === p ? "border-ai bg-ai/15 text-ai" : "border-border hover:border-ai/40"
                      )}
                    >
                      {tx(p)}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-2.5 text-sm font-bold">{t("ai.structureLabel")}</p>
                <div className="flex flex-wrap gap-2">
                  {STRUCTURES.map((s) => (
                    <button
                      key={s}
                      type="button"
                      aria-pressed={prefs.structure === s}
                      onClick={() => update({ structure: prefs.structure === s ? null : s })}
                      className={cn(
                        "rounded-full border px-4 py-2 text-sm font-bold transition-all",
                        prefs.structure === s ? "border-ai bg-ai/15 text-ai" : "border-border hover:border-ai/40"
                      )}
                    >
                      {tx(s)}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : null}

          {step === 2 ? (
            <div className="space-y-6">
              <div>
                <p className="mb-2.5 text-sm font-bold">{t("ai.modeLabel")}</p>
                <div className="grid grid-cols-2 gap-2">
                  {MODES.map((m) => (
                    <button
                      key={m}
                      type="button"
                      aria-pressed={prefs.mode === m}
                      onClick={() => update({ mode: prefs.mode === m ? null : m })}
                      className={cn(
                        "flex items-center gap-2 rounded-xl border px-3.5 py-3 text-sm font-bold transition-all",
                        prefs.mode === m ? "border-ai bg-ai/15 text-ai" : "border-border hover:border-ai/40"
                      )}
                    >
                      <Gamepad2 className="size-4" />
                      {tx(m)}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-2.5 text-sm font-bold">{t("ai.sessionLabel")}</p>
                <div className="grid grid-cols-3 gap-2">
                  {SESSION_BUCKETS.map((b) => (
                    <button
                      key={b.v}
                      type="button"
                      aria-pressed={prefs.sessionBucket === b.v}
                      onClick={() => update({ sessionBucket: prefs.sessionBucket === b.v ? null : b.v })}
                      className={cn(
                        "rounded-xl border p-3 text-center transition-all",
                        prefs.sessionBucket === b.v ? "border-ai bg-ai/15" : "border-border hover:border-ai/40"
                      )}
                    >
                      <span className={cn("block text-sm font-extrabold", prefs.sessionBucket === b.v && "text-ai")}>{b.v ? tx(b.v!) : ""}</span>
                      <span className="mt-1 block text-[0.65rem] text-muted-foreground">{t(b.hintKey)}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : null}

          {step === 3 ? (
            <div className="space-y-6">
              <div>
                <p className="mb-2.5 text-sm font-bold">{t("ai.intentLabel")}</p>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { v: "buy", labelKey: "ai.intentBuyCta" },
                      { v: "rent", labelKey: "ai.intentRentCta" },
                      { v: "either", labelKey: "ai.intentEitherCta" },
                    ] as const
                  ).map((o) => (
                    <button
                      key={o.v}
                      type="button"
                      aria-pressed={prefs.intent === o.v}
                      onClick={() => update({ intent: o.v })}
                      className={cn(
                        "rounded-xl border px-3 py-3 text-sm font-bold transition-all",
                        prefs.intent === o.v ? "border-ai bg-ai/15 text-ai" : "border-border hover:border-ai/40"
                      )}
                    >
                      {t(o.labelKey)}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <p className="text-sm font-bold">{t("ai.maxBudget")}</p>
                  <p className="text-sm font-black text-ai tnum">{prefs.budgetToman ? f.toman(prefs.budgetToman) : t("ai.noLimit")}</p>
                </div>
                <Slider
                  value={[prefs.budgetToman ?? 3_000_000]}
                  min={200_000}
                  max={3_000_000}
                  step={50_000}
                  onValueChange={([v]) => update({ budgetToman: v >= 3_000_000 ? null : v })}
                  aria-label={t("ai.budgetAria")}
                />
                <div className="mt-3 flex gap-2">
                  {BUDGET_PRESETS.map((b) => (
                    <button
                      key={b}
                      type="button"
                      onClick={() => update({ budgetToman: b })}
                      className="rounded-full border border-border px-3 py-1 text-xs font-bold text-muted-foreground transition-colors hover:border-ai/40 hover:text-foreground tnum"
                    >
                      {f.toman(b)}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => update({ budgetToman: null })}
                    className="rounded-full border border-border px-3 py-1 text-xs font-bold text-muted-foreground hover:text-foreground"
                  >
                    {t("ai.noCap")}
                  </button>
                </div>
                {prefs.budgetToman !== null && prefs.intent === "buy" ? (
                  <p className="mt-3 text-xs leading-6 text-muted-foreground">{t("ai.budgetNote")}</p>
                ) : null}
              </div>
            </div>
          ) : null}

          {/* ناوبری مراحل */}
          <div className="mt-8 flex items-center justify-between">
            <Button variant="ghost" disabled={step === 0} onClick={() => setStep((s) => s - 1)} className="gap-1.5">
              <ArrowRight className="size-4" />
              {t("ai.prev")}
            </Button>
            <span className="text-xs text-muted-foreground tnum">
              {t("ai.stepNofM", { n: f.num(step + 1), m: f.num(STEPS.length) })}
            </span>
            {step < STEPS.length - 1 ? (
              <Button onClick={() => setStep((s) => s + 1)} className="gap-1.5 bg-ai text-white hover:bg-ai/90">
                {t("ai.next")}
                <ArrowLeft className="size-4" />
              </Button>
            ) : (
              <Button onClick={finish} className="gap-1.5 bg-ai text-white hover:bg-ai/90 glow-ai">
                {t("ai.seeResults")}
                <Sparkles className="size-4" />
              </Button>
            )}
          </div>
        </motion.section>
      </AnimatePresence>
    </div>
  );
}
