import type { NextConfig } from "next";

/* هدرهای امنیتی — در production فعال؛ FRAME_GUARD=false فقط برای محیط‌های
 * تعبیه‌شده‌ی خاص (پیش‌نمایش داخل iframe) خاموش می‌شود. */
const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
  { key: "X-DNS-Prefetch-Control", value: "on" },
];

const isProd = process.env.NODE_ENV === "production";
const frameGuard = isProd && process.env.FRAME_GUARD !== "false";

if (frameGuard) {
  securityHeaders.push(
    { key: "X-Frame-Options", value: "SAMEORIGIN" },
    {
      key: "Content-Security-Policy",
      value: [
        "default-src 'self'",
        "script-src 'self' 'unsafe-inline'", // Next.js hydration نیاز به inline bootstrap دارد
        "style-src 'self' 'unsafe-inline'",
        "img-src 'self' data: blob: https:",
        "font-src 'self' data:",
        "connect-src 'self'",
        "frame-ancestors 'self'",
        "base-uri 'self'",
        "form-action 'self'",
      ].join("; "),
    }
  );
}

const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: false,
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
};

export default nextConfig;
