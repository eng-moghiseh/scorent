/* ————— نشست‌ها: توکن امضاشده HMAC-SHA256 در کوکی httpOnly + رکورد Session برای ابطال —————
 * قالب توکن: base64url(payload).base64url(hmac)
 * payload: { uid, jti, exp }
 * کلید امضا: env AUTH_SECRET → فایل db/.auth-secret → تولید و ذخیره‌ی خودکار
 */

import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";

export const SESSION_COOKIE = "scorent_session";
const SESSION_DAYS = 30;

function secretPath(): string {
  return resolve(process.cwd(), "db", ".auth-secret");
}

let cachedSecret: Buffer | null = null;

/** آیا در محیط serverless هستیم؟ (فایل پایدار نداریم — secret باید از env بیاید) */
function isServerless(): boolean {
  return Boolean(
    process.env.NETLIFY ||
      process.env.AWS_LAMBDA_FUNCTION_NAME ||
      process.env.VERCEL ||
      process.env.AWS_EXECUTION_ENV
  );
}

export function authSecret(): Buffer {
  if (cachedSecret) return cachedSecret;
  const envSecret = process.env.AUTH_SECRET;
  if (envSecret && envSecret.length >= 24) {
    if (envSecret.length < 32) {
      console.warn("[auth] AUTH_SECRET is shorter than 32 chars — use a longer random value in production");
    }
    cachedSecret = Buffer.from(envSecret, "utf8");
    return cachedSecret;
  }
  const p = secretPath();
  if (existsSync(p)) {
    const fromFile = readFileSync(p, "utf8").trim();
    if (fromFile.length >= 24) {
      cachedSecret = Buffer.from(fromFile, "utf8");
      return cachedSecret;
    }
  }
  //production + serverless: فایل پایدار نداریم؛ secret تصادفیِ هر نمونه = بی‌اعتباری
  //تصادفی نشست‌ها → fail-safe با پیام واضح (باید AUTH_SECRET تنظیم شود)
  if (process.env.NODE_ENV === "production" && isServerless()) {
    throw new Error("AUTH_SECRET_MISSING: set a >=32-char random AUTH_SECRET in your hosting environment variables (required on serverless runtimes)");
  }
  const generated = randomBytes(32).toString("hex");
  try {
    writeFileSync(p, generated, { encoding: "utf8", mode: 0o600 });
  } catch {
    /* در محیط فقط-خواندنی به حافظه اکتفا می‌شود */
  }
  cachedSecret = Buffer.from(generated, "utf8");
  return cachedSecret;
}

function b64url(buf: Buffer | string): string {
  return Buffer.from(buf).toString("base64url");
}

function sign(data: string): string {
  return createHmac("sha256", authSecret()).update(data).digest("base64url");
}

/** مقایسه‌ی زمان-امن امضا (جلوگیری از timing attack روی کوکی نشست) */
function signatureMatches(sig: string, expected: string): boolean {
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

export interface TokenPayload {
  uid: string;
  jti: string;
  exp: number; // epoch ms
}

export function issueToken(uid: string): { token: string; jti: string; exp: number } {
  const jti = randomBytes(16).toString("hex");
  const exp = Date.now() + SESSION_DAYS * 86_400_000;
  const payload: TokenPayload = { uid, jti, exp };
  const body = b64url(JSON.stringify(payload));
  const token = `${body}.${sign(body)}`;
  return { token, jti, exp };
}

export function parseToken(token: string | undefined | null): TokenPayload | null {
  if (!token) return null;
  const dot = token.lastIndexOf(".");
  if (dot <= 0) return null;
  const body = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  let expected: string;
  try {
    expected = sign(body);
  } catch {
    return null;
  }
  if (sig.length !== expected.length || !signatureMatches(sig, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as TokenPayload;
    if (typeof payload.uid !== "string" || typeof payload.jti !== "string" || typeof payload.exp !== "number") return null;
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

/** کاربرِ متصل را از کوکی درخواست برمی‌گرداند (status و ابطال نشست بررسی می‌شود) */
export async function userFromRequest(req: NextRequest) {
  const payload = parseToken(req.cookies.get(SESSION_COOKIE)?.value);
  if (!payload) return null;
  const session = await db.session.findUnique({ where: { id: payload.jti }, include: { user: true } });
  if (!session || session.revokedAt || session.expiresAt.getTime() < Date.now()) return null;
  if (session.user.status !== "ACTIVE") return null;
  return session.user;
}

export interface SessionCookieOptions {
  maxAgeMs: number;
}

export function sessionCookieAttrs(maxAgeMs: number) {
  /* در production: SameSite=None + Partitioned (CHIPS) تا نشست داخل iframe
   * پیش‌نمایش/اپ‌های تعبیه‌شده هم کار کند؛ امنیت با httpOnly + Secure +
   * بررسی same-origin سمت سرور در تمام مسیرهای POST حفظ می‌شود.
   * در dev (http بدون Secure) مرورگر SameSite=None را رد می‌کند → Lax.
   */
  const prod = process.env.NODE_ENV === "production";
  return {
    name: SESSION_COOKIE,
    httpOnly: true as const,
    sameSite: (prod ? "none" : "lax") as "none" | "lax",
    secure: prod,
    partitioned: prod,
    path: "/",
    maxAge: Math.floor(maxAgeMs / 1000),
  };
}

export async function createSession(uid: string, meta: { ip?: string; userAgent?: string }) {
  const { token, jti, exp } = issueToken(uid);
  await db.session.create({
    data: {
      id: jti,
      userId: uid,
      ip: meta.ip ?? null,
      userAgent: meta.userAgent?.slice(0, 300) ?? null,
      expiresAt: new Date(exp),
    },
  });
  return { token, jti, exp };
}

export async function revokeSession(jti: string) {
  await db.session.update({ where: { id: jti }, data: { revokedAt: new Date() } }).catch(() => undefined);
}
