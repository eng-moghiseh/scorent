/* ————— Scorent domain models (typed, single source of truth) ————— */

export type Genre =
  | "نقش‌آفرینی"
  | "اکشن"
  | "ماجرایی"
  | "استراتژیک"
  | "شبیه‌سازی"
  | "معمایی پازل"
  | "تیراندازی"
  | "سکوبازی"
  | "روگ‌لایت"
  | "مسابقه‌ای"
  | "ورزشی";

export const ALL_GENRES: Genre[] = [
  "نقش‌آفرینی",
  "اکشن",
  "ماجرایی",
  "استراتژیک",
  "شبیه‌سازی",
  "معمایی پازل",
  "تیراندازی",
  "سکوبازی",
  "روگ‌لایت",
  "مسابقه‌ای",
  "ورزشی",
];

export type Playstyle = "داستان‌محور" | "رقابتی" | "آرام و دلنشین" | "چالشی" | "اکتشافی" | "تاکتیکی";

export const ALL_PLAYSTYLES: Playstyle[] = [
  "داستان‌محور",
  "رقابتی",
  "آرام و دلنشین",
  "چالشی",
  "اکتشافی",
  "تاکتیکی",
];

/** ساختار پیشرفت بازی */
export type Structure = "دنیای آزاد" | "نیمه‌آزاد" | "خطی";

export type GameMode = "تک‌نفره" | "همکاری محلی" | "همکاری آنلاین" | "رقابتی آنلاین";

export const ALL_MODES: GameMode[] = ["تک‌نفره", "همکاری محلی", "همکاری آنلاین", "رقابتی آنلاین"];

export type SessionBucket = "کوتاه" | "متوسط" | "بلند";

export type CoverMotif =
  | "peaks"
  | "orb"
  | "grid"
  | "waves"
  | "slashes"
  | "spiral"
  | "shards"
  | "ring"
  | "pips"
  | "arch";

export interface RentalRates {
  /** اجاره ۱ روزه */
  d1: number;
  /** اجاره ۳ روزه */
  d3: number;
  /** اجاره ۷ روزه */
  d7: number;
}

export type TrialKind = "official-demo" | "friends-pass" | "none";

export interface TrialInfo {
  kind: TrialKind;
  /** توضیح فارسی — همیشه با برچسب «نمونه» همراه است */
  note: string;
}

export interface Game {
  id: string;
  /** عنوان اصلی بازی (انگلیسی، بدون ترجمه) */
  title: string;
  /** شعار/زیرعنوان فارسی */
  tagline: string;
  description: string;
  developer: string;
  year: number;
  genres: Genre[];
  playstyles: Playstyle[];
  structure: Structure;
  modes: GameMode[];
  /** بازه زمانی یک جلسه بازی (دقیقه) */
  sessionMinutes: [number, number];
  /** طول کمپین اصلی (ساعت) — null اگر معنا ندارد */
  campaignHours: [number, number] | null;
  /** امتیاز ۰ تا ۵ — داده نمونه */
  rating: number;
  ratingSource: string;
  /** قیمت خرید فعلی (تومان، نمونه) */
  price: number;
  /** قیمت پیش از تخفیف (تومان، نمونه) */
  originalPrice: number;
  /** درصد تخفیف ۰ تا ۹۰ — نمونه */
  discountPercent: number;
  rental: RentalRates | null;
  rentalAvailable: boolean;
  indie: boolean;
  featured: boolean;
  /** محبوبیت ۰ تا ۱۰۰ — نمونه */
  popularity: number;
  available: boolean;
  trial: TrialInfo;
  /** پالت سه‌رنگ برای کاور رویه‌ای */
  palette: [string, string, string];
  motif: CoverMotif;
  /** چرا این بازی را تجربه کنیم (فارسی) */
  highlights: string[];
  /** متن جایگزین انگلیسی از اورراید ادمین (اختیاری) */
  taglineEn?: string;
  descriptionEn?: string;
}

/* ————— Preferences (Scorent AI) ————— */

export type PurchaseIntent = "buy" | "rent" | "either";

export interface Preferences {
  genres: Genre[];
  playstyle: Playstyle | null;
  structure: Structure | null;
  mode: GameMode | null;
  sessionBucket: SessionBucket | null;
  /** حداکثر بودجه به تومان */
  budgetToman: number | null;
  intent: PurchaseIntent;
}

/* ————— User entities ————— */

export interface Profile {
  name: string;
  avatar: string;
  /** null = هنوز ویرایش نشده */
  createdAt: number | null;
}

export interface Purchase {
  id: string;
  gameId: string;
  /** مبلغ پرداخت‌شده (تومان) */
  price: number;
  purchasedAt: number;
}

export type RentalStatus = "active" | "completed";

export interface Rental {
  id: string;
  gameId: string;
  /** ۱ یا ۳ یا ۷ روز */
  days: 1 | 3 | 7;
  price: number;
  startedAt: number;
  expiresAt: number;
  status: RentalStatus;
  completedAt: number | null;
  /** آخرین تمدید — برای جلوگیری از تمدیدهای تکراری ناخواسته */
  lastRenewedAt?: number;
  /** منشأ اجاره: فروشگاه اجاره یا اشتراک‌گذاری همتا‌به‌همتا */
  source: "rent" | "share";
}

export interface Listing {
  id: string;
  gameId: string;
  ownerName: string;
  /** قیمت برای بازه انتخابی (تومان) */
  price: number;
  days: 1 | 3 | 7;
  description: string;
  available: boolean;
  createdAt: number;
  /** آیا توسط کاربر فعلی ساخته شده */
  mine: boolean;
}

export interface ShareOrder {
  id: string;
  listingId: string;
  gameId: string;
  /** مبلغ اجاره (تومان) */
  price: number;
  /** سهم پلتفرم ۱۰٪ (تومان) */
  commission: number;
  /** درآمد برآوردی مالک (تومان) */
  ownerEarnings: number;
  rentedAt: number;
}

export interface Review {
  id: string;
  gameId: string;
  author: string;
  rating: number; // 1..5
  text: string;
  createdAt: number;
  mine: boolean;
}

export interface XPEvent {
  id: string;
  amount: number;
  label: string;
  at: number;
}

export interface ActivityEvent {
  id: string;
  type: "purchase" | "rent" | "review" | "wishlist" | "listing" | "share" | "profile" | "xp" | "ai";
  text: string;
  gameId?: string;
  at: number;
  /** کلید ترجمه برای رندر چندزبانه (نوشته‌های جدید) */
  key?: string;
  /** پارامترهای جایگزینی در ترجمه، مثل {game} و {days} */
  p?: Record<string, string>;
}

export interface SavedPrefsMeta {
  completedAt: number | null;
}
