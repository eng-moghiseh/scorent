"use client";

/* ————— تخفیف‌ها: محاسبه یکسان، بدون قیمت منفی (دوزبانه) ————— */

import { useMemo } from "react";
import { motion } from "framer-motion";
import { BadgePercent, PiggyBank, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { GameCover } from "@/components/scorent/game-cover";
import { PriceTag, PurchaseDialog, RentDialog } from "@/components/scorent/commerce";
import { DiscountBadge, EmptyState, RatingBadge, SectionHeader } from "@/components/scorent/shared";
import { Link as RouteLink } from "@/components/scorent/router";
import { dealGames } from "@/lib/data/games";
import { finalPrice, savingsAmount } from "@/lib/pricing";
import { useFmt, useT, useTx, useGameText } from "@/lib/i18n";
import { DEMO_DATA_NOTE } from "@/lib/data/games";
import type { Game } from "@/lib/types";

/* تخفیف بزرگ هفته — متن کاتالوگ به زبان فعال */
function HeroDeal({ game }: { game: Game }) {
  const t = useT();
  const f = useFmt();
  const gt = useGameText(game);
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-8 grid overflow-hidden rounded-3xl border border-deal/30 bg-card lg:grid-cols-[340px_1fr]"
    >
      <RouteLink to={`/game/${game.id}`} className="relative block">
        <GameCover game={game} className="h-full min-h-64 w-full" />
        <span className="absolute start-3 top-3 rounded-full bg-deal px-3 py-1.5 text-sm font-black text-[#3a1c00] tnum">
          {t("deals.bigBadge", { p: f.num(game.discountPercent) })}
        </span>
      </RouteLink>
      <div className="p-6 md:p-8">
        <p className="text-xs font-bold text-deal">{t("deals.biggestActive")}</p>
        <h2 className="mt-2 text-3xl font-black" dir="ltr">
          {game.title}
        </h2>
        <p className="mt-3 max-w-xl text-sm leading-8 text-muted-foreground">{gt.description}</p>
        <div className="mt-5 flex flex-wrap items-center gap-4">
          <div>
            <p className="text-sm text-muted-foreground line-through tnum">{f.toman(game.originalPrice)}</p>
            <p className="text-3xl font-black text-deal tnum">{f.toman(finalPrice(game))}</p>
          </div>
          <span className="rounded-xl bg-rent/12 px-3.5 py-2 text-sm font-extrabold text-rent tnum">
            {t("deals.lessAmount", { a: f.toman(savingsAmount(game)) })}
          </span>
        </div>
        <div className="mt-6 flex flex-wrap gap-2">
          <PurchaseDialog game={game} />
          {game.rentalAvailable ? <RentDialog game={game} defaultDays={3} /> : null}
          <RouteLink to={`/game/${game.id}`}>
            <Button variant="outline">{t("deals.details")}</Button>
          </RouteLink>
        </div>
      </div>
    </motion.div>
  );
}

export function DealsPage() {
  const deals = useMemo(() => [...dealGames()].sort((a, b) => b.discountPercent - a.discountPercent), []);
  const totalSavings = deals.reduce((a, g) => a + savingsAmount(g), 0);
  const t = useT();
  const f = useFmt();
  const tx = useTx();

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div className="max-w-2xl">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-deal/14 px-3.5 py-1.5 text-xs font-bold text-deal">
            <BadgePercent className="size-3.5" />
            {t("deals.badge")}
          </div>
          <h1 className="text-3xl font-black">{t("deals.title")}</h1>
          <p className="mt-2 text-sm leading-7 text-muted-foreground">{t("deals.desc")}</p>
        </div>
        <div className="rounded-2xl border border-deal/25 bg-card px-5 py-3 text-center">
          <p className="flex items-center gap-1.5 text-lg font-black text-deal tnum">
            <PiggyBank className="size-5" />
            {f.toman(totalSavings, false)}
          </p>
          <p className="text-[0.62rem] text-muted-foreground">{t("deals.totalSavingsNote")}</p>
        </div>
      </header>

      {deals.length === 0 ? (
        <EmptyState icon={Tag} title={t("deals.emptyTitle")} description={t("deals.emptyDesc")} />
      ) : (
        <>
          {/* تخفیف بزرگ هفته */}
          {deals[0] ? <HeroDeal game={deals[0]} /> : null}

          <SectionHeader
            title={t("deals.allTitle")}
            description={t("deals.allCount", { n: f.num(deals.length) })}
            icon={Tag}
            tone="deal"
          />
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {deals.map((g, i) => (
              <motion.div
                key={g.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-30px" }}
                transition={{ duration: 0.4, delay: Math.min(i * 0.04, 0.25) }}
                className="card-hover overflow-hidden rounded-2xl border border-border bg-card"
              >
                <RouteLink to={`/game/${g.id}`} className="relative block">
                  <GameCover game={g} className="aspect-[3/4] w-full" />
                  <div className="absolute start-2 top-2">
                    <DiscountBadge percent={g.discountPercent} />
                  </div>
                  <div className="absolute end-2 top-2">
                    <RatingBadge rating={g.rating} />
                  </div>
                </RouteLink>
                <div className="p-4">
                  <RouteLink to={`/game/${g.id}`} className="block truncate font-bold hover:text-deal" dir="ltr">
                    {g.title}
                  </RouteLink>
                  <div className="mt-2 flex items-baseline gap-2">
                    <span className="text-lg font-black text-deal tnum">{f.toman(finalPrice(g))}</span>
                    <span className="text-xs text-muted-foreground line-through tnum">{f.toman(g.originalPrice)}</span>
                  </div>
                  <p className="mt-1 text-[0.7rem] font-bold text-rent tnum">{t("deals.savingOf", { a: f.toman(savingsAmount(g)) })}</p>
                  <div className="mt-3">
                    <PurchaseDialog game={g} />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </>
      )}

      <p className="mt-10 text-xs leading-6 text-muted-foreground">{tx(DEMO_DATA_NOTE)}</p>
    </div>
  );
}
