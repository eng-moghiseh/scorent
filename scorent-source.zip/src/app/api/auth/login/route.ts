/* POST /api/auth/login — ورود با ایمیل یا موبایل + رمز */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, json, readJson, sameOrigin } from "@/lib/server/http";
import { verifyPassword } from "@/lib/server/password";
import { createSession } from "@/lib/server/session";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";
import { ensureSeed } from "@/lib/server/seed";
import { audit } from "@/lib/server/audit";
import { findUserByIdentifier, publicUser, setSessionCookie } from "@/lib/server/auth-helpers";

interface Body {
  identifier?: string;
  password?: string;
}

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  await ensureSeed();

  const ip = clientIp(req);
  if (!(await rateLimit(`login:${ip}`, 12, 5 * 60_000))) {
    return json({ ok: false, error: "RATE_LIMITED" }, 429);
  }

  const body = await readJson<Body>(req);
  const identifier = typeof body?.identifier === "string" ? body.identifier.trim() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  if (!identifier || !password) return json({ ok: false, error: "MISSING_FIELDS" }, 400);

  const idKey = identifier.toLowerCase().slice(0, 120);
  if (!(await rateLimit(`login-id:${idKey}`, 15, 15 * 60_000))) {
    return json({ ok: false, error: "TOO_MANY_ATTEMPTS" }, 429);
  }

  const user = await findUserByIdentifier(identifier);
  // پیام یکسان برای «کاربر نیست» و «رمز غلط» — ضد شمارش کاربران
  const generic = () => {
    audit("LOGIN_FAIL", { target: identifier.slice(0, 40), ip });
    return json({ ok: false, error: "INVALID_CREDENTIALS" }, 401);
  };
  if (!user || !user.passwordHash) return generic();
  if (user.status === "SUSPENDED") {
    audit("LOGIN_FAIL", { actorId: user.id, target: user.email ?? user.phone, meta: "suspended", ip });
    return json({ ok: false, error: "SUSPENDED" }, 403);
  }

  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) return generic();

  await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
  const { token, exp } = await createSession(user.id, { ip, userAgent: req.headers.get("user-agent") ?? undefined });
  const res = json({ ok: true, user: publicUser(user) });
  audit("LOGIN_OK", { actorId: user.id, target: user.email ?? user.phone, ip });
  setSessionCookie(res, token, exp);
  return res;
}
