/* ————— موتور پیشنهاد Scorent (نسخه مبتنی بر قاعده — Rule-based) —————
 *
 * ⚠️ شفافیت: این موتور یک «سیستم امتیازدهی قاعده‌محور و قابل توضیح» است،
 * نه یک مدل هوش مصنوعی آموزش‌دیده. معماری آن طوری نوشته شده که در آینده
 * بتوان نتایج یک API واقعی را جایگزین یا ترکیب کرد بدون تغییر UI.
 *
 * وزن‌های امتیاز (مجموع = ۱۰۰):
 *   - همخوانی ژانر:            ۳۵ نمره
 *   - همخوانی سبک بازی + ساختار: ۲۵ نمره (سبک ۱۵ + ساختار ۱۰)
 *   - همخوانی حالت بازی:        ۱۵ نمره
 *   - سازگاری بودجه:            ۱۵ نمره
 *   - سازگاری طول جلسه:         ۱۰ نمره
 *
 * رفتار با ترجیحات خالی: نمره خنثی (نصف نمرهٔ آن بخش) می‌گیرد تا بازی‌ها بی‌دلیل جریمه نشوند.
 * رفتار با بودجه: اگر مبلغِ لازم ≤ بودجه → نمره کامل؛ اگر نسبت بودجه/مبلغ ≥ ۰٫۶ → نمره نسبی
 * و توضیح «کمی بالاتر از بودجه»؛ در غیر این صورت صفر + توضیح جایگزین (اجاره یا گزینه ارزان‌تر).
 *
 * تابع کاملاً Pure است و برای هر ورودی یکسان، خروجی یکسان می‌دهد (بدون عدد تصادفی).
 * توضیح‌ها دوزبانه‌اند: scoreGame(game, prefs, lang) — پیش‌فرض فارسی.
 */

import type { Game, Preferences, PurchaseIntent, SessionBucket } from "./types";
import { finalPrice, rentalPrice } from "./pricing";
import { toFaDigits } from "./format";
import type { Lang } from "./i18n-core";
import { joinAnd, txStatic } from "./i18n-core";

export const RECOMMENDATION_WEIGHTS = {
  genre: 35,
  playstyle: 15,
  structure: 10,
  mode: 15,
  budget: 15,
  session: 10,
} as const;

export interface ScoreResult {
  game: Game;
  /** نمره خام ۰..۱۰۰ */
  score: number;
  /** درصد نهایی (گرد شده) */
  percentage: number;
  /** دلایل مثبت (به زبان درخواستی) */
  matched: string[];
  /** توضیح محدودیت‌ها و جایگزین‌ها (به زبان درخواستی) */
  tradeoffs: string[];
}

const SESSION_ORDER: SessionBucket[] = ["کوتاه", "متوسط", "بلند"];

function bucketOfGame(game: Game): SessionBucket {
  const mid = (game.sessionMinutes[0] + game.sessionMinutes[1]) / 2;
  if (mid < 60) return "کوتاه";
  if (mid <= 180) return "متوسط";
  return "بلند";
}

function sessionDistance(a: SessionBucket, b: SessionBucket): number {
  return Math.abs(SESSION_ORDER.indexOf(a) - SESSION_ORDER.indexOf(b));
}

/** مبلغی که کاربر بابت این بازی (طبق نیت خرید/اجاره) پرداخت می‌کند — تومان */
export function effectiveSpend(game: Game, intent: PurchaseIntent): number | null {
  const buy = finalPrice(game);
  const rent3 = game.rentalAvailable && game.rental ? rentalPrice(game.rental, 3) : null;
  switch (intent) {
    case "buy":
      return buy;
    case "rent":
      return rent3;
    case "either":
      if (rent3 === null) return buy;
      return Math.min(buy, rent3);
  }
}

/** مبلغ پیشنهادی برای اجرای نیت کاربر — همراه با برچسب به زبان درخواستی */
export function spendLabel(intent: PurchaseIntent, lang: Lang = "fa"): string {
  const fa =
    intent === "buy" ? "خرید" : intent === "rent" ? "اجاره ۳ روزه" : "ارزان‌ترین گزینه (خرید یا اجاره)";
  return txStatic(fa, lang);
}

function formatBudgetHint(amount: number, lang: Lang): string {
  if (amount >= 1_000_000) {
    const m = amount / 1_000_000;
    const n = Number.isInteger(m) ? String(m) : m.toFixed(1);
    return lang === "fa" ? `${toFaDigits(n)} میلیون تومان` : `${n}M Toman`;
  }
  const k = Math.round(amount / 1000);
  return lang === "fa" ? `${toFaDigits(k)} هزار تومان` : `${k}K Toman`;
}

export function scoreGame(game: Game, prefs: Preferences, lang: Lang = "fa"): ScoreResult {
  const matched: string[] = [];
  const tradeoffs: string[] = [];
  let score = 0;
  const fa = lang === "fa";
  const L = (f: string, e: string) => (fa ? f : e);
  const g = (x: string) => txStatic(x, lang); // واژگان دامنه

  /* ۱) ژانر — ۳۵ نمره */
  if (prefs.genres.length > 0) {
    const overlap = game.genres.filter((x) => prefs.genres.includes(x));
    const ratio = overlap.length / prefs.genres.length;
    score += ratio * RECOMMENDATION_WEIGHTS.genre;
    if (overlap.length > 0) {
      matched.push(
        L(`ژانر ${joinAnd(overlap, lang)} با علاقه‌های تو هم‌پوشانی دارد`, `The ${joinAnd(overlap.map(g), lang)} genre matches your interests`)
      );
    } else {
      tradeoffs.push(
        L("ژانر این بازی در فهرست علاقه‌های تو نیست؛ شاید گزینه‌ای برای تنوع باشد", "This game's genre isn't in your list; it might be a good pick for variety")
      );
    }
  }

  /* ۲) سبک بازی — ۱۵ نمره */
  if (prefs.playstyle) {
    if (game.playstyles.includes(prefs.playstyle)) {
      score += RECOMMENDATION_WEIGHTS.playstyle;
      matched.push(
        L(`سبک ${g(prefs.playstyle)} این بازی دقیقاً همان چیزی است که دنبالش هستی`, `Its ${g(prefs.playstyle)} playstyle is exactly what you are looking for`)
      );
    } else {
      tradeoffs.push(
        L(`تمرکز این بازی روی سبک ${g(game.playstyles[0])} است، نه ${g(prefs.playstyle)}`, `This game focuses on ${g(game.playstyles[0])}, not ${g(prefs.playstyle)}`)
      );
    }
  }

  /* ۳) ساختار (دنیای آزاد ↔ خطی) — ۱۰ نمره */
  if (prefs.structure) {
    if (game.structure === prefs.structure) {
      score += RECOMMENDATION_WEIGHTS.structure;
      matched.push(L(`ساختار ${g(prefs.structure)} دارد؛ همان‌طور که دوست داری`, `${g(prefs.structure)} structure — just the way you like it`));
    } else {
      tradeoffs.push(L(`ساختار آن ${g(game.structure)} است، نه ${g(prefs.structure)}`, `Its structure is ${g(game.structure)}, not ${g(prefs.structure)}`));
    }
  }

  /* ۴) حالت بازی (تک‌نفره/همکاری/رقابتی) — ۱۵ نمره */
  if (prefs.mode) {
    if (game.modes.includes(prefs.mode)) {
      score += RECOMMENDATION_WEIGHTS.mode;
      matched.push(L(`حالت ${g(prefs.mode)} پشتیبانی می‌شود`, `${g(prefs.mode)} mode is supported`));
    } else {
      tradeoffs.push(L(`حالت ${g(prefs.mode)} ندارد (${game.modes.map(g).join(fa ? "، " : ", ")})`, `No ${g(prefs.mode)} mode (${game.modes.map(g).join(", ")})`));
    }
  }

  /* ۵) بودجه — ۱۵ نمره */
  const spend = effectiveSpend(game, prefs.intent);
  if (prefs.budgetToman !== null && spend !== null) {
    const budget = prefs.budgetToman;
    if (spend <= budget) {
      score += RECOMMENDATION_WEIGHTS.budget;
      matched.push(
        L(
          `${spendLabel(prefs.intent, lang)} آن با ${formatBudgetHint(spend, lang)} در بودجه‌ات جا می‌شود`,
          `${spendLabel(prefs.intent, lang)} at ${formatBudgetHint(spend, lang)} fits your budget`
        )
      );
    } else {
      const ratio = budget / spend;
      if (ratio >= 0.6) {
        score += RECOMMENDATION_WEIGHTS.budget * ratio;
        tradeoffs.push(
          L("اندکی بالاتر از بودجه‌ات است؛ با کمی صرفه‌جویی یا تخفیف بعدی دست‌یافتنی است", "Slightly above your budget; reachable with a little saving or the next discount")
        );
      } else {
        tradeoffs.push(
          L(
            `از بودجه‌ات گران‌تر است؛ ${game.rentalAvailable ? "نسخه اجاره‌ای برای آزمودن پیشنهاد می‌شود" : "فعلاً کنار بگذار و گزینه‌های ارزان‌تر را ببین"}`,
            game.rentalAvailable
              ? "Pricier than your budget; renting it first is recommended"
              : "Pricier than your budget; set it aside for now and check cheaper options"
          )
        );
      }
    }
  }

  /* ۶) طول جلسه — ۱۰ نمره */
  if (prefs.sessionBucket) {
    const gb = bucketOfGame(game);
    const dist = sessionDistance(gb, prefs.sessionBucket);
    if (dist === 0) {
      score += RECOMMENDATION_WEIGHTS.session;
      matched.push(L(`جلسه‌های ${g(prefs.sessionBucket)} آن با وقت بازی‌ات هماهنگ است`, `Its ${g(prefs.sessionBucket).toLowerCase()} sessions match your playtime`));
    } else if (dist === 1) {
      score += RECOMMENDATION_WEIGHTS.session / 2;
      tradeoffs.push(
        L(
          `جلسه‌هایش ${gb === "بلند" ? "کمی طولانی‌تر" : "کمی کوتاه‌تر"} از زمان همیشگی توست`,
          gb === "بلند" ? "Sessions run a bit longer than your usual time" : "Sessions run a bit shorter than your usual time"
        )
      );
    } else {
      tradeoffs.push(
        L(
          gb === "بلند"
            ? "جلسات طولانی می‌طلبد؛ اگر وقت محدودی داری شاید مناسب هفته‌های آزادت باشد"
            : "جلساتش خیلی کوتاه‌تر از چیزی است که برایش وقت می‌گذاری",
          gb === "بلند"
            ? "It demands long sessions; if your time is limited, it may suit your free weeks"
            : "Its sessions are much shorter than the time you usually spend"
        )
      );
    }
  }

  /* اگر هیچ ترجیحی ثبت نشده، امتیاز خنثی پایین می‌ماند و بازی‌های محبوب بالا می‌آیند */
  if (prefs.genres.length === 0 && !prefs.playstyle && !prefs.structure && !prefs.mode && !prefs.sessionBucket) {
    score += game.popularity / 10; // حداکثر ۱۰ نمره خنثی بر اساس محبوبیت
  }

  score = Math.max(0, Math.min(100, score));
  return { game, score, percentage: Math.round(score), matched, tradeoffs };
}

export interface RankOptions {
  limit?: number;
  /** بازی‌های ناموجود را حذف کن (پیش‌فرض: بله) */
  excludeUnavailable?: boolean;
  /** زبان توضیح‌ها (پیش‌فرض: فارسی) */
  lang?: Lang;
}

/** رتبه‌بندی قطعی: امتیاز ← امتیاز منتقدان ← محبوبیت ← شناسه (برای شکستن تساوی) */
export function rankGames(games: Game[], prefs: Preferences, opts: RankOptions = {}): ScoreResult[] {
  const { limit, excludeUnavailable = true, lang = "fa" } = opts;
  const pool = excludeUnavailable ? games.filter((x) => x.available) : games;
  const scored = pool.map((x) => scoreGame(x, prefs, lang));
  scored.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if (b.game.rating !== a.game.rating) return b.game.rating - a.game.rating;
    if (b.game.popularity !== a.game.popularity) return b.game.popularity - a.game.popularity;
    return a.game.id.localeCompare(b.game.id);
  });
  return limit ? scored.slice(0, limit) : scored;
}
