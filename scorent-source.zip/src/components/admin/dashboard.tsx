"use client";

/* ————— داشبورد مدیریت — آمار واقعی از دیتابیس ————— */

import { useEffect, useState } from "react";
import { Bell, Gamepad2, Inbox, LayoutDashboard, LifeBuoy, Users } from "lucide-react";
import { api } from "@/lib/auth";
import { useFmt, useT } from "@/lib/i18n";
import { Link } from "@/components/scorent/router";
import { AdminHeader, AdminError, RolePill, StatusPill } from "./ui";

interface Stats {
  users: number;
  ticketsOpen: number;
  ticketsTotal: number;
  notifs: number;
  announcements: number;
  overrides: number;
  content: number;
}
interface LatestUser {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  role: string;
  status: string;
  createdAt: string;
}
interface LatestTicket {
  id: string;
  subject: string;
  status: string;
  priority: string;
  category: string;
  createdAt: string;
}

export function AdminDashboard() {
  const t = useT();
  const f = useFmt();
  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<LatestUser[]>([]);
  const [tickets, setTickets] = useState<LatestTicket[]>([]);
  const [err, setErr] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get<{ ok: boolean; stats: Stats; latestUsers: LatestUser[]; latestTickets: LatestTicket[] }>("/api/admin/stats");
        setStats(res.stats);
        setUsers(res.latestUsers);
        setTickets(res.latestTickets);
      } catch {
        setErr(true);
      }
    })();
  }, []);

  if (err) return <AdminError />;

  const cards = stats
    ? [
        { icon: Users, label: t("admin.stat.users"), value: stats.users, tone: "text-ai" },
        { icon: LifeBuoy, label: t("admin.stat.ticketsOpen"), value: stats.ticketsOpen, tone: "text-deal" },
        { icon: Inbox, label: t("admin.stat.notifs"), value: stats.notifs, tone: "text-rent" },
        { icon: Bell, label: t("admin.stat.announcements"), value: stats.announcements, tone: "text-ai" },
        { icon: Gamepad2, label: t("admin.stat.overrides"), value: stats.overrides, tone: "text-foreground" },
      ]
    : [];

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.tab.dashboard")} description={t("admin.desc")} icon={LayoutDashboard} />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {cards.length === 0
          ? Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-28 animate-pulse rounded-2xl border border-border bg-card" />)
          : cards.map((c) => (
              <div key={c.label} className="rounded-2xl border border-border bg-card p-4">
                <c.icon className={`size-5 ${c.tone}`} />
                <p className="mt-2 text-2xl font-black tnum">{f.num(c.value)}</p>
                <p className="mt-0.5 text-[0.65rem] font-bold text-muted-foreground">{c.label}</p>
              </div>
            ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <section className="rounded-3xl border border-border bg-card p-5" aria-label={t("admin.latestUsers")}>
          <h2 className="mb-3 text-sm font-extrabold">{t("admin.latestUsers")}</h2>
          <ul className="space-y-2.5">
            {users.map((u) => (
              <li key={u.id} className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-secondary/30 px-3.5 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-xs font-extrabold">{u.name}</p>
                  <p dir="ltr" className="truncate text-start text-[0.62rem] text-muted-foreground tnum">{u.email ?? u.phone ?? "—"}</p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <RolePill role={u.role} />
                  <StatusPill status={u.status} />
                </div>
              </li>
            ))}
            {users.length === 0 && <li className="py-6 text-center text-xs text-muted-foreground">…</li>}
          </ul>
        </section>

        <section className="rounded-3xl border border-border bg-card p-5" aria-label={t("admin.latestTickets")}>
          <h2 className="mb-3 text-sm font-extrabold">{t("admin.latestTickets")}</h2>
          <ul className="space-y-2.5">
            {tickets.map((tk) => (
              <li key={tk.id} className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-secondary/30 px-3.5 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-xs font-extrabold">{tk.subject}</p>
                  <p className="text-[0.62rem] text-muted-foreground">
                    {t(`support.cat.${tk.category}`)} · {f.dateTime(new Date(tk.createdAt).getTime())}
                  </p>
                </div>
                <StatusPill status={tk.status} />
              </li>
            ))}
            {tickets.length === 0 && <li className="py-6 text-center text-xs text-muted-foreground">…</li>}
          </ul>
          <Link to="/admin/tickets" className="mt-3 inline-block text-xs font-extrabold text-ai hover:underline">
            {t("admin.tab.tickets")} →
          </Link>
        </section>
      </div>
    </div>
  );
}
