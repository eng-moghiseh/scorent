import { GAMES } from "/home/z/my-project/src/lib/data/games.ts";
for (const id of ["hades", "elden-ring"]) {
  const g = GAMES.find((x) => x.id === id);
  console.log(g.title, "| buy:", g.price, "| orig:", g.originalPrice, "| disc:", g.discountPercent, "| rental:", JSON.stringify(g.rental), "| campaign:", JSON.stringify(g.campaignHours), "| rating:", g.rating);
}
