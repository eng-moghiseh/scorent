/* /api/support/tickets/[id] — مشاهده و پاسخ تیکت توسط صاحب تیکت (ادمین مسیر خودش را دارد) */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, cleanText, json, notFound, readJson, sameOrigin, unauthorized } from "@/lib/server/http";
import { isGuardError, requireUser } from "@/lib/server/guard";
import { sendAndLog } from "@/lib/server/notify";

type Ctx = { params: Promise<{ id: string }> };

async function loadTicket(id: string) {
  return db.supportTicket.findUnique({ where: { id }, include: { messages: { orderBy: { createdAt: "asc" } } } });
}

export async function GET(req: NextRequest, ctx: Ctx) {
  const guard = await requireUser(req);
  if (isGuardError(guard)) return guard;
  const { id } = await ctx.params;
  const ticket = await loadTicket(id);
  if (!ticket || ticket.userId !== guard.user.id) return notFound("TICKET_NOT_FOUND");
  return json({ ok: true, ticket });
}

export async function POST(req: NextRequest, ctx: Ctx) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  const guard = await requireUser(req);
  if (isGuardError(guard)) return guard;
  const { id } = await ctx.params;
  const ticket = await loadTicket(id);
  if (!ticket || ticket.userId !== guard.user.id) return notFound("TICKET_NOT_FOUND");

  const body = await readJson<{ body?: string }>(req);
  const text = cleanText(body?.body, 2, 2000);
  if (!text) return json({ ok: false, error: "INVALID_INPUT" }, 400);
  if (ticket.status === "CLOSED") return json({ ok: false, error: "TICKET_CLOSED" }, 400);

  const message = await db.ticketMessage.create({
    data: { ticketId: ticket.id, authorId: guard.user.id, authorName: guard.user.name, authorRole: "USER", body: text },
  });
  await db.supportTicket.update({ where: { id: ticket.id }, data: { status: "OPEN", updatedAt: new Date() } });
  return json({ ok: true, message });
}

/** بستن تیکت توسط صاحب تیکت */
export async function PATCH(req: NextRequest, ctx: Ctx) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  const guard = await requireUser(req);
  if (isGuardError(guard)) return guard;
  const { id } = await ctx.params;
  const ticket = await loadTicket(id);
  if (!ticket || ticket.userId !== guard.user.id) return notFound("TICKET_NOT_FOUND");

  const updated = await db.supportTicket.update({ where: { id: ticket.id }, data: { status: "CLOSED" } });
  // اطلاع‌رسانی به ادمین‌ها لازم نیست؛ وضعیت در پنل دیده می‌شود
  void sendAndLog; // keep import referenced in future expansions
  return json({ ok: true, ticket: updated });
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  // صاحب تیکت نمی‌تواند حذف کند — فقط ادمین؛ اینجا صریحاً ممنوع
  void ctx;
  void req;
  return unauthorized();
}
