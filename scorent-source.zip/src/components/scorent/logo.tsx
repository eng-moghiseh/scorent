/* ————— هویت بصری Scorent —————
 * نشان عقرب نسل جدید: کاشی تیره با گرادیان لبه‌ای،
 * عقرب هندسی با نیش منحنی (S برند)، چنگال‌های باز و دم پرنور.
 * املای صحیح: Scorent
 */

import { useT } from "@/lib/i18n";

/** شعار اصلی برند (نسخه فارسی — برای متن ثابت/متادیتا) */
export const BRAND_SLOGAN = "کشف کن، تجربه کن، بازی کن";

/** شعار ماژول اجاره (نسخه فارسی — مکمل شعار اصلی) */
export const RENT_SLOGAN = "قبل از خرید، تجربه‌اش کن!";

export function ScorpionMark({ size = 32, rounded = true }: { size?: number; rounded?: boolean }) {
  const t = useT();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      role="img"
      aria-label={t("brand.logoAria")}
      style={{ borderRadius: rounded ? size * 0.24 : 0, flexShrink: 0, display: "block" }}
    >
      <defs>
        <linearGradient id="scrnt-gS" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#FFC46B" />
          <stop offset="1" stopColor="#FF7A1A" />
        </linearGradient>
        <linearGradient id="scrnt-gTile" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#242A38" />
          <stop offset="1" stopColor="#11131A" />
        </linearGradient>
        <linearGradient id="scrnt-gEdge" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="rgba(255,159,67,0.5)" />
          <stop offset="1" stopColor="rgba(255,122,26,0.1)" />
        </linearGradient>
        <radialGradient id="scrnt-glow" cx="0.5" cy="0.45" r="0.62">
          <stop offset="0" stopColor="rgba(255,140,40,0.25)" />
          <stop offset="1" stopColor="rgba(255,140,40,0)" />
        </radialGradient>
      </defs>
      <g>
        <rect width="64" height="64" rx="16" fill="url(#scrnt-gTile)" />
        <rect width="64" height="64" rx="16" fill="url(#scrnt-glow)" />
        <rect x="0.6" y="0.6" width="62.8" height="62.8" rx="15.4" fill="none" stroke="url(#scrnt-gEdge)" strokeWidth="1.2" />
        {/* دم: قلاب پرشده با نوک باریک‌شونده */}
        <path
          d="M30.5 38 C31 45.5 37.5 51 45 49.2 C51.5 47.6 54.8 40.8 52.4 34.7 C50.5 29.8 45.5 27.6 40.9 29.3 L42.1 33.2 C45.1 32.1 48.2 33.7 49.4 37 C50.9 41 48.8 45.3 44.5 46.5 C39.3 47.9 34.4 44.2 34.2 38.3 Z"
          fill="url(#scrnt-gS)"
        />
        {/* نیش */}
        <path d="M42.2 28.2 C39.2 28.6 36.9 30.7 36.4 33.5 C39.3 34.3 42.1 33 43.5 30.5 Z" fill="url(#scrnt-gS)" />
        {/* بدن و سر */}
        <rect x="26.6" y="21" width="10.2" height="18.5" rx="5.1" fill="url(#scrnt-gS)" />
        <circle cx="31.7" cy="20" r="5.8" fill="url(#scrnt-gS)" />
        {/* بازوهای چنگال */}
        <g stroke="url(#scrnt-gS)" strokeWidth="3" strokeLinecap="round" fill="none">
          <path d="M28.8 17.2 C26.4 14.6 23.4 13 20.2 12.8" />
          <path d="M34.6 17.2 C37 14.6 40 13 43.2 12.8" />
        </g>
        {/* چنگال‌های باز */}
        <path d="M12.5 14.8 L18.9 11.9 A6.5 6.5 0 1 0 17.5 21.4 Z" fill="url(#scrnt-gS)" />
        <path d="M50.9 14.8 L44.5 11.9 A6.5 6.5 0 1 1 45.9 21.4 Z" fill="url(#scrnt-gS)" />
        {/* پاها */}
        <g stroke="url(#scrnt-gS)" strokeWidth="2.4" strokeLinecap="round" fill="none" opacity="0.9">
          <path d="M26.8 25 L20.4 27.7" />
          <path d="M26.6 29.5 L20 33" />
          <path d="M36.6 25 L43 27.7" />
          <path d="M36.8 29.5 L43.4 33" />
        </g>
        {/* خطوط بند بدن */}
        <g stroke="#11131A" strokeWidth="1.2" opacity="0.3" strokeLinecap="round">
          <path d="M27.8 30 L35.6 30" />
          <path d="M27.8 34 L35.6 34" />
        </g>
        {/* چشم‌ها */}
        <circle cx="29.8" cy="18.8" r="1.05" fill="#11131A" />
        <circle cx="33.6" cy="18.8" r="1.05" fill="#11131A" />
      </g>
    </svg>
  );
}

/** نام مستعار نشانی برای استفاده در دستیار و جاهای برند-محور */
export const ScorentMark = ScorpionMark;

export function ScorentLogo({ size = 34, showTagline = false }: { size?: number; showTagline?: boolean }) {
  const t = useT();
  return (
    <span className="inline-flex items-center gap-2.5">
      <ScorpionMark size={size} />
      <span className="flex flex-col leading-none">
        <span className="text-[1.35rem] font-extrabold tracking-tight" dir="ltr" style={{ fontFamily: "inherit" }}>
          Scorent
        </span>
        {showTagline ? <span className="mt-1 text-[0.65rem] text-muted-foreground">{t("brand.slogan")}</span> : null}
      </span>
    </span>
  );
}
