/* ————— ترجمه‌ی انگلیسی محتوای کاتالوگ (داده نمونه) —————
 * متن‌های شعار/توضیح/نکات بازی‌ها در لایه داده فارسی‌اند؛ در حالت انگلیسی
 * از این نگاشت استفاده می‌شود (useGameText). اگر بازی کلید نداشت، متن فارسی نمایش داده می‌شود.
 */

export interface GameTextEn {
  tagline: string;
  description: string;
  highlights: string[];
}

export const CATALOG_EN: Record<string, GameTextEn> = {
  "elden-ring": {
    tagline: "The Lands Between await",
    description:
      "A massive open-world action RPG from FromSoftware and George R. R. Martin. Secrets, brutal bosses and the pure joy of discovery create an experience that spans hundreds of hours, letting every player find their own path.",
    highlights: ["An open world where exploration itself is the reward", "Memorable, challenging boss fights", "Hundreds of hours of content and varied builds"],
  },
  "cyberpunk-2077": {
    tagline: "Live the nights of Night City",
    description:
      "A first-person RPG set in a cyberpunk metropolis with deep branching narrative and freeform character building. After the major updates it has become a dense, gorgeous experience — perfect for story lovers and open-world fans.",
    highlights: ["Night City is one of gaming's richest cities", "Branching story with different endings", "Stunning visual craft"],
  },
  rdr2: {
    tagline: "The sunset of a wild era",
    description:
      "Rockstar's western epic with breathtaking detail and a slow, cinematic story. If you want a deep narrative inside a living world, Arthur Morgan is one of the greatest characters in gaming history.",
    highlights: ["Unmatched world and character detail", "Cinematic, emotional storytelling", "Perfect for calm, story-driven players"],
  },
  bg3: {
    tagline: "The dice shape your destiny",
    description:
      "An epic turn-based RPG built on D&D rules with staggering freedom. Every choice matters, every companion has their own story, and the group campaign is one of the best co-op experiences of recent years.",
    highlights: ["Rare narrative freedom", "Online co-op for a party of four", "Hundreds of hours of branching content"],
  },
  "gow-ragnarok": {
    tagline: "The Norse fate of Kratos",
    description:
      "Kratos and Atreus continue their journey through Norse myth with heavy combat and an emotional story. Blending puzzles, combat and family drama, it stands among the most complete action-adventures ever made.",
    highlights: ["Weighty, satisfying combat", "An emotional father-and-son tale", "Varied Norse realms"],
  },
  "witcher-3": {
    tagline: "Full-time monster hunter",
    description:
      "The undisputed classic RPG with side quests that each could have been standalone games. With massive DLCs and a story-filled world, it is still the benchmark every open-world RPG is measured against.",
    highlights: ["Exceptional side quests", "A great starting discount", "Two huge, high-quality expansions"],
  },
  "it-takes-two": {
    tagline: "Two players or nothing",
    description:
      "A creative co-op adventure where every level introduces a brand-new mechanic. Playing with a friend or partner on the same couch, it is one of the most joyful experiences possible.",
    highlights: ["A new mechanic in every level", "Perfect for two-player sessions", "Fast, varied pacing"],
  },
  "doom-eternal": {
    tagline: "Heavy rhythm and blood",
    description:
      "A blisteringly fast first-person shooter that plays like an action puzzle: fight for the very resources that keep you alive. For anyone craving intense solo competition, it is one of the cleanest executions around.",
    highlights: ["Fast, precise gameplay", "Big discount in the deals section", "Mick Gordon's epic soundtrack"],
  },
  "portal-2": {
    tagline: "Spatial thinking, timeless humor",
    description:
      "Top-tier puzzles with clever design and writing that still defines the genre. Its co-op campaign is a different treat for duos, and the permanent discount makes it the most affordable classic on the shelf.",
    highlights: ["A lasting classic at a low price", "Six-hour co-op campaign", "First-rate humor and writing"],
  },
  hades: {
    tagline: "Escape the underworld, again and again",
    description:
      "An action roguelite where the story advances with every death. Fast gameplay, lovable characters and a rich upgrade system made it the template for the whole genre.",
    highlights: ["Short, addictive runs", "Story that advances with every defeat", "Top-tier indie art and music"],
  },
  "hades-2": {
    tagline: "Melinoë versus the Titans",
    description:
      "Supergiant's successful sequel with a new protagonist, witchcraft and deeper systems. If you loved Hades, this delivers the same feeling with even more depth.",
    highlights: ["A magic system and fresh routes", "The series' signature storytelling", "A great gift for Hades fans"],
  },
  "hollow-knight": {
    tagline: "Delve into Hallownest",
    description:
      "A metroidvania with hand-drawn art and a hauntingly beautiful atmosphere. Interconnected maps, tough bosses and abundant secrets made it one of the most respected indie games ever.",
    highlights: ["An intricate, secret-laden world", "Affordable price with dozens of hours", "Stunning hand-made art"],
  },
  celeste: {
    tagline: "Climbing the mountain, climbing yourself",
    description:
      "A precise, challenging platformer with an intimate story about anxiety and self-acceptance. Perfect controls and instant retries make trying again a pleasure.",
    highlights: ["Precise, responsive controls", "An intimate, motivating story", "Assist options for every skill level"],
  },
  "stardew-valley": {
    tagline: "A farm for your peace of mind",
    description:
      "A delightful farming sim with a living village, relationships and seasons. Unrivaled after work or for calm weekend sessions — and free updates have kept coming for years.",
    highlights: ["Pure relaxation, zero pressure", "Co-op play with friends", "Years of free content updates"],
  },
  "disco-elysium": {
    tagline: "Detective work with no guns — all words",
    description:
      "A deep text-driven RPG with an inventive skill system and stunning dialogue. There is no combat; everything moves forward through conversation, thought and moral choices.",
    highlights: ["Arguably gaming's best writing (sample)", "Character building through dialogue", "A truly different experience"],
  },
  "outer-wilds": {
    tagline: "A time loop in a tiny solar system",
    description:
      "A space exploration adventure where progress comes only from knowledge, not gear. Each 22-minute loop reveals a new secret of the system — an experience you will wish you could play again for the first time.",
    highlights: ["Discovery-driven, with no map markers", "Perfect hidden-gem material", "Live-scored music and an intimate atmosphere"],
  },
  "slay-the-spire": {
    tagline: "Climb the spire with cards",
    description:
      "The founding deck-building roguelite. Building your deck along the way with countless synergies makes every run different — great for short sessions and competing with yourself.",
    highlights: ["30-minute runs", "Endless card synergies", "The blueprint for hundreds of successors"],
  },
  "vampire-survivors": {
    tagline: "Horde waves, smart choices",
    description:
      "Minimal action at a tiny price with boundless fun. Just move and pick upgrades — yet the weapon combos are so deep that hours fly by. An official demo is included.",
    highlights: ["Very affordable price", "Official demo to try", "Two-player local co-op"],
  },
  tunic: {
    tagline: "Little fox, mysterious booklet",
    description:
      "An open-world adventure whose puzzles hide inside its own instruction manual, written in an unknown language. A special experience for lovers of discovery and secret gifts.",
    highlights: ["Clever puzzles", "A rarely-seen hidden gem", "The feel of classic Zeldas"],
  },
  "blasphemous-2": {
    tagline: "Dark devotion, heavy penance",
    description:
      "A soulslike metroidvania with penitent Spanish art and punishing combat. Enemies and bosses are unforgettable, and its world drips with ritual mystery.",
    highlights: ["Unique, dark art", "Hard-but-fair boss fights", "Choose one of three starting weapons"],
  },
  "katana-zero": {
    tagline: "Plan, execute, slice",
    description:
      "A neon-noir action platformer with instant deaths and scene-by-scene planning. Its dark narrative and music-driven rhythm create a sharp, condensed experience; an official demo exists.",
    highlights: ["Sharp, precise gameplay", "A short, dense campaign", "Official demo available"],
  },
  gris: {
    tagline: "Watercolor, grief and hope",
    description:
      "A visual and musical journey about grief, with no failure or danger at all. Built for quiet evenings — like a living picture book.",
    highlights: ["Among the most beautiful art styles possible", "A short campaign for one evening", "No stress, no fail states"],
  },
  inside: {
    tagline: "The silence that screams",
    description:
      "An atmospheric puzzle-platformer from the makers of LIMBO with a wordless story. A few short but unforgettable hours whose ending stays with you.",
    highlights: ["A wordless narrative", "Made for one full evening", "Creative, cinematic puzzles"],
  },
  "papers-please": {
    tagline: "Glory to Arstotzka",
    description:
      "A passport-inspection sim on the border of a fictional country, tangled with ethics. Simple yet deep; every decision saves someone or puts them at risk.",
    highlights: ["A truly unique experience", "Real moral choices", "Low price, dense content"],
  },
  cuphead: {
    tagline: "1930s cartoons, 1990s difficulty",
    description:
      "Run-and-gun boss battles with hand-drawn animation over classic film aesthetics. A ruthless-but-fair challenge for soulslike fans and lovers of retro looks.",
    highlights: ["Stunning hand-drawn animation", "A serious challenge for veterans", "Engaging local co-op"],
  },
  sifu: {
    tagline: "Avenge — and age with every fall",
    description:
      "A martial-arts brawler with a unique aging mechanic: every death makes you older. Mastering real kung-fu styles feels tangible — excellent for challenge seekers.",
    highlights: ["A deep combat system", "An innovative aging mechanic", "A demanding road to stage mastery"],
  },
  "forza-horizon-5": {
    tagline: "A driving festival in Mexico",
    description:
      "An open-world racer with gorgeous vistas, hundreds of cars and endless events. Equally great for quick speed sessions or hours of collecting.",
    highlights: ["A beautiful, energetic open world", "The current big discount", "Enjoyable for players of every level"],
  },
  "rocket-league": {
    tagline: "Football with jet-powered cars",
    description:
      "A free online competitive sport with a sky-high skill ceiling. Five-minute matches designed for “just one more game” — and completely free.",
    highlights: ["Completely free", "Short, competitive sessions", "A bottomless skill ceiling"],
  },
};
