/* ————— fragment: dict-share — صفحه «اشتراک‌گذاری همتا‌به‌همتا» (Scorent Share) —————
 * هر کلید: [فارسی (متن اصلی و بدون تغییر), English].
 * پارامترها با الگوی {name} جایگزین می‌شوند؛ اعداد همیشه با f.num/f.toman پاس داده می‌شوند.
 */

export const STR: Record<string, [string, string]> = {
  /* ————— سربرگ صفحه ————— */
  "share.p2pBadge": ["Scorent Share — شبیه‌سازی", "Scorent Share — simulation"],
  "share.title": ["بازار اجاره همتا‌به‌همتا", "Peer-to-peer rental marketplace"],
  "share.subtitle": [
    "گیمرها آگهی اجاره می‌سازند، بقیه اجاره می‌کنند؛ پلتفرم {n}٪ کمیسیون برمی‌دارد. همه تراکنش‌ها شبیه‌سازی‌شده‌اند — اجاره واقعی به مجوز ناشر و مجوزهای پلتفرم نیاز دارد و خرید یک بازی به‌تنهایی اجازه اجاره‌دادن آن را نمی‌دهد.",
    "Gamers create rental listings and others rent them; the platform takes a {n}% commission. All transactions are simulated — real rentals would require publisher and platform licenses, and buying a game alone does not grant the right to rent it out.",
  ],
  "share.potentialEarnings": ["درآمد بالقوه آگهی‌های فعال تو", "Potential earnings from your active listings"],
  "share.realEarnings": ["درآمد واقعی ثبت‌شده (نمایشی)", "Recorded real earnings (demo)"],

  /* ————— نوار ابزار ————— */
  "share.newListing": ["ساخت آگهی جدید", "Create new listing"],
  "share.searchPlaceholder": ["جستجو در آگهی‌ها (بازی، مالک، متن)…", "Search listings (game, owner, text)…"],
  "share.searchAria": ["جستجوی آگهی", "Search listings"],
  "share.onlyAvailable": ["فقط آگهی‌های در دسترس", "Available listings only"],

  /* ————— بخش آگهی‌های من ————— */
  "share.myListingsAria": ["آگهی‌های من", "My listings"],
  "share.manageKicker": ["مدیریت", "Manage"],
  "share.myListingsTitle": ["آگهی‌های تو", "Your listings"],
  "share.mineEmpty": [
    "هنوز آگهی نساخته‌ای. اولین آگهی {n} XP دستاورد دارد.",
    "You haven't created a listing yet. Your first listing earns a {n} XP achievement.",
  ],

  /* ————— بخش بازار ————— */
  "share.allListingsAria": ["همه آگهی‌ها", "All listings"],
  "share.marketKicker": ["بازار", "Marketplace"],
  "share.allListingsTitle": ["همه آگهی‌ها ({n})", "All listings ({n})"],
  "share.sortNote": [
    "مرتب‌سازی: آگهی‌های در دسترس اول؛ تازه‌ترین‌ها جلوتر.",
    "Sorting: available listings first; newest ones up front.",
  ],
  "share.noResultsTitle": ["آگهی‌ای پیدا نشد", "No listings found"],
  "share.noResultsDesc": [
    "جستجو را تغییر بده یا فیلتر «در دسترس» را بردار. می‌توانی خودت هم اولین آگهی را بسازی.",
    "Try a different search or drop the “available” filter. You can create the first listing yourself too.",
  ],

  /* ————— یادداشت پایین صفحه ————— */
  "share.mathNote": [
    "همه مبالغ با اعداد صحیح تومان محاسبه می‌شوند. کمیسیون نمونه: اجاره {price} تومانی → {commission} تومان سهم پلتفرم و {earnings} تومان درآمد برآوردی مالک. هیچ پول واقعی جابه‌جا نمی‌شود.",
    "All amounts are computed with integer Toman math. Sample commission: on a {price} Toman rental → {commission} Toman platform share and {earnings} Toman estimated owner earnings. No real money changes hands.",
  ],

  /* ————— دیالوگ ساخت/ویرایش آگهی ————— */
  "share.createTitle": ["آگهی اجاره همتا‌به‌همتا", "Peer-to-peer rental listing"],
  "share.editTitle": ["ویرایش آگهی", "Edit listing"],
  "share.ethicsNote": [
    "توصیف آگهی اخلاقی: داشتن بازی اجازه اجاره یا بازتوزیع آن را نمی‌دهد؛ اینجا همه‌چیز شبیه‌سازی آموزشی است و تراکنش واقعی رخ نمی‌دهد.",
    "An ethical note on listings: owning a game does not grant the right to rent it out or redistribute it; everything here is an educational simulation and no real transaction takes place.",
  ],
  "share.gameLabel": ["بازی", "Game"],
  "share.gameSelectAria": ["انتخاب بازی", "Select a game"],
  "share.gamePlaceholder": ["یک بازی انتخاب کن…", "Choose a game…"],
  "share.ownerLabel": ["نام نمایشی مالک", "Owner display name"],
  "share.ownerPlaceholder": ["مثلاً آرمان_شبح", "e.g. Arman_Ghost"],
  "share.priceLabel": ["قیمت (تومان)", "Price (Toman)"],
  "share.daysLabel": ["بازه اجاره", "Rental period"],
  "share.day1": ["۱ روز", "1 day"],
  "share.day3": ["۳ روز", "3 days"],
  "share.day7": ["۷ روز", "7 days"],
  "share.descLabel": ["توضیح آگهی", "Listing description"],
  "share.descPlaceholder": [
    "وضعیت، شرایط تحویل، هر نکته‌ای که مستأجر باید بداند…",
    "Condition, handover details, anything the renter should know…",
  ],
  "share.earningsEstimate": ["برآورد درآمد (کمیسیون پلتفرم {n}٪)", "Earnings estimate ({n}% platform commission)"],
  "share.rentPriceLabel": ["قیمت اجاره", "Rental price"],
  "share.platformShare": ["سهم پلتفرم", "Platform share"],
  "share.yourEarnings": ["دریافتی تو", "You receive"],
  "share.commissionPreview": [
    "مثال: برای اجاره {price} تومانی → کمیسیون {commission} و درآمد مالک {earnings} تومان.",
    "Example: on a {price} Toman rental → {commission} commission and {earnings} Toman for the owner.",
  ],
  "share.cancel": ["انصراف", "Cancel"],
  "share.publish": ["انتشار آگهی", "Publish listing"],
  "share.saveChanges": ["ذخیره تغییرات", "Save changes"],

  /* ————— پیام‌های اعتبارسنجی فرم (zod) ————— */
  "share.pickGame": ["بازی را انتخاب کن", "Pick a game"],
  "share.nameMin": ["نام نمایشی حداقل {n} نویسه است", "Display name must be at least {n} characters"],
  "share.nameMax": ["نام حداکثر {n} نویسه است", "Name must be at most {n} characters"],
  "share.priceRequired": ["قیمت را وارد کن", "Enter a price"],
  "share.priceInt": ["قیمت باید عدد صحیح باشد", "Price must be a whole number"],
  "share.priceMin": ["حداقل قیمت {n} تومان است", "Minimum price is {n} Toman"],
  "share.priceMax": ["حداکثر قیمت {n} تومان است", "Maximum price is {n} Toman"],
  "share.descMin": ["توضیح حداقل {n} نویسه است", "Description must be at least {n} characters"],
  "share.descMax": ["توضیح حداکثر {n} نویسه است", "Description must be at most {n} characters"],

  /* ————— اعلان‌ها (toast) ————— */
  "share.updatedToast": ["آگهی به‌روزرسانی شد", "Listing updated"],
  "share.editErr": ["خطا در ویرایش", "Edit failed"],
  "share.createdToast": ["آگهی ساخته شد", "Listing created"],
  "share.createdToastDesc": [
    "دستاورد «{title}» +{xp} XP دارد",
    "The “{title}” achievement is included: +{xp} XP",
  ],
  "share.rentedToast": ["اجاره انجام شد (شبیه‌سازی)", "Rental completed (simulated)"],
  "share.rentedToastDesc": [
    "کمیسیون پلتفرم: {c} — درآمد مالک: {e}",
    "Platform commission: {c} — Owner earnings: {e}",
  ],
  "share.rentErr": ["خطا در اجاره", "Rental failed"],
  "share.deletedToast": ["آگهی حذف شد", "Listing deleted"],

  /* ————— کارت آگهی ————— */
  "share.ownerPrefix": ["مالک:", "Owner:"],
  "share.yourListing": ["آگهی تو", "Your listing"],
  "share.forDays": ["برای {n} روز", "for a {n}-day rental"],
  "share.commissionChip": ["کمیسیون {amount}", "Commission {amount}"],
  "share.ownerEarningsChip": ["درآمد مالک {amount}", "Owner earnings {amount}"],
  "share.postedAt": ["ثبت: {date}", "Posted: {date}"],
  "share.rentThis": ["اجاره این آگهی", "Rent this listing"],
  "share.rentedBadge": ["اجاره‌شده", "Rented"],
  "share.edit": ["ویرایش", "Edit"],
  "share.delete": ["حذف", "Delete"],
  "share.deleteTitle": ["حذف آگهی «{game}»؟", "Delete listing “{game}”?"],
  "share.deleteDesc": [
    "این عمل بازگشت‌پذیر نیست و آگهی از فهرست برداشته می‌شود.",
    "This action cannot be undone and the listing will be removed from the marketplace.",
  ],
  "share.deleteConfirm": ["حذف قطعی", "Delete permanently"],
  "share.realEarningsChip": ["درآمد واقعی از این آگهی: {amount}", "Real earnings from this listing: {amount}"],
};
