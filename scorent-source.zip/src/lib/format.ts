/* ————— Formatting utilities (deterministic, hydration-safe) —————
 * All Persian digit conversion and grouping is done manually (no Intl)
 * so server and client renders are always identical.
 */

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function toFaDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

export function toEnDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
}

const GROUP_SEP = "٬";

/** 1200000 -> "۱٬۲۰۰٬۰۰۰" */
export function groupFa(value: number): string {
  const n = Math.round(Math.abs(value));
  const sign = value < 0 ? "−" : "";
  const s = String(n);
  let out = "";
  for (let i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 === 0) out += GROUP_SEP;
    out += s[i];
  }
  return sign + toFaDigits(out);
}

/** قیمت به تومان: «۱٬۲۰۰٬۰۰۰ تومان» */
export function formatToman(value: number, withUnit = true): string {
  const v = Math.max(0, Math.round(value));
  return withUnit ? `${groupFa(v)} تومان` : groupFa(v);
}

/** «٪۳۵» */
export function formatPercentFa(value: number): string {
  return `٪${toFaDigits(Math.round(value))}`;
}

/** «۴.۸ از ۵» — امتیاز با یک رقم اعشار فارسی */
export function formatRatingFa(rating: number): string {
  const r = Math.max(0, Math.min(5, rating));
  const fixed = r.toFixed(1);
  const [int, frac] = fixed.split(".");
  return `${toFaDigits(int)}${frac === "0" ? "" : `٫${toFaDigits(frac)}`}`;
}

/** تبدیل دقیقه به برچسب بازه: [90,120] -> «۹۰ تا ۱۲۰ دقیقه» */
export function formatMinutesFa(range: [number, number]): string {
  const [a, b] = range;
  if (a >= 60 || b >= 60) {
    const ha = a % 60 === 0 ? toFaDigits(a / 60) : `${toFaDigits(Math.floor(a / 60))}:۱۵`;
    const hb = b % 60 === 0 ? toFaDigits(b / 60) : toFaDigits(Math.round(b / 60));
    if (a === b) return `${ha} ساعت`;
    return `${ha} تا ${hb} ساعت`;
  }
  return `${toFaDigits(a)} تا ${toFaDigits(b)} دقیقه`;
}

/** «۴۵ تا ۶۰ ساعت» برای طول کمپین */
export function formatHoursFa(range: [number, number] | null): string | null {
  if (!range) return null;
  return `${toFaDigits(range[0])} تا ${toFaDigits(range[1])} ساعت`;
}

/* ————— Time formatting ————— */

const MIN = 60_000;
const HOUR = 3_600_000;
const DAY = 86_400_000;

/** «۲ روز و ۵ ساعت» | «۳ ساعت و ۱۲ دقیقه» | «۴ دقیقه» | «کمتر از یک دقیقه» */
export function formatRemainingFa(ms: number): string {
  if (ms <= 0) return "پایان یافته";
  const days = Math.floor(ms / DAY);
  const hours = Math.floor((ms % DAY) / HOUR);
  const minutes = Math.floor((ms % HOUR) / MIN);
  const seconds = Math.floor((ms % MIN) / 1000);
  if (days > 0) return `${toFaDigits(days)} روز و ${toFaDigits(hours)} ساعت`;
  if (hours > 0) return `${toFaDigits(hours)} ساعت و ${toFaDigits(minutes)} دقیقه`;
  if (minutes > 0) return `${toFaDigits(minutes)} دقیقه`;
  return `${toFaDigits(seconds)} ثانیه`;
}

/** تاریخ شمسی — فقط سمت کلاینت استفاده شود (تاریخ‌ها پس از hydrate نمایش داده می‌شوند) */
export function formatDateFa(ts: number): string {
  try {
    return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(new Date(ts));
  } catch {
    return toFaDigits(new Date(ts).toLocaleDateString());
  }
}

export function formatDateTimeFa(ts: number): string {
  try {
    return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(ts));
  } catch {
    return toFaDigits(new Date(ts).toLocaleString());
  }
}
