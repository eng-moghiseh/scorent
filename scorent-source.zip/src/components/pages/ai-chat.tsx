"use client";

/* ————— صفحه گفتگو با دستیار Scorent — #/ai-chat (دوزبانه) —————
 * تجربه کامل چت: خوش‌آمد + پیشنهادهای آماده، تاریخچه مکالمات (سایدبار دسکتاپ
 * و کشوی موبایل)، مارک‌داون، استریم زنده، توقف/تلاش مجدد/کپی.
 */

import { useState } from "react";
import { motion } from "framer-motion";
import { History, MessageSquarePlus, SlidersHorizontal, Sparkles, Trash2, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { useFmt, useT, useUiDir } from "@/lib/i18n";
import { Link as RouteLink, navigate } from "@/components/scorent/router";
import { ScorentMark } from "@/components/scorent/logo";
import { ChatView, PromptGrid, SUGGESTED_PROMPTS } from "@/components/scorent/ai-chat-view";
import { useChatStore } from "@/lib/ai/chat-store";

/* ————— خوش‌آمد ————— */

function WelcomeHero({ compact = false }: { compact?: boolean }) {
  const t = useT();
  const f = useFmt();
  return (
    <div className={cn("flex flex-col items-center pt-6 text-center", compact ? "pb-2" : "pb-6")}>
      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        className="relative mb-4 flex size-16 items-center justify-center rounded-3xl border border-ai/40 bg-ai/10 glow-ai"
      >
        <ScorentMark size={40} />
        <span className="absolute -bottom-1.5 -end-1.5 flex size-6 items-center justify-center rounded-full border border-ai/50 bg-background" aria-hidden>
          <Sparkles className="size-3.5 text-ai" />
        </span>
      </motion.div>
      <h1 className="text-xl font-black md:text-2xl">
        {t("chat.heroTitlePre")} <span className="text-gradient-ai">Scorent</span>
        {t("chat.heroTitlePost")}
      </h1>
      <p className="mt-2.5 max-w-md text-xs leading-6 text-muted-foreground md:text-sm md:leading-7">{t("chat.heroDesc")}</p>
      {!compact ? (
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-[0.68rem]">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-ai/30 bg-ai/10 px-3 py-1 font-bold text-ai">
            <Zap className="size-3" />
            {t("chat.realModelChip")}
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-muted-foreground">
            {t("chat.promptsCount", { n: f.num(SUGGESTED_PROMPTS.length) })}
          </span>
        </div>
      ) : null}
    </div>
  );
}

/* ————— سایدبار مکالمات ————— */

function ConversationList({ onNavigate }: { onNavigate?: () => void }) {
  const conversations = useChatStore((s) => s.conversations);
  const activeId = useChatStore((s) => s.activeId);
  const select = useChatStore((s) => s.selectConversation);
  const remove = useChatStore((s) => s.deleteConversation);
  const newConv = useChatStore((s) => s.newConversation);
  const t = useT();

  return (
    <div className="flex h-full flex-col">
      <div className="p-3">
        <Button
          onClick={() => {
            newConv();
            onNavigate?.();
          }}
          className="w-full gap-2 bg-ai text-white hover:bg-ai/90"
        >
          <MessageSquarePlus className="size-4" />
          {t("chat.newConversation")}
        </Button>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-3" aria-label={t("chat.historyAria")}>
        {conversations.length === 0 ? (
          <p className="px-2 py-6 text-center text-xs leading-6 text-muted-foreground">{t("chat.historyEmpty")}</p>
        ) : (
          <ul className="space-y-1">
            {conversations.map((c) => {
              const active = c.id === activeId;
              const preview = c.messages[c.messages.length - 1]?.content.replace(/[#*`>\-]/g, "").slice(0, 40) ?? "";
              return (
                <li key={c.id} className="group relative">
                  <button
                    type="button"
                    onClick={() => {
                      select(c.id);
                      onNavigate?.();
                    }}
                    aria-current={active ? "true" : undefined}
                    className={cn(
                      "w-full rounded-xl border px-3 py-2.5 text-start transition-colors",
                      active ? "border-ai/40 bg-ai/10" : "border-transparent hover:bg-secondary/70"
                    )}
                  >
                    <span className={cn("block truncate text-xs font-bold", active ? "text-foreground" : "text-muted-foreground")}>
                      {c.title}
                    </span>
                    {preview ? <span className="mt-0.5 block truncate text-[0.65rem] text-muted-foreground/70">{preview}</span> : null}
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      remove(c.id);
                    }}
                    aria-label={t("chat.deleteConvAria", { title: c.title })}
                    className="absolute end-1.5 top-1/2 hidden -translate-y-1/2 rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/15 hover:text-destructive group-hover:block"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div className="border-t border-border p-3">
        <RouteLink
          to="/ai"
          onClick={onNavigate}
          className="flex items-center gap-2.5 rounded-xl border border-border bg-card px-3 py-2.5 text-xs font-bold transition-colors hover:border-ai/40"
        >
          <SlidersHorizontal className="size-4 text-ai" />
          <span className="flex-1">
            {t("chat.quizLink")}
            <span className="mt-0.5 block text-[0.62rem] font-medium text-muted-foreground">{t("chat.quizLinkDesc")}</span>
          </span>
        </RouteLink>
      </div>
    </div>
  );
}

/* ————— صفحه ————— */

export function AIChatPage() {
  const [historyOpen, setHistoryOpen] = useState(false);
  const conversations = useChatStore((s) => s.conversations);
  const streaming = useChatStore((s) => s.streaming);
  const t = useT();
  const dir = useUiDir();

  return (
    <div className="mx-auto flex h-[calc(100svh-8.4rem)] w-full max-w-6xl gap-0 overflow-hidden border-border px-0 lg:h-[calc(100svh-4rem)] lg:border-x" aria-label={t("chat.pageAria")}>
      {/* سایدبار دسکتاپ */}
      <aside className="hidden w-72 shrink-0 border-e border-border bg-surface/50 lg:block" aria-label={t("chat.historyAria")}>
        <ConversationList />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* سربرگ موبایل */}
        <div className="flex items-center gap-2 border-b border-border bg-background/80 px-3 py-2.5 backdrop-blur lg:hidden">
          <Sheet open={historyOpen} onOpenChange={setHistoryOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label={t("chat.historyAria")} className="relative">
                <History className="size-5" />
                {conversations.length > 0 ? (
                  <span className="absolute end-1 top-1 size-2 rounded-full bg-ai" />
                ) : null}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80 border-border bg-surface p-0" dir={dir}>
              <SheetTitle className="sr-only">{t("chat.historyAria")}</SheetTitle>
              <ConversationList onNavigate={() => setHistoryOpen(false)} />
            </SheetContent>
          </Sheet>

          <div className="flex flex-1 items-center gap-2">
            <span className="flex size-8 items-center justify-center rounded-full border border-ai/40 bg-ai/10">
              <Sparkles className="size-4 text-ai" />
            </span>
            <div>
              <p className="text-sm font-extrabold leading-5">{t("dock.title")}</p>
              <p className="text-[0.62rem] text-muted-foreground">{streaming ? t("chat.typing") : t("chat.connectedChip")}</p>
            </div>
          </div>
        </div>

        <ChatView
          emptyState={
            <div className="pt-4">
              <WelcomeHero />
              <PromptGrid onPick={() => undefined} />
              <p className="mt-5 text-center text-[0.68rem] leading-6 text-muted-foreground">{t("chat.scopeNote")}</p>
            </div>
          }
        />
      </div>
    </div>
  );
}

/** دکمه شروع گفتگوی تازه در هدر صفحه چت (برای دسترسی سریع) */
export function NewChatButton() {
  const newConv = useChatStore((s) => s.newConversation);
  const t = useT();
  return (
    <Button
      size="icon"
      variant="ghost"
      aria-label={t("chat.newConversation")}
      onClick={() => {
        newConv();
        navigate("/ai-chat");
      }}
    >
      <MessageSquarePlus className="size-5" />
    </Button>
  );
}
