"use client";

/* ————— پروفایل: همه‌چیز از رکوردهای واقعی اپلیکیشن مشتق می‌شود ————— */

import { useState, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import {
  BookOpen,
  CalendarDays,
  CheckCircle2,
  Heart,
  KeyRound,
  Library,
  MessageSquareQuote,
  Pencil,
  ScrollText,
  ShoppingBag,
  Sparkles,
  Store,
  Trophy,
  UserRound,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { GameCover } from "@/components/scorent/game-cover";
import { AccountCard } from "@/components/scorent/account-card";
import { PriceTag, RentDialog } from "@/components/scorent/commerce";
import { EmptyState, IconByName, SectionHeader, XPBar } from "@/components/scorent/shared";
import { Link as RouteLink, navigate } from "@/components/scorent/router";
import { AVATARS } from "@/lib/data/community";
import { getGame } from "@/lib/data/games";
import { useFmt, useT, useTx, useUiDir, type Fmt, type TFn } from "@/lib/i18n";
import { displayName, useHydrated, useLevelInfo, useScorent } from "@/lib/store";
import { cn } from "@/lib/utils";

/* پیام‌های اعتبارسنجی کلید دیکشنری‌اند و در زمان رندر با t() ترجمه می‌شوند */
const profileSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "profile.nameMin")
    .max(24, "profile.nameMax")
    .regex(/^[^<>{}]*$/, "profile.nameChars"),
});

type ProfileForm = z.infer<typeof profileSchema>;

function EditProfileDialog() {
  const [open, setOpen] = useState(false);
  const profile = useScorent((s) => s.profile);
  const setProfile = useScorent((s) => s.setProfile);
  const t = useT();
  const tx = useTx();
  const dir = useUiDir();
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: { name: "" },
  });

  const openHandler = (next: boolean) => {
    if (next) {
      setValue("name", profile.name);
    }
    setOpen(next);
  };

  const avatar = useScorent((s) => s.profile.avatar);
  const setAvatar = (id: string) => setProfile({ avatar: id });

  return (
    <Dialog open={open} onOpenChange={openHandler}>
      <DialogTrigger asChild>
        <Button size="sm" className="gap-1.5">
          <Pencil className="size-3.5" />
          {t("profile.edit")}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md" dir={dir}>
        <DialogHeader>
          <DialogTitle>{t("profile.edit")}</DialogTitle>
          <DialogDescription>
            {t("profile.editDesc", { achievement: tx("هویت گیمری") })}
          </DialogDescription>
        </DialogHeader>
        <form
          onSubmit={handleSubmit((data) => {
            setProfile({ name: data.name });
            toast.success(t("profile.saved"));
            setOpen(false);
          })}
          className="space-y-4"
        >
          <div className="space-y-1.5">
            <Label htmlFor="pf-name">{t("profile.displayName")}</Label>
            <Input id="pf-name" {...register("name")} placeholder={t("profile.namePlaceholder")} maxLength={24} />
            {errors.name ? <p className="text-xs text-destructive">{t(errors.name.message ?? "")}</p> : null}
          </div>
          <div>
            <Label className="mb-2 block">{t("profile.avatar")}</Label>
            <div className="grid grid-cols-6 gap-2">
              {AVATARS.map((a) => (
                <button
                  key={a.id}
                  type="button"
                  aria-label={t("profile.avatarAria", { id: a.id })}
                  aria-pressed={avatar === a.id}
                  onClick={() => setAvatar(a.id)}
                  className={cn(
                    "flex size-11 items-center justify-center rounded-xl border transition-all",
                    avatar === a.id ? "border-deal bg-deal/12" : "border-border hover:border-deal/40"
                  )}
                  style={{ color: a.color }}
                >
                  <IconByName name={a.icon} className="size-5" />
                </button>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              {t("profile.cancel")}
            </Button>
            <Button type="submit">{t("profile.save")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function ProfilePage() {
  const hydrated = useHydrated();
  const profile = useScorent((s) => s.profile);
  const level = useLevelInfo();
  const purchases = useScorent((s) => s.purchases);
  const rentals = useScorent((s) => s.rentals);
  const allListings = useScorent((s) => s.listings);
  const allReviews = useScorent((s) => s.reviews);
  const wishlist = useScorent((s) => s.wishlist);
  const achievements = useScorent((s) => s.achievements);
  const activity = useScorent((s) => s.activity);
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();

  /* مشتقات پایدار — سلکتورها هرگز آرایه تازه نمی‌سازند (جلوگیری از حلقه رندر) */
  const listings = useMemo(() => allListings.filter((l) => l.mine), [allListings]);
  const reviews = useMemo(() => allReviews.filter((r) => r.mine), [allReviews]);

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-16">
        <div className="skeleton-shimmer h-56 rounded-3xl" />
      </div>
    );
  }

  const av = AVATARS.find((a) => a.id === profile.avatar) ?? AVATARS[0];
  const name = displayName(profile);
  const activeRentals = rentals.filter((r) => r.status === "active");
  const completedRentals = rentals.filter((r) => r.status === "completed");

  const stats = [
    { icon: Library, label: t("profile.statLibrary"), value: purchases.length, tone: "text-deal" },
    { icon: KeyRound, label: t("profile.statActiveRentals"), value: activeRentals.length, tone: "text-rent" },
    { icon: Heart, label: t("profile.statWishlist"), value: wishlist.length, tone: "text-[#ff8fa8]" },
    { icon: MessageSquareQuote, label: t("profile.statReviews"), value: reviews.length, tone: "text-ai" },
    { icon: Store, label: t("profile.statListings"), value: listings.filter((l) => l.available).length, tone: "text-foreground" },
    { icon: Trophy, label: t("profile.statAchievements"), value: Object.keys(achievements).length, tone: "text-deal" },
  ];

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-10 md:px-6">
      {/* هدر پروفایل */}
      <motion.header
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8 rounded-3xl border border-border bg-card p-6"
      >
        <div className="flex flex-wrap items-center gap-5">
          <span
            className="flex size-20 items-center justify-center rounded-3xl border"
            style={{ background: `${av.color}1c`, borderColor: `${av.color}44`, color: av.color }}
          >
            <IconByName name={av.icon} className="size-9" />
          </span>
          <div className="min-w-40 flex-1">
            <h1 className="text-2xl font-black">{tx(name)}</h1>
            <p className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span className="rounded-full bg-deal/12 px-2.5 py-1 font-bold text-deal tnum">
                {t("profile.levelChip", { n: f.num(level.level), title: tx(level.title) })}
              </span>
              <span className="flex items-center gap-1 tnum">
                <CalendarDays className="size-3.5" />
                {profile.createdAt ? t("profile.memberSince", { date: f.dateTime(profile.createdAt) }) : t("profile.newcomer")}
              </span>
            </p>
            <div className="mt-3 max-w-sm">
              <XPBar value={level.intoLevel} max={level.forNext} />
              <p className="mt-1.5 text-[0.66rem] text-muted-foreground tnum">
                {t("profile.xpToNext", { cur: f.num(level.intoLevel), max: f.num(level.forNext), n: f.num(level.level + 1) })}
              </p>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <EditProfileDialog />
            <RouteLink to="/rewards">
              <Button size="sm" variant="outline" className="w-full gap-1.5">
                <Trophy className="size-3.5" />
                {t("profile.rewards")}
              </Button>
            </RouteLink>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-3 gap-2 sm:grid-cols-6">
          {stats.map((s) => (
            <div key={s.label} className="rounded-2xl border border-border bg-secondary/40 p-3 text-center">
              <s.icon className={cn("mx-auto size-4.5", s.tone)} />
              <p className="mt-1.5 text-lg font-black tnum">{f.num(s.value)}</p>
              <p className="text-[0.58rem] leading-4 text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>
      </motion.header>

      <AccountCard />

      <Tabs defaultValue="library" dir={dir}>
        <TabsList className="mb-5 flex-wrap">
          <TabsTrigger value="library" className="gap-1.5">
            <ShoppingBag className="size-3.5" /> {t("profile.tabLibrary")}
          </TabsTrigger>
          <TabsTrigger value="rentals" className="gap-1.5">
            <KeyRound className="size-3.5" /> {t("profile.tabRentals")}
          </TabsTrigger>
          <TabsTrigger value="listings" className="gap-1.5">
            <Store className="size-3.5" /> {t("profile.tabListings")}
          </TabsTrigger>
          <TabsTrigger value="reviews" className="gap-1.5">
            <MessageSquareQuote className="size-3.5" /> {t("profile.tabReviews")}
          </TabsTrigger>
          <TabsTrigger value="activity" className="gap-1.5">
            <ScrollText className="size-3.5" /> {t("profile.tabActivity")}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="library">
          {purchases.length === 0 ? (
            <EmptyState
              icon={BookOpen}
              title={t("profile.emptyLibraryTitle")}
              description={t("profile.emptyLibraryDesc")}
              action={
                <RouteLink to="/store">
                  <Button>{t("profile.goStore")}</Button>
                </RouteLink>
              }
            />
          ) : (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {purchases.map((p) => {
                const game = getGame(p.gameId);
                if (!game) return null;
                return (
                  <button key={p.id} type="button" onClick={() => navigate(`/game/${game.id}`)} className="group text-start">
                    <div className="relative overflow-hidden rounded-2xl border border-border">
                      <GameCover game={game} showTitle={false} className="aspect-[3/4] w-full transition-transform duration-500 group-hover:scale-105" />
                      <span className="absolute start-2 top-2 flex items-center gap-1 rounded-full bg-rent/90 px-2 py-0.5 text-[0.6rem] font-black text-[#062b18]">
                        <CheckCircle2 className="size-3" />
                        {t("profile.demoBadge")}
                      </span>
                    </div>
                    <p className="mt-2 truncate text-sm font-bold" dir="ltr" style={{ textAlign: "start" }}>
                      {game.title}
                    </p>
                    <p className="text-[0.66rem] text-muted-foreground tnum">{f.dateTime(p.purchasedAt)}</p>
                  </button>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="rentals">
          {rentals.length === 0 ? (
            <EmptyState
              icon={KeyRound}
              title={t("profile.emptyRentalsTitle")}
              description={t("profile.emptyRentalsDesc")}
              action={
                <RouteLink to="/rent">
                  <Button className="bg-rent text-[#062b18] hover:bg-rent/90">{t("profile.rentCatalog")}</Button>
                </RouteLink>
              }
            />
          ) : (
            <div className="space-y-2.5">
              {[...activeRentals, ...completedRentals].map((r) => {
                const game = getGame(r.gameId);
                if (!game) return null;
                return (
                  <div key={r.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-3.5">
                    <GameCover game={game} showTitle={false} className="h-14 w-11 rounded-lg" />
                    <div className="min-w-32 flex-1">
                      <p className="text-sm font-bold" dir="ltr" style={{ textAlign: "start" }}>
                        {game.title}
                      </p>
                      <p className="text-[0.66rem] text-muted-foreground tnum">
                        {t("profile.daysRental", { n: f.num(r.days) })} — {formatTomanLite(r.price, t, f)} — {r.status === "active" ? t("profile.statusActive") : t("profile.statusDone")}
                      </p>
                    </div>
                    {r.status === "active" ? (
                      <RouteLink to="/rentals">
                        <Button size="sm" variant="outline" className="text-rent">
                          {t("profile.track")}
                        </Button>
                      </RouteLink>
                    ) : (
                      <RentDialog game={game} defaultDays={r.days}>
                        <Button size="sm" variant="ghost" className="text-rent">
                          {t("profile.rentAgain")}
                        </Button>
                      </RentDialog>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="listings">
          {listings.length === 0 ? (
            <EmptyState
              icon={Store}
              title={t("profile.emptyListingsTitle")}
              description={t("profile.emptyListingsDesc")}
              action={
                <RouteLink to="/share">
                  <Button>{t("profile.createListing")}</Button>
                </RouteLink>
              }
            />
          ) : (
            <div className="space-y-2.5">
              {listings.map((l) => {
                const game = getGame(l.gameId);
                if (!game) return null;
                return (
                  <div key={l.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-3.5">
                    <GameCover game={game} showTitle={false} className="h-14 w-11 rounded-lg" />
                    <div className="min-w-32 flex-1">
                      <p className="text-sm font-bold" dir="ltr" style={{ textAlign: "start" }}>
                        {game.title}
                      </p>
                      <p className="text-[0.66rem] text-muted-foreground tnum">
                        {t("profile.daysRental", { n: f.num(l.days) })} — {formatTomanLite(l.price, t, f)} — {l.available ? t("profile.statusAvailable") : t("profile.statusRented")}
                      </p>
                    </div>
                    <RouteLink to="/share">
                      <Button size="sm" variant="outline">
                        {t("profile.manage")}
                      </Button>
                    </RouteLink>
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="reviews">
          {reviews.length === 0 ? (
            <EmptyState
              icon={MessageSquareQuote}
              title={t("profile.emptyReviewsTitle")}
              description={t("profile.emptyReviewsDesc")}
              action={
                <RouteLink to="/store">
                  <Button>{t("profile.pickGame")}</Button>
                </RouteLink>
              }
            />
          ) : (
            <div className="space-y-3">
              {reviews.map((r) => {
                const game = getGame(r.gameId);
                if (!game) return null;
                return (
                  <div key={r.id} className="rounded-2xl border border-border bg-card p-4">
                    <div className="flex items-center justify-between">
                      <RouteLink to={`/game/${game.id}`} className="text-sm font-bold hover:text-ai">
                        {game.title}
                      </RouteLink>
                      <span className="text-xs text-amber-400 tnum">{"★".repeat(r.rating)}</span>
                    </div>
                    <p className="mt-2 text-xs leading-6 text-muted-foreground">{tx(r.text)}</p>
                    <p className="mt-1.5 text-[0.62rem] text-muted-foreground tnum">{f.dateTime(r.createdAt)}</p>
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="activity">
          {activity.length === 0 ? (
            <EmptyState icon={ScrollText} title={t("profile.emptyActivityTitle")} description={t("profile.emptyActivityDesc")} />
          ) : (
            <div className="max-h-96 space-y-2 overflow-y-auto rounded-2xl border border-border p-3">
              {activity.map((a) => (
                <div key={a.id} className="flex items-center gap-3 rounded-xl bg-secondary/40 px-3 py-2.5">
                  <Sparkles className="size-3.5 shrink-0 text-deal" />
                  <p className="flex-1 text-xs leading-6 text-muted-foreground">{a.key ? t(a.key, a.p ?? {}) : tx(a.text)}</p>
                  <span className="shrink-0 text-[0.6rem] text-muted-foreground tnum">{f.dateTime(a.at)}</span>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <p className="mt-8 flex items-start gap-2 text-xs leading-6 text-muted-foreground">
        <UserRound className="mt-0.5 size-4 shrink-0" />
        {t("profile.derivedNote")}
      </p>
    </div>
  );
}

function formatTomanLite(n: number, t: TFn, f: Fmt): string {
  return t("profile.hezarToman", { n: f.num(Math.round(n / 1000)) });
}
