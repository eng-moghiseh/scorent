/* ————— fragment: dict-rent — صفحات اجاره (rent) و اجاره‌های من (rentals) —————
 * هر کلید: [فارسی، English] — پارامترها با الگوی {name} جایگزین می‌شوند.
 */

export const STR: Record<string, [string, string]> = {
  /* ————— صفحه کاتالوگ اجاره (rent.tsx) ————— */
  "rent.pageTitle": ["اجاره قبل از خرید", "Rent before you buy"],
  "rent.pageDesc": [
    "بازه‌های ۱، ۳ و ۷ روزه با قیمت شفاف. زمان اجاره از لحظه شروع محاسبه می‌شود و در صفحه «اجاره‌های من» زنده دیده می‌شود — این یک شبیه‌سازی آموزشی است و دسترسی واقعی به بازی ارائه نمی‌دهد.",
    "1, 3 and 7-day periods with transparent pricing. Rental time is counted from the moment it starts and can be watched live on the “My Rentals” page — this is an educational simulation and does not provide real game access.",
  ],
  "rent.chipTimestamp": ["زمان باقیمانده از timestamp محاسبه می‌شود", "Remaining time is computed from timestamps"],
  "rent.chipRenew": ["تمدید فعال: به انتهای مهلت فعلی اضافه می‌شود", "Active renewal: extra time is added to the end of the current period"],
  "rent.chipP2p": ["اجاره همتا‌به‌همتا در بخش اشتراک‌گذاری", "Peer-to-peer rentals live in the Sharing section"],
  "rent.myRentals": ["اجاره‌های من", "My Rentals"],
  "rent.catalogTitle": ["کاتالوگ اجاره", "Rental catalog"],
  "rent.catalogCount": ["{n} عنوان آماده اجاره (نمونه)", "{n} titles available for rent (sample)"],
  "rent.emptyTitle": ["فعلاً چیزی برای اجاره نیست", "Nothing available for rent right now"],
  "rent.emptyDesc": ["بعداً سر بزن.", "Check back later."],
  "rent.demoNotice": [
    "اجاره واقعی بازی‌ها به مجوز ناشر و رعایت شرایط لایسنس نیاز دارد؛ این ماژول فقط جریان محصول را شبیه‌سازی می‌کند و هیچ دسترسی واقعی به بازی اعطا نمی‌شود.",
    "Real game rentals require publisher licenses and license compliance; this module only simulates the product flow and grants no real game access.",
  ],
  "rent.startRent": ["شروع اجاره", "Start renting"],
  "rent.detailsLink": ["جزئیات ←", "Details →"],
  "rent.activeRentalChip": ["اجاره فعال داری", "You have an active rental"],
  "rent.dayCount": ["{n} روز", "{n} day(s)"],

  /* ————— صفحه اجاره‌های من (rentals.tsx) ————— */
  "rentals.myRentals": ["اجاره‌های من", "My Rentals"],
  "rentals.pageTitle": ["مدیریت اجاره‌ها", "Manage rentals"],
  "rentals.pageDesc": [
    "زمان باقیمانده هر بار از timestamp بازمحاسبه می‌شود — بعد از رفرش صفحه هم درست است.",
    "Remaining time is recomputed from timestamps on every render — it stays correct even after a page refresh.",
  ],
  "rentals.statusActive": ["فعال", "Active"],
  "rentals.totalSpent": ["مجموع هزینه (نمایشی)", "Total spent (demo)"],
  "rentals.kickerOngoing": ["در جریان", "Ongoing"],
  "rentals.activeTitle": ["اجاره‌های فعال", "Active rentals"],
  "rentals.emptyTitle": ["اجاره فعالی نداری", "You have no active rentals"],
  "rentals.emptyDesc": [
    "از کاتالوگ اجاره یک بازی انتخاب کن و یکی از بازه‌های ۱، ۳ یا ۷ روزه را امتحان کن. جریان کاملاً نمایشی است.",
    "Pick a game from the rental catalog and try one of the 1, 3 or 7-day periods. The whole flow is a demo.",
  ],
  "rentals.goCatalog": ["رفتن به کاتالوگ اجاره", "Go to rental catalog"],
  "rentals.remainingLabel": ["زمان باقیمانده", "Time remaining"],
  "rentals.dates": ["شروع: {start} — پایان: {end}", "Start: {start} — End: {end}"],
  "rentals.srcShare": ["از اشتراک‌گذاری همتا‌به‌همتا", "from peer-to-peer sharing"],
  "rentals.srcStore": ["اجاره فروشگاه", "store rental"],
  "rentals.sourceLine": ["{source} — {n} روزه", "{source} — {n}-day rental"],
  "rentals.dayCount": ["{n} روز", "{n} day(s)"],
  "rentals.renew": ["تمدید", "Renew"],
  "rentals.renewTitle": ["تمدید اجاره {game}", "Renew rental of {game}"],
  "rentals.renewActiveDesc": [
    "چون اجاره فعال است، مدت تمدید به انتهای مهلت فعلی اضافه می‌شود.",
    "Since the rental is active, the renewal time is added to the end of the current period.",
  ],
  "rentals.renewExpiredDesc": [
    "این اجاره منقضی شده؛ دوره تازه از همین لحظه شروع می‌شود.",
    "This rental has expired; a fresh period starts from this moment.",
  ],
  "rentals.cancel": ["انصراف", "Cancel"],
  "rentals.confirmRenew": ["تأیید تمدید", "Confirm renewal"],
  "rentals.renewOk": ["تمدید {n} روزه انجام شد (نمایشی)", "{n}-day renewal completed (demo)"],
  "rentals.renewErr": ["تمدید ناموفق بود", "Renewal failed"],
  "rentals.historyAria": ["تاریخچه اجاره", "Rental history"],
  "rentals.kickerArchive": ["بایگانی", "Archive"],
  "rentals.historyTitle": ["تاریخچه و دوره‌های تمام‌شده", "History & completed periods"],
  "rentals.historyEmpty": [
    "هنوز دوره‌ای تمام نشده. وقتی مهلت یک اجاره تمام شود، اینجا بایگانی می‌شود و {xp} XP تکمیل می‌گیری.",
    "No period has completed yet. When a rental runs out of time, it is archived here and you earn {xp} XP for completing it.",
  ],
  "rentals.completedRow": ["{n} روز — {price}", "{n} day(s) — {price}"],
  "rentals.endedAt": ["پایان: {when}", "ended: {when}"],
  "rentals.statusCompleted": ["تمام‌شده", "Completed"],
  "rentals.renewalRule": [
    "قانون تمدید: اجاره فعال از انتهای مهلت فعلی تمدید می‌شود و اجاره منقضی‌شده از لحظه فعلی. برای جلوگیری از تمدیدهای تکراری ناخواسته، چند ثانیه فاصله بین هر تمدید لازم است. XP تکمیل هر اجاره فقط یک‌بار اعطا می‌شود.",
    "Renewal rule: an active rental is renewed from the end of its current period, while an expired rental starts counting from now. To prevent accidental repeated renewals, a few seconds must pass between renewals. The completion XP for each rental is granted only once.",
  ],
};
