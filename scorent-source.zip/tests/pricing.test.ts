import { describe, expect, it } from "vitest";
import { commissionOf, finalPrice, ownerEarningsOf, rentalPrice, sanitizeDiscount, savingsAmount } from "../src/lib/pricing";
import { GAMES } from "../src/lib/data/games";

describe("pricing", () => {
  it("محاسبه قیمت نهایی با تخفیف", () => {
    expect(finalPrice({ price: 800_000, originalPrice: 1_000_000, discountPercent: 20 })).toBe(800_000);
    expect(finalPrice({ price: 500_000, originalPrice: 1_000_000, discountPercent: 75 })).toBe(250_000);
  });

  it("قیمت نهایی هرگز منفی نیست", () => {
    expect(finalPrice({ price: -100, originalPrice: -500, discountPercent: 30 })).toBe(0);
  });

  it("درصد تخفیف نامعتبر اصلاح می‌شود", () => {
    expect(sanitizeDiscount(120)).toBe(90);
    expect(sanitizeDiscount(-5)).toBe(0);
    expect(sanitizeDiscount(Number.NaN)).toBe(0);
  });

  it("مبلغ صرفه‌جویی درست است", () => {
    expect(savingsAmount({ price: 750_000, originalPrice: 1_000_000, discountPercent: 25 })).toBe(250_000);
  });

  it("کمیسیون پلتفرم ۱۰٪ — مثال سندشده ۲۰۰٬۰۰۰ تومان", () => {
    expect(commissionOf(200_000)).toBe(20_000);
    expect(ownerEarningsOf(200_000)).toBe(180_000);
  });

  it("قیمت اجاره بر اساس بازه", () => {
    const rates = { d1: 50_000, d3: 120_000, d7: 190_000 };
    expect(rentalPrice(rates, 1)).toBe(50_000);
    expect(rentalPrice(rates, 3)).toBe(120_000);
    expect(rentalPrice(rates, 7)).toBe(190_000);
    expect(rentalPrice(rates, 5)).toBeNull();
    expect(rentalPrice(null, 3)).toBeNull();
  });

  it("دیتاست مرکزی: قیمت‌ها با تخفیف سازگارند", () => {
    for (const g of GAMES) {
      const fp = finalPrice(g);
      expect(fp).toBeLessThanOrEqual(g.originalPrice);
      expect(fp).toBeGreaterThanOrEqual(0);
      expect(g.discountPercent).toBeGreaterThanOrEqual(0);
      expect(g.discountPercent).toBeLessThanOrEqual(90);
    }
  });
});
