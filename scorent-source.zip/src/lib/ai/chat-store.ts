"use client";

/* ————— استور گفتگوی دستیار Scorent (zustand + LocalStorage اعتبارسنجی‌شده) —————
 * استریم SSE را از /api/chat می‌خواند؛ توقف (AbortController)، تلاش مجدد،
 * مدیریت مکالمات و پایداری پس از رفرش را پوشش می‌دهد.
 * همه پاسخ‌ها از مدل واقعی می‌آیند — هیچ پاسخ ساختگی در کلاینت نیست.
 */

import { create } from "zustand";
import { useUi } from "@/lib/i18n";
import { createJSONStorage, persist } from "zustand/middleware";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  at: number;
  /** خطا در تولید این پیام رخ داده (دکمه تلاش مجدد نشان بده) */
  error?: boolean;
}

export interface ChatConversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
}

const STORAGE_KEY = "scorent-chat:v1";

function uid(): string {
  const rnd = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 12) : Math.random().toString(36).slice(2, 14);
  return `msg-${Date.now().toString(36)}-${rnd}`;
}

/** بازیابی امن: اگر شکل داده خراب بود، خالی شروع می‌کنیم */
function sanitizeConversations(raw: unknown): ChatConversation[] {
  if (!Array.isArray(raw)) return [];
  const out: ChatConversation[] = [];
  for (const c of raw) {
    if (typeof c !== "object" || c === null) continue;
    const conv = c as Record<string, unknown>;
    if (typeof conv.id !== "string" || !Array.isArray(conv.messages)) continue;
    const messages: ChatMessage[] = [];
    for (const m of conv.messages) {
      if (typeof m !== "object" || m === null) continue;
      const msg = m as Record<string, unknown>;
      if ((msg.role !== "user" && msg.role !== "assistant") || typeof msg.content !== "string") continue;
      messages.push({
        id: typeof msg.id === "string" ? msg.id : uid(),
        role: msg.role,
        content: msg.content,
        at: typeof msg.at === "number" ? msg.at : Date.now(),
        error: msg.error === true,
      });
    }
    out.push({
      id: conv.id,
      title: typeof conv.title === "string" ? conv.title : "گفتگوی تازه",
      messages,
      createdAt: typeof conv.createdAt === "number" ? conv.createdAt : Date.now(),
      updatedAt: typeof conv.updatedAt === "number" ? conv.updatedAt : Date.now(),
    });
  }
  return out.slice(0, 30);
}

interface ChatState {
  conversations: ChatConversation[];
  activeId: string | null;
  /** درخواست فعال در جریان است */
  streaming: boolean;
  newConversation: () => string;
  selectConversation: (id: string) => void;
  deleteConversation: (id: string) => void;
  clearAll: () => void;
  send: (text: string) => Promise<void>;
  stop: () => void;
  /** تلاش مجدد آخرین پیام کاربر (پس از خطا) */
  retry: () => Promise<void>;
}

let activeController: AbortController | null = null;

function titleFrom(text: string): string {
  const t = text.replace(/\s+/g, " ").trim();
  return t.length > 32 ? `${t.slice(0, 32)}…` : t || "گفتگوی تازه";
}

export const useChatStore = create<ChatState>()(
  persist(
    (set, get) => ({
      conversations: [],
      activeId: null,
      streaming: false,

      newConversation: () => {
        const id = `c-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
        const conv: ChatConversation = { id, title: "گفتگوی تازه", messages: [], createdAt: Date.now(), updatedAt: Date.now() };
        set((s) => ({ conversations: [conv, ...s.conversations].slice(0, 30), activeId: id }));
        return id;
      },

      selectConversation: (id) => set({ activeId: id }),

      deleteConversation: (id) =>
        set((s) => {
          const conversations = s.conversations.filter((c) => c.id !== id);
          return { conversations, activeId: s.activeId === id ? conversations[0]?.id ?? null : s.activeId };
        }),

      clearAll: () => set({ conversations: [], activeId: null }),

      /** ارسال پیام و خواندن استریم پاسخ */
      send: async (text) => {
        const content = text.replace(/\s+$/g, "").slice(0, 2000);
        if (!content || get().streaming) return;

        let convId = get().activeId;
        if (!convId || !get().conversations.some((c) => c.id === convId)) {
          convId = get().newConversation();
        }

        const userMsg: ChatMessage = { id: uid(), role: "user", content, at: Date.now() };
        const assistantMsg: ChatMessage = { id: uid(), role: "assistant", content: "", at: Date.now() };

        set((s) => ({
          streaming: true,
          conversations: s.conversations.map((c) =>
            c.id === convId
              ? {
                  ...c,
                  title: c.messages.length === 0 ? titleFrom(content) : c.title,
                  messages: [...c.messages, userMsg, assistantMsg],
                  updatedAt: Date.now(),
                }
              : c
          ),
        }));

        const controller = new AbortController();
        activeController = controller;
        const history = (get().conversations.find((c) => c.id === convId)?.messages ?? [])
          .filter((m) => !m.error && m.content.trim().length > 0 && m.id !== assistantMsg.id)
          .slice(-12)
          .map(({ role, content }) => ({ role, content: content.slice(0, 4000) }));

        const appendTo = (chunk: string, isError = false) => {
          set((s) => ({
            conversations: s.conversations.map((c) =>
              c.id === convId
                ? {
                    ...c,
                    updatedAt: Date.now(),
                    messages: c.messages.map((m) =>
                      m.id === assistantMsg.id ? { ...m, content: m.content + chunk, error: isError || m.error } : m
                    ),
                  }
                : c
            ),
          }));
        };

        try {
          const res = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ history, message: content, uiLang: useUi.getState().locale }),
            signal: controller.signal,
          });

          if (!res.ok || !res.body) {
            let msg = "ارتباط با سرور دستیار برقرار نشد.";
            try {
              const j = (await res.json()) as { error?: string };
              if (j.error) msg = j.error;
            } catch {
              /* بدنه خطا JSON نبود */
            }
            if (res.status === 429) msg = msg || "درخواست‌ها زیاد است؛ کمی صبر کن.";
            appendTo(`⚠️ ${msg}`, true);
            return;
          }

          const reader = res.body.getReader();
          const decoder = new TextDecoder();
          let buffer = "";

          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const events = buffer.split("\n\n");
            buffer = events.pop() ?? "";
            for (const evt of events) {
              for (const line of evt.split("\n")) {
                const trimmed = line.trim();
                if (!trimmed.startsWith("data:")) continue;
                const payload = trimmed.slice(5).trim();
                if (payload === "[DONE]") continue;
                try {
                  const j = JSON.parse(payload) as { t?: string; v?: string };
                  if (j.t === "delta" && typeof j.v === "string") appendTo(j.v);
                  else if (j.t === "error" && typeof j.v === "string") appendTo(`\n\n⚠️ ${j.v}`, true);
                } catch {
                  /* رویداد ناقص */
                }
              }
            }
          }
        } catch (err) {
          if ((err as Error)?.name === "AbortError") {
            appendTo(get().conversations.find((c) => c.id === convId)?.messages.find((m) => m.id === assistantMsg.id)?.content ? "" : "\n\n⚠️ ارسال متوقف شد.", false);
          } else {
            appendTo("\n\n⚠️ خطای شبکه؛ اتصال اینترنت را بررسی کن و «تلاش مجدد» را بزن.", true);
          }
        } finally {
          activeController = null;
          set({ streaming: false });
        }
      },

      stop: () => {
        activeController?.abort();
        activeController = null;
        set({ streaming: false });
      },

      retry: async () => {
        const state = get();
        if (state.streaming) return;
        const conv = state.conversations.find((c) => c.id === state.activeId);
        if (!conv) return;
        const lastUser = [...conv.messages].reverse().find((m) => m.role === "user");
        if (!lastUser) return;
        // حذف همه پیام‌های بعد از آخرین پیام کاربر (خطا و پاسخ ناقص)
        const idx = conv.messages.findIndex((m) => m.id === lastUser.id);
        set((s) => ({
          conversations: s.conversations.map((c) => (c.id === conv.id ? { ...c, messages: c.messages.slice(0, idx) } : c)),
        }));
        await get().send(lastUser.content);
      },
    }),
    {
      name: STORAGE_KEY,
      version: 1,
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ conversations: s.conversations, activeId: s.activeId }) as unknown as ChatState,
      merge: (persisted, current) => {
        const p = persisted as Partial<ChatState> | undefined;
        const conversations = sanitizeConversations(p?.conversations);
        const activeId = p?.activeId && conversations.some((c) => c.id === p.activeId) ? p.activeId : conversations[0]?.id ?? null;
        return { ...current, conversations, activeId, streaming: false };
      },
    }
  )
);

/** گفتگوی فعال (هوک کمکی) */
export function useActiveConversation(): ChatConversation | null {
  return useChatStore((s) => s.conversations.find((c) => c.id === s.activeId) ?? null);
}
