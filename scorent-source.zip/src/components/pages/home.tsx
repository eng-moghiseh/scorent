"use client";

/* ————— صفحه اصلی Scorent (دوزبانه) ————— */

import { motion } from "framer-motion";
import {
  ArrowLeft,
  BadgePercent,
  Clock3,
  Compass,
  Gamepad2,
  Heart,
  KeyRound,
  Library,
  MessageCircle,
  Route as RouteIcon,
  SlidersHorizontal,
  Sparkles,
  Star,
  ThumbsUp,
  Trophy,
  Users,
  Wallet,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { GameCover } from "@/components/scorent/game-cover";
import { GameCard, PriceTag, PurchaseDialog, RentDialog, DemoNotice } from "@/components/scorent/commerce";
import {
  AnimatedNumber,
  DiscountBadge,
  GenreChip,
  RatingBadge,
  SectionHeader,
  StaggerContainer,
  StaggerItem,
  XPBar,
} from "@/components/scorent/shared";
import { Link as RouteLink } from "@/components/scorent/router";
import { GAMES, dealGames, featuredGames, getGame, hiddenGems, indieGames, unusualPicks } from "@/lib/data/games";
import { SEED_ACTIVITY, SEED_REVIEWS, COMMUNITY_NOTE } from "@/lib/data/community";
import { finalPrice, rentalPrice, savingsAmount } from "@/lib/pricing";
import { useFmt, useLang, useT, useTx, useGameText } from "@/lib/i18n";
import { useContentValue } from "@/lib/site-content-client";
import { XP_REWARDS, useHydrated, useLevelInfo, useScorent } from "@/lib/store";
import { LEVEL_TITLES } from "@/lib/xp";

/* ————— ۱) هیرو ————— */

function Hero() {
  const heroCovers = ["elden-ring", "hades", "hollow-knight"].map((id) => getGame(id)!);
  const genreCount = new Set(GAMES.flatMap((g) => g.genres)).size;
  const t = useT();
  const f = useFmt();
  const lang = useLang();
  /* محتوای قابل‌مدیریت ادمین — fallback به دیکشنری */
  const heroTitle = useContentValue("hero.title");
  const heroSub = useContentValue("hero.subtitle");
  const heroKicker = useContentValue("hero.kicker");

  return (
    <section className="relative overflow-hidden border-b border-border" aria-label={t("home.heroAria")}>
      {/* پس‌زمینه لایه‌ای */}
      <div className="absolute inset-0 bg-grid mask-fade-b opacity-70" aria-hidden />
      <div className="absolute -top-40 start-1/4 size-[480px] rounded-full bg-deal/10 blur-[130px]" aria-hidden />
      <div className="absolute bottom-0 end-0 size-[420px] rounded-full bg-ai/10 blur-[130px]" aria-hidden />
      <div className="absolute inset-0 flex items-center justify-center" aria-hidden>
        <svg viewBox="0 0 64 64" className="size-[580px] opacity-[0.05]" style={{ transform: "translateX(-6%)" }}>
          <g fill="#FF9F43">
            <path d="M30.5 38 C31 45.5 37.5 51 45 49.2 C51.5 47.6 54.8 40.8 52.4 34.7 C50.5 29.8 45.5 27.6 40.9 29.3 L42.1 33.2 C45.1 32.1 48.2 33.7 49.4 37 C50.9 41 48.8 45.3 44.5 46.5 C39.3 47.9 34.4 44.2 34.2 38.3 Z" />
            <path d="M42.2 28.2 C39.2 28.6 36.9 30.7 36.4 33.5 C39.3 34.3 42.1 33 43.5 30.5 Z" />
            <rect x="26.6" y="21" width="10.2" height="18.5" rx="5.1" />
            <circle cx="31.7" cy="20" r="5.8" />
            <path d="M12.5 14.8 L18.9 11.9 A6.5 6.5 0 1 0 17.5 21.4 Z" />
            <path d="M50.9 14.8 L44.5 11.9 A6.5 6.5 0 1 1 45.9 21.4 Z" />
          </g>
          <g stroke="#FF9F43" strokeWidth="2.6" strokeLinecap="round" fill="none">
            <path d="M28.8 17.2 C26.4 14.6 23.4 13 20.2 12.8" />
            <path d="M34.6 17.2 C37 14.6 40 13 43.2 12.8" />
            <path d="M26.8 25 L20.4 27.7" />
            <path d="M26.6 29.5 L20 33" />
            <path d="M36.6 25 L43 27.7" />
            <path d="M36.8 29.5 L43.4 33" />
          </g>
        </svg>
      </div>

      <div className="relative mx-auto grid w-full max-w-7xl gap-12 px-4 pb-16 pt-14 md:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:pb-24 lg:pt-20">
        {/* متن هیرو */}
        <motion.div
          initial="hidden"
          animate="show"
          variants={{ hidden: {}, show: { transition: { staggerChildren: 0.09 } } }}
          className="flex flex-col justify-center"
        >
          <motion.div
            variants={{ hidden: { opacity: 0, y: 14 }, show: { opacity: 1, y: 0 } }}
            className="mb-5 inline-flex w-fit items-center gap-2 rounded-full border border-deal/30 bg-deal/10 px-3.5 py-1.5 text-xs font-bold text-deal"
          >
            <Gamepad2 className="size-3.5" />
            {heroKicker ?? t("home.heroBadge")}
          </motion.div>

          <motion.h1
            variants={{ hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0, transition: { duration: 0.6 } } }}
            className="text-4xl font-black leading-[1.25] md:text-5xl lg:text-[3.4rem] lg:leading-[1.2]"
          >
            <HeroTitle title={heroTitle} lang={lang} />
          </motion.h1>

          <motion.p
            variants={{ hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0 } }}
            className="mt-5 max-w-xl text-base leading-8 text-muted-foreground md:text-lg md:leading-9"
          >
            {heroSub ?? t("home.heroDesc")}
          </motion.p>

          <motion.div
            variants={{ hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0 } }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <RouteLink to="/store">
              <Button size="lg" className="glow-brand gap-2 text-base">
                <Compass className="size-5" />
                {t("home.heroCta1")}
              </Button>
            </RouteLink>
            <RouteLink to="/ai-chat">
              <Button size="lg" variant="outline" className="gap-2 border-ai/40 text-base text-ai hover:bg-ai/10">
                <MessageCircle className="size-5" />
                {t("home.heroCta2")}
              </Button>
            </RouteLink>
          </motion.div>

          <motion.dl
            variants={{ hidden: { opacity: 0 }, show: { opacity: 1 } }}
            className="mt-10 grid max-w-md grid-cols-3 gap-4"
          >
            {[
              { v: GAMES.length, label: t("home.statGames") },
              { v: genreCount, label: t("home.statGenres") },
              { v: 3, label: t("home.statRent") },
            ].map(({ v, label }) => (
              <div key={label} className="rounded-2xl border border-border bg-card/60 p-3.5 text-center backdrop-blur">
                <dt className="sr-only">{label}</dt>
                <dd className="text-2xl font-black text-deal tnum">
                  <AnimatedNumber value={v} />
                </dd>
                <dd className="mt-1 text-[0.7rem] leading-5 text-muted-foreground">{label}</dd>
              </div>
            ))}
          </motion.dl>
        </motion.div>

        {/* کلاژ کاورها */}
        <div className="relative hidden min-h-[460px] lg:block" aria-hidden>
          <div className="aurora-orb absolute start-1/2 top-1/2 size-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full" aria-hidden />
          {heroCovers.map((game, i) => {
            const cfg = [
              { w: "w-64", pos: "top-2 end-6", rot: "6deg", delay: 0 },
              { w: "w-56", pos: "bottom-6 start-10", rot: "-7deg", delay: 0.9 },
              { w: "w-48", pos: "top-28 start-44", rot: "10deg", delay: 1.7 },
            ][i];
            return (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, y: 40, rotate: 0 }}
                animate={{ opacity: 1, y: 0, rotate: 0 }}
                transition={{ delay: 0.25 + i * 0.14, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
                className={`absolute ${cfg.pos}`}
              >
                <div className="float-slow" style={{ ["--float-rot" as string]: cfg.rot, animationDelay: `${cfg.delay}s` }}>
                  <GameCover game={game} priority className={`${cfg.w} aspect-[3/4] rounded-2xl border border-white/10 shadow-2xl shadow-black/60`} />
                </div>
              </motion.div>
            );
          })}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.9, duration: 0.5 }}
            className="absolute bottom-0 end-0 flex items-center gap-2 rounded-2xl border border-rent/30 bg-background/80 px-4 py-3 backdrop-blur"
          >
            <KeyRound className="size-5 text-rent" />
            <div>
              <p className="text-xs font-extrabold text-rent">{t("home.rentFromChip")}</p>
              <p className="text-[0.65rem] text-muted-foreground">{t("home.rentPeriodsChip")}</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/** عنوان هیرو با بخش گرادیانی — مستقل برای مدیریت دو زبانه */
/* عنوان هیرو: متن ادمین در صورت وجود، وگرنه پیش‌فرض با گرادیان کلمه‌ی آخر */
function HeroTitle({ title, lang }: { title: string | null; lang: "fa" | "en" }) {
  if (title) {
    const parts = title.split(/\s+/);
    const last = parts.pop() ?? "";
    if (parts.length > 0) {
      return (
        <>
          {parts.join(" ")} <span className="text-gradient-brand">{last}</span>
        </>
      );
    }
    return <span className="text-gradient-brand">{title}</span>;
  }
  if (lang === "en") {
    return (
      <>
        Pick your next game <span className="text-gradient-brand">the smart way</span>
      </>
    );
  }
  return (
    <>
      بازی بعدیت رو <span className="text-gradient-brand">هوشمندانه</span> انتخاب کن
    </>
  );
}

/* ————— ۲) بازی‌های منتخب ————— */

function FeaturedSection() {
  const games = featuredGames().slice(0, 8);
  const t = useT();
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-14 md:px-6" aria-label={t("home.featuredAria")}>
      <SectionHeader
        kicker={t("home.featuredKicker")}
        title={t("home.featuredTitle")}
        description={t("home.featuredDesc")}
        icon={Star}
        action={{ label: t("home.allGames"), to: "/store" }}
      />
      <StaggerContainer className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {games.map((g, i) => (
          <StaggerItem key={g.id}>
            <GameCard game={g} index={i} />
          </StaggerItem>
        ))}
      </StaggerContainer>
    </section>
  );
}

/* ————— ۳) معرفی Scorent AI ————— */

function AISection() {
  const t = useT();
  const f = useFmt();
  const capabilities = [
    { icon: Wallet, titleKey: "home.cap1Title", descKey: "home.cap1Desc" },
    { icon: ThumbsUp, titleKey: "home.cap2Title", descKey: "home.cap2Desc" },
    { icon: Compass, titleKey: "home.cap3Title", descKey: "home.cap3Desc" },
    { icon: Sparkles, titleKey: "home.cap4Title", descKey: "home.cap4Desc" },
  ];
  return (
    <section className="border-y border-border bg-surface/60" aria-label={t("home.aiAria")}>
      <div className="mx-auto grid w-full max-w-7xl items-center gap-10 px-4 py-14 md:px-6 lg:grid-cols-2">
        <div>
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-ai/12 px-3.5 py-1.5 text-xs font-bold text-ai">
            <Sparkles className="size-3.5" />
            {t("home.aiBadge")}
          </div>
          <h2 className="text-2xl font-extrabold leading-snug md:text-3xl">
            {t("home.aiTitlePre")} <span className="text-gradient-ai">{t("home.aiTitleGrad")}</span>
          </h2>
          <p className="mt-4 text-sm leading-8 text-muted-foreground md:text-base">{t("home.aiDesc")}</p>
          <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
            {capabilities.map(({ icon: Icon, titleKey, descKey }) => (
              <li key={titleKey} className="flex items-start gap-2.5 rounded-xl border border-border bg-card/70 p-3">
                <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg bg-ai/12 text-ai">
                  <Icon className="size-4" />
                </span>
                <span>
                  <b className="block text-sm font-extrabold">{t(titleKey)}</b>
                  <span className="mt-0.5 block text-xs leading-6 text-muted-foreground">{t(descKey)}</span>
                </span>
              </li>
            ))}
          </ul>
          <div className="mt-7 flex flex-wrap gap-3">
            <RouteLink to="/ai-chat">
              <Button size="lg" className="gap-2 bg-ai text-white hover:bg-ai/90 glow-ai">
                <MessageCircle className="size-4.5" />
                {t("home.heroCta2")}
              </Button>
            </RouteLink>
            <RouteLink to="/ai">
              <Button size="lg" variant="outline" className="gap-2 border-ai/35 text-ai hover:bg-ai/10">
                <SlidersHorizontal className="size-4.5" />
                {t("home.aiQuizCta")}
              </Button>
            </RouteLink>
          </div>
        </div>

        {/* ماکت گفتگو */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6 }}
          className="rounded-3xl border border-ai/25 bg-card p-5 glow-ai md:p-6"
          aria-hidden
        >
          <div className="mb-4 flex items-center gap-2 border-b border-border pb-3">
            <span className="flex size-8 items-center justify-center rounded-full border border-ai/40 bg-ai/10">
              <Sparkles className="size-4 text-ai" />
            </span>
            <div>
              <p className="text-sm font-extrabold">{t("dock.title")}</p>
              <p className="text-[0.65rem] text-muted-foreground">{t("home.aiMockSubtitle")}</p>
            </div>
          </div>
          <div className="space-y-3 text-xs leading-6">
            <div className="ms-auto w-fit max-w-[85%] rounded-2xl rounded-te-md border border-border bg-secondary px-3.5 py-2.5">
              {t("home.aiMockQ")}
            </div>
            <div className="me-auto w-fit max-w-[92%] rounded-2xl rounded-ts-md border border-ai/25 bg-ai/8 px-3.5 py-2.5">
              <p>{t("home.aiMockA")}</p>
              <ul className="mt-2 list-disc space-y-1.5 pe-4">
                <li>
                  <b className="text-foreground">Stardew Valley</b> — {t("home.aiMockL1")}{" "}
                  <span className="tnum">{f.toman(400_000)}</span> {t("home.aiMockWith")}{" "}
                  <span className="tnum">{f.percent(20)}</span> {t("home.aiMockOff")}
                </li>
                <li>
                  <b className="text-foreground">Outer Wilds</b> — {t("home.aiMockL2")}{" "}
                  <span className="tnum">{f.toman(455_000)}</span>
                </li>
                <li>
                  <b className="text-foreground">INSIDE</b> — {t("home.aiMockL3")}{" "}
                  <span className="tnum">{f.toman(293_000)}</span>
                </li>
              </ul>
              <p className="mt-2 text-[0.68rem] text-ai">{t("home.aiMockFooter")}</p>
            </div>
            <div className="rounded-xl bg-ai/10 p-3 text-[0.7rem] leading-6 text-ai">
              {t("home.aiMockNote")}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ————— ۴) اسپات‌لایت ————— */

function SpotlightSection() {
  const game = getGame("hades")!;
  const t = useT();
  const tx = useTx();
  const gt = useGameText(game);
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-14 md:px-6" aria-label={t("home.spotlightAria")}>
      <SectionHeader kicker={t("home.spotKicker")} title={t("home.spotTitle")} icon={Star} tone="deal" />
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 0.6 }}
        className="grid overflow-hidden rounded-3xl border border-border bg-card lg:grid-cols-[380px_1fr]"
      >
        <div className="relative min-h-[300px]">
          <GameCover game={game} className="absolute inset-0 size-full" />
          <div className="absolute inset-0 hidden bg-gradient-to-l from-card via-card/40 to-transparent lg:block" />
        </div>
        <div className="p-6 md:p-9">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-deal/15 px-3 py-1 text-xs font-extrabold text-deal">{t("home.spotBadge")}</span>
            <RatingBadge rating={game.rating} />
            {game.genres.map((g) => (
              <GenreChip key={g} label={tx(g)} />
            ))}
          </div>
          <h3 className="mt-4 text-3xl font-black" dir="ltr" style={{ textAlign: "start" }}>
            {game.title}
          </h3>
          <p className="mt-3 max-w-2xl text-sm leading-8 text-muted-foreground">{gt.description}</p>
          <ul className="mt-5 grid gap-2 sm:grid-cols-3">
            {gt.highlights.map((h) => (
              <li key={h} className="flex items-start gap-2 rounded-xl bg-secondary/60 p-3 text-xs leading-6 text-muted-foreground">
                <Star className="mt-1 size-3.5 shrink-0 fill-deal text-deal" />
                {h}
              </li>
            ))}
          </ul>
          <div className="mt-7 flex flex-wrap items-center gap-3">
            <RouteLink to={`/game/${game.id}`}>
              <Button>{t("home.viewDetails")}</Button>
            </RouteLink>
            <PurchaseDialog game={game} />
            <RentDialog game={game} defaultDays={3} />
            <div className="ms-auto flex items-center gap-3">
              <PriceTag game={game} />
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}

/* ————— ۵) تخفیف‌ها ————— */

function DealsSection() {
  const deals = [...dealGames()].sort((a, b) => b.discountPercent - a.discountPercent).slice(0, 4);
  const t = useT();
  const f = useFmt();
  const lang = useLang();
  return (
    <section className="border-y border-border bg-surface/60" aria-label={t("home.dealsAria")}>
      <div className="mx-auto w-full max-w-7xl px-4 py-14 md:px-6">
        <SectionHeader
          kicker={t("home.dealsKicker")}
          title={t("home.dealsTitle")}
          description={t("home.dealsDesc")}
          icon={BadgePercent}
          tone="deal"
          action={{ label: t("home.allDeals"), to: "/deals" }}
        />
        <StaggerContainer className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {deals.map((g, i) => (
            <StaggerItem key={g.id}>
              <motion.div whileHover={{ y: -4 }} className="group overflow-hidden rounded-2xl border border-deal/20 bg-card">
                <RouteLink to={`/game/${g.id}`} className="relative block">
                  <GameCover game={g} className="aspect-[3/4] w-full transition-transform duration-500 group-hover:scale-[1.04]" />
                  <span className="absolute start-2 top-2 rounded-full bg-deal px-2.5 py-1 text-sm font-black text-[#3a1c00] tnum">
                    {lang === "fa" ? `${f.num(g.discountPercent)}٪−` : `−${g.discountPercent}%`}
                  </span>
                </RouteLink>
                <div className="p-4">
                  <RouteLink to={`/game/${g.id}`} className="block truncate font-bold hover:text-deal">
                    {g.title}
                  </RouteLink>
                  <div className="mt-2 flex items-baseline gap-2">
                    <span className="text-lg font-black text-deal tnum">{f.toman(finalPrice(g))}</span>
                    <span className="text-xs text-muted-foreground line-through tnum">{f.toman(g.originalPrice)}</span>
                  </div>
                  <p className="mt-1 text-[0.7rem] text-rent tnum">{t("home.saving")}: {f.toman(savingsAmount(g))}</p>
                </div>
              </motion.div>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}

/* ————— ۶) کشف ————— */

function DiscoverySection() {
  const t = useT();
  const cats = [
    {
      title: t("home.discCat1Title"),
      desc: t("home.discCat1Desc"),
      games: indieGames().slice(0, 3),
      to: "/discovery?tab=indie",
    },
    {
      title: t("home.discCat2Title"),
      desc: t("home.discCat2Desc"),
      games: hiddenGems().slice(0, 3),
      to: "/discovery?tab=gems",
    },
    {
      title: t("home.discCat3Title"),
      desc: t("home.discCat3Desc"),
      games: unusualPicks().slice(0, 3),
      to: "/discovery?tab=unusual",
    },
  ];
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-14 md:px-6" aria-label={t("home.discAria")}>
      <SectionHeader
        kicker={t("home.discKicker")}
        title={t("home.discTitle")}
        description={t("home.discDesc")}
        icon={Compass}
        action={{ label: t("home.discEnter"), to: "/discovery" }}
      />
      <div className="grid gap-4 md:grid-cols-3">
        {cats.map((c) => (
          <motion.div
            key={c.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.5 }}
            className="flex flex-col rounded-3xl border border-border bg-card p-5"
          >
            <h3 className="text-lg font-extrabold">{c.title}</h3>
            <p className="mt-1.5 text-xs leading-6 text-muted-foreground">{c.desc}</p>
            <div className="mt-4 grid grid-cols-3 gap-2">
              {c.games.map((g) => (
                <RouteLink key={g.id} to={`/game/${g.id}`} className="group relative overflow-hidden rounded-xl">
                  <GameCover game={g} showTitle={false} className="aspect-[3/4] w-full transition-transform duration-500 group-hover:scale-105" />
                </RouteLink>
              ))}
            </div>
            <RouteLink
              to={c.to}
              className="mt-4 inline-flex items-center gap-1.5 text-sm font-bold text-muted-foreground transition-colors hover:text-foreground"
            >
              {t("home.seeAll")}
              <ArrowLeft className="size-4" />
            </RouteLink>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ————— ۷) اجاره ————— */

function RentSection() {
  const demo = getGame("hades")!;
  const t = useT();
  const f = useFmt();
  const steps = [
    { icon: Compass, title: t("home.rentStep1Title"), desc: t("home.rentStep1Desc") },
    { icon: Clock3, title: t("home.rentStep2Title"), desc: t("home.rentStep2Desc") },
    { icon: Gamepad2, title: t("home.rentStep3Title"), desc: t("home.rentStep3Desc") },
  ];
  return (
    <section className="border-y border-border bg-surface/60" aria-label={t("home.rentAria")}>
      <div className="mx-auto w-full max-w-7xl px-4 py-14 md:px-6">
        <div className="grid items-center gap-10 lg:grid-cols-[1fr_420px]">
          <div>
            <SectionHeader
              kicker="Scorent Rent"
              title={t("home.rentTitle")}
              description={t("home.rentDesc")}
              icon={KeyRound}
              tone="rent"
            />
            <ol className="grid gap-3 sm:grid-cols-3">
              {steps.map((s, i) => (
                <motion.li
                  key={s.title}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08, duration: 0.45 }}
                  className="rounded-2xl border border-border bg-card p-4"
                >
                  <div className="mb-2.5 flex size-9 items-center justify-center rounded-xl bg-rent/12 text-rent">
                    <s.icon className="size-4.5" />
                  </div>
                  <p className="text-sm font-extrabold">
                    <span className="me-1 text-rent tnum">{f.num(i + 1)}.</span>
                    {s.title}
                  </p>
                  <p className="mt-1 text-xs leading-6 text-muted-foreground">{s.desc}</p>
                </motion.li>
              ))}
            </ol>
            <div className="mt-6 flex flex-wrap gap-3">
              <RouteLink to="/rent">
                <Button className="gap-2 bg-rent text-[#062b18] hover:bg-rent/90 glow-rent">
                  <KeyRound className="size-4" />
                  {t("home.rentCatalogCta")}
                </Button>
              </RouteLink>
              <RouteLink to="/share">
                <Button variant="outline" className="gap-2">
                  <RouteIcon className="size-4" />
                  {t("home.p2pCta")}
                </Button>
              </RouteLink>
            </div>
          </div>

          {/* پیش‌نمایش قیمت اجاره */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
            className="rounded-3xl border border-rent/25 bg-card p-5 glow-rent"
          >
            <p className="mb-4 text-sm font-extrabold text-rent">{t("home.rentSamplePrices")} — {demo.title}</p>
            <div className="grid grid-cols-3 gap-2">
              {([1, 3, 7] as const).map((d) => (
                <div key={d} className="rounded-2xl border border-border bg-secondary/50 p-3 text-center">
                  <p className="text-xs text-muted-foreground">{t("commerce.dayCount", { n: f.num(d) })}</p>
                  <p className="mt-1.5 text-sm font-black text-rent tnum">{f.toman(rentalPrice(demo.rental!, d) ?? 0)}</p>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <RentDialog game={demo} defaultDays={7}>
                <Button variant="outline" className="w-full border-rent/40 text-rent hover:bg-rent/10">
                  {t("home.tryRentFlow")}
                </Button>
              </RentDialog>
            </div>
            <DemoNotice>{t("home.rentFlowNote")}</DemoNotice>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ————— ۸) جوایز ————— */

function RewardsSection() {
  const level = useLevelInfo();
  const hydrated = useHydrated();
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-14 md:px-6" aria-label={t("home.rewardsAria")}>
      <div className="grid items-center gap-10 lg:grid-cols-2">
        <div>
          <SectionHeader
            kicker="Scorent Rewards"
            title={t("home.rewardsTitle")}
            description={t("home.rewardsDesc")}
            icon={Trophy}
            action={{ label: t("home.rewardsCta"), to: "/rewards" }}
          />
          <ul className="grid gap-2.5 sm:grid-cols-2">
            {[
              { icon: Wallet, text: `${t("xp.demoPurchase")}: ${f.num(XP_REWARDS.purchase)} XP` },
              { icon: KeyRound, text: `${t("xp.rentalComplete")}: ${f.num(XP_REWARDS.rentalComplete)} XP` },
              { icon: Library, text: `${t("xp.validReview")}: ${f.num(XP_REWARDS.review)} XP` },
              { icon: Users, text: `${t("xp.weeklyChallenge")}: ${f.num(XP_REWARDS.weeklyChallenge)} XP` },
            ].map(({ icon: Icon, text }) => (
              <li key={text} className="flex items-center gap-2.5 rounded-xl border border-border bg-card px-4 py-3 text-sm">
                <Icon className="size-4.5 text-deal" />
                {text}
              </li>
            ))}
          </ul>
          <div className="mt-6 flex flex-wrap gap-2" aria-label={t("home.levelMilestonesAria")}>
            {LEVEL_TITLES.map((lt) => (
              <span
                key={lt.minLevel}
                className={`rounded-full border px-3 py-1 text-xs font-bold tnum ${
                  hydrated && level.level >= lt.minLevel ? "border-deal/50 bg-deal/10 text-deal" : "border-border text-muted-foreground"
                }`}
              >
                {t("home.levelN", { n: f.num(lt.minLevel) })}: {tx(lt.title)}
              </span>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55 }}
          className="rounded-3xl border border-deal/25 bg-card p-6 glow-brand"
        >
          <div className="flex items-center gap-4">
            <div className="flex size-16 items-center justify-center rounded-2xl bg-deal/12 text-2xl font-black text-deal tnum">
              {hydrated ? f.num(level.level) : "—"}
            </div>
            <div className="flex-1">
              <p className="text-sm text-muted-foreground">{t("home.currentLevel")}</p>
              <p className="text-xl font-black">{hydrated ? tx(level.title) : tx("تازه‌کار")}</p>
            </div>
            <div className="text-end">
              <p className="text-sm font-extrabold text-deal tnum">
                {hydrated ? <AnimatedNumber value={level.intoLevel} /> : f.num(0)}
                <span className="text-xs font-medium text-muted-foreground"> / {f.num(level.forNext)} XP</span>
              </p>
              <p className="text-[0.68rem] text-muted-foreground">{t("home.toNextLevel")}</p>
            </div>
          </div>
          <XPBar value={hydrated ? level.intoLevel : 0} max={level.forNext || 100} className="mt-4" />
          <p className="mt-4 text-xs leading-6 text-muted-foreground">{t("home.xpNote")}</p>
        </motion.div>
      </div>
    </section>
  );
}

/* ————— ۹) جامعه ————— */

function CommunitySection() {
  const reviews = SEED_REVIEWS.slice(0, 3);
  const activity = SEED_ACTIVITY.slice(0, 4);
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  return (
    <section className="border-t border-border bg-surface/60" aria-label={t("home.communityAria")}>
      <div className="mx-auto w-full max-w-7xl px-4 py-14 md:px-6">
        <SectionHeader
          kicker={t("home.communityKicker")}
          title={t("home.communityTitle")}
          description={t("home.communityDesc")}
          icon={Users}
          action={{ label: t("home.writeReview"), to: "/store" }}
        />
        <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
          <StaggerContainer className="grid gap-4 sm:grid-cols-3">
            {reviews.map((r) => {
              const game = getGame(r.gameId);
              if (!game) return null;
              return (
                <StaggerItem key={r.id}>
                  <div className="flex h-full flex-col rounded-2xl border border-border bg-card p-4">
                    <div className="flex items-center gap-1" aria-label={t("home.ratingOutOf5", { n: f.rating(r.rating) })}>
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className={`size-3.5 ${i < r.rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground/40"}`} />
                      ))}
                    </div>
                    <p className="mt-3 flex-1 text-xs leading-6 text-muted-foreground">«{tx(r.text)}»</p>
                    <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
                      <div>
                        <p className="text-xs font-bold">{r.author}</p>
                        <RouteLink to={`/game/${game.id}`} className="text-[0.68rem] text-muted-foreground hover:text-foreground">
                          {t("home.onGame", { game: game.title })}
                        </RouteLink>
                      </div>
                      <span className="flex items-center gap-1 text-[0.68rem] text-muted-foreground tnum">
                        <ThumbsUp className="size-3" />
                        {f.num(24)}
                      </span>
                    </div>
                  </div>
                </StaggerItem>
              );
            })}
          </StaggerContainer>

          <div className="rounded-2xl border border-border bg-card p-5">
            <h3 className="mb-4 flex items-center gap-2 text-sm font-extrabold">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-rent opacity-60" />
                <span className="relative inline-flex size-2 rounded-full bg-rent" />
              </span>
              {t("home.recentActivity")}
            </h3>
            <ul className="space-y-3.5">
              {activity.map((a) => {
                const game = getGame(a.gameId);
                return (
                  <li key={a.author + a.gameId} className="flex items-center gap-3">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-secondary">
                      <Heart className="size-4 text-muted-foreground" />
                    </span>
                    <p className="text-xs leading-6 text-muted-foreground">
                      <b className="text-foreground">{a.author}</b> {tx(a.text)}
                      {game ? (
                        <>
                          {" — "}
                          <RouteLink to={`/game/${game.id}`} className="text-deal hover:underline">
                            {game.title}
                          </RouteLink>
                        </>
                      ) : null}
                    </p>
                  </li>
                );
              })}
            </ul>
            <p className="mt-5 rounded-xl bg-secondary/60 p-3 text-[0.68rem] leading-5 text-muted-foreground">{tx(COMMUNITY_NOTE)}</p>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ————— صفحه اصلی ————— */

export function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedSection />
      <AISection />
      <SpotlightSection />
      <DealsSection />
      <DiscoverySection />
      <RentSection />
      <RewardsSection />
      <CommunitySection />
    </>
  );
}
