"use client";

/* ————— فروشگاه مرکزی Scorent (zustand + LocalStorage اعتبارسنجی‌شده) —————
 * لایه ذخیره‌سازی از UI جدا است. همه رویدادهای XP با شناسه یکتا ثبت می‌شوند
 * تا هیچ جایزه‌ای دوباره اعطا نشود (idempotent).
 */

import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { getISOWeek, getISOWeekYear } from "date-fns";
import type {
  ActivityEvent,
  Listing,
  Preferences,
  Profile,
  Purchase,
  Rental,
  Review,
  ShareOrder,
  XPEvent,
} from "./types";
import { finalPrice, isRentalDays, rentalPrice } from "./pricing";
import { DAY_MS, renewalExpiry, RENEW_COOLDOWN_MS } from "./rental-time";
import { ACHIEVEMENTS, SEED_REVIEWS, WEEKLY_CHALLENGES } from "./data/community";
import { getGame } from "./data/games";
import { levelTitle } from "./xp";

const STORAGE_KEY = "scorent:v1";
const STORE_VERSION = 1;

export const XP_REWARDS = {
  profileComplete: 50,
  review: 30,
  rentalComplete: 40,
  purchase: 60,
  weeklyChallenge: 100,
  helpfulVote: 20,
} as const;

function uid(prefix: string): string {
  const rnd = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10);
  return `${prefix}-${Date.now().toString(36)}-${rnd}`;
}

function weekKeyOf(ts: number): string {
  const d = new Date(ts);
  return `${getISOWeekYear(d)}-W${getISOWeek(d)}`;
}

export function currentWeekKey(): string {
  return weekKeyOf(Date.now());
}

/* ————— ذخیره‌سازی امن: اعتبارسنجی + بازیابی از داده خراب ————— */

interface PersistedShape {
  version: number;
  profile: Profile;
  wishlist: unknown;
  purchases: unknown;
  rentals: unknown;
  listings: unknown;
  shareOrders: unknown;
  reviews: unknown;
  votedReviewIds: unknown;
  helpfulDelta: unknown;
  xpEvents: unknown;
  achievements: unknown;
  completedChallenges: unknown;
  activity: unknown;
  prefs: unknown;
  aiCompleted: unknown;
}

function isValidShape(x: unknown): x is Omit<PersistedShape, "version"> {
  if (!x || typeof x !== "object") return false;
  const o = x as PersistedShape;
  return (
    typeof o.profile === "object" &&
    o.profile !== null &&
    typeof (o.profile as Profile).name === "string" &&
    Array.isArray(o.wishlist) &&
    Array.isArray(o.purchases) &&
    Array.isArray(o.rentals) &&
    Array.isArray(o.listings) &&
    Array.isArray(o.shareOrders) &&
    Array.isArray(o.reviews) &&
    Array.isArray(o.votedReviewIds) &&
    Array.isArray(o.xpEvents) &&
    Array.isArray(o.activity) &&
    typeof o.achievements === "object" &&
    o.achievements !== null
  );
}

const safeStorage = {
  getItem: (name: string): string | null => {
    /* SSR: localStorage در دسترس نیست — بی‌صدا null (بدون لاگ اسپم سرور) */
    if (typeof window === "undefined") return null;
    try {
      const raw = window.localStorage.getItem(name);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      // قالب zustand persist: { state: {...}, version: n } — نسخه در لایه بیرونی است
      const inner = parsed && typeof parsed === "object" && "state" in parsed ? parsed.state : parsed;
      const version =
        parsed && typeof parsed === "object" && typeof parsed.version === "number"
          ? parsed.version
          : inner && typeof inner === "object" && typeof (inner as PersistedShape).version === "number"
            ? (inner as PersistedShape).version
            : STORE_VERSION;
      if (version > STORE_VERSION) {
        console.warn("[Scorent] نسخه داده ذخیره‌شده جدیدتر از نسخه اپ است؛ بازنشانی می‌شود.");
        return null;
      }
      if (!isValidShape(inner)) {
        console.warn("[Scorent] داده ذخیره‌شده نامعتبر بود؛ بازنشانی می‌شود.");
        return null;
      }
      return raw;
    } catch {
      console.warn("[Scorent] داده ذخیره‌شده خراب بود؛ بازنشانی می‌شود.");
      return null;
    }
  },
  setItem: (name: string, value: string): void => {
    try {
      window.localStorage.setItem(name, value);
    } catch {
      /* حافظه پر یا غیرفعال — نادیده گرفته می‌شود */
    }
  },
  removeItem: (name: string): void => {
    try {
      window.localStorage.removeItem(name);
    } catch {
      /* noop */
    }
  },
};

/* ————— آگهی‌های نمونه اجاره همتا‌به‌همتا (داده نمایشی) ————— */

function seedListings(): Listing[] {
  const base = Date.now() - 3 * DAY_MS;
  const mk = (i: number, gameId: string, ownerName: string, price: number, days: 1 | 3 | 7, description: string, offsetDays: number): Listing => ({
    id: `seed-l${i}`,
    gameId,
    ownerName,
    price,
    days,
    description,
    available: true,
    createdAt: base - offsetDays * DAY_MS,
    mine: false,
  });
  return [
    mk(1, "elden-ring", "آرمان_شبح", 850_000, 7, "دو هفته تمامش کردم؛ دنیای عظیمی دارد. برای کسی که می‌خواهد امتحانش کند، اجاره ۷ روزه عالی است.", 6),
    mk(2, "rdr2", "خانم_مرجانی", 320_000, 3, "داستانش را تمام کرده‌ام، دیسک سالم است. برای آخر هفته‌ی داستانی عالی است.", 5),
    mk(3, "hades", "Melody", 120_000, 3, "برای شروع روگ‌لایت بهترین انتخاب است. هر جلسه ۳۰ دقیقه؛ ریسک کم، لذت زیاد.", 4),
    mk(4, "bg3", "D&D_Lover", 450_000, 3, "با گروه ۳ نفره شروع کردیم؛ اجاره‌اش می‌ارزد تا ببینید با سلیقه گروهتان جور است یا نه.", 3),
    mk(5, "forza-horizon-5", "پهلوان_گاز", 150_000, 1, "برای یک شب رانندگی با دوستان. کنترلر و فرمول هر دو اوکی است.", 2),
    mk(6, "stardew-valley", "آقای_کدوبان", 90_000, 7, "یک هفته مزرعه‌داری؛ اگر آرامش می‌خواهید همین است. آموزش نصب هم می‌دهم.", 1),
  ];
}

/* ————— حالت مرکزی ————— */

export interface FlashItem {
  kind: "xp" | "achievement" | "challenge";
  text: string;
  /** kind=xp: مقدار XP رویداد */
  xp?: number;
  /** kind=xp: برچسب ثابت رویداد (قابل ترجمه با tx) */
  label?: string;
  /** kind=achievement|challenge: عنوان ثابت (قابل ترجمه با tx) */
  title?: string;
}

export interface ScorentState {
  hydrated: boolean;
  flashId: number;
  flash: FlashItem[];
  profile: Profile;
  wishlist: string[];
  purchases: Purchase[];
  rentals: Rental[];
  listings: Listing[];
  shareOrders: ShareOrder[];
  reviews: Review[];
  votedReviewIds: string[];
  helpfulDelta: Record<string, number>;
  xpEvents: XPEvent[];
  achievements: Record<string, { unlockedAt: number }>;
  completedChallenges: Record<string, { completedAt: number }>;
  activity: ActivityEvent[];
  prefs: Preferences | null;
  aiCompleted: boolean;

  setHydrated: () => void;
  setProfile: (p: Partial<Profile>) => void;
  toggleWishlist: (gameId: string) => "added" | "removed";
  isWishlisted: (gameId: string) => boolean;
  isOwned: (gameId: string) => boolean;
  purchase: (gameId: string) => { ok: boolean; reason?: string };
  rent: (gameId: string, days: 1 | 3 | 7, source?: "rent" | "share") => { ok: boolean; reason?: string; rental?: Rental };
  renewRental: (rentalId: string, days: 1 | 3 | 7) => { ok: boolean; reason?: string };
  completeExpiredRentals: (now?: number) => number;
  createListing: (data: Omit<Listing, "id" | "available" | "createdAt" | "mine">) => Listing;
  updateListing: (id: string, data: Partial<Pick<Listing, "price" | "days" | "description" | "available">>) => { ok: boolean; reason?: string };
  removeListing: (id: string) => void;
  rentListing: (listingId: string) => { ok: boolean; reason?: string; order?: ShareOrder };
  addReview: (gameId: string, rating: number, text: string) => { ok: boolean; reason?: string };
  voteHelpful: (reviewId: string) => { ok: boolean; reason?: string };
  setPrefs: (p: Preferences) => void;
  completeAI: () => void;
  totalXp: () => number;
  challengeProgress: (metric: "wishlist" | "review" | "rental") => number;
  clearFlash: () => void;
  resetAll: () => void;
  exportData: () => string | null;
  importData: (json: string) => { ok: boolean; reason?: string };
}

const initialData = {
  profile: { name: "", avatar: "scorpion", createdAt: null } as Profile,
  wishlist: [] as string[],
  purchases: [] as Purchase[],
  rentals: [] as Rental[],
  listings: seedListings(),
  shareOrders: [] as ShareOrder[],
  reviews: [] as Review[],
  votedReviewIds: [] as string[],
  helpfulDelta: {} as Record<string, number>,
  xpEvents: [] as XPEvent[],
  achievements: {} as Record<string, { unlockedAt: number }>,
  completedChallenges: {} as Record<string, { completedAt: number }>,
  activity: [] as ActivityEvent[],
  prefs: null as Preferences | null,
  aiCompleted: false,
};

export const useScorent = create<ScorentState>()(
  persist(
    (set, get) => {
      /** اعطای XP با شناسه یکتا — جلوی جایزه تکراری را می‌گیرد */
      function awardXp(eventId: string, amount: number, label: string): boolean {
        const st = get();
        if (st.xpEvents.some((e) => e.id === eventId)) return false;
        const ev: XPEvent = { id: eventId, amount, label, at: Date.now() };
        set((s) => ({
          xpEvents: [...s.xpEvents, ev],
          flash: [...s.flash, { kind: "xp" as const, text: `+${amount} XP — ${label}`, xp: amount, label }],
          flashId: s.flashId + 1,
        }));
        return true;
      }

      function logActivity(type: ActivityEvent["type"], text: string, gameId?: string, key?: string, p?: Record<string, string>): void {
        const ev: ActivityEvent = { id: uid("act"), type, text, gameId, at: Date.now(), ...(key ? { key, p } : {}) };
        set((s) => ({ activity: [ev, ...s.activity].slice(0, 100) }));
      }

      function pushFlash(item: FlashItem): void {
        set((s) => ({ flash: [...s.flash, item], flashId: s.flashId + 1 }));
      }

      /** بررسی و بازکردن دستاوردهای وضعیت‌محور */
      function checkAchievements(): void {
        const st = get();
        const owned = st.purchases.length;
        const level = computeLevelSafe(st.xpEvents);
        const userReviews = st.reviews.filter((r) => r.mine);
        const reviewGames = new Set(userReviews.map((r) => r.gameId));
        const candidates: string[] = [];
        if (st.profile.name.trim().length >= 2) candidates.push("profile-complete");
        if (owned >= 1) candidates.push("first-purchase");
        if (owned >= 3) candidates.push("collector-3");
        if (st.rentals.length >= 1) candidates.push("first-rental");
        if (st.rentals.some((r) => r.days === 7 && r.status === "completed")) candidates.push("rental-7d");
        if (userReviews.length >= 1) candidates.push("first-review");
        if (reviewGames.size >= 3) candidates.push("critic-3");
        if (st.wishlist.length >= 5) candidates.push("wishlist-5");
        if (st.aiCompleted) candidates.push("ai-explorer");
        if (st.listings.some((l) => l.mine)) candidates.push("first-listing");
        if (level >= 5) candidates.push("level-5");
        if (level >= 10) candidates.push("level-10");

        for (const id of candidates) {
          if (st.achievements[id]) continue;
          const def = ACHIEVEMENTS.find((a) => a.id === id);
          if (!def) continue;
          set((s) => ({ achievements: { ...s.achievements, [id]: { unlockedAt: Date.now() } } }));
          pushFlash({ kind: "achievement", text: `دستاورد باز شد: ${def.title}`, title: def.title });
          if (def.bonusXp > 0) awardXp(`achievement:${id}`, def.bonusXp, def.title);
        }
      }

      function computeLevelSafe(events: XPEvent[]): number {
        const xp = events.reduce((a, e) => a + e.amount, 0);
        let level = 1;
        const total = (l: number) => {
          const n = l - 1;
          return n * 100 + (50 * (n - 1) * n) / 2;
        };
        while (level < 50 && xp >= total(level + 1)) level++;
        return level;
      }

      /** چالش هفتگی را در صورت تکمیل، یک‌بار برای این هفته ثبت کن */
      function checkWeekly(metric: "wishlist" | "review" | "rental"): void {
        const st = get();
        const wk = currentWeekKey();
        for (const ch of WEEKLY_CHALLENGES) {
          if (ch.metric !== metric) continue;
          const key = `${wk}:${ch.id}`;
          if (st.completedChallenges[key]) continue;
          const progress = get().challengeProgress(metric);
          if (progress >= ch.target) {
            set((s) => ({ completedChallenges: { ...s.completedChallenges, [key]: { completedAt: Date.now() } } }));
            pushFlash({ kind: "challenge", text: `چالش هفتگی «${ch.title}» کامل شد`, title: ch.title });
            awardXp(`challenge:${key}`, ch.xp, ch.title);
            logActivity("xp", `چالش هفتگی «${ch.title}» کامل شد`, undefined, "act.challengeDone", { title: ch.title });
          }
        }
      }

      return {
        hydrated: false,
        flashId: 0,
        flash: [],
        ...initialData,

        setHydrated: () => set({ hydrated: true }),

        setProfile: (p) => {
          const prev = get().profile;
          const next: Profile = { ...prev, ...p };
          const wasComplete = prev.name.trim().length >= 2;
          const isComplete = next.name.trim().length >= 2;
          if (!next.createdAt) next.createdAt = Date.now();
          set({ profile: next });
          if (isComplete && !wasComplete) {
            awardXp("profile-completed", XP_REWARDS.profileComplete, "تکمیل پروفایل");
            logActivity("profile", "پروفایل را کامل کرد", undefined, "act.profileCompleted");
          }
          checkAchievements();
        },

        toggleWishlist: (gameId) => {
          const has = get().wishlist.includes(gameId);
          if (has) {
            set((s) => ({ wishlist: s.wishlist.filter((id) => id !== gameId) }));
            return "removed";
          }
          const game = getGame(gameId);
          set((s) => ({ wishlist: [gameId, ...s.wishlist] }));
          logActivity("wishlist", `${game?.title ?? gameId} را به علاقه‌مندی‌ها اضافه کرد`, gameId, "act.wishlistAdd", { game: game?.title ?? gameId });
          checkWeekly("wishlist");
          checkAchievements();
          return "added";
        },

        isWishlisted: (gameId) => get().wishlist.includes(gameId),
        isOwned: (gameId) => get().purchases.some((p) => p.gameId === gameId),

        purchase: (gameId) => {
          const game = getGame(gameId);
          if (!game) return { ok: false, reason: "بازی پیدا نشد" };
          if (get().isOwned(gameId)) return { ok: false, reason: "این بازی قبلاً خریداری شده است" };
          const purchase: Purchase = {
            id: uid("buy"),
            gameId,
            price: finalPrice(game),
            purchasedAt: Date.now(),
          };
          set((s) => ({ purchases: [purchase, ...s.purchases] }));
          logActivity("purchase", `${game.title} را خرید (نمایشی)`, gameId, "act.purchase", { game: game.title });
          awardXp(`purchase:${purchase.id}`, XP_REWARDS.purchase, "خرید نمایشی");
          checkAchievements();
          return { ok: true };
        },

        rent: (gameId, days, source = "rent") => {
          const game = getGame(gameId);
          if (!game) return { ok: false, reason: "بازی پیدا نشد" };
          if (!game.rentalAvailable || !game.rental) return { ok: false, reason: "اجاره این عنوان در دسترس نیست" };
          if (!isRentalDays(days)) return { ok: false, reason: "بازه اجاره نامعتبر است" };
          const price = rentalPrice(game.rental, days);
          if (price === null) return { ok: false, reason: "قیمت اجاره نامعتبر است" };
          const now = Date.now();
          const rental: Rental = {
            id: uid("rent"),
            gameId,
            days,
            price,
            startedAt: now,
            expiresAt: now + days * DAY_MS,
            status: "active",
            completedAt: null,
            source,
          };
          set((s) => ({ rentals: [rental, ...s.rentals] }));
          logActivity("rent", `${game.title} را برای ${days} روز اجاره کرد (نمایشی)`, gameId, "act.rent", { game: game.title, days: String(days) });
          checkWeekly("rental");
          checkAchievements();
          return { ok: true, rental };
        },

        renewRental: (rentalId, days) => {
          const st = get();
          const rental = st.rentals.find((r) => r.id === rentalId);
          if (!rental) return { ok: false, reason: "اجاره پیدا نشد" };
          if (!isRentalDays(days)) return { ok: false, reason: "بازه نامعتبر است" };
          const now = Date.now();
          if (rental.lastRenewedAt && now - rental.lastRenewedAt < RENEW_COOLDOWN_MS) {
            return { ok: false, reason: "تازگی تمدید شده؛ چند لحظه صبر کن" };
          }
          const newExpiry = renewalExpiry(rental, now, days);
          const game = getGame(rental.gameId);
          set((s) => ({
            rentals: s.rentals.map((r) =>
              r.id === rentalId ? { ...r, expiresAt: newExpiry, status: "active", completedAt: null, lastRenewedAt: now } : r
            ),
          }));
          logActivity("rent", `${game?.title ?? ""} تا ${days} روز دیگر تمدید شد (نمایشی)`, rental.gameId, "act.renew", { game: game?.title ?? "", days: String(days) });
          checkAchievements();
          return { ok: true };
        },

        completeExpiredRentals: (now = Date.now()) => {
          const st = get();
          let count = 0;
          for (const r of st.rentals) {
            if (r.status === "active" && r.expiresAt <= now) {
              count++;
              set((s) => ({
                rentals: s.rentals.map((x) => (x.id === r.id ? { ...x, status: "completed" as const, completedAt: now } : x)),
              }));
              const game = getGame(r.gameId);
              awardXp(`rental-complete:${r.id}`, XP_REWARDS.rentalComplete, "تکمیل دوره اجاره");
              logActivity("rent", `دوره اجاره ${game?.title ?? ""} تمام شد`, r.gameId, "act.rentalEnded", { game: game?.title ?? "" });
              checkAchievements();
            }
          }
          return count;
        },

        createListing: (data) => {
          const listing: Listing = {
            ...data,
            id: uid("lst"),
            available: true,
            createdAt: Date.now(),
            mine: true,
          };
          set((s) => ({ listings: [listing, ...s.listings] }));
          const game = getGame(data.gameId);
          logActivity("listing", `آگهی اجاره ${game?.title ?? ""} ساخته شد`, data.gameId, "act.listingCreated", { game: game?.title ?? "" });
          checkAchievements();
          return listing;
        },

        updateListing: (id, data) => {
          const st = get();
          const listing = st.listings.find((l) => l.id === id);
          if (!listing) return { ok: false, reason: "آگهی پیدا نشد" };
          if (!listing.mine) return { ok: false, reason: "فقط آگهی‌های خودت قابل ویرایش است" };
          set((s) => ({ listings: s.listings.map((l) => (l.id === id ? { ...l, ...data } : l)) }));
          return { ok: true };
        },

        removeListing: (id) => {
          set((s) => ({ listings: s.listings.filter((l) => l.id !== id) }));
        },

        rentListing: (listingId) => {
          const st = get();
          const listing = st.listings.find((l) => l.id === listingId);
          if (!listing) return { ok: false, reason: "آگهی پیدا نشد" };
          if (!listing.available) return { ok: false, reason: "این آگهی دیگر در دسترس نیست" };
          const price = Math.max(0, Math.round(listing.price));
          const commission = Math.round(price * 0.1);
          const order: ShareOrder = {
            id: uid("ord"),
            listingId,
            gameId: listing.gameId,
            price,
            commission,
            ownerEarnings: price - commission,
            rentedAt: Date.now(),
          };
          set((s) => ({
            shareOrders: [order, ...s.shareOrders],
            listings: s.listings.map((l) => (l.id === listingId ? { ...l, available: false } : l)),
          }));
          const game = getGame(listing.gameId);
          logActivity("share", `آگهی ${game?.title ?? ""} از ${listing.ownerName} اجاره شد (شبیه‌سازی)`, listing.gameId, "act.orderPlaced", { game: game?.title ?? "", owner: listing.ownerName });
          // اجاره همتا‌به‌همتا هم به‌عنوان اجاره فعال ثبت می‌شود
          const rental: Rental = {
            id: uid("rent"),
            gameId: listing.gameId,
            days: listing.days,
            price,
            startedAt: Date.now(),
            expiresAt: Date.now() + listing.days * DAY_MS,
            status: "active",
            completedAt: null,
            source: "share",
          };
          set((s) => ({ rentals: [rental, ...s.rentals] }));
          checkWeekly("rental");
          checkAchievements();
          return { ok: true, order };
        },

        addReview: (gameId, rating, text) => {
          const game = getGame(gameId);
          if (!game) return { ok: false, reason: "بازی پیدا نشد" };
          const r = Math.round(rating);
          if (r < 1 || r > 5) return { ok: false, reason: "امتیاز باید بین ۱ تا ۵ باشد" };
          const clean = text.trim();
          if (clean.length < 10) return { ok: false, reason: "متن نظر باید حداقل ۱۰ نویسه باشد" };
          if (clean.length > 600) return { ok: false, reason: "متن نظر بیش از حد طولانی است" };
          const review: Review = {
            id: uid("rev"),
            gameId,
            author: get().profile.name.trim() || "گیمر مهمان",
            rating: r,
            text: clean,
            createdAt: Date.now(),
            mine: true,
          };
          set((s) => ({ reviews: [review, ...s.reviews] }));
          logActivity("review", `برای ${game.title} نظر ثبت کرد`, gameId, "act.reviewAdded", { game: game.title });
          awardXp(`review:${review.id}`, XP_REWARDS.review, "ثبت نظر معتبر");
          checkWeekly("review");
          checkAchievements();
          return { ok: true };
        },

        voteHelpful: (reviewId) => {
          const st = get();
          if (st.votedReviewIds.includes(reviewId)) return { ok: false, reason: "قبلاً به این نظر رأی دادی" };
          set((s) => ({
            votedReviewIds: [...s.votedReviewIds, reviewId],
            helpfulDelta: { ...s.helpfulDelta, [reviewId]: (s.helpfulDelta[reviewId] ?? 0) + 1 },
          }));
          awardXp(`helpful:${reviewId}`, XP_REWARDS.helpfulVote, "رأی مفید به نظر");
          return { ok: true };
        },

        setPrefs: (p) => set({ prefs: p }),

        completeAI: () => {
          if (get().aiCompleted) return;
          set({ aiCompleted: true });
          logActivity("ai", "پرسش‌نامه Scorent AI را کامل کرد", undefined, "act.aiCompleted");
          checkAchievements();
        },

        totalXp: () => get().xpEvents.reduce((a, e) => a + e.amount, 0),

        challengeProgress: (metric) => {
          const wk = currentWeekKey();
          const weekStart = getWeekStartTs();
          const st = get();
          const inWeek = (ts: number) => weekKeyOf(ts) === wk && ts >= weekStart - 1000;
          switch (metric) {
            case "wishlist":
              return st.activity.filter((a) => a.type === "wishlist" && inWeek(a.at)).length;
            case "review":
              return st.reviews.filter((r) => r.mine && inWeek(r.createdAt)).length;
            case "rental":
              return st.rentals.filter((r) => inWeek(r.startedAt)).length;
          }
        },

        clearFlash: () => set({ flash: [] }),

        resetAll: () => {
          set({ ...initialData, flash: [], flashId: 0 });
          try {
            window.localStorage.removeItem(STORAGE_KEY);
          } catch {
            /* noop */
          }
        },

        exportData: () => {
          const st = get();
          const data = {
            version: STORE_VERSION,
            exportedAt: new Date().toISOString(),
            profile: st.profile,
            wishlist: st.wishlist,
            purchases: st.purchases,
            rentals: st.rentals,
            listings: st.listings,
            shareOrders: st.shareOrders,
            reviews: st.reviews,
            votedReviewIds: st.votedReviewIds,
            helpfulDelta: st.helpfulDelta,
            xpEvents: st.xpEvents,
            achievements: st.achievements,
            completedChallenges: st.completedChallenges,
            activity: st.activity,
            prefs: st.prefs,
            aiCompleted: st.aiCompleted,
          };
          try {
            return JSON.stringify(data, null, 2);
          } catch {
            return null;
          }
        },

        importData: (json) => {
          try {
            const parsed = JSON.parse(json);
            if (!isValidShape(parsed)) return { ok: false, reason: "ساختار فایل پشتیبانی نمی‌شود" };
            set({
              profile: parsed.profile,
              wishlist: parsed.wishlist as string[],
              purchases: parsed.purchases as Purchase[],
              rentals: parsed.rentals as Rental[],
              listings: parsed.listings as Listing[],
              shareOrders: parsed.shareOrders as ShareOrder[],
              reviews: parsed.reviews as Review[],
              votedReviewIds: parsed.votedReviewIds as string[],
              helpfulDelta: parsed.helpfulDelta as Record<string, number>,
              xpEvents: parsed.xpEvents as XPEvent[],
              achievements: parsed.achievements as Record<string, { unlockedAt: number }>,
              completedChallenges: parsed.completedChallenges as Record<string, { completedAt: number }>,
              activity: parsed.activity as ActivityEvent[],
              prefs: parsed.prefs as Preferences | null,
              aiCompleted: Boolean(parsed.aiCompleted),
            });
            return { ok: true };
          } catch {
            return { ok: false, reason: "فایل JSON معتبر نیست" };
          }
        },
      };
    },
    {
      name: STORAGE_KEY,
      version: STORE_VERSION,
      storage: createJSONStorage(() => safeStorage),
      partialize: (s) => ({
        profile: s.profile,
        wishlist: s.wishlist,
        purchases: s.purchases,
        rentals: s.rentals,
        listings: s.listings,
        shareOrders: s.shareOrders,
        reviews: s.reviews,
        votedReviewIds: s.votedReviewIds,
        helpfulDelta: s.helpfulDelta,
        xpEvents: s.xpEvents,
        achievements: s.achievements,
        completedChallenges: s.completedChallenges,
        activity: s.activity,
        prefs: s.prefs,
        aiCompleted: s.aiCompleted,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated();
      },
    }
  )
);

function getWeekStartTs(): number {
  // شروع هفته ISO = دوشنبه؛ برای نمایش کافی است
  const d = new Date();
  const day = (d.getDay() + 6) % 7;
  d.setHours(0, 0, 0, 0);
  return d.getTime() - day * DAY_MS;
}

/* ————— هوک‌های کمکی ————— */

import { computeLevel } from "./xp";

export function useHydrated(): boolean {
  return useScorent((s) => s.hydrated);
}

export function useLevelInfo() {
  const totalXp = useScorent((s) => s.xpEvents.reduce((a, e) => a + e.amount, 0));
  return computeLevel(totalXp);
}

export function useLevelTitle(): string {
  const totalXp = useScorent((s) => s.xpEvents.reduce((a, e) => a + e.amount, 0));
  return levelTitle(computeLevel(totalXp).level);
}

export function displayName(profile: Profile): string {
  return profile.name.trim() || "گیمر مهمان";
}
