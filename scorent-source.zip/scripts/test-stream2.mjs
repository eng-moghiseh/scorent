/* Test SSE decoding of z-ai stream */
import ZAI from "z-ai-web-dev-sdk";

async function main() {
  const zai = await ZAI.create();
  const stream = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: "You are a helpful assistant. Reply briefly." },
      { role: "user", content: "بازی «Hades» چه ژانری دارد؟ در یک جمله." },
    ],
    stream: true,
    thinking: { type: "disabled" },
  });

  const decoder = new TextDecoder();
  let raw = "";
  for await (const chunk of stream) {
    raw += decoder.decode(chunk, { stream: true });
  }
  // Show first 3 SSE events and count
  const lines = raw.split("\n").filter(Boolean);
  console.log("total SSE lines:", lines.length);
  for (const l of lines.slice(0, 4)) console.log("LINE:", l.slice(0, 220));
  console.log("...");
  for (const l of lines.slice(-2)) console.log("LAST:", l.slice(0, 220));
}

main().catch((e) => {
  console.error("ERR:", e.message);
  process.exit(1);
});
