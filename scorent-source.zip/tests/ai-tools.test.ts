/* ————— تست ابزارهای کاتالوگ و پارسر نیت دستیار Scorent —————
 * اصل: هر عددی که دستیار به کاربر می‌دهد باید از این توابع قطعی بیاید.
 */

import { describe, expect, it } from "vitest";
import { GAMES } from "../src/lib/data/games";
import { finalPrice } from "../src/lib/pricing";
import {
  byBudgetTool,
  byPlaystyleKeyword,
  catalogStatsTool,
  compareGamesTool,
  dealsTool,
  gameDetailTool,
  recommendTool,
  searchCatalogTool,
  toBrief,
} from "../src/lib/ai/catalog-tools";
import { clampHistory } from "../src/lib/ai/prompt";
import { emptyIntent, extractIntentDeterministic, mergeIntents } from "../src/lib/ai/intent";

describe("catalog tools — grounded data", () => {
  it("brief link and final price always match the central dataset", () => {
    for (const g of GAMES.slice(0, 10)) {
      const b = toBrief(g);
      expect(b.link).toBe(`#/game/${g.id}`);
      expect(b.priceToman).toBe(finalPrice(g));
      expect(b.priceToman).toBeLessThanOrEqual(g.originalPrice);
    }
  });

  it("search finds hades by English title", () => {
    const res = searchCatalogTool("hades");
    expect(res.count).toBeGreaterThan(0);
    expect(res.results[0].id).toBe("hades");
  });

  it("budget filter only returns games within the real buy price", () => {
    const res = byBudgetTool({ maxToman: 500_000, intent: "buy" });
    expect(res.budgetToman).toBe(500_000);
    for (const g of res.withinBudget) {
      expect(g.priceToman).toBeLessThanOrEqual(500_000);
      expect(g.available).toBe(true);
    }
    for (const g of res.justAboveBudget) {
      expect(g.priceToman).toBeGreaterThan(500_000);
    }
    // مرتب‌سازی نزولی داخل بودجه (نزدیک‌ترین به سقف اول)
    for (let i = 1; i < res.withinBudget.length; i++) {
      expect(res.withinBudget[i - 1].priceToman).toBeGreaterThanOrEqual(res.withinBudget[i].priceToman);
    }
  });

  it("detail tool resolves by id and by title, null for unknown", () => {
    expect(gameDetailTool("hades")?.title).toBe("Hades");
    expect(gameDetailTool("Hades")?.id).toBe("hades");
    expect(gameDetailTool("not-a-real-game-xyz")).toBeNull();
  });

  it("compare returns only found games and reports the rest", () => {
    const res = compareGamesTool(["hades", "elden-ring", "دست ندارد"]);
    expect(res.games.map((g) => g.id)).toEqual(["hades", "elden-ring"]);
    expect(res.notFound).toEqual(["دست ندارد"]);
  });

  it("recommend tool reuses the explainable engine with transparent weights", () => {
    const res = recommendTool({ genres: ["روگ‌لایت"], limit: 5 });
    expect(res.usedWeights).toEqual({ genre: 35, playstyleAndStructure: 25, mode: 15, budget: 15, session: 10 });
    expect(res.results.length).toBeGreaterThan(0);
    for (const r of res.results) {
      expect(r.matchPercent).toBeGreaterThanOrEqual(0);
      expect(r.matchPercent).toBeLessThanOrEqual(100);
      expect(Array.isArray(r.matched)).toBe(true);
    }
    // بالاترین نتیجه باید با ژانر خواسته‌شده هم‌پوشانی داشته باشد
    expect(res.results[0].genres).toContain("روگ‌لایت");
  });

  it("deals are sorted by discount descending", () => {
    const deals = dealsTool(8);
    for (let i = 1; i < deals.length; i++) {
      expect(deals[i - 1].discountPercent).toBeGreaterThanOrEqual(deals[i].discountPercent);
    }
  });

  it("playstyle keyword maps colloquial Persian to real playstyles", () => {
    const calm = byPlaystyleKeyword("یه بازی آروم برای آخر هفته می‌خوام");
    expect(calm.length).toBeGreaterThan(0);
    for (const g of calm) {
      const game = GAMES.find((x) => x.id === g.id)!;
      expect(game.playstyles).toContain("آرام و دلنشین");
    }
  });

  it("stats reflect the actual catalog size", () => {
    const stats = catalogStatsTool();
    expect(stats.total).toBe(GAMES.length);
    expect(stats.total).toBeGreaterThanOrEqual(20);
    expect(stats.available).toBeLessThanOrEqual(stats.total);
  });
});

describe("deterministic intent parser", () => {
  it("extracts genre + budget + recommendation wish from Persian", () => {
    const intent = extractIntentDeterministic("یه بازی روگ‌لایت زیر ۵۰۰ هزار تومان پیشنهاد بده");
    expect(intent.genres).toContain("روگ‌لایت");
    expect(intent.budgetToman).toBe(500_000);
    expect(intent.wantsRecommendation).toBe(true);
  });

  it("extracts million-based budgets and rental wish", () => {
    const intent = extractIntentDeterministic("با ۲ میلیون تومان چه بازی‌ای می‌تونم اجاره کنم؟");
    expect(intent.budgetToman).toBe(2_000_000);
    expect(intent.wantsRental).toBe(true);
    expect(intent.intent).toBe("rent");
  });

  it("detects named games including Persian aliases and comparison", () => {
    const intent = extractIntentDeterministic("هدز رو با الدرینگ مقایسه کن");
    expect(intent.mentionedTitles).toContain("hades");
    expect(intent.mentionedTitles).toContain("elden-ring");
    expect(intent.wantsComparison).toBe(true);
  });

  it("detects deals and stats questions", () => {
    expect(extractIntentDeterministic("بهترین تخفیف‌ها چیه؟").wantsDeals).toBe(true);
    expect(extractIntentDeterministic("کاتالوگ چندتا بازی داره؟").wantsStats).toBe(true);
  });

  it("empty message yields empty intent", () => {
    const intent = extractIntentDeterministic("سلام");
    expect(intent).toEqual(emptyIntent());
  });
});

describe("intent merge (model output sandboxed)", () => {
  it("drops invalid model genres/titles and keeps deterministic ones", () => {
    const base = extractIntentDeterministic("روگ‌لایت پیشنهاد بده");
    const merged = mergeIntents(base, {
      genres: ["روگ‌لایت", "ژانر ساختگی مدل"],
      mentionedTitles: ["hades", "بازی جعلی"],
      budgetToman: 999_999,
    });
    expect(merged.genres).toEqual(["روگ‌لایت"]);
    expect(merged.mentionedTitles).toEqual(["hades"]);
    expect(merged.budgetToman).toBe(999_999);
  });

  it("deterministic budget wins over the model", () => {
    const base = extractIntentDeterministic("زیر ۴۰۰ هزار تومان");
    const merged = mergeIntents(base, { budgetToman: 5_000_000 });
    expect(merged.budgetToman).toBe(400_000);
  });

  it("null model output changes nothing", () => {
    const base = extractIntentDeterministic("سلام");
    expect(mergeIntents(base, null)).toEqual(base);
  });
});

describe("history clamp", () => {
  it("keeps only the last 12 messages and truncates long content", () => {
    const many = Array.from({ length: 30 }, (_, i) => ({ role: "user" as const, content: `پیام ${i}` }));
    const clamped = clampHistory(many, 12);
    expect(clamped.length).toBe(12);
    expect(clamped[clamped.length - 1].content).toBe("پیام 29");

    const long = { role: "user" as const, content: "x".repeat(6000) };
    expect(clampHistory([long])[0].content.length).toBe(4000);
  });
});

describe("game title linkify (client-side grounding)", () => {
  it("converts bare catalog titles into deep links", async () => {
    const { linkifyGameTitles } = await import("../src/lib/ai/linkify");
    const out = linkifyGameTitles("این هم Hades عالی است و Cyberpunk 2077 هم هست");
    expect(out).toContain("[Hades](#/game/hades)");
    expect(out).toContain("[Cyberpunk 2077](#/game/cyberpunk-2077)");
  });

  it("does not double-link titles already in markdown links", async () => {
    const { linkifyGameTitles } = await import("../src/lib/ai/linkify");
    const input = "ببین [Hades](#/game/hades) و **INSIDE**";
    const out = linkifyGameTitles(input);
    expect(out.match(/\[#\/game/g)).toBeNull();
    expect(out.match(/\[Hades\]\(#\/game\/hades\)/g)?.length).toBe(1);
    expect(out).toContain("[INSIDE](#/game/inside)");
  });
});
