/* ————— هسته‌ی محض چندزبونگی — بدون «use client» — قابل استفاده در سرور —————
 * این فایل هیچ وابستگی به React/zustand ندارد تا در /api/chat و تست‌ها هم
 * قابل استفاده باشد. هوک‌ها و استور در i18n.ts (کلاینتی) قرار دارند و
 * کلاینتی‌ها همان‌ها را از «@/lib/i18n» ایمپورت می‌کنند (re-export می‌شود).
 */

import { STR } from "./i18n/dict";
import { EN_MAP } from "./i18n/en-map";
import { CATALOG_EN } from "./i18n/catalog-en";
import { toFaDigits, formatToman, formatRatingFa, formatMinutesFa, formatHoursFa, formatRemainingFa, formatDateFa, formatDateTimeFa } from "./format";
import type { Game } from "./types";

export type Lang = "fa" | "en";
export type Theme = "dark" | "light";

export const UI_STORAGE_KEY = "scorent-ui:v1";

/* ————— اسکریپت pre-paint (قبل از هر رندری اجرا می‌شود — جلوگیری از FOUC) ————— */
export const UI_BOOT_SCRIPT = `(function(){try{var r=localStorage.getItem("${UI_STORAGE_KEY}");var s=r?JSON.parse(r):null;var loc=s&&s.state&&s.state.locale?s.state.locale:"fa";var th=s&&s.state&&s.state.theme?s.state.theme:"dark";var e=document.documentElement;e.lang=loc==="en"?"en":"fa";e.dir=loc==="fa"?"rtl":"ltr";e.classList.toggle("light",th==="light");e.classList.toggle("dark",th!=="light");e.style.colorScheme=th;}catch(x){}})();`;

export type TFn = (key: string, params?: Record<string, string | number>) => string;

export function makeT(lang: Lang): TFn {
  return (key, params) => {
    const row = STR[key];
    let s = row ? (lang === "fa" ? row[0] : row[1]) : key;
    if (params) {
      for (const [k, v] of Object.entries(params)) s = s.split(`{${k}}`).join(String(v));
    }
    return s;
  };
}

/** ترجمه‌ی رشته‌های ثابت لایه داده (واژگان دامنه، دستاوردها، دلایل خطا و ...) */
export function txStatic(text: string, lang: Lang): string {
  if (lang === "fa") return text;
  return EN_MAP[text] ?? text;
}

/** اتصال چند آیتم با «و» فارسی یا «and» انگلیسی */
export function joinAnd(items: string[], lang: Lang): string {
  if (items.length === 0) return "";
  if (items.length === 1) return items[0];
  if (lang === "fa") return items.join(" و ");
  return `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;
}

/* ————— قالب‌بندی اعداد/تاریخ بر اساس زبان ————— */

export interface Fmt {
  /** عدد صحیح با ارقام محلی */
  num: (v: number | string) => string;
  /** «۱٬۲۰۰٬۰۰۰ تومان» | «1,200,000 Toman» */
  toman: (v: number, withUnit?: boolean) => string;
  /** «٪۳۵» | «35%» */
  percent: (v: number) => string;
  /** «۴٫۸» | «4.8» */
  rating: (v: number) => string;
  /** «۹۰ تا ۱۲۰ دقیقه» | «90–120 min» */
  minutes: (range: [number, number]) => string;
  /** «۴۵ تا ۶۰ ساعت» | «45–60 h» */
  hours: (range: [number, number] | null) => string | null;
  /** «۲ روز و ۵ ساعت» | «2 days and 5 hours» */
  remaining: (ms: number) => string;
  date: (ts: number) => string;
  dateTime: (ts: number) => string;
  /** گروه‌بندی سه‌رقمی با جداکننده محلی (بدون واحد) */
  group: (v: number) => string;
}

function groupEn(value: number): string {
  const n = Math.round(Math.abs(value));
  const sign = value < 0 ? "-" : "";
  return sign + String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export function makeFmt(lang: Lang): Fmt {
  if (lang === "en") {
    return {
      num: (v) => String(v),
      toman: (v, withUnit = true) => (withUnit ? `${groupEn(v)} Toman` : groupEn(v)),
      group: groupEn,
      percent: (v) => `${Math.round(v)}%`,
      rating: (v) => {
        const fixed = Math.max(0, Math.min(5, v)).toFixed(1);
        return fixed.endsWith(".0") ? fixed.slice(0, -2) : fixed;
      },
      minutes: (range) => {
        const [a, b] = range;
        if (a >= 60 || b >= 60) {
          const ha = a % 60 === 0 ? String(a / 60) : (a / 60).toFixed(1);
          const hb = b % 60 === 0 ? String(b / 60) : String(Math.round(b / 60));
          if (a === b) return `${ha} h`;
          return `${ha}–${hb} h`;
        }
        if (a === b) return `${a} min`;
        return `${a}–${b} min`;
      },
      hours: (range) => (range ? `${range[0]}–${range[1]} h` : null),
      remaining: (ms) => {
        if (ms <= 0) return "Ended";
        const days = Math.floor(ms / 86_400_000);
        const hours = Math.floor((ms % 86_400_000) / 3_600_000);
        const minutes = Math.floor((ms % 3_600_000) / 60_000);
        const seconds = Math.floor((ms % 60_000) / 1000);
        if (days > 0) return `${days} day${days > 1 ? "s" : ""} and ${hours} hour${hours !== 1 ? "s" : ""}`;
        if (hours > 0) return `${hours} hour${hours !== 1 ? "s" : ""} and ${minutes} min`;
        if (minutes > 0) return `${minutes} min`;
        return `${seconds} sec`;
      },
      date: (ts) => {
        try {
          return new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric" }).format(new Date(ts));
        } catch {
          return new Date(ts).toLocaleDateString();
        }
      },
      dateTime: (ts) => {
        try {
          return new Intl.DateTimeFormat("en-GB", {
            day: "numeric",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
          }).format(new Date(ts));
        } catch {
          return new Date(ts).toLocaleString();
        }
      },
    };
  }
  return {
    num: (v) => toFaDigits(v),
    toman: (v, withUnit = true) => formatToman(v, withUnit),
    group: (v) => formatToman(v, false),
    percent: (v) => `٪${toFaDigits(Math.round(v))}`,
    rating: (v) => formatRatingFa(v),
    minutes: (range) => formatMinutesFa(range),
    hours: (range) => formatHoursFa(range),
    remaining: (ms) => formatRemainingFa(ms),
    date: (ts) => formatDateFa(ts),
    dateTime: (ts) => formatDateTimeFa(ts),
  };
}

/* ————— متن کاتالوگ (شعار/توضیح/نکات بازی) به زبان فعال ————— */

export interface GameText {
  tagline: string;
  description: string;
  highlights: string[];
}

export function gameTextOf(game: Game, lang: Lang): GameText {
  if (lang === "en") {
    const en = CATALOG_EN[game.id];
    const base: GameText = en
      ? { tagline: en.tagline, description: en.description, highlights: en.highlights }
      : { tagline: game.tagline, description: game.description, highlights: game.highlights };
    /* اورراید ادمین بر کاتالوگ انگلیسی اولویت دارد */
    if (game.taglineEn || game.descriptionEn) {
      return {
        tagline: game.taglineEn || base.tagline,
        description: game.descriptionEn || base.description,
        highlights: base.highlights,
      };
    }
    return base;
  }
  return { tagline: game.tagline, description: game.description, highlights: game.highlights };
}
