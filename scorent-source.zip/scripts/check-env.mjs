/* اعتبارسنجی متغیرهای محیطی ضروری برای build استقرار production —
 * در Netlify قبل از next build اجرا می‌شود (build:netlify) و با پیام واضح شکست می‌خورد. */

const problems = [];
const warnings = [];

const isNetlify = Boolean(process.env.NETLIFY);

/* ۱) دیتابیس */
const dbUrl = process.env.DATABASE_URL ?? "";
if (!dbUrl) {
  problems.push("DATABASE_URL is not set — use a managed PostgreSQL URL (required on Netlify/serverless).");
} else if (dbUrl.startsWith("file:")) {
  if (isNetlify) {
    problems.push(
      "DATABASE_URL uses SQLite (file:) but you are deploying to Netlify serverless functions, " +
      "where the filesystem is read-only and NOT shared between instances. " +
      "Use a managed PostgreSQL URL (e.g. Neon/Supabase/Railway) instead."
    );
  } else {
    warnings.push("DATABASE_URL uses SQLite — fine for single-server hosting, NOT for serverless.");
  }
}

/* ۲) کلید امضای نشست‌ها */
const secret = process.env.AUTH_SECRET ?? "";
if (isNetlify && (!secret || secret.length < 24)) {
  problems.push(
    "AUTH_SECRET must be set to a random string of at least 32 characters on serverless hosting — " +
    "without it every function instance would generate a different signing key and sessions would break."
  );
} else if (secret && secret.length < 32) {
  warnings.push("AUTH_SECRET is shorter than 32 characters — consider a longer random value.");
}

/* ۳) ادمین اولیه */
const hasAdminEmail = Boolean(process.env.ADMIN_EMAIL);
const hasAdminPass = Boolean(process.env.ADMIN_PASSWORD);
if (isNetlify && !hasAdminEmail && !hasAdminPass) {
  warnings.push("ADMIN_EMAIL/ADMIN_PASSWORD not set — the first deployment will create NO administrator. Set both before first boot.");
}
if ((hasAdminEmail && !hasAdminPass) || (!hasAdminEmail && hasAdminPass)) {
  warnings.push("Set BOTH ADMIN_EMAIL and ADMIN_PASSWORD — partial configuration is ignored.");
}

/* ۴) گزارش */
for (const w of warnings) console.warn(`  WARN: ${w}`);
if (problems.length) {
  console.error("\n  DEPLOYMENT BLOCKED — fix these environment variables:\n");
  for (const p of problems) console.error(`  ✗ ${p}`);
  console.error("\n  See DEPLOY.md → Netlify section for exact values.\n");
  process.exit(1);
}
console.warn("  OK: required environment variables are present.");
