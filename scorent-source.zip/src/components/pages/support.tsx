"use client";

/* ————— صفحه پشتیبانی: ثبت تیکت (مهمان هم) + پیگیری تیکت‌های من ————— */

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { ChevronDown, LifeBuoy, MessageSquarePlus, Send, Ticket as TicketIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { SectionHeader, EmptyState } from "@/components/scorent/shared";
import { Link } from "@/components/scorent/router";
import { api, useAuth } from "@/lib/auth";
import type { AuthUser } from "@/lib/auth";
import { useFmt, useT, useUiDir } from "@/lib/i18n";
import { cn } from "@/lib/utils";

interface TicketMessage {
  id: string;
  authorName: string;
  authorRole: string;
  body: string;
  createdAt: string;
}

interface Ticket {
  id: string;
  subject: string;
  category: string;
  status: string;
  priority: string;
  contact: string;
  guestName: string | null;
  createdAt: string;
  updatedAt: string;
  messages: TicketMessage[];
}

const CATEGORIES = ["ACCOUNT", "BILLING", "GAME", "BUG", "SUGGESTION", "OTHER"] as const;

function statusCls(status: string): string {
  if (status === "OPEN") return "border-rent/40 bg-rent/10 text-rent";
  if (status === "PENDING") return "border-deal/40 bg-deal/10 text-deal";
  return "border-border bg-secondary text-muted-foreground";
}

function priorityCls(p: string): string {
  if (p === "HIGH") return "border-destructive/40 bg-destructive/10 text-destructive";
  return "border-border bg-secondary text-muted-foreground";
}

export function SupportPage() {
  const t = useT();
  const f = useFmt();
  const dir = useUiDir();
  const { user, ready } = useAuth();

  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState<string>("OTHER");
  const [message, setMessage] = useState("");
  const [guestName, setGuestName] = useState("");
  const [contact, setContact] = useState("");
  const [busy, setBusy] = useState(false);
  const [tracking, setTracking] = useState<string | null>(null);

  const [tickets, setTickets] = useState<Ticket[] | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [reply, setReply] = useState("");

  const loadMine = useCallback(async () => {
    if (!user) {
      setTickets(null);
      return;
    }
    try {
      const res = await api.get<{ ok: boolean; tickets: Ticket[] }>("/api/support/tickets");
      setTickets(res.tickets);
    } catch {
      setTickets([]);
    }
  }, [user]);

  useEffect(() => {
    if (!ready) return;
    const id = setTimeout(() => void loadMine(), 0);
    return () => clearTimeout(id);
  }, [ready, loadMine]);

  async function submit() {
    if (subject.trim().length < 4 || message.trim().length < 10) {
      toast.error(t("support.errToast"));
      return;
    }
    setBusy(true);
    try {
      const res = await api.post<{ ok: boolean; trackingId: string }>("/api/support/tickets", {
        name: user ? undefined : guestName.trim(),
        contact: user ? undefined : contact.trim(),
        subject: subject.trim(),
        message: message.trim(),
        category,
      });
      setTracking(res.trackingId);
      setSubject("");
      setMessage("");
      void loadMine();
      toast.success(t("support.okToast"));
    } catch {
      toast.error(t("support.errToast"));
    } finally {
      setBusy(false);
    }
  }

  async function sendReply(id: string) {
    if (reply.trim().length < 2) return;
    try {
      await api.post(`/api/support/tickets/${id}`, { body: reply.trim() });
      setReply("");
      setOpenId(id);
      void loadMine();
      toast.success(t("support.replyOk"));
    } catch {
      toast.error(t("support.errToast"));
    }
  }

  async function closeTicket(id: string) {
    try {
      await api.patch(`/api/support/tickets/${id}`);
      void loadMine();
      toast.success(t("support.closeOk"));
    } catch {
      toast.error(t("support.errToast"));
    }
  }

  const trackingId = tracking ? tracking : null;

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-10 md:px-6 md:py-14">
      <SectionHeader kicker={t("support.title")} title={t("support.title")} description={t("support.desc")} icon={LifeBuoy} tone="ai" />

      {trackingId && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-8 rounded-3xl border border-rent/40 bg-rent/10 p-5" role="status">
          <p className="text-sm font-black text-rent">{t("support.tracking", { id: trackingId })}</p>
          <p className="mt-1 text-xs leading-6 text-muted-foreground">{t("support.trackingNote")}</p>
        </motion.div>
      )}

      <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
        {/* فرم ثبت تیکت */}
        <section className="rounded-3xl border border-border bg-card p-6" aria-label={t("support.formTitle")}>
          <h2 className="flex items-center gap-2 text-lg font-extrabold">
            <MessageSquarePlus className="size-5 text-ai" /> {t("support.formTitle")}
          </h2>
          <p className="mt-1.5 text-xs leading-6 text-muted-foreground">{t("support.formDesc")}</p>

          <div className="mt-5 space-y-4">
            {!user && (
              <>
                <div className="rounded-2xl border border-deal/30 bg-deal/10 p-3 text-xs leading-6 text-deal">{t("support.guestNote")}</div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="g-name" className="text-xs font-bold text-muted-foreground">{t("auth.name")}</Label>
                    <Input id="g-name" value={guestName} onChange={(e) => setGuestName(e.target.value)} placeholder={t("auth.namePh")} />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="g-contact" className="text-xs font-bold text-muted-foreground">{t("support.contact")}</Label>
                    <Input id="g-contact" value={contact} onChange={(e) => setContact(e.target.value)} placeholder={t("support.contactPh")} dir="ltr" className="text-start" />
                  </div>
                </div>
              </>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="t-subject" className="text-xs font-bold text-muted-foreground">{t("support.subject")}</Label>
              <Input id="t-subject" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder={t("support.subjectPh")} maxLength={120} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-muted-foreground">{t("support.category")}</Label>
              <Select dir={dir} value={category} onValueChange={setCategory}>
                <SelectTrigger aria-label={t("support.category")}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {t(`support.cat.${c}`)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="t-message" className="text-xs font-bold text-muted-foreground">{t("support.message")}</Label>
              <Textarea id="t-message" value={message} onChange={(e) => setMessage(e.target.value)} placeholder={t("support.messagePh")} rows={5} maxLength={3000} />
            </div>
            <Button onClick={submit} disabled={busy} className="w-full bg-ai text-white hover:bg-ai/90">
              <Send className="size-4" /> {busy ? "…" : t("support.submit")}
            </Button>
          </div>
        </section>

        {/* تیکت‌های من */}
        <section aria-label={t("support.myTickets")}>
          <h2 className="mb-4 flex items-center gap-2 text-lg font-extrabold">
            <TicketIcon className="size-5 text-deal" /> {t("support.myTickets")}
          </h2>

          {!ready || (user && tickets === null) ? (
            <div className="space-y-3">
              <Skeleton className="h-20 w-full rounded-2xl" />
              <Skeleton className="h-20 w-full rounded-2xl" />
            </div>
          ) : !user ? (
            <EmptyState icon={LifeBuoy} title={t("support.myTickets")} description={t("support.signInForTickets")} action={<Link to="/auth?next=/support" className="rounded-xl bg-ai px-4 py-2 text-sm font-extrabold text-white hover:bg-ai/90">{t("account.signIn")}</Link>} />
          ) : tickets && tickets.length === 0 ? (
            <EmptyState icon={TicketIcon} title={t("support.empty")} description={t("support.emptyDesc")} />
          ) : (
            <div className="space-y-3">
              {tickets?.map((tk) => {
                const open = openId === tk.id;
                return (
                  <div key={tk.id} className="overflow-hidden rounded-2xl border border-border bg-card">
                    <button
                      type="button"
                      onClick={() => setOpenId(open ? null : tk.id)}
                      aria-expanded={open}
                      className="flex w-full items-center justify-between gap-3 p-4 text-start transition-colors hover:bg-secondary/40"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-sm font-extrabold">{tk.subject}</p>
                        <p className="mt-1 flex flex-wrap items-center gap-2 text-[0.68rem] text-muted-foreground">
                          <span className="tnum">#{tk.id.slice(-8).toUpperCase()}</span>
                          <span>·</span>
                          <span>{t(`support.cat.${tk.category}`)}</span>
                          <span>·</span>
                          <span>{f.dateTime(new Date(tk.updatedAt).getTime())}</span>
                        </p>
                      </div>
                      <div className="flex shrink-0 items-center gap-2">
                        <span className={cn("rounded-full border px-2.5 py-1 text-[0.65rem] font-extrabold", statusCls(tk.status))}>{t(`support.status.${tk.status}`)}</span>
                        <ChevronDown className={cn("size-4 text-muted-foreground transition-transform", open && "rotate-180")} />
                      </div>
                    </button>
                    {open && (
                      <div className="border-t border-border p-4" dir={dir}>
                        <p className="mb-3 text-[0.68rem] font-bold text-muted-foreground">{t("support.messages")}</p>
                        <div className="space-y-2.5">
                          {tk.messages.map((m) => (
                            <div key={m.id} className={cn("max-w-[92%] rounded-2xl px-3.5 py-2.5 text-xs leading-6", m.authorRole === "ADMIN" ? "ms-auto border border-ai/30 bg-ai/10" : "me-auto border border-border bg-secondary/50")}>
                              <p className="mb-1 text-[0.62rem] font-extrabold text-muted-foreground">
                                {m.authorRole === "ADMIN" ? t("support.staff") : t("support.you")} · {f.dateTime(new Date(m.createdAt).getTime())}
                              </p>
                              <p className="whitespace-pre-wrap">{m.body}</p>
                            </div>
                          ))}
                        </div>
                        {tk.status !== "CLOSED" ? (
                          <div className="mt-4 flex gap-2">
                            <Input value={openId === tk.id ? reply : ""} onChange={(e) => setReply(e.target.value)} placeholder={t("support.replyPh")} className="flex-1" />
                            <Button size="icon" aria-label={t("support.sendReply")} onClick={() => sendReply(tk.id)} className="shrink-0 bg-ai text-white hover:bg-ai/90">
                              <Send className="size-4" />
                            </Button>
                            <Button size="icon" variant="outline" aria-label={t("support.closeTicket")} onClick={() => closeTicket(tk.id)} className="shrink-0">
                              ✕
                            </Button>
                          </div>
                        ) : (
                          <p className="mt-3 text-xs text-muted-foreground">{t("support.closedNote")}</p>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
