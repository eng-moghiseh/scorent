/* POST /api/auth/verify — تأیید ایمیل/موبایل با کد یک‌بارمصرف */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, json, readJson, sameOrigin } from "@/lib/server/http";
import { userFromRequest } from "@/lib/server/session";
import { publicUser } from "@/lib/server/auth-helpers";
import { otpMatches } from "@/lib/server/seed";
import { audit } from "@/lib/server/audit";

interface Body {
  kind?: "EMAIL_VERIFY" | "PHONE_VERIFY";
  code?: string;
}

export async function POST(req: NextRequest) {
  if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
  const user = await userFromRequest(req);
  if (!user) return json({ ok: false, error: "UNAUTHORIZED" }, 401);

  const body = await readJson<Body>(req);
  const kind = body?.kind === "EMAIL_VERIFY" || body?.kind === "PHONE_VERIFY" ? body.kind : null;
  const code = typeof body?.code === "string" ? body.code.replace(/\D/g, "") : "";
  if (!kind || code.length !== 6) return json({ ok: false, error: "INVALID_INPUT" }, 400);

  const token = await db.token.findFirst({
    where: { userId: user.id, kind, usedAt: null },
    orderBy: { createdAt: "desc" },
  });
  if (!token) return json({ ok: false, error: "NO_PENDING_CODE" }, 400);
  if (token.expiresAt.getTime() < Date.now()) return json({ ok: false, error: "CODE_EXPIRED" }, 400);
  if (token.attempts >= 5) return json({ ok: false, error: "TOO_MANY_ATTEMPTS" }, 429);

  if (!otpMatches(code, token.codeHash)) {
    await db.token.update({ where: { id: token.id }, data: { attempts: { increment: 1 } } });
    return json({ ok: false, error: "WRONG_CODE" }, 400);
  }

  await db.token.update({ where: { id: token.id }, data: { usedAt: new Date() } });
  const updated = await db.user.update({
    where: { id: user.id },
    data: kind === "EMAIL_VERIFY" ? { emailVerified: true } : { phoneVerified: true },
  });
  audit(kind === "EMAIL_VERIFY" ? "EMAIL_VERIFIED" : "PHONE_VERIFIED", { actorId: user.id, target: kind === "EMAIL_VERIFY" ? user.email : user.phone });
  return json({ ok: true, user: publicUser(updated) });
}
