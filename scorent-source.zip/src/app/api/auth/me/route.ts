/* GET /api/auth/me — کاربر متصل فعلی (یا null) */

import type { NextRequest } from "next/server";
import { json } from "@/lib/server/http";
import { userFromRequest } from "@/lib/server/session";
import { publicUser } from "@/lib/server/auth-helpers";

export async function GET(req: NextRequest) {
  const user = await userFromRequest(req);
  return json({ ok: true, user: user ? publicUser(user) : null });
}
