import type { Game } from "../types";
import { GAMES as GAMES_PART1 } from "./games-1";
import { GAMES_PART2 } from "./games-2";

export const GAMES: Game[] = [...GAMES_PART1, ...GAMES_PART2];

/* ————— Selectors مشترک — همه ماژول‌ها از این توابع استفاده کنند —————
 * همه‌ی سلکتورها لیست ورودی اختیاری دارند تا با کاتالوگ زنده (اورراید ادمین)
 * هم کار کنند؛ پیش‌فرض همان دیتاست ثابت است. */

export function getGame(id: string, list: Game[] = GAMES): Game | undefined {
  return list.find((g) => g.id === id);
}

export function featuredGames(list: Game[] = GAMES): Game[] {
  return list.filter((g) => g.featured && g.available);
}

export function dealGames(list: Game[] = GAMES): Game[] {
  return list.filter((g) => g.discountPercent > 0 && g.available);
}

export function indieGames(list: Game[] = GAMES): Game[] {
  return list.filter((g) => g.indie && g.available);
}

/** گوهرهای پنهان: امتیاز بالا، محبوبیت نسبی پایین‌تر */
export function hiddenGems(list: Game[] = GAMES): Game[] {
  return list.filter((g) => g.available && g.rating >= 4.6 && g.popularity <= 80).sort(
    (a, b) => b.rating - a.rating || a.popularity - b.popularity
  );
}

/** غیرمعمول‌ها: بازی‌هایی با ترکیب ژانر یا تجربه متفاوت */
export function unusualPicks(list: Game[] = GAMES): Game[] {
  const ids = ["disco-elysium", "outer-wilds", "papers-please", "katana-zero", "tunic", "gris", "cuphead", "sifu"];
  return ids.map((id) => list.find((g) => g.id === id)).filter((g): g is Game => Boolean(g));
}

export function searchGames(query: string, list: Game[] = GAMES): Game[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return list.filter(
    (g) => g.title.toLowerCase().includes(q) || g.tagline.includes(q) || g.genres.some((x) => x.includes(q))
  );
}

/* ————— برچسب‌های شفافیت داده ————— */
export const DEMO_DATA_NOTE =
  "قیمت‌ها، امتیازها، تخفیف‌ها و موجودی در این پروتوتایپ «داده نمونه دمو» هستند و اطلاعات رسمی فروشگاه‌ها محسوب نمی‌شوند.";
