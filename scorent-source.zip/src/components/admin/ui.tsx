"use client";

/* ————— اجزای مشترک پنل مدیریت ————— */

import { motion } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import { useFmt, useT } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function AdminHeader({ kicker, title, description, icon: Icon, tone = "ai", action }: { kicker: string; title: string; description?: string; icon?: LucideIcon; tone?: "ai" | "rent" | "deal" | "destructive"; action?: React.ReactNode }) {
  const toneCls = { ai: "text-ai", rent: "text-rent", deal: "text-deal", destructive: "text-destructive" }[tone];
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className={cn("text-xs font-extrabold tracking-wide", toneCls)}>{kicker}</p>
        <h1 className="mt-1 flex items-center gap-2.5 text-2xl font-black md:text-3xl">
          {Icon ? <Icon className={cn("size-6", toneCls)} /> : null}
          {title}
        </h1>
        {description ? <p className="mt-2 max-w-2xl text-sm leading-7 text-muted-foreground">{description}</p> : null}
      </div>
      {action}
    </motion.div>
  );
}

export function StatCard({ icon: Icon, label, value, tone = "text-ai" }: { icon: LucideIcon; label: string; value: number; tone?: string }) {
  const f = useFmt();
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-border bg-card p-4">
      <Icon className={cn("size-5", tone)} />
      <p className="mt-2 text-2xl font-black tnum">{f.num(value)}</p>
      <p className="mt-0.5 text-[0.65rem] font-bold text-muted-foreground">{label}</p>
    </motion.div>
  );
}

export function AdminCard({ title, description, children, className }: { title?: string; description?: string; children: React.ReactNode; className?: string }) {
  const t = useT();
  return (
    <section className={cn("rounded-3xl border border-border bg-card p-5 md:p-6", className)} aria-label={title}>
      {title ? (
        <header className="mb-4">
          <h2 className="text-base font-extrabold md:text-lg">{title}</h2>
          {description ? <p className="mt-1 text-xs leading-6 text-muted-foreground">{description}</p> : null}
        </header>
      ) : null}
      {children}
      {!title && !description ? null : <span className="hidden">{t("admin.title")}</span>}
    </section>
  );
}

export function StatusPill({ status }: { status: string }) {
  const t = useT();
  const cls =
    status === "ACTIVE" || status === "SENT" || status === "OPEN"
      ? "border-rent/40 bg-rent/10 text-rent"
      : status === "SUSPENDED" || status === "FAILED" || status === "HIGH"
        ? "border-destructive/40 bg-destructive/10 text-destructive"
        : status === "PENDING" || status === "SIMULATED" || status === "QUEUED"
          ? "border-deal/40 bg-deal/10 text-deal"
          : "border-border bg-secondary text-muted-foreground";
  const key =
    status === "ACTIVE" ? "admin.users.active" : status === "SUSPENDED" ? "admin.users.suspended" : status.startsWith("status.") ? status : `admin.outbox.status.${status}`;
  return <span className={cn("inline-block rounded-full border px-2.5 py-0.5 text-[0.62rem] font-extrabold", cls)}>{t(key.startsWith("admin.outbox.status.") && status === "OPEN" ? "support.status.OPEN" : key.startsWith("admin.outbox.status.") && (status === "PENDING" || status === "CLOSED") ? `support.status.${status}` : key)}</span>;
}

export function RolePill({ role }: { role: string }) {
  const t = useT();
  const isSuper = role === "SUPER_ADMIN";
  return (
    <span className={cn("inline-block rounded-full px-2.5 py-0.5 text-[0.62rem] font-extrabold", isSuper ? "bg-deal/15 text-deal" : role === "USER" ? "bg-secondary text-muted-foreground" : "bg-ai/15 text-ai")}>
      {t(`account.role.${role}`)}
    </span>
  );
}

export function AdminError() {
  const t = useT();
  return <p className="rounded-2xl border border-destructive/30 bg-destructive/10 p-4 text-sm font-bold text-destructive">{t("admin.error")}</p>;
}
