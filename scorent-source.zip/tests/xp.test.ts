import { describe, expect, it } from "vitest";
import { computeLevel, levelTitle, totalXpForLevel, xpForNextLevel } from "../src/lib/xp";

describe("xp & levels", () => {
  it("فرمول XP هر سطح: ۱۰۰ + (سطح−۱)×۵۰", () => {
    expect(xpForNextLevel(1)).toBe(100);
    expect(xpForNextLevel(2)).toBe(150);
    expect(xpForNextLevel(3)).toBe(200);
  });

  it("مجموع XP برای رسیدن به سطح", () => {
    expect(totalXpForLevel(1)).toBe(0);
    expect(totalXpForLevel(2)).toBe(100);
    expect(totalXpForLevel(3)).toBe(250); // 100 + 150
    expect(totalXpForLevel(4)).toBe(450); // 100+150+200
  });

  it("سطح از مجموع XP محاسبه می‌شود (نه هاردکد)", () => {
    expect(computeLevel(0).level).toBe(1);
    expect(computeLevel(99).level).toBe(1);
    expect(computeLevel(100).level).toBe(2);
    expect(computeLevel(250).level).toBe(3);
    expect(computeLevel(449).level).toBe(3);
    expect(computeLevel(450).level).toBe(4);
  });

  it("عناوین سطح درست اعطا می‌شوند", () => {
    expect(levelTitle(1)).toBe("تازه‌کار");
    expect(levelTitle(4)).toBe("تازه‌کار");
    expect(levelTitle(5)).toBe("بازیکن");
    expect(levelTitle(10)).toBe("شکارچی");
    expect(levelTitle(25)).toBe("نخبه");
    expect(levelTitle(50)).toBe("افسانه");
  });

  it("پیشرفت سطح بین ۰ و ۱۰۰ است", () => {
    const info = computeLevel(120);
    expect(info.progress).toBeGreaterThanOrEqual(0);
    expect(info.progress).toBeLessThanOrEqual(100);
    expect(info.intoLevel + info.remaining).toBe(info.forNext);
  });
});
