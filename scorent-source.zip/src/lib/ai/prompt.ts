/* ————— سازنده پرامپت دستیار Scorent —————
 * شخصیت دستیار + قواعد سخت‌گیرانه استناد به داده واقعی + تزریق کانتکست کاتالوگ.
 * قاعده طلایی: مدل فقط تفسیر می‌کند؛ اعداد از توابع قطعی می‌آیند.
 */

import type { CatalogIntent } from "./intent";
import {
  byBudgetTool,
  byPlaystyleKeyword,
  catalogStatsTool,
  compareGamesTool,
  dealsTool,
  gameDetailTool,
  recommendTool,
  rentableTool,
  searchCatalogTool,
  type GameBrief,
  hiddenGemsTool,
} from "./catalog-tools";

export const ASSISTANT_VERSION = "Scorent Companion v2 — متصل به کاتالوگ واقعی";

export const SYSTEM_PERSONA = `تو «دستیار بازی Scorent» هستی — همراه هوشمند یک پلتفرم فارسی‌زبان کشف، مقایسه و اجاره بازی. لحن تو صمیمی، دقیق و بدون اغراق است؛ مثل یک رفیق گیمر که واقعاً کارشناس است.

## قواعد حیاتی (سرپیچی از آن‌ها ممنوع است)
1. **فقط از داده‌های کاتالوگ استفاده کن.** در پیام کاربر، بلوکی با عنوان «CATALOG_DATA» می‌بینی که داده واقعی و قطعی Scorent است (قیمت‌ها به تومان). هر عدد قیمت/امتیاز/تخفیف که می‌گویی باید عیناً از همان بلوک بیاید. اگر چیزی در بلوک نیست، صادقانه بگو «در کاتالوگ فعلی اطلاعاتش را ندارم» — هرگز از حافظه یا حدس، قیمت یا امتیاز نساز.
2. **شخص ثالث:** عناوین بازی را همان‌طور که هستند انگلیسی بنویس (مثلاً Hades) و داخل متن فارسی هم عناوین انگلیسی را دست‌نخورده نگه دار.
3. **لینک بازی:** هر بازی را که معرفی می‌کنی با لینک مارک‌داون به صفحه خودش بده، به شکل [نام بازی](#/game/شناسه). شناسه‌ها در CATALOG_DATA هست. این لینک‌ها در UI Scorent کلیک‌شدنی می‌شوند.
4. **شفافیت دمو:** قیمت‌ها و امتیازها «داده نمونه» پروتوتایپ هستند. وقتی قیمت می‌گویی، در پایان پاسخ یک جمله کوتاه بگو که اعداد نمایشی‌اند. هرگز ادعای خرید/اجاره/ذخیره واقعی نکن — Scorent در این نسخه پرداخت واقعی انجام نمی‌دهد.
5. **زبان:** به زبان پیام کاربر پاسخ بده (پیش‌فرض فارسی روان). اعداد داخل متن فارسی را با ارقام فارسی بنویس (مثلاً ۴۵۰٬۰۰۰ تومان).
6. **قالب:** پاسخ‌ها را کوتاه و اسکن‌پذیر نگه دار: برای معرفی بازی از فهرست کوتاه با خط تیره استفاده کن، برای مقایسه از جدول مارک‌داون، برای توضیح مفاهیم گیمینگ حداکثر ۲-۳ پاراگراف کوتاه. از سرصفحه (heading) فقط وقتی پاسخ واقعاً بلند است استفاده کن.
7. **مفاهیم گیمینگ:** اگر درباره مفهوم گیمینگ پرسیدند (روگ‌لایت چیست، فرق FPS و TPS و ...)، دقیق و مختصر توضیح بده و اگر بازی مرتبطی در CATALOG_DATA هست معرفی کن.
8. **خارج از گیمینگ:** اگر سؤال کاملاً بی‌ربط به بازی بود، مؤدبانه بگو تخصصت بازی است و برگرد به کار خودت.
9. هرگز توصیه پزشکی/مالی/قانونی نده و محتوای نامناسب سنی تولید نکن.

## ساختار CATALOG_DATA
هر بازی این فیلدها را دارد: id, title, priceToman (قیمت نهایی فعلی), originalPriceToman, discountPercent, rental {d1,d3,d7} (قیمت اجاره ۱/۳/۷ روزه به تومان), rating, genres, playstyles, structure, modes, sessionMinutes, matchPercent (فقط در خروجی موتور پیشنهاد), link.
کمیسیون پلتفرم در اجاره همتابه‌همتا ۱۰٪ است (مثال: اجاره ۲۰۰٬۰۰۰ → ۲۰٬۰۰۰ کمیسیون و ۱۸۰٬۰۰۰ سهم مالک).`;

/** تشخیص زبان پیام (هیوریستیک ساده و قطعی) */
export function detectLanguage(message: string): "fa" | "en" {
  const faChars = (message.match(/[\u0600-\u06FF]/g) ?? []).length;
  const latinChars = (message.match(/[A-Za-z]/g) ?? []).length;
  return latinChars > faChars ? "en" : "fa";
}

/** یادآور زبان — به انتهای پرامپت سیستم اضافه می‌شود.
 * اولویت: زبان پیام کاربر؛ اگر پیام حروف نداشت، زبان UI سایت.
 */
export function languageHint(message: string, uiLang: "fa" | "en" = "fa"): string {
  const faChars = (message.match(/[\u0600-\u06FF]/g) ?? []).length;
  const latinChars = (message.match(/[A-Za-z]/g) ?? []).length;
  const effective: "fa" | "en" = faChars + latinChars === 0 ? uiLang : detectLanguage(message);
  return effective === "en"
    ? "LANG_HINT: The user's latest message is in ENGLISH. Reply entirely in fluent English (game titles stay as-is). Keep the [Game](#/game/id) link format."
    : "LANG_HINT: آخرین پیام کاربر فارسی است؛ پاسخ را کاملاً فارسی و روان بده و عناوین انگلیسی بازی‌ها را دست‌نخورده نگه دار.";
}

/** فشرده‌سازی خروجی ابزار برای تزریق (حذف فیلدهای کم‌اهمیت وقتی جا تنگ است) */
function briefs(briefsList: GameBrief[], compact = false): string {
  return JSON.stringify(
    briefsList.map((b) =>
      compact
        ? {
            id: b.id,
            title: b.title,
            genres: b.genres,
            rating: b.rating,
            priceToman: b.priceToman,
            discountPercent: b.discountPercent,
            rentalAvailable: b.rentalAvailable,
            rental: b.rental,
            matchPercent: (b as GameBrief & { matchPercent?: number }).matchPercent,
            link: b.link,
          }
        : b
    )
  );
}

/** اجرای ابزارها بر اساس نیت استخراج‌شده و ساخت بلوک CATALOG_DATA */
export function buildCatalogContext(intent: CatalogIntent, rawMessage: string): string {
  const sections: string[] = [];
  const wantsAnything =
    intent.mentionedTitles.length > 0 ||
    intent.wantsRecommendation ||
    intent.wantsComparison ||
    intent.wantsDeals ||
    intent.wantsRental ||
    intent.wantsTrial ||
    intent.wantsStats ||
    intent.budgetToman !== null;

  /* جزئیات بازی‌های نام‌برده */
  if (intent.mentionedTitles.length > 0) {
    const { games, notFound } = compareGamesTool(intent.mentionedTitles);
    if (games.length > 0) {
      sections.push(
        intent.mentionedTitles.length >= 2
          ? `### مقایسه درخواستی\n${JSON.stringify(games)}`
          : `### جزئیات بازی نام‌برده\n${JSON.stringify(games)}`
      );
    }
    if (notFound.length > 0) {
      sections.push(`### یافت‌نشده در کاتالوگ (درباره‌شان داده نداری): ${JSON.stringify(notFound)}`);
    }
  }

  /* مقایسه صریح */
  if (intent.wantsComparison && intent.mentionedTitles.length < 2 && intent.genres.length > 0) {
    const rec = recommendTool({ genres: intent.genres, intent: intent.intent, limit: 3 });
    sections.push(`### گزینه‌های برتر برای مقایسه\n${briefs(rec.results as never)}`);
  }

  /* بودجه */
  if (intent.budgetToman !== null) {
    const res = byBudgetTool({
      maxToman: intent.budgetToman,
      intent: intent.intent,
      genres: intent.genres,
    });
    sections.push(`### نتایج بودجه (سقف ${intent.budgetToman.toLocaleString("en-US")} تومان)\nداخل بودجه: ${briefs(res.withinBudget, true)}\nکمی بالاتر از بودجه (کاندید اجاره): ${briefs(res.justAboveBudget, true)}`);
  }

  /* موتور پیشنهاد */
  if (intent.wantsRecommendation) {
    const rec = recommendTool({
      genres: intent.genres,
      playstyle: intent.playstyle,
      mode: intent.mode,
      sessionBucket: intent.sessionBucket,
      budgetToman: intent.budgetToman,
      intent: intent.intent,
      limit: 5,
    });
    sections.push(`### پیشنهاد موتور امتیازدهی (وزن‌ها: ژانر ۳۵، سبک+ساختار ۲۵، حالت ۱۵، بودجه ۱۵، جلسه ۱۰)\n${JSON.stringify(rec.results)}`);
  }

  /* سبک با کلیدواژه محاوره‌ای («آروم»، «یه چیزی برای چالش» و ...) */
  if (intent.playstyle === null && intent.mentionedTitles.length === 0 && intent.genres.length === 0) {
    const byMood = byPlaystyleKeyword(rawMessage, 4);
    if (byMood.length > 0) {
      sections.push(`### تطبیق سبک با کلیدواژه پیام\n${briefs(byMood)}`);
    }
  }

  /* تخفیف‌ها */
  if (intent.wantsDeals) {
    sections.push(`### بزرگ‌ترین تخفیف‌های فعال\n${briefs(dealsTool(5), true)}`);
  }

  /* اجاره */
  if (intent.wantsRental || intent.intent === "rent") {
    sections.push(`### ارزان‌ترین گزینه‌های اجاره (۳ روزه)\n${briefs(rentableTool(5), true)}`);
  }

  /* آمار کاتالوگ */
  if (intent.wantsStats) {
    sections.push(`### آمار کاتالوگ\n${JSON.stringify(catalogStatsTool())}`);
  }

  /* حالت پیش‌فرض: پاسخ عمومی درباره بازی → جستجوی کلیدواژه + محبوب‌ها */
  if (!wantsAnything || sections.length === 0) {
    /* جستجوی توکن‌های لاتین meaningful (عناوین/ژانرهای انگلیسی) */
    const latinTokens = rawMessage
      .toLowerCase()
      .match(/[a-z][a-z\-']{3,}/g)
      ?.filter((t) => !STOPWORDS_EN.has(t))
      .slice(0, 4) ?? [];
    for (const token of latinTokens) {
      const found = searchCatalogTool(token, 3);
      if (found.count > 0) {
        sections.push(`### تطبیق جستجو برای «${token}»
${briefs(found.results)}`);
      }
    }
    const popular = recommendTool({ limit: 4 });
    sections.push(`### محبوب‌های کاتالوگ\n${briefs(popular.results as never)}`);
    sections.push(`### گوهرهای پنهان (امتیاز بالا، کمتر دیده‌شده)\n${briefs(hiddenGemsTool(3), true)}`);
  }

  return `CATALOG_DATA (داده قطعی Scorent — تنها مجاز به استفاده از همین اعداد هستی):\n\n${sections.join("\n\n")}`;
}

/** تاریخچه چت → پیام‌های API (سقف تعداد و طول) */
const STOPWORDS_EN = new Set([
  "what", "does", "mean", "give", "from", "the", "catalog", "game", "games", "with", "that", "this", "have", "has", "are", "and", "for", "you", "your", "can", "about", "tell", "please", "best", "good", "want", "need", "which", "there", "examples", "example", "some",
]);

export function clampHistory(history: Array<{ role: "user" | "assistant"; content: string }>, maxMessages = 12): Array<{ role: "user" | "assistant"; content: string }> {
  return history
    .slice(-maxMessages)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 4000) }));
}
