"use client";

/* ————— روتر سبک مبتنی بر hash —————
 * محیط پیش‌نمایش فقط مسیر «/» را سرو می‌کند؛ بنابراین کل تجربه چندصفحه‌ای
 * با روتر hash پیاده شده: #/store، #/game/:id، #/ai و ...
 * مزیت: لینک عمیق، دکمه Back/Forward مرورگر و URL خوانا همه کار می‌کنند.
 */

import { createContext, useContext, useMemo, useSyncExternalStore, type ReactNode, type MouseEvent } from "react";

export interface RouteState {
  path: string;
  segments: string[];
  query: URLSearchParams;
  full: string;
}

function parseHash(raw: string): RouteState {
  let h = raw.startsWith("#") ? raw.slice(1) : raw;
  if (!h.startsWith("/")) h = "/" + h;
  const qIndex = h.indexOf("?");
  const pathPart = qIndex === -1 ? h : h.slice(0, qIndex);
  const queryPart = qIndex === -1 ? "" : h.slice(qIndex + 1);
  const path = pathPart.replace(/\/+$/, "") || "/";
  const segments = path.split("/").filter(Boolean);
  return { path, segments, query: new URLSearchParams(queryPart), full: h };
}

function subscribe(cb: () => void): () => void {
  window.addEventListener("hashchange", cb);
  return () => window.removeEventListener("hashchange", cb);
}

const serverSnapshot = "#/";

export function useRoute(): RouteState {
  const hash = useSyncExternalStore(
    subscribe,
    () => window.location.hash || "#/",
    () => serverSnapshot
  );
  return useMemo(() => parseHash(hash), [hash]);
}

export function navigate(to: string, opts?: { replace?: boolean }): void {
  const url = `#${to.startsWith("/") ? to : `/${to}`}`;
  if (opts?.replace) {
    window.location.replace(url);
  } else {
    window.location.hash = url;
  }
}

export function back(): void {
  window.history.back();
}

export function buildPath(path: string, params?: Record<string, string | undefined>): string {
  if (!params) return path;
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== "") qs.set(k, v);
  }
  const s = qs.toString();
  return s ? `${path}?${s}` : path;
}

export function Link({
  to,
  children,
  className,
  onClick,
  ariaLabel,
  title,
  dir,
  style,
}: {
  to: string;
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  ariaLabel?: string;
  title?: string;
  dir?: "rtl" | "ltr";
  style?: React.CSSProperties;
}) {
  const handle = (e: MouseEvent<HTMLAnchorElement>) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    navigate(to);
    onClick?.();
  };
  return (
    <a href={`#${to}`} onClick={handle} className={className} aria-label={ariaLabel} title={title} dir={dir} style={style}>
      {children}
    </a>
  );
}

/* کانتکست برای اسکرول به بالای صفحه هنگام تغییر مسیر — در AppShell استفاده می‌شود */
export const RouterContext = createContext<RouteState | null>(null);

export function useRouterContext(): RouteState {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error("RouterContext missing");
  return ctx;
}
