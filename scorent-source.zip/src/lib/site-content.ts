/* ————— محتوای پیش‌فرض سایت (مشترک بین سرور و کلاینت — بدون وابستگی سرور) —————
 * ادمین از پنل مدیریت این کلیدها را ویرایش می‌کند؛ صفحات با fallback به همین
 * مقادیر، همیشه محتوای کامل نمایش می‌دهند.
 */

export interface SiteContentRow {
  key: string;
  valueFa: string;
  valueEn: string;
}

export const CONTENT_LABELS: Record<string, { labelFa: string; labelEn: string; multiline?: boolean }> = {
  "hero.kicker": { labelFa: "سربخش هیرو", labelEn: "Hero kicker" },
  "hero.title": { labelFa: "عنوان اصلی هیرو", labelEn: "Hero title" },
  "hero.subtitle": { labelFa: "توضیح زیر عنوان", labelEn: "Hero subtitle", multiline: true },
  "banner.enabled": { labelFa: "بنر اعلان فعال باشد؟", labelEn: "Announcement banner enabled", },
  "banner.text": { labelFa: "متن بنر اعلان (خالی = مخفی)", labelEn: "Banner text (empty = hidden)", multiline: true },
  "brand.slogan": { labelFa: "شعار برند در نوار بالا", labelEn: "Brand slogan (top strip)" },
};

export const DEFAULT_CONTENT: SiteContentRow[] = [
  { key: "hero.kicker", valueFa: "پلتفرم کشف و اجاره‌ی بازی", valueEn: "Game discovery & rental platform" },
  { key: "hero.title", valueFa: "بازی بعدیت رو هوشمندانه انتخاب کن", valueEn: "Choose your next game, intelligently" },
  {
    key: "hero.subtitle",
    valueFa: "با دستیار هوشمند متصل به کاتالوگ و موتور پیشنهاد شفاف، بازی بعدی‌ات را بر اساس سلیقه، بودجه و زمان خودت پیدا کن؛ اول تجربه کن، بعد با خیال راحت انتخاب کن.",
    valueEn: "With an AI assistant connected to the catalog and a transparent recommendation engine, find your next game by taste, budget and time — try first, then commit with confidence.",
  },
  { key: "banner.enabled", valueFa: "false", valueEn: "false" },
  { key: "banner.text", valueFa: "", valueEn: "" },
  { key: "brand.slogan", valueFa: "کشف کن، تجربه کن، بازی کن", valueEn: "Discover. Experience. Play." },
];

export const CONTENT_KEYS = DEFAULT_CONTENT.map((r) => r.key);
