"use client";

/* ————— مدیریت محتوای سایت — ویرایش متن‌های اصلی (fa/en) + انتشار فوری ————— */

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ExternalLink, FileText, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/auth";
import { useLang, useT } from "@/lib/i18n";
import { CONTENT_LABELS } from "@/lib/site-content";
import { AdminHeader, AdminError } from "./ui";

interface Row {
  key: string;
  valueFa: string;
  valueEn: string;
  updatedBy?: string | null;
  updatedAt?: string;
}

export function AdminContent() {
  const t = useT();
  const lang = useLang();
  const [rows, setRows] = useState<Row[] | null>(null);
  const [draft, setDraft] = useState<Record<string, Row>>({});
  const [err, setErr] = useState(false);
  const [busyKey, setBusyKey] = useState<string | null>(null);

  async function load() {
    try {
      const res = await api.get<{ ok: boolean; content: Row[] }>("/api/admin/content");
      setRows(res.content);
      setDraft(Object.fromEntries(res.content.map((r) => [r.key, { ...r }])));
    } catch {
      setErr(true);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function save(key: string) {
    const row = draft[key];
    if (!row) return;
    setBusyKey(key);
    try {
      await api.post("/api/admin/content", { key, valueFa: row.valueFa, valueEn: row.valueEn });
      toast.success(t("admin.content.saved"));
      void load();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusyKey(null);
    }
  }

  if (err) return <AdminError />;

  return (
    <div>
      <AdminHeader
        kicker={t("admin.title")}
        title={t("admin.content.title")}
        description={t("admin.content.desc")}
        icon={FileText}
        action={
          <a href="#/" target="_blank" className="flex items-center gap-1.5 rounded-xl border border-border bg-card px-3.5 py-2 text-xs font-extrabold hover:border-ai/40 hover:text-ai">
            <ExternalLink className="size-3.5" /> {t("admin.content.preview")}
          </a>
        }
      />

      {rows === null ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-24 animate-pulse rounded-2xl border border-border bg-card" />)}</div>
      ) : (
        <div className="space-y-4">
          {rows.map((row) => {
            const meta = CONTENT_LABELS[row.key];
            const label = meta ? (lang === "en" ? meta.labelEn : meta.labelFa) : row.key;
            const multiline = meta?.multiline || row.key.startsWith("banner.text");
            const isBool = row.key === "banner.enabled";
            const d = draft[row.key] ?? row;
            return (
              <section key={row.key} className="rounded-3xl border border-border bg-card p-5">
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h2 className="text-sm font-extrabold">{label}</h2>
                    <p dir="ltr" className="text-start text-[0.62rem] text-muted-foreground tnum">{row.key}</p>
                  </div>
                  {row.updatedBy && row.updatedBy !== "system" ? <span className="text-[0.6rem] text-muted-foreground">{row.updatedBy.slice(-6)}</span> : null}
                </div>

                {isBool ? (
                  <div className="flex items-center justify-between rounded-2xl border border-border bg-secondary/30 px-4 py-3">
                    <span className="text-xs font-bold">{t(d.valueFa === "true" ? "banner.announce" : "banner.announce")}</span>
                    <Switch
                      checked={d.valueFa === "true"}
                      onCheckedChange={(v) => {
                        setDraft((s) => ({ ...s, [row.key]: { ...d, valueFa: v ? "true" : "false", valueEn: v ? "true" : "false" } }));
                        setTimeout(() => {
                          void (async () => {
                            try {
                              await api.post("/api/admin/content", { key: row.key, valueFa: v ? "true" : "false", valueEn: v ? "true" : "false" });
                              toast.success(t("admin.content.saved"));
                            } catch {
                              toast.error(t("admin.error"));
                            }
                          })();
                        }, 0);
                      }}
                      aria-label={label}
                    />
                  </div>
                ) : (
                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label className="text-xs font-bold text-muted-foreground">{t("admin.content.fa")}</Label>
                      {multiline ? (
                        <Textarea rows={3} value={d.valueFa} onChange={(e) => setDraft((s) => ({ ...s, [row.key]: { ...d, valueFa: e.target.value } }))} />
                      ) : (
                        <Input value={d.valueFa} onChange={(e) => setDraft((s) => ({ ...s, [row.key]: { ...d, valueFa: e.target.value } }))} />
                      )}
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs font-bold text-muted-foreground">{t("admin.content.en")}</Label>
                      {multiline ? (
                        <Textarea rows={3} dir="ltr" className="text-start" value={d.valueEn} onChange={(e) => setDraft((s) => ({ ...s, [row.key]: { ...d, valueEn: e.target.value } }))} />
                      ) : (
                        <Input dir="ltr" className="text-start" value={d.valueEn} onChange={(e) => setDraft((s) => ({ ...s, [row.key]: { ...d, valueEn: e.target.value } }))} />
                      )}
                    </div>
                  </div>
                )}

                {!isBool && (
                  <div className="mt-3 flex justify-end">
                    <Button size="sm" onClick={() => save(row.key)} disabled={busyKey === row.key} className="gap-1.5 bg-ai text-white hover:bg-ai/90">
                      <Save className="size-3.5" /> {t("admin.content.save")}
                    </Button>
                  </div>
                )}
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
}
