"use client";

/* ————— تنظیمات: ظاهر (تم/زبان) + داده دمو (خروجی/ورودی/بازنشانی) + درباره ————— */

import { useRef, useState } from "react";
import { Check, Download, FileJson, Info, Languages, Moon, RefreshCcw, ShieldAlert, Sparkles, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { SectionHeader } from "@/components/scorent/shared";
import { useHydrated, useScorent } from "@/lib/store";
import { useFmt, useT, useTx, useUi, useUiDir, type Lang, type Theme } from "@/lib/i18n";
import { cn } from "@/lib/utils";

/* ————— انتخاب تم — تیره/روشن ————— */

function ThemePicker() {
  const theme = useUi((s) => s.theme);
  const setTheme = useUi((s) => s.setTheme);
  const t = useT();

  const cards: { value: Theme; icon: typeof Sun; labelKey: string; descKey: string; preview: string[] }[] = [
    {
      value: "dark",
      icon: Moon,
      labelKey: "ui.dark",
      descKey: "settings.darkDesc",
      preview: ["#111318", "#20242E", "#FF9F43"],
    },
    {
      value: "light",
      icon: Sun,
      labelKey: "ui.light",
      descKey: "settings.lightDesc",
      preview: ["#F5F6F9", "#FFFFFF", "#E8880C"],
    },
  ];

  return (
    <div className="grid gap-3 sm:grid-cols-2" role="radiogroup" aria-label={t("ui.theme")}>
      {cards.map(({ value, icon: Icon, labelKey, descKey, preview }) => {
        const active = theme === value;
        return (
          <button
            key={value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => setTheme(value)}
            className={cn(
              "group flex items-center gap-3 rounded-2xl border p-4 text-start transition-all",
              active ? "border-deal/50 bg-deal/8 glow-brand" : "border-border bg-card hover:border-deal/30"
            )}
          >
            <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-secondary text-deal">
              <Icon className="size-5" />
            </span>
            <span className="min-w-0 flex-1">
              <b className="block text-sm font-extrabold">{t(labelKey)}</b>
              <span className="mt-0.5 block text-xs leading-6 text-muted-foreground">{t(descKey)}</span>
            </span>
            <span className="flex flex-col gap-1" aria-hidden>
              {preview.map((c) => (
                <span key={c} className="block h-2.5 w-9 rounded-full border border-black/10" style={{ background: c }} />
              ))}
            </span>
            <span
              className={cn(
                "flex size-5 shrink-0 items-center justify-center rounded-full border transition-colors",
                active ? "border-deal bg-deal text-[#3a1c00]" : "border-border text-transparent"
              )}
            >
              <Check className="size-3" />
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* ————— انتخاب زبان — فارسی/English ————— */

function LangPicker() {
  const locale = useUi((s) => s.locale);
  const setLocale = useUi((s) => s.setLocale);
  const t = useT();

  const cards: { value: Lang; title: string; sub: string; sample: string }[] = [
    { value: "fa", title: "فارسی", sub: t("settings.faSub"), sample: "کشف کن، تجربه کن، بازی کن" },
    { value: "en", title: "English", sub: t("settings.enSub"), sample: "Discover. Experience. Play." },
  ];

  return (
    <div className="grid gap-3 sm:grid-cols-2" role="radiogroup" aria-label={t("ui.language")}>
      {cards.map(({ value, title, sub, sample }) => {
        const active = locale === value;
        return (
          <button
            key={value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => setLocale(value)}
            className={cn(
              "group flex items-center gap-3 rounded-2xl border p-4 text-start transition-all",
              active ? "border-ai/50 bg-ai/8 glow-ai" : "border-border bg-card hover:border-ai/30"
            )}
          >
            <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-secondary text-ai">
              <Languages className="size-5" />
            </span>
            <span className="min-w-0 flex-1">
              <b className="block text-sm font-extrabold">{title}</b>
              <span className="mt-0.5 block text-xs leading-6 text-muted-foreground">{sub}</span>
              <span className="mt-1 block truncate text-[0.66rem] text-muted-foreground/70">«{sample}»</span>
            </span>
            <span
              className={cn(
                "flex size-5 shrink-0 items-center justify-center rounded-full border transition-colors",
                active ? "border-ai bg-ai text-white" : "border-border text-transparent"
              )}
            >
              <Check className="size-3" />
            </span>
          </button>
        );
      })}
    </div>
  );
}

export function SettingsPage() {
  const hydrated = useHydrated();
  const exportData = useScorent((s) => s.exportData);
  const importData = useScorent((s) => s.importData);
  const resetAll = useScorent((s) => s.resetAll);
  const xpEvents = useScorent((s) => s.xpEvents.length);
  const purchases = useScorent((s) => s.purchases.length);
  const rentals = useScorent((s) => s.rentals.length);
  const reviews = useScorent((s) => s.reviews.length);
  const fileRef = useRef<HTMLInputElement>(null);
  const [pendingText, setPendingText] = useState<string | null>(null);
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();

  const doExport = () => {
    const json = exportData();
    if (!json) {
      toast.error(t("settings.exportErr"));
      return;
    }
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `scorent-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t("settings.exportOk"));
  };

  const doImport = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const res = importData(String(reader.result));
      if (res.ok) toast.success(t("settings.importOk"));
      else toast.error(tx(res.reason ?? t("settings.importErr")));
    };
    reader.readAsText(file);
  };

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16">
        <div className="skeleton-shimmer h-40 rounded-3xl" />
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-10 md:px-6">
      <header className="mb-8">
        <h1 className="text-3xl font-black">{t("settings.title")}</h1>
        <p className="mt-2 text-sm leading-7 text-muted-foreground">{t("settings.desc")}</p>
      </header>

      <section className="mb-10 rounded-3xl border border-border bg-card p-6" aria-label={t("ui.theme")}>
        <SectionHeader kicker={t("settings.appearanceKicker")} title={t("settings.themeTitle")} description={t("settings.themeDesc")} icon={Sun} />
        <ThemePicker />
        <div className="hairline-brand my-6" aria-hidden />
        <SectionHeader kicker={t("settings.languageKicker")} title={t("settings.langTitle")} description={t("settings.langDesc")} icon={Languages} />
        <LangPicker />
      </section>

      <section className="mb-10 rounded-3xl border border-border bg-card p-6" aria-label={t("settings.dataStatusAria")}>
        <SectionHeader kicker={t("settings.statusKicker")} title={t("settings.statusTitle")} icon={FileJson} />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { l: t("settings.statXp"), v: xpEvents },
            { l: t("settings.statPurchases"), v: purchases },
            { l: t("settings.statRentals"), v: rentals },
            { l: t("settings.statReviews"), v: reviews },
          ].map((s) => (
            <div key={s.l} className="rounded-2xl border border-border bg-secondary/40 p-3 text-center">
              <p className="text-xl font-black tnum">{f.num(s.v)}</p>
              <p className="text-[0.62rem] text-muted-foreground">{s.l}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-10 rounded-3xl border border-border bg-card p-6" aria-label={t("settings.backupAria")}>
        <SectionHeader
          kicker={t("settings.backupKicker")}
          title={t("settings.backupTitle")}
          description={t("settings.backupDesc")}
          icon={Download}
        />
        <div className="flex flex-wrap gap-3">
          <Button onClick={doExport} className="gap-2">
            <Download className="size-4" />
            {t("settings.downloadBackup")}
          </Button>
          <div>
            <Input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) doImport(file);
                e.target.value = "";
              }}
            />
            <Button variant="outline" className="gap-2" onClick={() => fileRef.current?.click()}>
              <FileJson className="size-4" />
              {t("settings.restore")}
            </Button>
          </div>
        </div>
      </section>

      <section className="mb-10 rounded-3xl border border-destructive/30 bg-destructive/5 p-6" aria-label={t("settings.resetAria")}>
        <SectionHeader
          kicker={t("settings.dangerKicker")}
          title={t("settings.resetTitle")}
          description={t("settings.resetDesc")}
          icon={ShieldAlert}
        />
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive" className="gap-2">
              <RefreshCcw className="size-4" />
              {t("settings.wipeAll")}
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent dir={dir}>
            <AlertDialogHeader>
              <AlertDialogTitle>{t("settings.wipeConfirmTitle")}</AlertDialogTitle>
              <AlertDialogDescription>{t("settings.wipeConfirmDesc")}</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>{t("commerce.cancel")}</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-white hover:bg-destructive/90"
                onClick={() => {
                  resetAll();
                  toast.success(t("settings.wipeDone"));
                }}
              >
                {t("settings.wipeYes")}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </section>

      <section className="rounded-3xl border border-border bg-card p-6" aria-label={t("settings.aboutAria")}>
        <SectionHeader kicker={t("settings.aboutKicker")} title={t("settings.aboutTitle")} icon={Info} />
        <div className="space-y-3 text-sm leading-8 text-muted-foreground">
          <p>
            <b className="text-foreground">Scorent</b> {t("settings.aboutP1")}
          </p>
          <p>{t("settings.aboutP2")}</p>
          <p className="flex items-center gap-2 text-xs">
            <Sparkles className="size-3.5 text-ai" />
            {t("settings.version")}
          </p>
        </div>
      </section>

      {pendingText ? <Label className="sr-only">{pendingText}</Label> : null}
    </div>
  );
}
