/* Test z-ai-web-dev-sdk streaming format */
import ZAI from "z-ai-web-dev-sdk";

async function main() {
  const zai = await ZAI.create();
  const stream = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: "You are a helpful assistant. Reply briefly." },
      { role: "user", content: "بازی «Hades» چه ژانری دارد؟ در یک جمله." },
    ],
    stream: true,
    thinking: { type: "disabled" },
  });

  console.log("stream type:", typeof stream, stream?.constructor?.name);
  // Try async iterator
  if (stream && typeof stream[Symbol.asyncIterator] === "function") {
    console.log("→ async iterator supported");
    let chunks = 0;
    for await (const chunk of stream) {
      chunks++;
      if (chunks <= 3) {
        console.log("chunk sample:", JSON.stringify(chunk).slice(0, 300));
      }
    }
    console.log("total chunks:", chunks);
  } else {
    console.log("full response:", JSON.stringify(stream).slice(0, 500));
  }
}

main().catch((e) => {
  console.error("ERR:", e.message);
  process.exit(1);
});
