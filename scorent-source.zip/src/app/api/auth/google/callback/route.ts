/* GET /api/auth/google/callback — تبادل کد OAuth و ورود */

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { baseUrl } from "@/lib/server/auth-helpers";
import { googleConfigured } from "@/lib/server/notify";
import { createSession, sessionCookieAttrs } from "@/lib/server/session";
import { clientIp } from "@/lib/server/rate-limit";

const OAUTH_STATE = "scorent_oauth_state";

interface GoogleProfile {
  sub: string;
  email?: string;
  email_verified?: boolean;
  name?: string;
  picture?: string;
}

export async function GET(req: NextRequest) {
  const base = baseUrl(req);
  const fail = (reason: string) => NextResponse.redirect(`${base}/#/auth?google=err&reason=${encodeURIComponent(reason)}`);

  /* خطای سمت گوگل (مثل access_denied یا redirect_uri_mismatch) را شفاف پاس بده */
  const googleError = req.nextUrl.searchParams.get("error");
  if (googleError) return fail(googleError);

  if (!googleConfigured()) return fail("not_configured");

  const code = req.nextUrl.searchParams.get("code");
  const state = req.nextUrl.searchParams.get("state");
  const stateCookie = req.cookies.get(OAUTH_STATE)?.value;
  if (!code || !state || !stateCookie || state !== stateCookie) return fail("state");

  try {
    const redirectUri = `${base}/api/auth/google/callback`;
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID!,
        client_secret: process.env.GOOGLE_CLIENT_SECRET!,
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
      }),
    });
    if (!tokenRes.ok) return fail("token");
    const tokens = (await tokenRes.json()) as { access_token?: string };
    if (!tokens.access_token) return fail("token");

    const infoRes = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    if (!infoRes.ok) return fail("userinfo");
    const profile = (await infoRes.json()) as GoogleProfile;
    if (!profile.sub || !profile.email) return fail("profile");

    // کاربر موجود بر اساس googleId یا ایمیل
    let user = await db.user.findUnique({ where: { googleId: profile.sub } });
    if (!user) {
      const byEmail = await db.user.findUnique({ where: { email: profile.email.toLowerCase() } });
      if (byEmail) {
        user = await db.user.update({
          where: { id: byEmail.id },
          data: { googleId: profile.sub, emailVerified: byEmail.emailVerified || Boolean(profile.email_verified) },
        });
      }
    }
    if (!user) {
      user = await db.user.create({
        data: {
          name: profile.name?.slice(0, 40) || profile.email.split("@")[0],
          email: profile.email.toLowerCase(),
          googleId: profile.sub,
          emailVerified: Boolean(profile.email_verified),
          avatar: profile.picture ?? null,
        },
      });
    }
    if (user.status === "SUSPENDED") return NextResponse.redirect(`${base}/#/auth?google=suspended`);

    await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    const { token, exp } = await createSession(user.id, { ip: clientIp(req), userAgent: req.headers.get("user-agent") ?? undefined });
    const res = NextResponse.redirect(`${base}/#/auth?google=ok`);
    res.cookies.set({ ...sessionCookieAttrs(Math.max(1000, exp - Date.now())), value: token });
    res.cookies.set({ name: OAUTH_STATE, value: "", path: "/", maxAge: 0 });
    return res;
  } catch {
    return fail("exception");
  }
}
