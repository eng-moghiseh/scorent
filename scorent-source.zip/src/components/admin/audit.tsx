"use client";

/* ————— گزارش حسابرسی — آخرین اقدامات حساس ثبت‌شده در سرور ————— */

import { useEffect, useState } from "react";
import { RefreshCcw, ScrollText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/auth";
import { useLang, useT, useUiDir } from "@/lib/i18n";
import { cn } from "@/lib/utils";

interface AuditRow {
  id: string;
  actorId: string | null;
  action: string;
  target: string | null;
  meta: string | null;
  ip: string | null;
  createdAt: string;
}

const ACTION_TONE: Record<string, string> = {
  LOGIN_OK: "text-rent",
  LOGIN_FAIL: "text-destructive",
  ACCOUNT_SUSPENDED: "text-destructive",
  USER_DELETED: "text-destructive",
  ROLE_CHANGED: "text-deal",
  ADMIN_ADDED: "text-ai",
  ADMIN_REMOVED: "text-deal",
  PASSWORD_CHANGED: "text-ai",
  PASSWORD_RESET: "text-deal",
  CONTENT_UPDATED: "text-ai",
  OVERRIDE_UPDATED: "text-ai",
  ANNOUNCEMENT_SENT: "text-ai",
};

export function AuditTrail() {
  const t = useT();
  const lang = useLang();
  const dir = useUiDir();
  const [rows, setRows] = useState<AuditRow[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(false);

  const fmtDate = (iso: string) => {
    const d = new Date(iso);
    return lang === "fa"
      ? d.toLocaleString("fa-IR", { dateStyle: "short", timeStyle: "short" })
      : d.toLocaleString("en-US", { dateStyle: "short", timeStyle: "short" });
  };

  async function load() {
    setBusy(true);
    setErr(false);
    try {
      const res = await api.get<{ ok: boolean; audit: AuditRow[] }>("/api/admin/audit?take=40");
      setRows(res.audit);
    } catch {
      setErr(true);
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <section className="rounded-2xl border border-border bg-card p-5" aria-label={t("admin.audit.title")}>
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <h3 className="flex items-center gap-2 text-sm font-black">
            <ScrollText className="size-4 text-ai" /> {t("admin.audit.title")}
          </h3>
          <p className="mt-1 text-xs text-muted-foreground">{t("admin.audit.desc")}</p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={busy} aria-label={t("admin.audit.refresh")}>
          <RefreshCcw className={cn("size-3.5", busy && "animate-spin")} /> {t("admin.audit.refresh")}
        </Button>
      </div>

      {err && <p className="text-xs font-bold text-destructive">{t("admin.audit.error")}</p>}
      {rows && rows.length === 0 && <p className="text-xs text-muted-foreground">{t("admin.audit.empty")}</p>}

      {rows && rows.length > 0 && (
        <ul className="divide-y divide-border/60" dir={dir}>
          {rows.map((r) => (
            <li key={r.id} className="flex flex-wrap items-center gap-x-2 gap-y-1 py-2 text-xs leading-6">
              <span className={cn("font-black tnum", ACTION_TONE[r.action] ?? "text-foreground")}>{r.action}</span>
              <span className="text-muted-foreground">{r.target ? `→ ${r.target}` : ""}</span>
              {r.meta && <span className="text-muted-foreground/70">({r.meta})</span>}
              <span className="ms-auto text-muted-foreground/60 tnum" title={r.ip ?? undefined}>
                {fmtDate(r.createdAt)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
