"use client";

/* ————— اجزای مشترک سیستم طراحی Scorent ————— */

import { useEffect, useRef, useState, type ReactNode } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import {
  Star,
  BadgePercent,
  Sparkles,
  UserRound,
  ShoppingBag,
  Library,
  KeyRound,
  CalendarCheck,
  MessageSquareQuote,
  PenLine,
  Heart,
  Store,
  TrendingUp,
  Crosshair,
  Compass,
  MessageSquarePlus,
  Timer,
  Bug,
  Flame,
  Ghost,
  Zap,
  Rocket,
  Crown,
  Target,
  Swords,
  Shield,
  MoonStar,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useFmt, useT } from "@/lib/i18n";
import { Link } from "./router";

/* ————— رجیستری آیکون برای داده‌های پیکربندی‌شده (دستاورد/چالش/آواتار) ————— */

export const ICON_MAP: Record<string, LucideIcon> = {
  UserRound,
  ShoppingBag,
  Library,
  KeyRound,
  CalendarCheck,
  MessageSquareQuote,
  PenLine,
  Heart,
  Sparkles,
  Store,
  TrendingUp,
  Crosshair,
  Compass,
  MessageSquarePlus,
  Timer,
  Bug,
  Flame,
  Ghost,
  Zap,
  Rocket,
  Crown,
  Target,
  Swords,
  Shield,
  MoonStar,
  Star,
};

export function IconByName({ name, className }: { name: string; className?: string }) {
  const Icon = ICON_MAP[name] ?? Sparkles;
  return <Icon className={className} />;
}

/* ————— برچسب‌ها ————— */

export function RatingBadge({ rating, className }: { rating: number; className?: string }) {
  const f = useFmt();
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full bg-black/35 px-2 py-0.5 text-xs font-bold tnum",
        className
      )}
      title="Demo sample rating"
    >
      <Star className="size-3 fill-amber-400 text-amber-400" />
      {f.rating(rating)}
    </span>
  );
}

export function DiscountBadge({ percent, className }: { percent: number; className?: string }) {
  const f = useFmt();
  if (percent <= 0) return null;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full bg-deal px-2 py-0.5 text-xs font-extrabold text-[#3a1c00] tnum",
        className
      )}
    >
      <BadgePercent className="size-3" />
      {f.percent(percent)}
    </span>
  );
}

export function GenreChip({ label, tone = "neutral" }: { label: string; tone?: "neutral" | "ai" | "rent" | "deal" }) {
  const tones = {
    neutral: "bg-secondary text-secondary-foreground/80",
    ai: "bg-ai/15 text-ai dark:text-[#c4b0f5]",
    rent: "bg-rent/15 text-rent dark:text-[#8aefbd]",
    deal: "bg-deal/15 text-deal",
  } as const;
  return <span className={cn("rounded-full px-2.5 py-0.5 text-[0.7rem] font-medium", tones[tone])}>{label}</span>;
}

export function IndieBadge({ className }: { className?: string }) {
  const t = useT();
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border border-border px-2 py-0.5 text-[0.68rem] font-semibold text-muted-foreground",
        className
      )}
      title={t("shared.indieTitle")}
    >
      <Sparkles className="size-3" />
      {t("shared.indie")}
    </span>
  );
}

/* ————— سربرگ بخش‌ها ————— */

export function SectionHeader({
  kicker,
  title,
  description,
  icon: Icon,
  tone = "brand",
  action,
}: {
  kicker?: string;
  title: ReactNode;
  description?: string;
  icon?: LucideIcon;
  tone?: "brand" | "ai" | "rent" | "deal";
  action?: { label: string; to: string };
}) {
  const toneText = { brand: "text-deal", ai: "text-ai", rent: "text-rent", deal: "text-deal" }[tone];
  const toneDot = { brand: "bg-deal", ai: "bg-ai", rent: "bg-rent", deal: "bg-deal" }[tone];
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        {kicker ? (
          <div className="mb-2 flex items-center gap-2">
            <span className={cn("size-1.5 rounded-full", toneDot)} />
            <span className={cn("text-xs font-bold tracking-wide", toneText)}>{kicker}</span>
          </div>
        ) : null}
        <h2 className="flex items-center gap-2.5 text-2xl font-extrabold md:text-3xl">
          {Icon ? <Icon className={cn("size-6", toneText)} /> : null}
          {title}
        </h2>
        {description ? <p className="mt-2 max-w-xl text-sm leading-7 text-muted-foreground">{description}</p> : null}
      </div>
      {action ? (
        <Link
          to={action.to}
          className="group inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-2 text-sm font-bold transition-colors hover:border-primary/40 hover:text-primary"
        >
          {action.label}
          <span className="transition-transform group-hover:-translate-x-0.5">←</span>
        </Link>
      ) : null}
    </div>
  );
}

/* ————— حالت خالی ————— */

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card/40 px-6 py-14 text-center"
    >
      <div className="mb-4 flex size-14 items-center justify-center rounded-2xl bg-secondary">
        <Icon className="size-7 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-bold">{title}</h3>
      <p className="mt-2 max-w-sm text-sm leading-7 text-muted-foreground">{description}</p>
      {action ? <div className="mt-5">{action}</div> : null}
    </motion.div>
  );
}

/* ————— شماره متحرک — فقط جایی که درک را بهتر می‌کند ————— */

export function AnimatedNumber({
  value,
  format,
  duration = 1.1,
  className,
}: {
  value: number;
  format?: (v: number) => string;
  duration?: number;
  className?: string;
}) {
  const f = useFmt();
  const fmt = format ?? ((v: number) => f.num(Math.round(v)));
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const reduced = useReducedMotion();
  const [fallbackInView, setFallbackInView] = useState(false);
  const [display, setDisplay] = useState(0);
  const prev = useRef(0);
  /* IO در برخی لودهای اولیه (بدون هیچ اسکرولی) آتش نمی‌زند — fallback مستقیم روی viewport */
  const visible = inView || fallbackInView;

  useEffect(() => {
    if (inView || reduced) return;
    const el = ref.current;
    if (!el) return;
    const id = setTimeout(() => {
      const r = el.getBoundingClientRect();
      if (r.top < window.innerHeight && r.bottom > 0) setFallbackInView(true);
    }, 600);
    return () => clearTimeout(id);
  }, [inView, reduced]);

  useEffect(() => {
    if (!visible || reduced) return;
    const from = prev.current;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / (duration * 1000));
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from + (value - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
      else prev.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [visible, value, duration, reduced]);

  /* با reduced-motion بدون انیمیشن و بدون setState مستقیم مقدار نهایی نمایش داده می‌شود */
  return (
    <span ref={ref} className={cn("tnum", className)}>
      {fmt(reduced ? value : display)}
    </span>
  );
}

/* ————— نوار پیشرفت XP ————— */

export function XPBar({
  value,
  max,
  tone = "brand",
  showNumbers = false,
  className,
}: {
  value: number;
  max: number;
  tone?: "brand" | "ai" | "rent";
  showNumbers?: boolean;
  className?: string;
}) {
  const f = useFmt();
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  const bg = { brand: "bg-gradient-to-l from-[#ff7a1a] to-deal", ai: "bg-gradient-to-l from-[#6d3ff0] to-ai", rent: "bg-gradient-to-l from-[#1fbf6d] to-rent" }[tone];
  return (
    <div className={className}>
      <div className="h-2.5 w-full overflow-hidden rounded-full bg-secondary" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        <motion.div
          className={cn("h-full rounded-full", bg)}
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
        />
      </div>
      {showNumbers ? (
        <div className="mt-1.5 flex justify-between text-[0.7rem] text-muted-foreground tnum">
          <span>{f.num(value)}</span>
          <span>{f.num(max)}</span>
        </div>
      ) : null}
    </div>
  );
}

/* ————— اسکلت کارت بازی ————— */

export function GameCardSkeleton() {
  return (
    <div className="overflow-hidden rounded-2xl border border-border bg-card">
      <div className="skeleton-shimmer aspect-[3/4] w-full" />
      <div className="space-y-2 p-4">
        <div className="skeleton-shimmer h-4 w-3/4 rounded" />
        <div className="skeleton-shimmer h-3 w-1/2 rounded" />
      </div>
    </div>
  );
}

/* ————— ورودی مرحله‌ای (Stagger) ————— */

export function StaggerContainer({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-60px" }}
      variants={{ hidden: {}, show: { transition: { staggerChildren: 0.07 } } }}
    >
      {children}
    </motion.div>
  );
}

export function StaggerItem({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <motion.div
      className={className}
      variants={{
        hidden: { opacity: 0, y: 18 },
        show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] } },
      }}
    >
      {children}
    </motion.div>
  );
}
