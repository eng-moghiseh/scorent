"use client";

/* ————— اعلان رویداد (ایمیل+پیامک همزمان) و صندوق خروجی ————— */

import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { Bell, Inbox, Megaphone, RefreshCw, Search, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { api } from "@/lib/auth";
import { useFmt, useT, useUiDir } from "@/lib/i18n";
import { AdminHeader, AdminError, StatusPill } from "./ui";
import { cn } from "@/lib/utils";

/* ————— ارسال اعلان ————— */

interface AnnouncementRow {
  id: string;
  title: string;
  body: string;
  kind: string;
  audience: string;
  channels: string;
  recipients: number;
  sentCount: number;
  failCount: number;
  createdAt: string;
}

const KINDS = ["EVENT", "UPDATE", "PROMO", "MAINTENANCE"] as const;
const AUDIENCES = ["USERS", "ADMINS", "ALL"] as const;

export function AdminAnnouncements() {
  const t = useT();
  const f = useFmt();
  const dir = useUiDir();

  const [titleFa, setTitleFa] = useState("");
  const [titleEn, setTitleEn] = useState("");
  const [bodyFa, setBodyFa] = useState("");
  const [bodyEn, setBodyEn] = useState("");
  const [kind, setKind] = useState<string>("EVENT");
  const [audience, setAudience] = useState<string>("USERS");
  const [emailCh, setEmailCh] = useState(true);
  const [smsCh, setSmsCh] = useState(true);
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState<AnnouncementRow[] | null>(null);
  const [err, setErr] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await api.get<{ ok: boolean; announcements: AnnouncementRow[] }>("/api/admin/announcements");
      setHistory(res.announcements);
    } catch {
      setErr(true);
    }
  }, []);

  useEffect(() => {
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [load]);

  async function send() {
    if (titleFa.trim().length < 3 || bodyFa.trim().length < 5 || (!emailCh && !smsCh)) {
      toast.error(t("admin.error"));
      return;
    }
    setBusy(true);
    try {
      const res = await api.post<{ ok: boolean; sent: number; failed: number }>("/api/admin/announcements", {
        titleFa: titleFa.trim(),
        titleEn: titleEn.trim() || titleFa.trim(),
        bodyFa: bodyFa.trim(),
        bodyEn: bodyEn.trim() || bodyFa.trim(),
        kind,
        audience,
        channels: [emailCh ? "EMAIL" : null, smsCh ? "SMS" : null].filter(Boolean),
      });
      toast.success(t("admin.announce.sent", { sent: f.num(res.sent), failed: f.num(res.failed) }));
      setTitleFa("");
      setTitleEn("");
      setBodyFa("");
      setBodyEn("");
      void load();
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "NO_CHANNEL" ? t("admin.error") : t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  if (err) return <AdminError />;

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.announce.compose")} description={t("admin.announce.composeDesc")} icon={Megaphone} />

      <section className="mb-6 rounded-3xl border border-border bg-card p-5" aria-label={t("admin.announce.compose")}>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-muted-foreground">{t("admin.announce.titleFa")}</Label>
            <Input value={titleFa} onChange={(e) => setTitleFa(e.target.value)} maxLength={120} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-muted-foreground">{t("admin.announce.titleEn")}</Label>
            <Input dir="ltr" className="text-start" value={titleEn} onChange={(e) => setTitleEn(e.target.value)} maxLength={120} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-muted-foreground">{t("admin.announce.bodyFa")}</Label>
            <Textarea rows={4} value={bodyFa} onChange={(e) => setBodyFa(e.target.value)} maxLength={2000} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-muted-foreground">{t("admin.announce.bodyEn")}</Label>
            <Textarea rows={4} dir="ltr" className="text-start" value={bodyEn} onChange={(e) => setBodyEn(e.target.value)} maxLength={2000} />
          </div>
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <div dir={dir} className="rounded-2xl border border-border bg-secondary/30 p-3">
            <p className="mb-1.5 text-[0.62rem] font-bold text-muted-foreground">{t("admin.announce.kind")}</p>
            <Select dir={dir} value={kind} onValueChange={setKind}>
              <SelectTrigger className="h-9 text-xs" aria-label={t("admin.announce.kind")}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {KINDS.map((k) => (
                  <SelectItem key={k} value={k}>{t(`admin.announce.kind.${k}`)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div dir={dir} className="rounded-2xl border border-border bg-secondary/30 p-3">
            <p className="mb-1.5 text-[0.62rem] font-bold text-muted-foreground">{t("admin.announce.audience")}</p>
            <Select dir={dir} value={audience} onValueChange={setAudience}>
              <SelectTrigger className="h-9 text-xs" aria-label={t("admin.announce.audience")}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {AUDIENCES.map((a) => (
                  <SelectItem key={a} value={a}>{t(`admin.announce.audience.${a}`)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="rounded-2xl border border-border bg-secondary/30 p-3">
            <p className="mb-1.5 text-[0.62rem] font-bold text-muted-foreground">{t("admin.announce.channels")}</p>
            <div className="flex gap-2">
              <label className="flex flex-1 items-center justify-between gap-2 rounded-xl border border-border bg-card px-3 py-2">
                <span className="text-xs font-bold">{t("admin.announce.channel.EMAIL")}</span>
                <Switch checked={emailCh} onCheckedChange={setEmailCh} aria-label={t("admin.announce.channel.EMAIL")} />
              </label>
              <label className="flex flex-1 items-center justify-between gap-2 rounded-xl border border-border bg-card px-3 py-2">
                <span className="text-xs font-bold">{t("admin.announce.channel.SMS")}</span>
                <Switch checked={smsCh} onCheckedChange={setSmsCh} aria-label={t("admin.announce.channel.SMS")} />
              </label>
            </div>
          </div>
        </div>

        <div className="mt-4 flex justify-end">
          <Button onClick={send} disabled={busy} className="gap-2 bg-ai text-white hover:bg-ai/90">
            <Send className="size-4" /> {busy ? "…" : t("admin.announce.send")}
          </Button>
        </div>
      </section>

      <section className="rounded-3xl border border-border bg-card p-5" aria-label={t("admin.announce.history")}>
        <h2 className="mb-3 flex items-center gap-2 text-base font-extrabold">
          <Bell className="size-5 text-deal" /> {t("admin.announce.history")}
        </h2>
        {history === null ? (
          <div className="space-y-2">{Array.from({ length: 2 }).map((_, i) => <div key={i} className="h-12 animate-pulse rounded-xl bg-secondary/40" />)}</div>
        ) : history.length === 0 ? (
          <p className="py-8 text-center text-xs text-muted-foreground">{t("admin.announce.none")}</p>
        ) : (
          <ul className="space-y-2.5">
            {history.map((a) => {
              let channels: string[] = [];
              try {
                channels = JSON.parse(a.channels) as string[];
              } catch {
                /* ignore */
              }
              return (
                <li key={a.id} className="rounded-2xl border border-border bg-secondary/30 p-3.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm font-extrabold">{a.title}</p>
                    <p className="text-[0.65rem] font-bold text-muted-foreground tnum">
                      {t("admin.announce.recipients")}: {f.num(a.recipients)} · ✓{f.num(a.sentCount)} · ✕{f.num(a.failCount)}
                    </p>
                  </div>
                  <p className="mt-1 line-clamp-2 text-[0.68rem] leading-6 text-muted-foreground">{a.body}</p>
                  <p className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[0.6rem] text-muted-foreground">
                    <span className="rounded-full bg-ai/15 px-2 py-0.5 font-bold text-ai">{t(`admin.announce.kind.${a.kind}`)}</span>
                    <span className="rounded-full bg-secondary px-2 py-0.5 font-bold">{t(`admin.announce.audience.${a.audience}`)}</span>
                    {channels.map((c) => (
                      <span key={c} className="rounded-full bg-secondary px-2 py-0.5 font-bold">{t(`admin.announce.channel.${c}`)}</span>
                    ))}
                    <span className="tnum">{f.dateTime(new Date(a.createdAt).getTime())}</span>
                  </p>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}

/* ————— صندوق خروجی ————— */

interface NotificationRow {
  id: string;
  channel: string;
  recipient: string;
  subject: string | null;
  body: string;
  kind: string;
  status: string;
  provider: string | null;
  error: string | null;
  createdAt: string;
}

export function AdminOutbox() {
  const t = useT();
  const f = useFmt();
  const dir = useUiDir();
  const [rows, setRows] = useState<NotificationRow[] | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("all");
  const [channel, setChannel] = useState("all");
  const [q, setQ] = useState("");
  const [err, setErr] = useState(false);

  const load = useCallback(async () => {
    setRows(null);
    try {
      const params = new URLSearchParams({ page: String(page) });
      if (status !== "all") params.set("status", status);
      if (channel !== "all") params.set("channel", channel);
      if (q.trim()) params.set("q", q.trim());
      const res = await api.get<{ ok: boolean; notifications: NotificationRow[]; total: number }>(`/api/admin/notifications?${params.toString()}`);
      setRows(res.notifications);
      setTotal(res.total);
    } catch {
      setErr(true);
    }
  }, [page, status, channel, q]);

  useEffect(() => {
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [load]);

  async function retry(id: string) {
    try {
      await api.post(`/api/admin/notifications/${id}/retry`);
      toast.success(t("admin.outbox.retried"));
      void load();
    } catch {
      toast.error(t("admin.error"));
    }
  }

  if (err) return <AdminError />;
  const pages = Math.max(1, Math.ceil(total / 20));

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.outbox.title")} description={t("admin.outbox.desc")} icon={Inbox} />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative min-w-48 flex-1">
          <Search className="absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder={t("admin.search")} className="ps-9" />
        </div>
        <Select dir={dir} value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger className="w-40" aria-label={t("admin.outbox.filterStatus")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.users.all")}</SelectItem>
            {["SENT", "SIMULATED", "FAILED", "QUEUED"].map((s) => (
              <SelectItem key={s} value={s}>{t(`admin.outbox.status.${s}`)}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select dir={dir} value={channel} onValueChange={(v) => { setChannel(v); setPage(1); }}>
          <SelectTrigger className="w-36" aria-label={t("admin.outbox.filterChannel")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.users.all")}</SelectItem>
            <SelectItem value="EMAIL">{t("admin.announce.channel.EMAIL")}</SelectItem>
            <SelectItem value="SMS">{t("admin.announce.channel.SMS")}</SelectItem>
          </SelectContent>
        </Select>
        <Button size="icon" variant="outline" className="size-9" onClick={() => void load()} aria-label="refresh">
          <RefreshCw className="size-4" />
        </Button>
      </div>

      {rows === null ? (
        <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-14 animate-pulse rounded-2xl border border-border bg-card" />)}</div>
      ) : rows.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">{t("admin.outbox.empty")}</p>
      ) : (
        <div className="space-y-2.5">
          {rows.map((n) => (
            <div key={n.id} className={cn("rounded-2xl border bg-card p-3.5", n.status === "FAILED" ? "border-destructive/40" : "border-border")}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex min-w-0 items-center gap-2">
                  <span className={cn("flex size-7 shrink-0 items-center justify-center rounded-lg text-[0.6rem] font-black", n.channel === "EMAIL" ? "bg-ai/15 text-ai" : "bg-rent/15 text-rent")}>
                    {n.channel === "EMAIL" ? "✉" : "≡"}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-xs font-extrabold">{n.subject ?? n.body.slice(0, 60)}</p>
                    <p dir="ltr" className="truncate text-start text-[0.62rem] text-muted-foreground tnum">{n.recipient}</p>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[0.6rem] font-bold text-muted-foreground">{t(`admin.outbox.kind.${n.kind}`)}</span>
                  <StatusPill status={n.status} />
                  {n.status === "FAILED" && (
                    <Button size="sm" variant="outline" className="h-7 text-[0.62rem]" onClick={() => retry(n.id)}>
                      {t("admin.outbox.retry")}
                    </Button>
                  )}
                </div>
              </div>
              <p className="mt-2 line-clamp-2 text-[0.66rem] leading-6 text-muted-foreground">{n.body}</p>
              <p className="mt-1 text-[0.6rem] text-muted-foreground tnum">
                {f.dateTime(new Date(n.createdAt).getTime())}
                {n.provider ? ` · ${n.provider}` : ""}
                {n.error ? ` · ${n.error.slice(0, 80)}` : ""}
              </p>
            </div>
          ))}
          {pages > 1 && (
            <div className="flex items-center justify-center gap-3 pt-2">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>‹</Button>
              <span className="text-xs font-bold text-muted-foreground tnum">{t("admin.page", { n: f.num(page), total: f.num(pages) })}</span>
              <Button size="sm" variant="outline" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>›</Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
