/* ————— سنجش قدرت رمز (مشترک بین کلاینت و سرور — بدون وابستگی node) ————— */

/** قدرت رمز: 0..3 (خیلی ضعیف تا عالی) — برای نمایش سنجاق قدرت در UI */
export function passwordStrength(pw: string): 0 | 1 | 2 | 3 {
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
  if (/\d/.test(pw) && /[^a-zA-Z0-9]/.test(pw)) score++;
  return Math.min(3, score) as 0 | 1 | 2 | 3;
}
